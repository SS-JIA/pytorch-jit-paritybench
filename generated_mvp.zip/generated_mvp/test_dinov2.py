import sys
_module = sys.modules[__name__]
del sys
configs = _module
datasets = _module
decoders = _module
extended = _module
image_net = _module
image_net_22k = _module
data = _module
adapters = _module
augmentations = _module
collate = _module
loaders = _module
masking = _module
samplers = _module
transforms = _module
distributed = _module
eval = _module
knn = _module
linear = _module
log_regression = _module
metrics = _module
setup = _module
utils = _module
fsdp = _module
layers = _module
attention = _module
block = _module
dino_head = _module
drop_path = _module
layer_scale = _module
mlp = _module
patch_embed = _module
swiglu_ffn = _module
logging = _module
helpers = _module
loss = _module
dino_clstoken_loss = _module
ibot_patch_loss = _module
koleo_loss = _module
models = _module
vision_transformer = _module
train = _module
run = _module
submit = _module
ssl_meta_arch = _module
train = _module
cluster = _module
config = _module
dtype = _module
param_groups = _module
utils = _module
dinov2 = _module
hubconf = _module

from _paritybench_helpers import _mock_config, patch_functional
from unittest.mock import mock_open, MagicMock
from torch.autograd import Function
from torch.nn import Module
import abc, collections, copy, enum, functools, inspect, itertools, logging, math, matplotlib, numbers, numpy, pandas, queue, random, re, scipy, sklearn, string, tensorflow, time, torch, torchaudio, torchtext, torchvision, types, typing, uuid, warnings
import operator as op
from dataclasses import dataclass
import numpy as np
from torch import Tensor
patch_functional()
open = mock_open()
yaml = logging = sys = argparse = MagicMock()
ArgumentParser = argparse.ArgumentParser
_global_config = args = argv = cfg = config = params = _mock_config()
argparse.ArgumentParser.return_value.parse_args.return_value = _global_config
yaml.load.return_value = _global_config
sys.argv = _global_config
__version__ = '1.0.0'
xrange = range
wraps = functools.wraps


from typing import Any


from typing import Tuple


from torch.utils.data import Dataset


import torch


import random


import logging


from enum import Enum


from typing import Callable


from typing import List


from typing import Optional


from typing import TypeVar


from torch.utils.data import Sampler


import itertools


import warnings


import numpy as np


from torch.utils.data.sampler import Sampler


from typing import Sequence


from torchvision import transforms


import re


from typing import Dict


import torch.distributed as dist


from functools import partial


from torch.nn.functional import one_hot


from torch.nn.functional import softmax


import torch.nn as nn


from torch.nn.parallel import DistributedDataParallel


import time


import torch.backends.cudnn as cudnn


import torch.distributed


from torch import nn


from torch.utils.data import TensorDataset


from torch import Tensor


from torch.distributed.fsdp import FullyShardedDataParallel as FSDP


from torch.distributed.fsdp import ShardingStrategy


from torch.distributed.fsdp import MixedPrecision


from torch.distributed.fsdp import StateDictType


from torch.distributed.fsdp.sharded_grad_scaler import ShardedGradScaler


from torch.distributed.fsdp.wrap import ModuleWrapPolicy


from torch.distributed.fsdp._runtime_utils import _reshard


from torch.nn.init import trunc_normal_


from torch.nn.utils import weight_norm


from typing import Union


import torch.nn.functional as F


from collections import defaultdict


from collections import deque


import math


import torch.utils.checkpoint


class KnnModule(torch.nn.Module):
    """
    Gets knn of test features from all processes on a chunk of the train features

    Each rank gets a chunk of the train features as well as a chunk of the test features.
    In `compute_neighbors`, for each rank one after the other, its chunk of test features
    is sent to all devices, partial knns are computed with each chunk of train features
    then collated back on the original device.
    """

    def __init__(self, train_features, train_labels, nb_knn, T, device, num_classes=1000):
        super().__init__()
        self.global_rank = distributed.get_global_rank()
        self.global_size = distributed.get_global_size()
        self.device = device
        self.train_features_rank_T = train_features.chunk(self.global_size)[self.global_rank].T
        self.candidates = train_labels.chunk(self.global_size)[self.global_rank].view(1, -1)
        self.nb_knn = nb_knn
        self.max_k = max(self.nb_knn)
        self.T = T
        self.num_classes = num_classes

    def _get_knn_sims_and_labels(self, similarity, train_labels):
        topk_sims, indices = similarity.topk(self.max_k, largest=True, sorted=True)
        neighbors_labels = torch.gather(train_labels, 1, indices)
        return topk_sims, neighbors_labels

    def _similarity_for_rank(self, features_rank, source_rank):
        broadcast_shape = torch.tensor(features_rank.shape)
        torch.distributed.broadcast(broadcast_shape, source_rank)
        broadcasted = features_rank
        if self.global_rank != source_rank:
            broadcasted = torch.zeros(*broadcast_shape, dtype=features_rank.dtype, device=self.device)
        torch.distributed.broadcast(broadcasted, source_rank)
        similarity_rank = torch.mm(broadcasted, self.train_features_rank_T)
        candidate_labels = self.candidates.expand(len(similarity_rank), -1)
        return self._get_knn_sims_and_labels(similarity_rank, candidate_labels)

    def _gather_all_knn_for_rank(self, topk_sims, neighbors_labels, target_rank):
        topk_sims_rank = retrieved_rank = None
        if self.global_rank == target_rank:
            topk_sims_rank = [torch.zeros_like(topk_sims) for _ in range(self.global_size)]
            retrieved_rank = [torch.zeros_like(neighbors_labels) for _ in range(self.global_size)]
        torch.distributed.gather(topk_sims, topk_sims_rank, dst=target_rank)
        torch.distributed.gather(neighbors_labels, retrieved_rank, dst=target_rank)
        if self.global_rank == target_rank:
            topk_sims_rank = torch.cat(topk_sims_rank, dim=1)
            retrieved_rank = torch.cat(retrieved_rank, dim=1)
            results = self._get_knn_sims_and_labels(topk_sims_rank, retrieved_rank)
            return results
        return None

    def compute_neighbors(self, features_rank):
        for rank in range(self.global_size):
            topk_sims, neighbors_labels = self._similarity_for_rank(features_rank, rank)
            results = self._gather_all_knn_for_rank(topk_sims, neighbors_labels, rank)
            if results is not None:
                topk_sims_rank, neighbors_labels_rank = results
        return topk_sims_rank, neighbors_labels_rank

    def forward(self, features_rank):
        """
        Compute the results on all values of `self.nb_knn` neighbors from the full `self.max_k`
        """
        assert all(k <= self.max_k for k in self.nb_knn)
        topk_sims, neighbors_labels = self.compute_neighbors(features_rank)
        batch_size = neighbors_labels.shape[0]
        topk_sims_transform = softmax(topk_sims / self.T, 1)
        matmul = torch.mul(one_hot(neighbors_labels, num_classes=self.num_classes), topk_sims_transform.view(batch_size, -1, 1))
        probas_for_k = {k: torch.sum(matmul[:, :k, :], 1) for k in self.nb_knn}
        return probas_for_k


class DictKeysModule(torch.nn.Module):

    def __init__(self, keys):
        super().__init__()
        self.keys = keys

    def forward(self, features_dict, targets):
        for k in self.keys:
            features_dict = features_dict[k]
        return {'preds': features_dict, 'target': targets}


class ModuleDictWithForward(torch.nn.ModuleDict):

    def forward(self, *args, **kwargs):
        return {k: module(*args, **kwargs) for k, module in self._modules.items()}


def create_linear_input(x_tokens_list, use_n_blocks, use_avgpool):
    intermediate_output = x_tokens_list[-use_n_blocks:]
    output = torch.cat([class_token for _, class_token in intermediate_output], dim=-1)
    if use_avgpool:
        output = torch.cat((output, torch.mean(intermediate_output[-1][0], dim=1)), dim=-1)
        output = output.reshape(output.shape[0], -1)
    return output.float()


class LinearClassifier(nn.Module):
    """Linear layer to train on top of frozen features"""

    def __init__(self, out_dim, use_n_blocks, use_avgpool, num_classes=1000):
        super().__init__()
        self.out_dim = out_dim
        self.use_n_blocks = use_n_blocks
        self.use_avgpool = use_avgpool
        self.num_classes = num_classes
        self.linear = nn.Linear(out_dim, num_classes)
        self.linear.weight.data.normal_(mean=0.0, std=0.01)
        self.linear.bias.data.zero_()

    def forward(self, x_tokens_list):
        output = create_linear_input(x_tokens_list, self.use_n_blocks, self.use_avgpool)
        return self.linear(output)


class AllClassifiers(nn.Module):

    def __init__(self, classifiers_dict):
        super().__init__()
        self.classifiers_dict = nn.ModuleDict()
        self.classifiers_dict.update(classifiers_dict)

    def forward(self, inputs):
        return {k: v.forward(inputs) for k, v in self.classifiers_dict.items()}

    def __len__(self):
        return len(self.classifiers_dict)


class LinearPostprocessor(nn.Module):

    def __init__(self, linear_classifier, class_mapping=None):
        super().__init__()
        self.linear_classifier = linear_classifier
        self.register_buffer('class_mapping', None if class_mapping is None else torch.LongTensor(class_mapping))

    def forward(self, samples, targets):
        preds = self.linear_classifier(samples)
        return {'preds': preds[:, (self.class_mapping)] if self.class_mapping is not None else preds, 'target': targets}


DEFAULT_MAX_ITER = 1000


_CPU_DEVICE = torch.device('cpu')


class LogRegModule(nn.Module):

    def __init__(self, C, max_iter=DEFAULT_MAX_ITER, dtype=torch.float64, device=_CPU_DEVICE):
        super().__init__()
        self.dtype = dtype
        self.device = device
        self.estimator = LogisticRegression(penalty='l2', C=C, max_iter=max_iter, output_type='numpy', tol=1e-12, linesearch_max_iter=50)

    def forward(self, samples, targets):
        samples_device = samples.device
        samples = samples
        if self.device == _CPU_DEVICE:
            samples = samples.numpy()
        probas = self.estimator.predict_proba(samples)
        return {'preds': torch.from_numpy(probas), 'target': targets}

    def fit(self, train_features, train_labels):
        train_features = train_features
        train_labels = train_labels
        if self.device == _CPU_DEVICE:
            train_features = train_features.numpy()
            train_labels = train_labels.numpy()
        self.estimator.fit(train_features, train_labels)


class ModelWithNormalize(torch.nn.Module):

    def __init__(self, model):
        super().__init__()
        self.model = model

    def forward(self, samples):
        return nn.functional.normalize(self.model(samples), dim=1, p=2)


class ModelWithIntermediateLayers(nn.Module):

    def __init__(self, feature_model, n_last_blocks, autocast_ctx):
        super().__init__()
        self.feature_model = feature_model
        self.feature_model.eval()
        self.n_last_blocks = n_last_blocks
        self.autocast_ctx = autocast_ctx

    def forward(self, images):
        with torch.inference_mode():
            with self.autocast_ctx():
                features = self.feature_model.get_intermediate_layers(images, self.n_last_blocks, return_class_token=True)
        return features


class Attention(nn.Module):

    def __init__(self, dim: 'int\n', num_heads: 'int\n'=8, qkv_bias: 'bool\n'=False, proj_bias: 'bool\n'=True, attn_drop: 'float\n'=0.0, proj_drop: 'float\n'=0.0) ->None:
        super().__init__()
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = head_dim ** -0.5
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim, bias=proj_bias)
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, x: 'Tensor\n') ->Tensor:
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0] * self.scale, qkv[1], qkv[2]
        attn = q @ k.transpose(-2, -1)
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)
        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x


class MemEffAttention(Attention):

    def forward(self, x: 'Tensor\n', attn_bias=None) ->Tensor:
        if not XFORMERS_AVAILABLE:
            assert attn_bias is None, 'xFormers is required for nested tensors usage'
            return super().forward(x)
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads)
        q, k, v = unbind(qkv, 2)
        x = memory_efficient_attention(q, k, v, attn_bias=attn_bias)
        x = x.reshape([B, N, C])
        x = self.proj(x)
        x = self.proj_drop(x)
        return x


def drop_path(x, drop_prob: 'float\n'=0.0, training: 'bool\n'=False):
    if drop_prob == 0.0 or not training:
        return x
    keep_prob = 1 - drop_prob
    shape = (x.shape[0],) + (1,) * (x.ndim - 1)
    random_tensor = x.new_empty(shape).bernoulli_(keep_prob)
    if keep_prob > 0.0:
        random_tensor.div_(keep_prob)
    output = x * random_tensor
    return output


class DropPath(nn.Module):
    """Drop paths (Stochastic Depth) per sample (when applied in main path of residual blocks)."""

    def __init__(self, drop_prob=None):
        super(DropPath, self).__init__()
        self.drop_prob = drop_prob

    def forward(self, x):
        return drop_path(x, self.drop_prob, self.training)


class LayerScale(nn.Module):

    def __init__(self, dim: 'int\n', init_values: 'Union[(float, Tensor)]\n'=1e-05, inplace: 'bool\n'=False) ->None:
        super().__init__()
        self.inplace = inplace
        self.gamma = nn.Parameter(init_values * torch.ones(dim))

    def forward(self, x: 'Tensor\n') ->Tensor:
        return x.mul_(self.gamma) if self.inplace else x * self.gamma


class Mlp(nn.Module):

    def __init__(self, in_features: 'int\n', hidden_features: 'Optional[int]\n'=None, out_features: 'Optional[int]\n'=None, act_layer: 'Callable[(..., nn.Module)]\n'=nn.GELU, drop: 'float\n'=0.0, bias: 'bool\n'=True) ->None:
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Linear(in_features, hidden_features, bias=bias)
        self.act = act_layer()
        self.fc2 = nn.Linear(hidden_features, out_features, bias=bias)
        self.drop = nn.Dropout(drop)

    def forward(self, x: 'Tensor\n') ->Tensor:
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x


def drop_add_residual_stochastic_depth(x: 'Tensor\n', residual_func: 'Callable[([Tensor], Tensor)]\n', sample_drop_ratio: 'float\n'=0.0) ->Tensor:
    b, n, d = x.shape
    sample_subset_size = max(int(b * (1 - sample_drop_ratio)), 1)
    brange = torch.randperm(b, device=x.device)[:sample_subset_size]
    x_subset = x[brange]
    residual = residual_func(x_subset)
    x_flat = x.flatten(1)
    residual = residual.flatten(1)
    residual_scale_factor = b / sample_subset_size
    x_plus_residual = torch.index_add(x_flat, 0, brange, residual, alpha=residual_scale_factor)
    return x_plus_residual.view_as(x)


class Block(nn.Module):

    def __init__(self, dim: 'int\n', num_heads: 'int\n', mlp_ratio: 'float\n'=4.0, qkv_bias: 'bool\n'=False, proj_bias: 'bool\n'=True, ffn_bias: 'bool\n'=True, drop: 'float\n'=0.0, attn_drop: 'float\n'=0.0, init_values=None, drop_path: 'float\n'=0.0, act_layer: 'Callable[(..., nn.Module)]\n'=nn.GELU, norm_layer: 'Callable[(..., nn.Module)]\n'=nn.LayerNorm, attn_class: 'Callable[(..., nn.Module)]\n'=Attention, ffn_layer: 'Callable[(..., nn.Module)]\n'=Mlp) ->None:
        super().__init__()
        self.norm1 = norm_layer(dim)
        self.attn = attn_class(dim, num_heads=num_heads, qkv_bias=qkv_bias, proj_bias=proj_bias, attn_drop=attn_drop, proj_drop=drop)
        self.ls1 = LayerScale(dim, init_values=init_values) if init_values else nn.Identity()
        self.drop_path1 = DropPath(drop_path) if drop_path > 0.0 else nn.Identity()
        self.norm2 = norm_layer(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = ffn_layer(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop, bias=ffn_bias)
        self.ls2 = LayerScale(dim, init_values=init_values) if init_values else nn.Identity()
        self.drop_path2 = DropPath(drop_path) if drop_path > 0.0 else nn.Identity()
        self.sample_drop_ratio = drop_path

    def forward(self, x: 'Tensor\n') ->Tensor:

        def attn_residual_func(x: 'Tensor\n') ->Tensor:
            return self.ls1(self.attn(self.norm1(x)))

        def ffn_residual_func(x: 'Tensor\n') ->Tensor:
            return self.ls2(self.mlp(self.norm2(x)))
        if self.training and self.sample_drop_ratio > 0.1:
            x = drop_add_residual_stochastic_depth(x, residual_func=attn_residual_func, sample_drop_ratio=self.sample_drop_ratio)
            x = drop_add_residual_stochastic_depth(x, residual_func=ffn_residual_func, sample_drop_ratio=self.sample_drop_ratio)
        elif self.training and self.sample_drop_ratio > 0.0:
            x = x + self.drop_path1(attn_residual_func(x))
            x = x + self.drop_path1(ffn_residual_func(x))
        else:
            x = x + attn_residual_func(x)
            x = x + ffn_residual_func(x)
        return x


def add_residual(x, brange, residual, residual_scale_factor, scaling_vector=None):
    if scaling_vector is None:
        x_flat = x.flatten(1)
        residual = residual.flatten(1)
        x_plus_residual = torch.index_add(x_flat, 0, brange, residual, alpha=residual_scale_factor)
    else:
        x_plus_residual = scaled_index_add(x, brange, residual, scaling=scaling_vector, alpha=residual_scale_factor)
    return x_plus_residual


def get_attn_bias_and_cat(x_list, branges=None):
    """
    this will perform the index select, cat the tensors, and provide the attn_bias from cache
    """
    batch_sizes = [b.shape[0] for b in branges] if branges is not None else [x.shape[0] for x in x_list]
    all_shapes = tuple((b, x.shape[1]) for b, x in zip(batch_sizes, x_list))
    if all_shapes not in attn_bias_cache.keys():
        seqlens = []
        for b, x in zip(batch_sizes, x_list):
            for _ in range(b):
                seqlens.append(x.shape[1])
        attn_bias = fmha.BlockDiagonalMask.from_seqlens(seqlens)
        attn_bias._batch_sizes = batch_sizes
        attn_bias_cache[all_shapes] = attn_bias
    if branges is not None:
        cat_tensors = index_select_cat([x.flatten(1) for x in x_list], branges).view(1, -1, x_list[0].shape[-1])
    else:
        tensors_bs1 = tuple(x.reshape([1, -1, *x.shape[2:]]) for x in x_list)
        cat_tensors = torch.cat(tensors_bs1, dim=1)
    return attn_bias_cache[all_shapes], cat_tensors


def get_branges_scales(x, sample_drop_ratio=0.0):
    b, n, d = x.shape
    sample_subset_size = max(int(b * (1 - sample_drop_ratio)), 1)
    brange = torch.randperm(b, device=x.device)[:sample_subset_size]
    residual_scale_factor = b / sample_subset_size
    return brange, residual_scale_factor


def drop_add_residual_stochastic_depth_list(x_list: 'List[Tensor]\n', residual_func: 'Callable[([Tensor, Any], Tensor)]\n', sample_drop_ratio: 'float\n'=0.0, scaling_vector=None) ->Tensor:
    branges_scales = [get_branges_scales(x, sample_drop_ratio=sample_drop_ratio) for x in x_list]
    branges = [s[0] for s in branges_scales]
    residual_scale_factors = [s[1] for s in branges_scales]
    attn_bias, x_cat = get_attn_bias_and_cat(x_list, branges)
    residual_list = attn_bias.split(residual_func(x_cat, attn_bias=attn_bias))
    outputs = []
    for x, brange, residual, residual_scale_factor in zip(x_list, branges, residual_list, residual_scale_factors):
        outputs.append(add_residual(x, brange, residual, residual_scale_factor, scaling_vector).view_as(x))
    return outputs


class NestedTensorBlock(Block):

    def forward_nested(self, x_list: 'List[Tensor]\n') ->List[Tensor]:
        """
        x_list contains a list of tensors to nest together and run
        """
        assert isinstance(self.attn, MemEffAttention)
        if self.training and self.sample_drop_ratio > 0.0:

            def attn_residual_func(x: 'Tensor\n', attn_bias=None) ->Tensor:
                return self.attn(self.norm1(x), attn_bias=attn_bias)

            def ffn_residual_func(x: 'Tensor\n', attn_bias=None) ->Tensor:
                return self.mlp(self.norm2(x))
            x_list = drop_add_residual_stochastic_depth_list(x_list, residual_func=attn_residual_func, sample_drop_ratio=self.sample_drop_ratio, scaling_vector=self.ls1.gamma if isinstance(self.ls1, LayerScale) else None)
            x_list = drop_add_residual_stochastic_depth_list(x_list, residual_func=ffn_residual_func, sample_drop_ratio=self.sample_drop_ratio, scaling_vector=self.ls2.gamma if isinstance(self.ls1, LayerScale) else None)
            return x_list
        else:

            def attn_residual_func(x: 'Tensor\n', attn_bias=None) ->Tensor:
                return self.ls1(self.attn(self.norm1(x), attn_bias=attn_bias))

            def ffn_residual_func(x: 'Tensor\n', attn_bias=None) ->Tensor:
                return self.ls2(self.mlp(self.norm2(x)))
            attn_bias, x = get_attn_bias_and_cat(x_list)
            x = x + attn_residual_func(x, attn_bias=attn_bias)
            x = x + ffn_residual_func(x)
            return attn_bias.split(x)

    def forward(self, x_or_x_list):
        if isinstance(x_or_x_list, Tensor):
            return super().forward(x_or_x_list)
        elif isinstance(x_or_x_list, list):
            assert XFORMERS_AVAILABLE, 'Please install xFormers for nested tensors usage'
            return self.forward_nested(x_or_x_list)
        else:
            raise AssertionError


def _build_mlp(nlayers, in_dim, bottleneck_dim, hidden_dim=None, use_bn=False, bias=True):
    if nlayers == 1:
        return nn.Linear(in_dim, bottleneck_dim, bias=bias)
    else:
        layers = [nn.Linear(in_dim, hidden_dim, bias=bias)]
        if use_bn:
            layers.append(nn.BatchNorm1d(hidden_dim))
        layers.append(nn.GELU())
        for _ in range(nlayers - 2):
            layers.append(nn.Linear(hidden_dim, hidden_dim, bias=bias))
            if use_bn:
                layers.append(nn.BatchNorm1d(hidden_dim))
            layers.append(nn.GELU())
        layers.append(nn.Linear(hidden_dim, bottleneck_dim, bias=bias))
        return nn.Sequential(*layers)


class DINOHead(nn.Module):

    def __init__(self, in_dim, out_dim, use_bn=False, nlayers=3, hidden_dim=2048, bottleneck_dim=256, mlp_bias=True):
        super().__init__()
        nlayers = max(nlayers, 1)
        self.mlp = _build_mlp(nlayers, in_dim, bottleneck_dim, hidden_dim=hidden_dim, use_bn=use_bn, bias=mlp_bias)
        self.apply(self._init_weights)
        self.last_layer = weight_norm(nn.Linear(bottleneck_dim, out_dim, bias=False))
        self.last_layer.weight_g.data.fill_(1)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=0.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)

    def forward(self, x):
        x = self.mlp(x)
        eps = 1e-06 if x.dtype == torch.float16 else 1e-12
        x = nn.functional.normalize(x, dim=-1, p=2, eps=eps)
        x = self.last_layer(x)
        return x


def make_2tuple(x):
    if isinstance(x, tuple):
        assert len(x) == 2
        return x
    assert isinstance(x, int)
    return x, x


class PatchEmbed(nn.Module):
    """
    2D image to patch embedding: (B,C,H,W) -> (B,N,D)

    Args:
        img_size: Image size.
        patch_size: Patch token size.
        in_chans: Number of input image channels.
        embed_dim: Number of linear projection output channels.
        norm_layer: Normalization layer.
    """

    def __init__(self, img_size: 'Union[(int, Tuple[(int, int)])]\n'=224, patch_size: 'Union[(int, Tuple[(int, int)])]\n'=16, in_chans: 'int\n'=3, embed_dim: 'int\n'=768, norm_layer: 'Optional[Callable]\n'=None, flatten_embedding: 'bool\n'=True) ->None:
        super().__init__()
        image_HW = make_2tuple(img_size)
        patch_HW = make_2tuple(patch_size)
        patch_grid_size = image_HW[0] // patch_HW[0], image_HW[1] // patch_HW[1]
        self.img_size = image_HW
        self.patch_size = patch_HW
        self.patches_resolution = patch_grid_size
        self.num_patches = patch_grid_size[0] * patch_grid_size[1]
        self.in_chans = in_chans
        self.embed_dim = embed_dim
        self.flatten_embedding = flatten_embedding
        self.proj = nn.Conv2d(in_chans, embed_dim, kernel_size=patch_HW, stride=patch_HW)
        self.norm = norm_layer(embed_dim) if norm_layer else nn.Identity()

    def forward(self, x: 'Tensor\n') ->Tensor:
        _, _, H, W = x.shape
        patch_H, patch_W = self.patch_size
        assert H % patch_H == 0, f'Input image height {H} is not a multiple of patch height {patch_H}'
        assert W % patch_W == 0, f'Input image width {W} is not a multiple of patch width: {patch_W}'
        x = self.proj(x)
        H, W = x.size(2), x.size(3)
        x = x.flatten(2).transpose(1, 2)
        x = self.norm(x)
        if not self.flatten_embedding:
            x = x.reshape(-1, H, W, self.embed_dim)
        return x

    def flops(self) ->float:
        Ho, Wo = self.patches_resolution
        flops = Ho * Wo * self.embed_dim * self.in_chans * (self.patch_size[0] * self.patch_size[1])
        if self.norm is not None:
            flops += Ho * Wo * self.embed_dim
        return flops


class SwiGLUFFN(nn.Module):

    def __init__(self, in_features: 'int\n', hidden_features: 'Optional[int]\n'=None, out_features: 'Optional[int]\n'=None, act_layer: 'Callable[(..., nn.Module)]\n'=None, drop: 'float\n'=0.0, bias: 'bool\n'=True) ->None:
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.w12 = nn.Linear(in_features, 2 * hidden_features, bias=bias)
        self.w3 = nn.Linear(hidden_features, out_features, bias=bias)

    def forward(self, x: 'Tensor\n') ->Tensor:
        x12 = self.w12(x)
        x1, x2 = x12.chunk(2, dim=-1)
        hidden = F.silu(x1) * x2
        return self.w3(hidden)


class DINOLoss(nn.Module):

    def __init__(self, out_dim, student_temp=0.1, center_momentum=0.9):
        super().__init__()
        self.student_temp = student_temp
        self.center_momentum = center_momentum
        self.register_buffer('center', torch.zeros(1, out_dim))
        self.updated = True
        self.reduce_handle = None
        self.len_teacher_output = None
        self.async_batch_center = None

    @torch.no_grad()
    def softmax_center_teacher(self, teacher_output, teacher_temp):
        self.apply_center_update()
        return F.softmax((teacher_output - self.center) / teacher_temp, dim=-1)

    @torch.no_grad()
    def sinkhorn_knopp_teacher(self, teacher_output, teacher_temp, n_iterations=3):
        teacher_output = teacher_output.float()
        world_size = dist.get_world_size() if dist.is_initialized() else 1
        Q = torch.exp(teacher_output / teacher_temp).t()
        B = Q.shape[1] * world_size
        K = Q.shape[0]
        sum_Q = torch.sum(Q)
        if dist.is_initialized():
            dist.all_reduce(sum_Q)
        Q /= sum_Q
        for it in range(n_iterations):
            sum_of_rows = torch.sum(Q, dim=1, keepdim=True)
            if dist.is_initialized():
                dist.all_reduce(sum_of_rows)
            Q /= sum_of_rows
            Q /= K
            Q /= torch.sum(Q, dim=0, keepdim=True)
            Q /= B
        Q *= B
        return Q.t()

    def forward(self, student_output_list, teacher_out_softmaxed_centered_list):
        """
        Cross-entropy between softmax outputs of the teacher and student networks.
        """
        total_loss = 0
        for s in student_output_list:
            lsm = F.log_softmax(s / self.student_temp, dim=-1)
            for t in teacher_out_softmaxed_centered_list:
                loss = torch.sum(t * lsm, dim=-1)
                total_loss -= loss.mean()
        return total_loss

    @torch.no_grad()
    def update_center(self, teacher_output):
        self.reduce_center_update(teacher_output)

    @torch.no_grad()
    def reduce_center_update(self, teacher_output):
        self.updated = False
        self.len_teacher_output = len(teacher_output)
        self.async_batch_center = torch.sum(teacher_output, dim=0, keepdim=True)
        if dist.is_initialized():
            self.reduce_handle = dist.all_reduce(self.async_batch_center, async_op=True)

    @torch.no_grad()
    def apply_center_update(self):
        if self.updated is False:
            world_size = dist.get_world_size() if dist.is_initialized() else 1
            if self.reduce_handle is not None:
                self.reduce_handle.wait()
            _t = self.async_batch_center / (self.len_teacher_output * world_size)
            self.center = self.center * self.center_momentum + _t * (1 - self.center_momentum)
            self.updated = True


class iBOTPatchLoss(nn.Module):

    def __init__(self, patch_out_dim, student_temp=0.1, center_momentum=0.9):
        super().__init__()
        self.student_temp = student_temp
        self.center_momentum = center_momentum
        self.register_buffer('center', torch.zeros(1, 1, patch_out_dim))
        self.updated = True
        self.reduce_handle = None
        self.len_teacher_patch_tokens = None
        self.async_batch_center = None

    @torch.no_grad()
    def softmax_center_teacher(self, teacher_patch_tokens, teacher_temp):
        self.apply_center_update()
        return F.softmax((teacher_patch_tokens - self.center) / teacher_temp, dim=-1)

    @torch.no_grad()
    def sinkhorn_knopp_teacher(self, teacher_output, teacher_temp, n_masked_patches_tensor, n_iterations=3):
        teacher_output = teacher_output.float()
        Q = torch.exp(teacher_output / teacher_temp).t()
        B = n_masked_patches_tensor
        dist.all_reduce(B)
        K = Q.shape[0]
        sum_Q = torch.sum(Q)
        if dist.is_initialized():
            dist.all_reduce(sum_Q)
        Q /= sum_Q
        for it in range(n_iterations):
            sum_of_rows = torch.sum(Q, dim=1, keepdim=True)
            if dist.is_initialized():
                dist.all_reduce(sum_of_rows)
            Q /= sum_of_rows
            Q /= K
            Q /= torch.sum(Q, dim=0, keepdim=True)
            Q /= B
        Q *= B
        return Q.t()

    def forward(self, student_patch_tokens, teacher_patch_tokens, student_masks_flat):
        """
        Cross-entropy between softmax outputs of the teacher and student networks.
        student_patch_tokens: (B, N, D) tensor
        teacher_patch_tokens: (B, N, D) tensor
        student_masks_flat: (B, N) tensor
        """
        t = teacher_patch_tokens
        s = student_patch_tokens
        loss = torch.sum(t * F.log_softmax(s / self.student_temp, dim=-1), dim=-1)
        loss = torch.sum(loss * student_masks_flat.float(), dim=-1) / student_masks_flat.sum(dim=-1).clamp(min=1.0)
        return -loss.mean()

    def forward_masked(self, student_patch_tokens_masked, teacher_patch_tokens_masked, student_masks_flat, n_masked_patches=None, masks_weight=None):
        t = teacher_patch_tokens_masked
        s = student_patch_tokens_masked
        loss = lossfunc(t, s, self.student_temp)
        if masks_weight is None:
            masks_weight = (1 / student_masks_flat.sum(-1).clamp(min=1.0)).unsqueeze(-1).expand_as(student_masks_flat)[student_masks_flat]
        if n_masked_patches is not None:
            loss = loss[:n_masked_patches]
        loss = loss * masks_weight
        return -loss.sum() / student_masks_flat.shape[0]

    @torch.no_grad()
    def update_center(self, teacher_patch_tokens):
        self.reduce_center_update(teacher_patch_tokens)

    @torch.no_grad()
    def reduce_center_update(self, teacher_patch_tokens):
        self.updated = False
        self.len_teacher_patch_tokens = len(teacher_patch_tokens)
        self.async_batch_center = torch.sum(teacher_patch_tokens.mean(1), dim=0, keepdim=True)
        if dist.is_initialized():
            self.reduce_handle = dist.all_reduce(self.async_batch_center, async_op=True)

    @torch.no_grad()
    def apply_center_update(self):
        if self.updated is False:
            world_size = dist.get_world_size() if dist.is_initialized() else 1
            if self.reduce_handle is not None:
                self.reduce_handle.wait()
            _t = self.async_batch_center / (self.len_teacher_patch_tokens * world_size)
            self.center = self.center * self.center_momentum + _t * (1 - self.center_momentum)
            self.updated = True


class KoLeoLoss(nn.Module):
    """Kozachenko-Leonenko entropic loss regularizer from Sablayrolles et al. - 2018 - Spreading vectors for similarity search"""

    def __init__(self):
        super().__init__()
        self.pdist = nn.PairwiseDistance(2, eps=1e-08)

    def pairwise_NNs_inner(self, x):
        """
        Pairwise nearest neighbors for L2-normalized vectors.
        Uses Torch rather than Faiss to remain on GPU.
        """
        dots = torch.mm(x, x.t())
        n = x.shape[0]
        dots.view(-1)[::n + 1].fill_(-1)
        _, I = torch.max(dots, dim=1)
        return I

    def forward(self, student_output, eps=1e-08):
        """
        Args:
            student_output (BxD): backbone output of student
        """
        with torch.amp.autocast(enabled=False):
            student_output = F.normalize(student_output, eps=eps, p=2, dim=-1)
            I = self.pairwise_NNs_inner(student_output)
            distances = self.pdist(student_output, student_output[I])
            loss = -torch.log(distances + eps).mean()
        return loss


class BlockChunk(nn.ModuleList):

    def forward(self, x):
        for b in self:
            x = b(x)
        return x


def init_weights_vit_timm(module: 'nn.Module\n', name: 'str\n'=''):
    """ViT weight initialization, original timm impl (for reproducibility)"""
    if isinstance(module, nn.Linear):
        trunc_normal_(module.weight, std=0.02)
        if module.bias is not None:
            nn.init.zeros_(module.bias)


logger = logging.getLogger('dinov2')


def named_apply(fn: 'Callable\n', module: 'nn.Module\n', name='', depth_first=True, include_root=False) ->nn.Module:
    if not depth_first and include_root:
        fn(module=module, name=name)
    for child_name, child_module in module.named_children():
        child_name = '.'.join((name, child_name)) if name else child_name
        named_apply(fn=fn, module=child_module, name=child_name, depth_first=depth_first, include_root=True)
    if depth_first and include_root:
        fn(module=module, name=name)
    return module


class DinoVisionTransformer(nn.Module):

    def __init__(self, img_size=224, patch_size=16, in_chans=3, embed_dim=768, depth=12, num_heads=12, mlp_ratio=4.0, qkv_bias=True, ffn_bias=True, proj_bias=True, drop_path_rate=0.0, drop_path_uniform=False, init_values=None, embed_layer=PatchEmbed, act_layer=nn.GELU, block_fn=Block, ffn_layer='mlp', block_chunks=1):
        """
        Args:
            img_size (int, tuple): input image size
            patch_size (int, tuple): patch size
            in_chans (int): number of input channels
            embed_dim (int): embedding dimension
            depth (int): depth of transformer
            num_heads (int): number of attention heads
            mlp_ratio (int): ratio of mlp hidden dim to embedding dim
            qkv_bias (bool): enable bias for qkv if True
            proj_bias (bool): enable bias for proj in attn if True
            ffn_bias (bool): enable bias for ffn if True
            drop_path_rate (float): stochastic depth rate
            drop_path_uniform (bool): apply uniform drop rate across blocks
            weight_init (str): weight init scheme
            init_values (float): layer-scale init values
            embed_layer (nn.Module): patch embedding layer
            act_layer (nn.Module): MLP activation layer
            block_fn (nn.Module): transformer block class
            ffn_layer (str): "mlp", "swiglu", "swiglufused" or "identity"
            block_chunks: (int) split block sequence into block_chunks units for FSDP wrap
        """
        super().__init__()
        norm_layer = partial(nn.LayerNorm, eps=1e-06)
        self.num_features = self.embed_dim = embed_dim
        self.num_tokens = 1
        self.n_blocks = depth
        self.num_heads = num_heads
        self.patch_size = patch_size
        self.patch_embed = embed_layer(img_size=img_size, patch_size=patch_size, in_chans=in_chans, embed_dim=embed_dim)
        num_patches = self.patch_embed.num_patches
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.pos_embed = nn.Parameter(torch.zeros(1, num_patches + self.num_tokens, embed_dim))
        if drop_path_uniform is True:
            dpr = [drop_path_rate] * depth
        else:
            dpr = [x.item() for x in torch.linspace(0, drop_path_rate, depth)]
        if ffn_layer == 'mlp':
            logger.info('using MLP layer as FFN')
            ffn_layer = Mlp
        elif ffn_layer == 'swiglufused' or ffn_layer == 'swiglu':
            logger.info('using SwiGLU layer as FFN')
            ffn_layer = SwiGLUFFNFused
        elif ffn_layer == 'identity':
            logger.info('using Identity layer as FFN')

            def f(*args, **kwargs):
                return nn.Identity()
            ffn_layer = f
        else:
            raise NotImplementedError
        blocks_list = [block_fn(dim=embed_dim, num_heads=num_heads, mlp_ratio=mlp_ratio, qkv_bias=qkv_bias, proj_bias=proj_bias, ffn_bias=ffn_bias, drop_path=dpr[i], norm_layer=norm_layer, act_layer=act_layer, ffn_layer=ffn_layer, init_values=init_values) for i in range(depth)]
        if block_chunks > 0:
            self.chunked_blocks = True
            chunked_blocks = []
            chunksize = depth // block_chunks
            for i in range(0, depth, chunksize):
                chunked_blocks.append([nn.Identity()] * i + blocks_list[i:i + chunksize])
            self.blocks = nn.ModuleList([BlockChunk(p) for p in chunked_blocks])
        else:
            self.chunked_blocks = False
            self.blocks = nn.ModuleList(blocks_list)
        self.norm = norm_layer(embed_dim)
        self.head = nn.Identity()
        self.mask_token = nn.Parameter(torch.zeros(1, embed_dim))
        self.init_weights()

    def init_weights(self):
        trunc_normal_(self.pos_embed, std=0.02)
        nn.init.normal_(self.cls_token, std=1e-06)
        named_apply(init_weights_vit_timm, self)

    def interpolate_pos_encoding(self, x, w, h):
        previous_dtype = x.dtype
        npatch = x.shape[1] - 1
        N = self.pos_embed.shape[1] - 1
        if npatch == N and w == h:
            return self.pos_embed
        pos_embed = self.pos_embed.float()
        class_pos_embed = pos_embed[:, (0)]
        patch_pos_embed = pos_embed[:, 1:]
        dim = x.shape[-1]
        w0 = w // self.patch_size
        h0 = h // self.patch_size
        w0, h0 = w0 + 0.1, h0 + 0.1
        patch_pos_embed = nn.functional.interpolate(patch_pos_embed.reshape(1, int(math.sqrt(N)), int(math.sqrt(N)), dim).permute(0, 3, 1, 2), scale_factor=(w0 / math.sqrt(N), h0 / math.sqrt(N)), mode='bicubic')
        assert int(w0) == patch_pos_embed.shape[-2] and int(h0) == patch_pos_embed.shape[-1]
        patch_pos_embed = patch_pos_embed.permute(0, 2, 3, 1).view(1, -1, dim)
        return torch.cat((class_pos_embed.unsqueeze(0), patch_pos_embed), dim=1)

    def prepare_tokens_with_masks(self, x, masks=None):
        B, nc, w, h = x.shape
        x = self.patch_embed(x)
        if masks is not None:
            x = torch.where(masks.unsqueeze(-1), self.mask_token.unsqueeze(0), x)
        x = torch.cat((self.cls_token.expand(x.shape[0], -1, -1), x), dim=1)
        x = x + self.interpolate_pos_encoding(x, w, h)
        return x

    def forward_features_list(self, x_list, masks_list):
        x = [self.prepare_tokens_with_masks(x, masks) for x, masks in zip(x_list, masks_list)]
        for blk in self.blocks:
            x = blk(x)
        all_x = x
        output = []
        for x, masks in zip(all_x, masks_list):
            x_norm = self.norm(x)
            output.append({'x_norm_clstoken': x_norm[:, (0)], 'x_norm_patchtokens': x_norm[:, 1:], 'x_prenorm': x, 'masks': masks})
        return output

    def forward_features(self, x, masks=None):
        if isinstance(x, list):
            return self.forward_features_list(x, masks)
        x = self.prepare_tokens_with_masks(x, masks)
        for blk in self.blocks:
            x = blk(x)
        x_norm = self.norm(x)
        return {'x_norm_clstoken': x_norm[:, (0)], 'x_norm_patchtokens': x_norm[:, 1:], 'x_prenorm': x, 'masks': masks}

    def _get_intermediate_layers_not_chunked(self, x, n=1):
        x = self.prepare_tokens_with_masks(x)
        output, total_block_len = [], len(self.blocks)
        blocks_to_take = range(total_block_len - n, total_block_len) if isinstance(n, int) else n
        for i, blk in enumerate(self.blocks):
            x = blk(x)
            if i in blocks_to_take:
                output.append(x)
        assert len(output) == len(blocks_to_take), f'only {len(output)} / {len(blocks_to_take)} blocks found'
        return output

    def _get_intermediate_layers_chunked(self, x, n=1):
        x = self.prepare_tokens_with_masks(x)
        output, i, total_block_len = [], 0, len(self.blocks[-1])
        blocks_to_take = range(total_block_len - n, total_block_len) if isinstance(n, int) else n
        for block_chunk in self.blocks:
            for blk in block_chunk[i:]:
                x = blk(x)
                if i in blocks_to_take:
                    output.append(x)
                i += 1
        assert len(output) == len(blocks_to_take), f'only {len(output)} / {len(blocks_to_take)} blocks found'
        return output

    def get_intermediate_layers(self, x: 'torch.Tensor\n', n: 'Union[(int, Sequence)]\n'=1, reshape: 'bool\n'=False, return_class_token: 'bool\n'=False, norm=True) ->Tuple[Union[torch.Tensor, Tuple[torch.Tensor]]]:
        if self.chunked_blocks:
            outputs = self._get_intermediate_layers_chunked(x, n)
        else:
            outputs = self._get_intermediate_layers_not_chunked(x, n)
        if norm:
            outputs = [self.norm(out) for out in outputs]
        class_tokens = [out[:, (0)] for out in outputs]
        outputs = [out[:, 1:] for out in outputs]
        if reshape:
            B, _, w, h = x.shape
            outputs = [out.reshape(B, w // self.patch_size, h // self.patch_size, -1).permute(0, 3, 1, 2).contiguous() for out in outputs]
        if return_class_token:
            return tuple(zip(outputs, class_tokens))
        return tuple(outputs)

    def forward(self, *args, is_training=False, **kwargs):
        ret = self.forward_features(*args, **kwargs)
        if is_training:
            return ret
        else:
            return self.head(ret['x_norm_clstoken'])


def build_model(args, only_teacher=False, img_size=224):
    args.arch = args.arch.removesuffix('_memeff')
    if 'vit' in args.arch:
        vit_kwargs = dict(img_size=img_size, patch_size=args.patch_size, init_values=args.layerscale, ffn_layer=args.ffn_layer, block_chunks=args.block_chunks, qkv_bias=args.qkv_bias, proj_bias=args.proj_bias, ffn_bias=args.ffn_bias)
        teacher = vits.__dict__[args.arch](**vit_kwargs)
        if only_teacher:
            return teacher, teacher.embed_dim
        student = vits.__dict__[args.arch](**vit_kwargs, drop_path_rate=args.drop_path_rate, drop_path_uniform=args.drop_path_uniform)
        embed_dim = student.embed_dim
    return student, teacher, embed_dim


def build_model_from_cfg(cfg, only_teacher=False):
    return build_model(cfg.student, only_teacher=only_teacher, img_size=cfg.crops.global_crops_size)


def fuse_params_groups(all_params_groups, keys=('lr_multiplier', 'wd_multiplier', 'is_last_layer')):
    fused_params_groups = defaultdict(lambda : {'params': []})
    for d in all_params_groups:
        identifier = ''
        for k in keys:
            identifier += k + str(d[k]) + '_'
        for k in keys:
            fused_params_groups[identifier][k] = d[k]
        fused_params_groups[identifier]['params'].append(d['params'])
    return fused_params_groups.values()


def get_fsdp_modules(x):
    return FSDP.fsdp_modules(x)


def get_fsdp_wrapper(model_cfg, modules_to_wrap=set()):
    sharding_strategy_dict = {'NO_SHARD': ShardingStrategy.NO_SHARD, 'SHARD_GRAD_OP': ShardingStrategy.SHARD_GRAD_OP, 'FULL_SHARD': ShardingStrategy.FULL_SHARD}
    dtype_dict = {'fp32': torch.float32, 'fp16': torch.float16, 'bf16': torch.bfloat16}
    mixed_precision_config = MixedPrecision(param_dtype=dtype_dict[model_cfg.mixed_precision.param_dtype], reduce_dtype=dtype_dict[model_cfg.mixed_precision.reduce_dtype], buffer_dtype=dtype_dict[model_cfg.mixed_precision.buffer_dtype])
    sharding_strategy_config = sharding_strategy_dict[model_cfg.sharding_strategy]
    local_rank = distributed.get_local_rank()
    fsdp_wrapper = partial(FSDP, sharding_strategy=sharding_strategy_config, mixed_precision=mixed_precision_config, device_id=local_rank, sync_module_states=True, use_orig_params=True, auto_wrap_policy=ModuleWrapPolicy(modules_to_wrap))
    return fsdp_wrapper


def get_vit_lr_decay_rate(name, lr_decay_rate=1.0, num_layers=12, force_is_backbone=False, chunked_blocks=False):
    """
    Calculate lr decay rate for different ViT blocks.
    Args:
        name (string): parameter name.
        lr_decay_rate (float): base lr decay rate.
        num_layers (int): number of ViT blocks.
    Returns:
        lr decay rate for the given parameter.
    """
    layer_id = num_layers + 1
    if name.startswith('backbone') or force_is_backbone:
        if '.pos_embed' in name or '.patch_embed' in name or '.mask_token' in name or '.cls_token' in name:
            layer_id = 0
        elif force_is_backbone and ('pos_embed' in name or 'patch_embed' in name or 'mask_token' in name or 'cls_token' in name):
            layer_id = 0
        elif '.blocks.' in name and '.residual.' not in name:
            layer_id = int(name[name.find('.blocks.'):].split('.')[2]) + 1
        elif chunked_blocks and 'blocks.' in name and 'residual.' not in name:
            layer_id = int(name[name.find('blocks.'):].split('.')[2]) + 1
        elif 'blocks.' in name and 'residual.' not in name:
            layer_id = int(name[name.find('blocks.'):].split('.')[1]) + 1
    return lr_decay_rate ** (num_layers + 1 - layer_id)


def get_params_groups_with_decay(model, lr_decay_rate=1.0, patch_embed_lr_mult=1.0):
    chunked_blocks = False
    if hasattr(model, 'n_blocks'):
        logger.info('chunked fsdp')
        n_blocks = model.n_blocks
        chunked_blocks = model.chunked_blocks
    elif hasattr(model, 'blocks'):
        logger.info('first code branch')
        n_blocks = len(model.blocks)
    elif hasattr(model, 'backbone'):
        logger.info('second code branch')
        n_blocks = len(model.backbone.blocks)
    else:
        logger.info('else code branch')
        n_blocks = 0
    all_param_groups = []
    for name, param in model.named_parameters():
        name = name.replace('_fsdp_wrapped_module.', '')
        if not param.requires_grad:
            continue
        decay_rate = get_vit_lr_decay_rate(name, lr_decay_rate, num_layers=n_blocks, force_is_backbone=n_blocks > 0, chunked_blocks=chunked_blocks)
        d = {'params': param, 'is_last_layer': False, 'lr_multiplier': decay_rate, 'wd_multiplier': 1.0, 'name': name}
        if 'last_layer' in name:
            d.update({'is_last_layer': True})
        if name.endswith('.bias') or 'norm' in name or 'gamma' in name:
            d.update({'wd_multiplier': 0.0})
        if 'patch_embed' in name:
            d.update({'lr_multiplier': d['lr_multiplier'] * patch_embed_lr_mult})
        all_param_groups.append(d)
        logger.info(f"{name}: lr_multiplier: {d['lr_multiplier']}, wd_multiplier: {d['wd_multiplier']}")
    return all_param_groups


def has_batchnorms(model):
    bn_types = nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d, nn.SyncBatchNorm
    for name, module in model.named_modules():
        if isinstance(module, bn_types):
            return True
    return False


def is_fsdp(x):
    return isinstance(x, FSDP)


def is_sharded_fsdp(x):
    return is_fsdp(x) and x.sharding_strategy is not ShardingStrategy.NO_SHARD


def free_if_fsdp(x):
    if is_sharded_fsdp(x):
        handles = x._handles
        true_list = [(True) for h in handles]
        _reshard(x, handles, true_list)


def reshard_fsdp_model(x):
    for m in get_fsdp_modules(x):
        free_if_fsdp(m)


class SSLMetaArch(nn.Module):

    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.fp16_scaler = ShardedGradScaler() if cfg.compute_precision.grad_scaler else None
        student_model_dict = dict()
        teacher_model_dict = dict()
        student_backbone, teacher_backbone, embed_dim = build_model_from_cfg(cfg)
        student_model_dict['backbone'] = student_backbone
        teacher_model_dict['backbone'] = teacher_backbone
        logger.info(f'OPTIONS -- architecture : embed_dim: {embed_dim}')
        if cfg.student.pretrained_weights:
            chkpt = torch.load(cfg.student.pretrained_weights)
            logger.info(f'OPTIONS -- pretrained weights: loading from {cfg.student.pretrained_weights}')
            student_backbone.load_state_dict(chkpt['model'], strict=False)
        self.embed_dim = embed_dim
        self.dino_out_dim = cfg.dino.head_n_prototypes
        self.do_dino = cfg.dino.loss_weight > 0
        self.do_koleo = cfg.dino.koleo_loss_weight > 0
        self.do_ibot = cfg.ibot.loss_weight > 0
        self.ibot_separate_head = cfg.ibot.separate_head
        logger.info('OPTIONS -- DINO')
        if self.do_dino:
            logger.info(f'OPTIONS -- DINO -- loss_weight: {cfg.dino.loss_weight}')
            logger.info(f'OPTIONS -- DINO -- head_n_prototypes: {cfg.dino.head_n_prototypes}')
            logger.info(f'OPTIONS -- DINO -- head_bottleneck_dim: {cfg.dino.head_bottleneck_dim}')
            logger.info(f'OPTIONS -- DINO -- head_hidden_dim: {cfg.dino.head_hidden_dim}')
            self.dino_loss_weight = cfg.dino.loss_weight
            dino_head = partial(DINOHead, in_dim=embed_dim, out_dim=cfg.dino.head_n_prototypes, hidden_dim=cfg.dino.head_hidden_dim, bottleneck_dim=cfg.dino.head_bottleneck_dim, nlayers=cfg.dino.head_nlayers)
            self.dino_loss = DINOLoss(self.dino_out_dim)
            if self.do_koleo:
                logger.info('OPTIONS -- DINO -- applying KOLEO regularization')
                self.koleo_loss = KoLeoLoss()
        else:
            logger.info('OPTIONS -- DINO -- not using DINO')
        if self.do_dino or self.do_ibot:
            student_model_dict['dino_head'] = dino_head()
            teacher_model_dict['dino_head'] = dino_head()
        logger.info('OPTIONS -- IBOT')
        logger.info(f'OPTIONS -- IBOT -- loss_weight: {cfg.ibot.loss_weight}')
        logger.info(f'OPTIONS -- IBOT masking -- ibot_mask_ratio_tuple: {cfg.ibot.mask_ratio_min_max}')
        logger.info(f'OPTIONS -- IBOT masking -- ibot_mask_sample_probability: {cfg.ibot.mask_sample_probability}')
        if self.do_ibot:
            self.ibot_loss_weight = cfg.ibot.loss_weight
            assert max(cfg.ibot.mask_ratio_min_max) > 0, 'please provide a positive mask ratio tuple for ibot'
            assert cfg.ibot.mask_sample_probability > 0, 'please provide a positive mask probability for ibot'
            self.ibot_out_dim = cfg.ibot.head_n_prototypes if self.ibot_separate_head else cfg.dino.head_n_prototypes
            self.ibot_patch_loss = iBOTPatchLoss(self.ibot_out_dim)
            if self.ibot_separate_head:
                logger.info(f'OPTIONS -- IBOT -- loss_weight: {cfg.ibot.loss_weight}')
                logger.info(f'OPTIONS -- IBOT -- head_n_prototypes: {cfg.ibot.head_n_prototypes}')
                logger.info(f'OPTIONS -- IBOT -- head_bottleneck_dim: {cfg.ibot.head_bottleneck_dim}')
                logger.info(f'OPTIONS -- IBOT -- head_hidden_dim: {cfg.ibot.head_hidden_dim}')
                ibot_head = partial(DINOHead, in_dim=embed_dim, out_dim=cfg.ibot.head_n_prototypes, hidden_dim=cfg.ibot.head_hidden_dim, bottleneck_dim=cfg.ibot.head_bottleneck_dim, nlayers=cfg.ibot.head_nlayers)
                student_model_dict['ibot_head'] = ibot_head()
                teacher_model_dict['ibot_head'] = ibot_head()
            else:
                logger.info('OPTIONS -- IBOT -- head shared with DINO')
        self.need_to_synchronize_fsdp_streams = True
        self.student = nn.ModuleDict(student_model_dict)
        self.teacher = nn.ModuleDict(teacher_model_dict)
        for p in self.teacher.parameters():
            p.requires_grad = False
        logger.info(f'Student and Teacher are built: they are both {cfg.student.arch} network.')

    def forward(self, inputs):
        raise NotImplementedError

    def backprop_loss(self, loss):
        if self.fp16_scaler is not None:
            self.fp16_scaler.scale(loss).backward()
        else:
            loss.backward()

    def forward_backward(self, images, teacher_temp):
        n_global_crops = 2
        assert n_global_crops == 2
        n_local_crops = self.cfg.crops.local_crops_number
        global_crops = images['collated_global_crops']
        local_crops = images['collated_local_crops']
        masks = images['collated_masks']
        mask_indices_list = images['mask_indices_list']
        n_masked_patches_tensor = images['n_masked_patches']
        n_masked_patches = mask_indices_list.shape[0]
        upperbound = images['upperbound']
        masks_weight = images['masks_weight']
        n_local_crops_loss_terms = max(n_local_crops * n_global_crops, 1)
        n_global_crops_loss_terms = (n_global_crops - 1) * n_global_crops
        do_dino = self.do_dino
        do_ibot = self.do_ibot
        ibot_loss_scale = 1.0 / n_global_crops

        @torch.no_grad()
        def get_teacher_output():
            x, n_global_crops_teacher = global_crops, n_global_crops
            teacher_backbone_output_dict = self.teacher.backbone(x, is_training=True)
            teacher_cls_tokens = teacher_backbone_output_dict['x_norm_clstoken']
            teacher_cls_tokens = teacher_cls_tokens.chunk(n_global_crops_teacher)
            teacher_cls_tokens = torch.cat((teacher_cls_tokens[1], teacher_cls_tokens[0]))
            ibot_teacher_patch_tokens = teacher_backbone_output_dict['x_norm_patchtokens']
            _dim = ibot_teacher_patch_tokens.shape[-1]
            n_cls_tokens = teacher_cls_tokens.shape[0]
            if do_ibot and not self.ibot_separate_head:
                buffer_tensor_teacher = ibot_teacher_patch_tokens.new_zeros(upperbound + n_cls_tokens, _dim)
                buffer_tensor_teacher[:n_cls_tokens].copy_(teacher_cls_tokens)
                torch.index_select(ibot_teacher_patch_tokens.flatten(0, 1), dim=0, index=mask_indices_list, out=buffer_tensor_teacher[n_cls_tokens:n_cls_tokens + n_masked_patches])
                tokens_after_head = self.teacher.dino_head(buffer_tensor_teacher)
                teacher_cls_tokens_after_head = tokens_after_head[:n_cls_tokens]
                masked_teacher_patch_tokens_after_head = tokens_after_head[n_cls_tokens:n_cls_tokens + n_masked_patches]
            elif do_ibot and self.ibot_separate_head:
                buffer_tensor_teacher = ibot_teacher_patch_tokens.new_zeros(upperbound, _dim)
                torch.index_select(ibot_teacher_patch_tokens.flatten(0, 1), dim=0, index=mask_indices_list, out=buffer_tensor_teacher[:n_masked_patches])
                teacher_cls_tokens_after_head = self.teacher.dino_head(teacher_cls_tokens)
                masked_teacher_patch_tokens_after_head = self.teacher.ibot_head(buffer_tensor_teacher)[:n_masked_patches]
            else:
                teacher_cls_tokens_after_head = self.teacher.dino_head(teacher_cls_tokens)
                masked_teacher_ibot_softmaxed_centered = None
            if self.cfg.train.centering == 'centering':
                teacher_dino_softmaxed_centered_list = self.dino_loss.softmax_center_teacher(teacher_cls_tokens_after_head, teacher_temp=teacher_temp).view(n_global_crops_teacher, -1, *teacher_cls_tokens_after_head.shape[1:])
                self.dino_loss.update_center(teacher_cls_tokens_after_head)
                if do_ibot:
                    masked_teacher_patch_tokens_after_head = masked_teacher_patch_tokens_after_head.unsqueeze(0)
                    masked_teacher_ibot_softmaxed_centered = self.ibot_patch_loss.softmax_center_teacher(masked_teacher_patch_tokens_after_head[:, :n_masked_patches], teacher_temp=teacher_temp)
                    masked_teacher_ibot_softmaxed_centered = masked_teacher_ibot_softmaxed_centered.squeeze(0)
                    self.ibot_patch_loss.update_center(masked_teacher_patch_tokens_after_head[:n_masked_patches])
            elif self.cfg.train.centering == 'sinkhorn_knopp':
                teacher_dino_softmaxed_centered_list = self.dino_loss.sinkhorn_knopp_teacher(teacher_cls_tokens_after_head, teacher_temp=teacher_temp).view(n_global_crops_teacher, -1, *teacher_cls_tokens_after_head.shape[1:])
                if do_ibot:
                    masked_teacher_ibot_softmaxed_centered = self.ibot_patch_loss.sinkhorn_knopp_teacher(masked_teacher_patch_tokens_after_head, teacher_temp=teacher_temp, n_masked_patches_tensor=n_masked_patches_tensor)
            else:
                raise NotImplementedError
            return teacher_dino_softmaxed_centered_list, masked_teacher_ibot_softmaxed_centered
        teacher_dino_softmaxed_centered_list, masked_teacher_ibot_softmaxed_centered = get_teacher_output()
        reshard_fsdp_model(self.teacher)
        loss_dict = {}
        loss_accumulator = 0
        student_global_backbone_output_dict, student_local_backbone_output_dict = self.student.backbone([global_crops, local_crops], masks=[masks, None], is_training=True)
        inputs_for_student_head_list = []
        student_local_cls_tokens = student_local_backbone_output_dict['x_norm_clstoken']
        inputs_for_student_head_list.append(student_local_cls_tokens.unsqueeze(0))
        student_global_cls_tokens = student_global_backbone_output_dict['x_norm_clstoken']
        inputs_for_student_head_list.append(student_global_cls_tokens.unsqueeze(0))
        if do_ibot:
            _dim = student_global_backbone_output_dict['x_norm_clstoken'].shape[-1]
            ibot_student_patch_tokens = student_global_backbone_output_dict['x_norm_patchtokens']
            buffer_tensor_patch_tokens = ibot_student_patch_tokens.new_zeros(upperbound, _dim)
            buffer_tensor_patch_tokens[:n_masked_patches].copy_(torch.index_select(ibot_student_patch_tokens.flatten(0, 1), dim=0, index=mask_indices_list))
            if not self.ibot_separate_head:
                inputs_for_student_head_list.append(buffer_tensor_patch_tokens.unsqueeze(0))
            else:
                student_global_masked_patch_tokens_after_head = self.student.ibot_head(buffer_tensor_patch_tokens)[:n_masked_patches]
        _attn_bias, cat_inputs = fmha.BlockDiagonalMask.from_tensor_list(inputs_for_student_head_list)
        outputs_list = _attn_bias.split(self.student.dino_head(cat_inputs))
        student_local_cls_tokens_after_head = outputs_list.pop(0).squeeze(0)
        student_global_cls_tokens_after_head = outputs_list.pop(0).squeeze(0)
        if do_ibot and not self.ibot_separate_head:
            student_global_masked_patch_tokens_after_head = outputs_list.pop(0).squeeze(0)[:n_masked_patches]
        if n_local_crops > 0:
            dino_local_crops_loss = self.dino_loss(student_output_list=student_local_cls_tokens_after_head.chunk(n_local_crops), teacher_out_softmaxed_centered_list=teacher_dino_softmaxed_centered_list) / (n_global_crops_loss_terms + n_local_crops_loss_terms)
            loss_dict['dino_local_crops_loss'] = dino_local_crops_loss
            loss_accumulator += self.dino_loss_weight * dino_local_crops_loss
        loss_scales = 2
        if do_dino:
            dino_global_crops_loss = self.dino_loss(student_output_list=[student_global_cls_tokens_after_head], teacher_out_softmaxed_centered_list=[teacher_dino_softmaxed_centered_list.flatten(0, 1)]) * loss_scales / (n_global_crops_loss_terms + n_local_crops_loss_terms)
            loss_dict['dino_global_crops_loss'] = dino_global_crops_loss
            loss_accumulator += self.dino_loss_weight * dino_global_crops_loss
            student_cls_tokens = student_global_cls_tokens
            if self.do_koleo:
                koleo_loss = self.cfg.dino.koleo_loss_weight * sum(self.koleo_loss(p) for p in student_cls_tokens.chunk(2))
                loss_accumulator += koleo_loss
                loss_dict['koleo_loss'] = koleo_loss / loss_scales
        if do_ibot:
            ibot_patch_loss = self.ibot_patch_loss.forward_masked(student_global_masked_patch_tokens_after_head, masked_teacher_ibot_softmaxed_centered, student_masks_flat=masks, n_masked_patches=n_masked_patches, masks_weight=masks_weight) * loss_scales * ibot_loss_scale
            loss_dict['ibot_loss'] = ibot_patch_loss / 2
            loss_accumulator += self.ibot_loss_weight * ibot_patch_loss
        self.backprop_loss(loss_accumulator)
        self.fsdp_synchronize_streams()
        return loss_dict

    def fsdp_synchronize_streams(self):
        if self.need_to_synchronize_fsdp_streams:
            torch.cuda.synchronize()
            self.student.dino_head._streams = self.teacher.dino_head._streams = self.student.backbone._streams = self.teacher.backbone._streams
            self.need_to_synchronize_fsdp_streams = False

    def update_teacher(self, m):
        student_param_list = []
        teacher_param_list = []
        with torch.no_grad():
            for k in self.student.keys():
                for ms, mt in zip(get_fsdp_modules(self.student[k]), get_fsdp_modules(self.teacher[k])):
                    student_param_list += ms.params
                    teacher_param_list += mt.params
            torch._foreach_mul_(teacher_param_list, m)
            torch._foreach_add_(teacher_param_list, student_param_list, alpha=1 - m)

    def train(self):
        super().train()
        self.teacher.eval()

    def get_maybe_fused_params_for_submodel(self, m):
        params_groups = get_params_groups_with_decay(model=m, lr_decay_rate=self.cfg.optim.layerwise_decay, patch_embed_lr_mult=self.cfg.optim.patch_embed_lr_mult)
        fused_params_groups = fuse_params_groups(params_groups)
        logger.info('fusing param groups')
        for g in fused_params_groups:
            g['foreach'] = True
        return fused_params_groups

    def get_params_groups(self):
        all_params_groups = []
        for m in self.student.values():
            all_params_groups += self.get_maybe_fused_params_for_submodel(m)
        return all_params_groups

    def prepare_for_distributed_training(self):
        logger.info('DISTRIBUTED FSDP -- preparing model for distributed training')
        if has_batchnorms(self.student):
            raise NotImplementedError
        for k, v in self.student.items():
            self.teacher[k].load_state_dict(self.student[k].state_dict())
            student_model_cfg = self.cfg.compute_precision.student[k]
            self.student[k] = get_fsdp_wrapper(student_model_cfg, modules_to_wrap={BlockChunk})(self.student[k])
            teacher_model_cfg = self.cfg.compute_precision.teacher[k]
            self.teacher[k] = get_fsdp_wrapper(teacher_model_cfg, modules_to_wrap={BlockChunk})(self.teacher[k])


class _LinearClassifierWrapper(nn.Module):

    def __init__(self, *, backbone: nn.Module, linear_head: nn.Module, layers: int=4):
        super().__init__()
        self.backbone = backbone
        self.linear_head = linear_head
        self.layers = layers

    def forward(self, x):
        if self.layers == 1:
            x = self.backbone.forward_features(x)
            cls_token = x['x_norm_clstoken']
            patch_tokens = x['x_norm_patchtokens']
            linear_input = torch.cat([cls_token, patch_tokens.mean(dim=1)], dim=1)
        elif self.layers == 4:
            x = self.backbone.get_intermediate_layers(x, n=4, return_class_token=True)
            linear_input = torch.cat([x[0][1], x[1][1], x[2][1], x[3][1], x[3][0].mean(dim=1)], dim=1)
        else:
            assert False, f'Unsupported number of layers: {self.layers}'
        return self.linear_head(linear_input)


import torch
from torch.nn import MSELoss, ReLU
from _paritybench_helpers import _mock_config, _mock_layer, _paritybench_base, _fails_compile


TESTCASES = [
    # (nn.Module, init_args, forward_args, jit_compiles)
    (AllClassifiers,
     lambda: ([], {'classifiers_dict': {'relu': ReLU()}}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (Block,
     lambda: ([], {'dim': 4, 'num_heads': 4}),
     lambda: ([torch.rand([4, 4, 4])], {}),
     False),
    (BlockChunk,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (DINOHead,
     lambda: ([], {'in_dim': 4, 'out_dim': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     False),
    (DINOLoss,
     lambda: ([], {'out_dim': 4}),
     lambda: ([torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4])], {}),
     True),
    (DropPath,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     False),
    (LayerScale,
     lambda: ([], {'dim': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (LinearPostprocessor,
     lambda: ([], {'linear_classifier': _mock_layer()}),
     lambda: ([torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4])], {}),
     True),
    (Mlp,
     lambda: ([], {'in_features': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (ModelWithNormalize,
     lambda: ([], {'model': _mock_layer()}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     False),
    (ModuleDictWithForward,
     lambda: ([], {}),
     lambda: ([], {}),
     False),
    (NestedTensorBlock,
     lambda: ([], {'dim': 4, 'num_heads': 4}),
     lambda: ([torch.rand([4, 4, 4])], {}),
     False),
    (SwiGLUFFN,
     lambda: ([], {'in_features': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (iBOTPatchLoss,
     lambda: ([], {'patch_out_dim': 4}),
     lambda: ([torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4])], {}),
     True),
]

class Test_dinov2(_paritybench_base):
    def test_000(self):
        self._check(*TESTCASES[0])

    def test_001(self):
        self._check(*TESTCASES[1])

    def test_002(self):
        self._check(*TESTCASES[2])

    def test_003(self):
        self._check(*TESTCASES[3])

    def test_004(self):
        self._check(*TESTCASES[4])

    def test_005(self):
        self._check(*TESTCASES[5])

    def test_006(self):
        self._check(*TESTCASES[6])

    def test_007(self):
        self._check(*TESTCASES[7])

    def test_008(self):
        self._check(*TESTCASES[8])

    def test_009(self):
        self._check(*TESTCASES[9])

    def test_010(self):
        self._check(*TESTCASES[10])

    def test_011(self):
        self._check(*TESTCASES[11])

    def test_012(self):
        self._check(*TESTCASES[12])

    def test_013(self):
        self._check(*TESTCASES[13])

