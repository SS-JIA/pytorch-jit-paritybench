import sys
_module = sys.modules[__name__]
del sys
process_commit = _module
make_assets = _module
beta_status = _module
conf = _module
trace_model = _module
plot_datapoints = _module
plot_optical_flow = _module
plot_repurposing_annotations = _module
plot_scripted_tensor_transforms = _module
plot_transforms = _module
plot_transforms_v2 = _module
plot_transforms_v2_e2e = _module
plot_video_api = _module
plot_visualization_utils = _module
make_assets = _module
relocate = _module
presets = _module
sampler = _module
train = _module
train_quantization = _module
transforms = _module
utils = _module
distributed = _module
logger = _module
losses = _module
metrics = _module
norm = _module
padder = _module
stereo = _module
cascade_evaluation = _module
parsing = _module
presets = _module
train = _module
transforms = _module
visualization = _module
coco_eval = _module
coco_utils = _module
engine = _module
group_by_aspect_ratio = _module
presets = _module
train = _module
transforms = _module
utils = _module
presets = _module
train = _module
transforms = _module
utils = _module
coco_utils = _module
presets = _module
train = _module
transforms = _module
utils = _module
loss = _module
model = _module
sampler = _module
test = _module
train = _module
datasets = _module
presets = _module
train = _module
transforms = _module
utils = _module
classify_prs = _module
retrieve_prs_data = _module
collect_model_urls = _module
download_model_urls = _module
trace_model = _module
_utils_internal = _module
builtin_dataset_mocks = _module
common_extended_utils = _module
common_utils = _module
conftest = _module
datasets_utils = _module
prototype_common_utils = _module
smoke_test = _module
test_architecture_ops = _module
test_backbone_utils = _module
test_datapoints = _module
test_datasets = _module
test_datasets_download = _module
test_datasets_samplers = _module
test_datasets_utils = _module
test_datasets_video_utils = _module
test_datasets_video_utils_opt = _module
test_extended_models = _module
test_functional_tensor = _module
test_image = _module
test_internal_utils = _module
test_internet = _module
test_io = _module
test_io_opt = _module
test_models = _module
test_models_detection_anchor_utils = _module
test_models_detection_negative_samples = _module
test_models_detection_utils = _module
test_onnx = _module
test_ops = _module
test_prototype_datasets_builtin = _module
test_prototype_datasets_utils = _module
test_prototype_models = _module
test_prototype_transforms = _module
test_transforms = _module
test_transforms_tensor = _module
test_transforms_v2 = _module
test_transforms_v2_consistency = _module
test_transforms_v2_functional = _module
test_transforms_v2_refactored = _module
test_transforms_v2_utils = _module
test_transforms_video = _module
test_utils = _module
test_video_gpu_decoder = _module
test_video_reader = _module
test_videoapi = _module
transforms_v2_dispatcher_infos = _module
transforms_v2_kernel_infos = _module
datapoints = _module
_bounding_box = _module
_datapoint = _module
_dataset_wrapper = _module
_image = _module
_mask = _module
_video = _module
samplers = _module
clip_sampler = _module
_optical_flow = _module
_stereo_matching = _module
caltech = _module
celeba = _module
cifar = _module
cityscapes = _module
clevr = _module
coco = _module
country211 = _module
dtd = _module
eurosat = _module
fakedata = _module
fer2013 = _module
fgvc_aircraft = _module
flickr = _module
flowers102 = _module
folder = _module
food101 = _module
gtsrb = _module
hmdb51 = _module
imagenet = _module
inaturalist = _module
kinetics = _module
kitti = _module
lfw = _module
lsun = _module
mnist = _module
moving_mnist = _module
omniglot = _module
oxford_iiit_pet = _module
pcam = _module
phototour = _module
places365 = _module
rendered_sst2 = _module
sbd = _module
sbu = _module
semeion = _module
stanford_cars = _module
stl10 = _module
sun397 = _module
svhn = _module
ucf101 = _module
usps = _module
utils = _module
video_utils = _module
vision = _module
voc = _module
widerface = _module
io = _module
_load_gpu_decoder = _module
_video_opt = _module
image = _module
video = _module
video_reader = _module
detection = _module
_utils = _module
anchor_utils = _module
backbone_utils = _module
faster_rcnn = _module
fcos = _module
generalized_rcnn = _module
image_list = _module
keypoint_rcnn = _module
mask_rcnn = _module
retinanet = _module
roi_heads = _module
rpn = _module
ssd = _module
ssdlite = _module
transform = _module
optical_flow = _module
_utils = _module
raft = _module
quantization = _module
googlenet = _module
inception = _module
mobilenet = _module
mobilenetv2 = _module
mobilenetv3 = _module
resnet = _module
shufflenetv2 = _module
utils = _module
segmentation = _module
_utils = _module
deeplabv3 = _module
fcn = _module
lraspp = _module
mvit = _module
resnet = _module
s3d = _module
swin_transformer = _module
models = _module
_api = _module
_meta = _module
_utils = _module
alexnet = _module
convnext = _module
densenet = _module
efficientnet = _module
feature_extraction = _module
googlenet = _module
inception = _module
maxvit = _module
mnasnet = _module
mobilenetv2 = _module
mobilenetv3 = _module
regnet = _module
resnet = _module
shufflenetv2 = _module
squeezenet = _module
swin_transformer = _module
vgg = _module
vision_transformer = _module
ops = _module
_box_convert = _module
_register_onnx_ops = _module
_utils = _module
boxes = _module
ciou_loss = _module
deform_conv = _module
diou_loss = _module
drop_block = _module
feature_pyramid_network = _module
focal_loss = _module
giou_loss = _module
misc = _module
poolers = _module
ps_roi_align = _module
ps_roi_pool = _module
roi_align = _module
roi_pool = _module
stochastic_depth = _module
_label = _module
_builtin = _module
caltech = _module
celeba = _module
coco = _module
cub200 = _module
fer2013 = _module
mnist = _module
sbd = _module
semeion = _module
usps = _module
_dataset = _module
_encoded = _module
_internal = _module
_resource = _module
_folder = _module
_home = _module
benchmark = _module
generate_category_files = _module
crestereo = _module
raft_stereo = _module
depth = _module
_augment = _module
_geometry = _module
_misc = _module
_presets = _module
_type_conversion = _module
_internal = _module
prototype = _module
functional = _module
_augment = _module
_color = _module
_deprecated = _module
_geometry = _module
_meta = _module
_misc = _module
_temporal = _module
_type_conversion = _module
_utils = _module
v2 = _module
_augment = _module
_auto_augment = _module
_color = _module
_container = _module
_deprecated = _module
_geometry = _module
_meta = _module
_misc = _module
_transform = _module
_type_conversion = _module
_functional_pil = _module
_functional_tensor = _module
_functional_video = _module
_presets = _module
_transforms_video = _module
autoaugment = _module
functional = _module
functional_pil = _module
functional_tensor = _module
transforms = _module
torchvision = _module
_internally_replaced_utils = _module
_meta_registrations = _module
extension = _module
utils = _module
hubconf = _module
setup = _module

from _paritybench_helpers import _mock_config, patch_functional
from unittest.mock import mock_open, MagicMock
from torch.autograd import Function
from torch.nn import Module
import abc, collections, copy, enum, functools, inspect, itertools, logging, math, matplotlib, numbers, numpy, pandas, queue, random, re, scipy, sklearn, string, tensorflow, time, torch, torchaudio, torchtext, torchvision, types, typing, uuid, warnings
import operator as op
from dataclasses import dataclass
import numpy as np
from torch import Tensor
patch_functional()
open = mock_open()
yaml = logging = sys = argparse = MagicMock()
ArgumentParser = argparse.ArgumentParser
_global_config = args = argv = cfg = config = params = _mock_config()
argparse.ArgumentParser.return_value.parse_args.return_value = _global_config
yaml.load.return_value = _global_config
sys.argv = _global_config
__version__ = '1.0.0'
xrange = range
wraps = functools.wraps


import torch


from torch.utils.mobile_optimizer import optimize_for_mobile


from torchvision.models.detection import fasterrcnn_mobilenet_v3_large_320_fpn


from torchvision.models.detection import FasterRCNN_MobileNet_V3_Large_320_FPN_Weights


from copy import copy


import torchvision


import torchvision.models as M


import torchvision.datapoints


from torchvision import datapoints


from torchvision.transforms.v2 import functional as F


import numpy as np


import matplotlib.pyplot as plt


import torchvision.transforms.functional as F


from torchvision.io import read_video


from torchvision.models.optical_flow import Raft_Large_Weights


from torchvision.models.optical_flow import raft_large


from torchvision.utils import flow_to_image


from torchvision.io import read_image


from torchvision.utils import draw_segmentation_masks


from torchvision.ops import masks_to_boxes


from torchvision.utils import draw_bounding_boxes


from torchvision.models.detection import fasterrcnn_resnet50_fpn


from torchvision.models.detection import FasterRCNN_ResNet50_FPN_Weights


import torchvision.transforms as T


import torch.nn as nn


from torchvision.models import resnet18


from torchvision.models import ResNet18_Weights


import torchvision.transforms.v2 as transforms


from collections import defaultdict


import torch.utils.data


from torchvision import models


from torchvision import datasets


from torchvision.datasets.utils import download_url


import itertools


import random


from torchvision.datasets.folder import make_dataset


from torchvision import transforms as t


from torch.utils.data import DataLoader


from torchvision.utils import make_grid


from torchvision.models.segmentation import fcn_resnet50


from torchvision.models.segmentation import FCN_ResNet50_Weights


from torchvision.models.detection import maskrcnn_resnet50_fpn


from torchvision.models.detection import MaskRCNN_ResNet50_FPN_Weights


from torchvision.models.detection import keypointrcnn_resnet50_fpn


from torchvision.models.detection import KeypointRCNN_ResNet50_FPN_Weights


from torchvision.utils import draw_keypoints


from torchvision.transforms.functional import InterpolationMode


import math


import torch.distributed as dist


import time


import warnings


import torchvision.transforms


from torch import nn


from torch.utils.data.dataloader import default_collate


import copy


import torch.ao.quantization


from typing import Tuple


from torch import Tensor


from torchvision.transforms import functional as F


from collections import deque


from collections import OrderedDict


from typing import List


from typing import Optional


from torch.nn import functional as F


from torchvision.prototype.models.depth.stereo.raft_stereo import grid_sample


from torchvision.prototype.models.depth.stereo.raft_stereo import make_coords_grid


from typing import Dict


import torch.nn.functional as F


import torchvision.prototype.models.depth.stereo


from functools import partial


from torchvision.datasets import CarlaStereo


from torchvision.datasets import CREStereo


from torchvision.datasets import ETH3DStereo


from torchvision.datasets import FallingThingsStereo


from torchvision.datasets import InStereo2k


from torchvision.datasets import Kitti2012Stereo


from torchvision.datasets import Kitti2015Stereo


from torchvision.datasets import Middlebury2014Stereo


from torchvision.datasets import SceneFlowStereo


from torchvision.datasets import SintelStereo


from typing import Union


import torchvision.models.optical_flow


from torchvision.transforms.functional import get_dimensions


from torchvision.transforms.functional import resize


from typing import Callable


from typing import Sequence


import torchvision.models.detection.mask_rcnn


from itertools import chain


from itertools import repeat


from torch.utils.data.sampler import BatchSampler


from torch.utils.data.sampler import Sampler


from torch.utils.model_zoo import tqdm


import torchvision.models.detection


from torchvision.transforms import InterpolationMode


from torchvision import ops


from torchvision.transforms import transforms as T


from math import ceil


from torchvision.datasets import FlyingChairs


from torchvision.datasets import FlyingThings3D


from torchvision.datasets import HD1K


from torchvision.datasets import KittiFlow


from torchvision.datasets import Sintel


from torch.optim.lr_scheduler import PolynomialLR


from torchvision import transforms as T


import torchvision.models as models


import torchvision.transforms as transforms


from torchvision.datasets import FakeData


from torch.optim import Adam


from torchvision.datasets import FashionMNIST


from torchvision.transforms import transforms


import torchvision.datasets.video_utils


from torchvision.datasets.samplers import DistributedSampler


from torchvision.datasets.samplers import RandomClipSampler


from torchvision.datasets.samplers import UniformClipSampler


from time import perf_counter


import collections.abc


import functools


from collections import Counter


from torch.nn.functional import one_hot


from torch.testing import make_tensor as _make_tensor


from torchvision.prototype import datasets


from numbers import Number


from typing import Any


from torch.utils._python_dispatch import TorchDispatchMode


from torch.utils._pytree import tree_map


from torchvision.models._api import Weights


import enum


import re


import torch.testing


from torch.testing._comparison import BooleanPair


from torch.testing._comparison import NonePair


from torch.testing._comparison import not_close_error_metas


from torch.testing._comparison import NumberPair


from torch.testing._comparison import TensorLikePair


from torchvision import io


from torchvision.transforms._functional_tensor import _max_value as get_max_value


from torchvision.transforms.v2.functional import convert_dtype_image_tensor


from torchvision.transforms.v2.functional import to_image_pil


from torchvision.transforms.v2.functional import to_image_tensor


import inspect


import string


from typing import Iterator


import torchvision.datasets


import torchvision.io


from torch.utils._pytree import tree_any


import torchvision.datasets as datasets


from torchvision.prototype import datapoints


from torchvision.io import decode_jpeg


from torchvision.io import read_file


from torchvision.models import resnet50


from torchvision.models import ResNet50_Weights


from torchvision.models.maxvit import SwapAxes


from torchvision.models.maxvit import WindowDepartition


from torchvision.models.maxvit import WindowPartition


from typing import Mapping


from torchvision.models._utils import IntermediateLayerGetter


from torchvision.models.detection.backbone_utils import BackboneWithFPN


from torchvision.models.detection.backbone_utils import mobilenet_backbone


from torchvision.models.detection.backbone_utils import resnet_fpn_backbone


from torchvision.models.feature_extraction import create_feature_extractor


from torchvision.models.feature_extraction import get_graph_node_names


from copy import deepcopy


from torchvision.datasets.video_utils import VideoClips


import torchvision.datasets.utils as utils


from torch._utils_internal import get_file_path_2


from torchvision.datasets.utils import _COMPRESSED_FILE_OPENERS


from torchvision.datasets.video_utils import unfold


from torchvision.models import get_model_weights


from torchvision.models import Weights


from torchvision.models import WeightsEnum


from torchvision.models._utils import handle_legacy_interface


import torchvision.transforms._functional_pil as F_pil


import torchvision.transforms._functional_tensor as F_t


from torchvision.io.image import _read_png_16


from torchvision.io.image import decode_image


from torchvision.io.image import decode_jpeg


from torchvision.io.image import decode_png


from torchvision.io.image import encode_jpeg


from torchvision.io.image import encode_png


from torchvision.io.image import ImageReadMode


from torchvision.io.image import read_file


from torchvision.io.image import read_image


from torchvision.io.image import write_file


from torchvision.io.image import write_jpeg


from torchvision.io.image import write_png


import torchvision.io as io


from torchvision import get_video_backend


import torch.fx


from torchvision import transforms


from torchvision.models import get_model_builder


from torchvision.models import list_models


from torchvision.models.detection.anchor_utils import AnchorGenerator


from torchvision.models.detection.anchor_utils import DefaultBoxGenerator


from torchvision.models.detection.image_list import ImageList


import torchvision.models


from torchvision.models.detection.faster_rcnn import FastRCNNPredictor


from torchvision.models.detection.faster_rcnn import TwoMLPHead


from torchvision.models.detection.roi_heads import RoIHeads


from torchvision.models.detection.rpn import AnchorGenerator


from torchvision.models.detection.rpn import RegionProposalNetwork


from torchvision.models.detection.rpn import RPNHead


from torchvision.ops import MultiScaleRoIAlign


from torchvision.models.detection import _utils


from torchvision.models.detection import backbone_utils


from torchvision.models.detection.transform import GeneralizedRCNNTransform


from torchvision.ops import _register_onnx_ops


from abc import ABC


from abc import abstractmethod


from functools import lru_cache


from itertools import product


from torch.autograd import gradcheck


from torch.nn.modules.utils import _pair


from torch.testing._comparison import ObjectPair


from torch.utils.data.graph_settings import get_all_graph_pipes


from torchvision._utils import sequence_to_str


from torchvision.prototype.datapoints import Label


from torchvision.prototype.datasets.utils import EncodedImage


from torchvision.prototype.datasets.utils._internal import INFINITE_BUFFER_SIZE


from torchvision.transforms.v2.utils import is_simple_tensor


from torchvision.datasets._optical_flow import _read_flo as read_flo_ref


from torchvision.datasets.utils import _decompress


from torchvision.prototype.datasets.utils import Dataset


from torchvision.prototype.datasets.utils import GDriveResource


from torchvision.prototype.datasets.utils import HttpResource


from torchvision.prototype.datasets.utils import OnlineResource


from torchvision.prototype.datasets.utils._internal import fromfile


from torchvision.prototype.datasets.utils._internal import read_flo


from torchvision.prototype import models


from torchvision.datapoints import BoundingBox


from torchvision.datapoints import BoundingBoxFormat


from torchvision.datapoints import Image


from torchvision.datapoints import Mask


from torchvision.datapoints import Video


from torchvision.prototype import transforms


from torchvision.transforms.v2._utils import _convert_fill_arg


from torchvision.transforms.v2.functional import InterpolationMode


from torchvision.transforms.v2.functional import pil_to_tensor


from torchvision.transforms.v2.utils import check_type


from torchvision.transforms.autoaugment import _apply_op


from torch.utils._pytree import tree_flatten


from torch.utils._pytree import tree_unflatten


from torchvision.ops.boxes import box_iou


from torchvision.transforms.functional import to_pil_image


from torchvision.transforms.v2.utils import query_chw


import torchvision.transforms.v2 as v2_transforms


from torchvision import transforms as legacy_transforms


from torchvision.transforms import functional as legacy_F


from torchvision.transforms.v2 import functional as prototype_F


from torchvision.transforms.v2.utils import query_spatial_size


from typing import get_type_hints


from torchvision.transforms.functional import _get_perspective_coeffs


from torchvision.transforms.v2.functional._geometry import _center_crop_compute_padding


from torchvision.transforms.v2.functional._meta import clamp_bounding_box


from torchvision.transforms.v2.functional._meta import convert_format_bounding_box


from torch.testing import assert_close


from torchvision.transforms.functional import pil_modes_mapping


import torchvision.transforms.v2.utils


from torchvision.transforms.v2.utils import has_all


from torchvision.transforms.v2.utils import has_any


from torchvision.transforms import Compose


import torchvision.utils as utils


from torchvision.io import _HAS_GPU_VIDEO_DECODER


from torchvision.io import VideoReader


import collections


from numpy.random import randint


from torchvision import set_video_backend


from torchvision.io import _HAS_VIDEO_OPT


import torchvision.ops


import torchvision.transforms.v2.functional as F


from torchvision.transforms._functional_tensor import _parse_pad_padding


from enum import Enum


from types import ModuleType


from typing import Type


from typing import TypeVar


from torch._C import DisableTorchFunctionSubclass


from torch.types import _device


from torch.types import _dtype


from torch.types import _size


from torch.utils.data import Dataset


from typing import cast


from typing import Sized


from torch.utils.data import Sampler


from collections import namedtuple


from torchvision.datasets.utils import verify_str_arg


from torchvision.datasets.vision import VisionDataset


from typing import IO


from typing import Iterable


from torchvision.io import _probe_video_from_file


from torchvision.io import _read_video_from_file


from torchvision.io import read_video_timestamps


import torch.utils.data as data


from warnings import warn


from torchvision.ops import complete_box_iou_loss


from torchvision.ops import distance_box_iou_loss


from torchvision.ops import FrozenBatchNorm2d


from torchvision.ops import generalized_box_iou_loss


from torchvision.ops import misc as misc_nn_ops


from torchvision.ops.feature_pyramid_network import ExtraFPNBlock


from torchvision.ops.feature_pyramid_network import FeaturePyramidNetwork


from torchvision.ops.feature_pyramid_network import LastLevelMaxPool


from torchvision.ops import boxes as box_ops


from torchvision.ops import roi_align


from torchvision.ops import Conv2dNormActivation


from torch.nn.modules.batchnorm import BatchNorm2d


from torch.nn.modules.instancenorm import InstanceNorm2d


from torchvision.models import inception as inception_module


from torchvision.models.inception import Inception_V3_Weights


from torchvision.models.inception import InceptionOutputs


from torch.ao.quantization import DeQuantStub


from torch.ao.quantization import QuantStub


from torchvision.models.mobilenetv2 import InvertedResidual


from torchvision.models.mobilenetv2 import MobileNet_V2_Weights


from torchvision.models.mobilenetv2 import MobileNetV2


from torchvision.models.resnet import BasicBlock


from torchvision.models.resnet import Bottleneck


from torchvision.models.resnet import ResNet


from torchvision.models.resnet import ResNet18_Weights


from torchvision.models.resnet import ResNet50_Weights


from torchvision.models.resnet import ResNeXt101_32X8D_Weights


from torchvision.models.resnet import ResNeXt101_64X4D_Weights


from torchvision.models import shufflenetv2


from torchvision.ops.misc import Conv3dNormActivation


from inspect import signature


from typing import Set


import torch.utils.checkpoint as cp


from torchvision.ops import StochasticDepth


from torch import fx


from torch.fx.graph_module import _copy_attr


from torchvision.models._api import register_model


from torchvision.models._api import WeightsEnum


from torchvision.models._meta import _IMAGENET_CATEGORIES


from torchvision.models._utils import _ovewrite_named_param


from torchvision.ops.misc import Conv2dNormActivation


from torchvision.ops.misc import SqueezeExcitation


from torchvision.ops.stochastic_depth import StochasticDepth


from torchvision.transforms._presets import ImageClassification


from torchvision.transforms._presets import InterpolationMode


from torchvision.utils import _log_api_usage_once


import torch.nn.init as init


from typing import NamedTuple


from torch.onnx import symbolic_opset11 as opset11


from torch.onnx.symbolic_helper import parse_args


from torchvision.extension import _assert_has_ops


from torch.nn import init


from torch.nn.parameter import Parameter


from torchvision.ops.boxes import box_area


import torch._dynamo


from torch.jit.annotations import BroadcastingList2


from torchvision.extension import _has_ops


from torchvision.datapoints._datapoint import Datapoint


from typing import BinaryIO


from torchvision.prototype.datasets.utils._internal import hint_sharding


from torchvision.prototype.datasets.utils._internal import hint_shuffling


from torchvision.prototype.datasets.utils._internal import read_categories_file


from torchvision.prototype.datasets.utils._internal import read_mat


from torchvision.prototype.datasets.utils._internal import getitem


from torchvision.prototype.datasets.utils._internal import path_accessor


from torchvision.prototype.datasets.utils._internal import MappingIterator


from torchvision.prototype.datasets.utils._internal import path_comparator


from torchvision.prototype.datasets.utils import KaggleDownloadResource


import abc


from torchvision.prototype.utils._internal import fromfile


from torchvision.prototype.datapoints import OneHotLabel


from torchvision.prototype.utils._internal import ReadOnlyTensorBuffer


from torchvision import datasets as legacy_datasets


from torchvision.datasets.utils import extract_archive


from torchvision.prototype import datasets as new_datasets


from torchvision.transforms import PILToTensor


import torchvision.models.optical_flow.raft as raft


from torchvision.models.optical_flow._utils import grid_sample


from torchvision.models.optical_flow._utils import make_coords_grid


from torchvision.models.optical_flow._utils import upsample_flow


from torchvision.prototype.transforms._presets import StereoMatching


from torchvision.models.optical_flow.raft import FlowHead


from torchvision.models.optical_flow.raft import MotionEncoder


from torchvision.models.optical_flow.raft import ResidualBlock


from torchvision.prototype import datapoints as proto_datapoints


from torchvision.transforms.v2 import InterpolationMode


from torchvision.transforms.v2 import Transform


from torchvision.transforms.v2._transform import _RandomApplyTransform


from torchvision.transforms.v2.functional._geometry import _check_interpolation


from torchvision.transforms.v2._utils import _setup_fill_arg


from torchvision.transforms.v2._utils import _setup_size


from torchvision.transforms.v2.utils import query_bounding_box


from torchvision.transforms.v2._utils import _get_defaultdict


from typing import Collection


from torchvision.transforms.functional import pil_to_tensor


from torch.nn.functional import conv2d


from torchvision.transforms import _functional_pil as _FP


from torchvision.transforms._functional_tensor import _max_value


from torchvision.transforms import functional as _F


import numbers


from torch.nn.functional import grid_sample


from torch.nn.functional import interpolate


from torch.nn.functional import pad as torch_pad


from torchvision.transforms._functional_tensor import _pad_symmetric


from torchvision.transforms.functional import _check_antialias


from torchvision.transforms.functional import _compute_resized_output_size as __compute_resized_output_size


from torchvision.transforms.functional import _interpolation_modes_from_int


from torchvision import transforms as _transforms


from torch.utils._pytree import TreeSpec


from torchvision.transforms import _functional_tensor as _FT


from torchvision.transforms.v2 import AutoAugmentPolicy


from torchvision.transforms.v2.functional._meta import get_spatial_size


from typing import Literal


from torchvision.transforms import RandomCrop


from torchvision.transforms import RandomResizedCrop


from collections.abc import Sequence


from torchvision import _meta_registrations


from torchvision import utils


from torch.hub import _get_torch_home


import torch.library


import torchvision.extension


from types import FunctionType


from torchvision.models import get_weight


from torchvision.models.alexnet import alexnet


from torchvision.models.convnext import convnext_base


from torchvision.models.convnext import convnext_large


from torchvision.models.convnext import convnext_small


from torchvision.models.convnext import convnext_tiny


from torchvision.models.densenet import densenet121


from torchvision.models.densenet import densenet161


from torchvision.models.densenet import densenet169


from torchvision.models.densenet import densenet201


from torchvision.models.efficientnet import efficientnet_b0


from torchvision.models.efficientnet import efficientnet_b1


from torchvision.models.efficientnet import efficientnet_b2


from torchvision.models.efficientnet import efficientnet_b3


from torchvision.models.efficientnet import efficientnet_b4


from torchvision.models.efficientnet import efficientnet_b5


from torchvision.models.efficientnet import efficientnet_b6


from torchvision.models.efficientnet import efficientnet_b7


from torchvision.models.efficientnet import efficientnet_v2_l


from torchvision.models.efficientnet import efficientnet_v2_m


from torchvision.models.efficientnet import efficientnet_v2_s


from torchvision.models.googlenet import googlenet


from torchvision.models.inception import inception_v3


from torchvision.models.maxvit import maxvit_t


from torchvision.models.mnasnet import mnasnet0_5


from torchvision.models.mnasnet import mnasnet0_75


from torchvision.models.mnasnet import mnasnet1_0


from torchvision.models.mnasnet import mnasnet1_3


from torchvision.models.mobilenetv2 import mobilenet_v2


from torchvision.models.mobilenetv3 import mobilenet_v3_large


from torchvision.models.mobilenetv3 import mobilenet_v3_small


from torchvision.models.optical_flow import raft_small


from torchvision.models.regnet import regnet_x_16gf


from torchvision.models.regnet import regnet_x_1_6gf


from torchvision.models.regnet import regnet_x_32gf


from torchvision.models.regnet import regnet_x_3_2gf


from torchvision.models.regnet import regnet_x_400mf


from torchvision.models.regnet import regnet_x_800mf


from torchvision.models.regnet import regnet_x_8gf


from torchvision.models.regnet import regnet_y_128gf


from torchvision.models.regnet import regnet_y_16gf


from torchvision.models.regnet import regnet_y_1_6gf


from torchvision.models.regnet import regnet_y_32gf


from torchvision.models.regnet import regnet_y_3_2gf


from torchvision.models.regnet import regnet_y_400mf


from torchvision.models.regnet import regnet_y_800mf


from torchvision.models.regnet import regnet_y_8gf


from torchvision.models.resnet import resnet101


from torchvision.models.resnet import resnet152


from torchvision.models.resnet import resnet18


from torchvision.models.resnet import resnet34


from torchvision.models.resnet import resnet50


from torchvision.models.resnet import resnext101_32x8d


from torchvision.models.resnet import resnext101_64x4d


from torchvision.models.resnet import resnext50_32x4d


from torchvision.models.resnet import wide_resnet101_2


from torchvision.models.resnet import wide_resnet50_2


from torchvision.models.segmentation import deeplabv3_mobilenet_v3_large


from torchvision.models.segmentation import deeplabv3_resnet101


from torchvision.models.segmentation import deeplabv3_resnet50


from torchvision.models.segmentation import fcn_resnet101


from torchvision.models.segmentation import lraspp_mobilenet_v3_large


from torchvision.models.shufflenetv2 import shufflenet_v2_x0_5


from torchvision.models.shufflenetv2 import shufflenet_v2_x1_0


from torchvision.models.shufflenetv2 import shufflenet_v2_x1_5


from torchvision.models.shufflenetv2 import shufflenet_v2_x2_0


from torchvision.models.squeezenet import squeezenet1_0


from torchvision.models.squeezenet import squeezenet1_1


from torchvision.models.swin_transformer import swin_b


from torchvision.models.swin_transformer import swin_s


from torchvision.models.swin_transformer import swin_t


from torchvision.models.swin_transformer import swin_v2_b


from torchvision.models.swin_transformer import swin_v2_s


from torchvision.models.swin_transformer import swin_v2_t


from torchvision.models.vgg import vgg11


from torchvision.models.vgg import vgg11_bn


from torchvision.models.vgg import vgg13


from torchvision.models.vgg import vgg13_bn


from torchvision.models.vgg import vgg16


from torchvision.models.vgg import vgg16_bn


from torchvision.models.vgg import vgg19


from torchvision.models.vgg import vgg19_bn


from torchvision.models.video import mc3_18


from torchvision.models.video import mvit_v1_b


from torchvision.models.video import mvit_v2_s


from torchvision.models.video import r2plus1d_18


from torchvision.models.video import r3d_18


from torchvision.models.video import s3d


from torchvision.models.video import swin3d_b


from torchvision.models.video import swin3d_s


from torchvision.models.video import swin3d_t


from torchvision.models.vision_transformer import vit_b_16


from torchvision.models.vision_transformer import vit_b_32


from torchvision.models.vision_transformer import vit_h_14


from torchvision.models.vision_transformer import vit_l_16


from torchvision.models.vision_transformer import vit_l_32


from torch.utils.cpp_extension import BuildExtension


from torch.utils.cpp_extension import CppExtension


from torch.utils.cpp_extension import CUDA_HOME


from torch.utils.cpp_extension import CUDAExtension


class Predictor(nn.Module):

    def __init__(self):
        super().__init__()
        weights = ResNet18_Weights.DEFAULT
        self.resnet18 = resnet18(weights=weights, progress=False).eval()
        self.transforms = weights.transforms()

    def forward(self, x: 'torch.Tensor\n') ->torch.Tensor:
        with torch.no_grad():
            x = self.transforms(x)
            y_pred = self.resnet18(x)
            return y_pred.argmax(dim=1)


class _BaseMixupCutmix(_RandomApplyTransform):

    def __init__(self, alpha: 'float\n', p: 'float\n'=0.5) ->None:
        super().__init__(p=p)
        self.alpha = alpha
        self._dist = torch.distributions.Beta(torch.tensor([alpha]), torch.tensor([alpha]))

    def _check_inputs(self, flat_inputs: 'List[Any]\n') ->None:
        if not (has_any(flat_inputs, datapoints.Image, datapoints.Video, is_simple_tensor) and has_any(flat_inputs, proto_datapoints.OneHotLabel)):
            raise TypeError(f'{type(self).__name__}() is only defined for tensor images/videos and one-hot labels.')
        if has_any(flat_inputs, PIL.Image.Image, datapoints.BoundingBox, datapoints.Mask, proto_datapoints.Label):
            raise TypeError(f'{type(self).__name__}() does not support PIL images, bounding boxes, masks and plain labels.')

    def _mixup_onehotlabel(self, inpt: 'proto_datapoints.OneHotLabel\n', lam: 'float\n') ->proto_datapoints.OneHotLabel:
        if inpt.ndim < 2:
            raise ValueError('Need a batch of one hot labels')
        output = inpt.roll(1, 0).mul_(1.0 - lam).add_(inpt.mul(lam))
        return proto_datapoints.OneHotLabel.wrap_like(inpt, output)


class RandomMixup(_BaseMixupCutmix):

    def _get_params(self, flat_inputs: 'List[Any]\n') ->Dict[str, Any]:
        return dict(lam=float(self._dist.sample(())))

    def _transform(self, inpt: 'Any\n', params: 'Dict[(str, Any)]\n') ->Any:
        lam = params['lam']
        if isinstance(inpt, (datapoints.Image, datapoints.Video)) or is_simple_tensor(inpt):
            expected_ndim = 5 if isinstance(inpt, datapoints.Video) else 4
            if inpt.ndim < expected_ndim:
                raise ValueError('The transform expects a batched input')
            output = inpt.roll(1, 0).mul_(1.0 - lam).add_(inpt.mul(lam))
            if isinstance(inpt, (datapoints.Image, datapoints.Video)):
                output = type(inpt).wrap_like(inpt, output)
            return output
        elif isinstance(inpt, proto_datapoints.OneHotLabel):
            return self._mixup_onehotlabel(inpt, lam)
        else:
            return inpt


class RandomCutmix(_BaseMixupCutmix):

    def _get_params(self, flat_inputs: 'List[Any]\n') ->Dict[str, Any]:
        lam = float(self._dist.sample(()))
        H, W = query_spatial_size(flat_inputs)
        r_x = torch.randint(W, ())
        r_y = torch.randint(H, ())
        r = 0.5 * math.sqrt(1.0 - lam)
        r_w_half = int(r * W)
        r_h_half = int(r * H)
        x1 = int(torch.clamp(r_x - r_w_half, min=0))
        y1 = int(torch.clamp(r_y - r_h_half, min=0))
        x2 = int(torch.clamp(r_x + r_w_half, max=W))
        y2 = int(torch.clamp(r_y + r_h_half, max=H))
        box = x1, y1, x2, y2
        lam_adjusted = float(1.0 - (x2 - x1) * (y2 - y1) / (W * H))
        return dict(box=box, lam_adjusted=lam_adjusted)

    def _transform(self, inpt: 'Any\n', params: 'Dict[(str, Any)]\n') ->Any:
        if isinstance(inpt, (datapoints.Image, datapoints.Video)) or is_simple_tensor(inpt):
            box = params['box']
            expected_ndim = 5 if isinstance(inpt, datapoints.Video) else 4
            if inpt.ndim < expected_ndim:
                raise ValueError('The transform expects a batched input')
            x1, y1, x2, y2 = box
            rolled = inpt.roll(1, 0)
            output = inpt.clone()
            output[(...), y1:y2, x1:x2] = rolled[(...), y1:y2, x1:x2]
            if isinstance(inpt, (datapoints.Image, datapoints.Video)):
                output = inpt.wrap_like(inpt, output)
            return output
        elif isinstance(inpt, proto_datapoints.OneHotLabel):
            lam_adjusted = params['lam_adjusted']
            return self._mixup_onehotlabel(inpt, lam_adjusted)
        else:
            return inpt


class ExponentialMovingAverage(torch.optim.swa_utils.AveragedModel):
    """Maintains moving averages of model parameters using an exponential decay.
    ``ema_avg = decay * avg_model_param + (1 - decay) * model_param``
    `torch.optim.swa_utils.AveragedModel <https://pytorch.org/docs/stable/optim.html#custom-averaging-strategies>`_
    is used to compute the EMA.
    """

    def __init__(self, model, decay, device='cpu'):

        def ema_avg(avg_model_param, model_param, num_averaged):
            return decay * avg_model_param + (1 - decay) * model_param
        super().__init__(model, device, ema_avg, use_buffers=True)


def _sequence_loss_fn(flow_preds: 'List[Tensor]\n', flow_gt: 'Tensor\n', valid_flow_mask: 'Optional[Tensor]\n', gamma: 'Tensor\n', max_flow: 'int\n'=256, exclude_large: 'bool\n'=False, weights: 'Optional[Tensor]\n'=None):
    """Loss function defined over sequence of flow predictions"""
    torch._assert(gamma < 1, 'sequence_loss: `gamma` must be lower than 1, but got {}'.format(gamma))
    if exclude_large:
        flow_norm = torch.sum(flow_gt ** 2, dim=1).sqrt()
        if valid_flow_mask is not None:
            valid_flow_mask = valid_flow_mask & (flow_norm < max_flow)
        else:
            valid_flow_mask = flow_norm < max_flow
    if valid_flow_mask is not None:
        valid_flow_mask = valid_flow_mask.unsqueeze(1)
    flow_preds = torch.stack(flow_preds)
    abs_diff = (flow_preds - flow_gt).abs()
    if valid_flow_mask is not None:
        abs_diff = abs_diff * valid_flow_mask.unsqueeze(0)
    abs_diff = abs_diff.mean(axis=(1, 2, 3, 4))
    num_predictions = flow_preds.shape[0]
    if weights is None or len(weights) != num_predictions:
        weights = gamma ** torch.arange(num_predictions - 1, -1, -1, device=flow_preds.device, dtype=flow_preds.dtype)
    flow_loss = (abs_diff * weights).sum()
    return flow_loss, weights


class SequenceLoss(nn.Module):

    def __init__(self, gamma: 'float\n'=0.8, max_flow: 'int\n'=256, exclude_large_flows: 'bool\n'=False) ->None:
        """
        Args:
            gamma: value for the exponential weighting of the loss across frames
            max_flow: maximum flow value to exclude
            exclude_large_flows: whether to exclude large flows
        """
        super().__init__()
        self.max_flow = max_flow
        self.excluding_large = exclude_large_flows
        self.register_buffer('gamma', torch.tensor([gamma]))
        self._weights = None

    def forward(self, flow_preds: 'List[Tensor]\n', flow_gt: 'Tensor\n', valid_flow_mask: 'Optional[Tensor]\n') ->Tensor:
        """
        Args:
            flow_preds: list of flow predictions of shape (batch_size, C, H, W)
            flow_gt: ground truth flow of shape (batch_size, C, H, W)
            valid_flow_mask: mask of valid flow pixels of shape (batch_size, H, W)
        """
        loss, weights = _sequence_loss_fn(flow_preds, flow_gt, valid_flow_mask, self.gamma, self.max_flow, self.excluding_large, self._weights)
        self._weights = weights
        return loss

    def set_gamma(self, gamma: 'float\n') ->None:
        self.gamma.fill_(gamma)
        self._weights = None


def _ssim_loss_fn(source: 'Tensor\n', reference: 'Tensor\n', kernel: 'Tensor\n', eps: 'float\n'=1e-08, c1: 'float\n'=0.01 ** 2, c2: 'float\n'=0.03 ** 2, use_padding: 'bool\n'=False) ->Tensor:
    torch._assert(source.ndim == reference.ndim == 4, 'SSIM: `source` and `reference` must be 4-dimensional tensors')
    torch._assert(source.shape == reference.shape, 'SSIM: `source` and `reference` must have the same shape, but got {} and {}'.format(source.shape, reference.shape))
    B, C, H, W = source.shape
    kernel = kernel.unsqueeze(0).unsqueeze(0).repeat(C, 1, 1, 1)
    if use_padding:
        pad_size = kernel.shape[2] // 2
        source = F.pad(source, (pad_size, pad_size, pad_size, pad_size), 'reflect')
        reference = F.pad(reference, (pad_size, pad_size, pad_size, pad_size), 'reflect')
    mu1 = F.conv2d(source, kernel, groups=C)
    mu2 = F.conv2d(reference, kernel, groups=C)
    mu1_sq = mu1.pow(2)
    mu2_sq = mu2.pow(2)
    mu1_mu2 = mu1 * mu2
    mu_img1_sq = F.conv2d(source.pow(2), kernel, groups=C)
    mu_img2_sq = F.conv2d(reference.pow(2), kernel, groups=C)
    mu_img1_mu2 = F.conv2d(source * reference, kernel, groups=C)
    sigma1_sq = mu_img1_sq - mu1_sq
    sigma2_sq = mu_img2_sq - mu2_sq
    sigma12 = mu_img1_mu2 - mu1_mu2
    numerator = (2 * mu1_mu2 + c1) * (2 * sigma12 + c2)
    denominator = (mu1_sq + mu2_sq + c1) * (sigma1_sq + sigma2_sq + c2)
    ssim = numerator / (denominator + eps)
    return 1 - ssim.mean(dim=(1, 2, 3))


def make_gaussian_kernel(kernel_size: 'int\n', sigma: 'float\n') ->torch.Tensor:
    """Function to create a 2D Gaussian kernel."""
    x = torch.arange(kernel_size, dtype=torch.float32)
    y = torch.arange(kernel_size, dtype=torch.float32)
    x = x - (kernel_size - 1) / 2
    y = y - (kernel_size - 1) / 2
    x, y = torch.meshgrid(x, y)
    grid = (x ** 2 + y ** 2) / (2 * sigma ** 2)
    kernel = torch.exp(-grid)
    kernel = kernel / kernel.sum()
    return kernel


class SSIM(nn.Module):

    def __init__(self, kernel_size: 'int\n'=11, max_val: 'float\n'=1.0, sigma: 'float\n'=1.5, eps: 'float\n'=1e-12, use_padding: 'bool\n'=True) ->None:
        """SSIM loss function.

        Args:
            kernel_size: size of the Gaussian kernel
            max_val: constant scaling factor
            sigma: sigma of the Gaussian kernel
            eps: constant for division by zero
            use_padding: whether to pad the input tensor such that we have a score for each pixel
        """
        super().__init__()
        self.kernel_size = kernel_size
        self.max_val = max_val
        self.sigma = sigma
        gaussian_kernel = make_gaussian_kernel(kernel_size, sigma)
        self.register_buffer('gaussian_kernel', gaussian_kernel)
        self.c1 = (0.01 * self.max_val) ** 2
        self.c2 = (0.03 * self.max_val) ** 2
        self.use_padding = use_padding
        self.eps = eps

    def forward(self, source: 'torch.Tensor\n', reference: 'torch.Tensor\n') ->torch.Tensor:
        """
        Args:
            source: source image of shape (batch_size, C, H, W)
            reference: reference image of shape (batch_size, C, H, W)

        Returns:
            SSIM loss of shape (batch_size,)
        """
        return _ssim_loss_fn(source, reference, kernel=self.gaussian_kernel, c1=self.c1, c2=self.c2, use_padding=self.use_padding, eps=self.eps)


def _smoothness_loss_fn(img_gx: 'Tensor\n', img_gy: 'Tensor\n', val_gx: 'Tensor\n', val_gy: 'Tensor\n'):
    torch._assert(img_gx.ndim >= 3, 'smoothness_loss: `img_gx` must be at least 3-dimensional tensor of shape (..., C, H, W)')
    torch._assert(img_gx.ndim == val_gx.ndim, 'smoothness_loss: `img_gx` and `depth_gx` must have the same dimensionality, but got {} and {}'.format(img_gx.ndim, val_gx.ndim))
    for idx in range(img_gx.ndim):
        torch._assert(img_gx.shape[idx] == val_gx.shape[idx] or (img_gx.shape[idx] == 1 or val_gx.shape[idx] == 1), 'smoothness_loss: `img_gx` and `depth_gx` must have either the same shape or broadcastable shape, but got {} and {}'.format(img_gx.shape, val_gx.shape))
    weights_x = torch.exp(-torch.mean(torch.abs(val_gx), axis=-3, keepdim=True))
    weights_y = torch.exp(-torch.mean(torch.abs(val_gy), axis=-3, keepdim=True))
    smoothness_x = img_gx * weights_x
    smoothness_y = img_gy * weights_y
    smoothness = (torch.abs(smoothness_x) + torch.abs(smoothness_y)).mean(axis=(-3, -2, -1))
    return smoothness


class SmoothnessLoss(nn.Module):

    def __init__(self) ->None:
        super().__init__()

    def _x_gradient(self, img: 'Tensor\n') ->Tensor:
        if img.ndim > 4:
            original_shape = img.shape
            is_reshaped = True
            img = img.reshape(-1, *original_shape[-3:])
        else:
            is_reshaped = False
        padded = F.pad(img, (0, 1, 0, 0), mode='replicate')
        grad = padded[(...), :, :-1] - padded[(...), :, 1:]
        if is_reshaped:
            grad = grad.reshape(original_shape)
        return grad

    def _y_gradient(self, x: 'torch.Tensor\n') ->torch.Tensor:
        if x.ndim > 4:
            original_shape = x.shape
            is_reshaped = True
            x = x.reshape(-1, *original_shape[-3:])
        else:
            is_reshaped = False
        padded = F.pad(x, (0, 0, 0, 1), mode='replicate')
        grad = padded[(...), :-1, :] - padded[(...), 1:, :]
        if is_reshaped:
            grad = grad.reshape(original_shape)
        return grad

    def forward(self, images: 'Tensor\n', vals: 'Tensor\n') ->Tensor:
        """
        Args:
            images: tensor of shape (D1, D2, ..., DN, C, H, W)
            vals: tensor of shape (D1, D2, ..., DN, 1, H, W)

        Returns:
            smoothness loss of shape (D1, D2, ..., DN)
        """
        img_gx = self._x_gradient(images)
        img_gy = self._y_gradient(images)
        val_gx = self._x_gradient(vals)
        val_gy = self._y_gradient(vals)
        return _smoothness_loss_fn(img_gx, img_gy, val_gx, val_gy)


def _flow_sequence_consistency_loss_fn(flow_preds: 'List[Tensor]\n', gamma: 'float\n'=0.8, resize_factor: 'float\n'=0.25, rescale_factor: 'float\n'=0.25, rescale_mode: 'str\n'='bilinear', weights: 'Optional[Tensor]\n'=None):
    """Loss function defined over sequence of flow predictions"""
    torch._assert(rescale_factor <= 1.0, 'sequence_consistency_loss: `rescale_factor` must be less than or equal to 1, but got {}'.format(rescale_factor))
    flow_preds = torch.stack(flow_preds)
    N, B, C, H, W = flow_preds.shape
    if rescale_factor:
        flow_preds = F.interpolate(flow_preds.view(N * B, C, H, W), scale_factor=resize_factor, mode=rescale_mode, align_corners=True) * rescale_factor
        flow_preds = torch.stack(torch.chunk(flow_preds, N, dim=0), dim=0)
    abs_diff = (flow_preds[1:] - flow_preds[:-1]).square()
    abs_diff = abs_diff.mean(axis=(1, 2, 3, 4))
    num_predictions = flow_preds.shape[0] - 1
    if weights is None or len(weights) != num_predictions:
        weights = gamma ** torch.arange(num_predictions - 1, -1, -1, device=flow_preds.device, dtype=flow_preds.dtype)
    flow_loss = (abs_diff * weights).sum()
    return flow_loss, weights


class FlowSequenceConsistencyLoss(nn.Module):

    def __init__(self, gamma: 'float\n'=0.8, resize_factor: 'float\n'=0.25, rescale_factor: 'float\n'=0.25, rescale_mode: 'str\n'='bilinear') ->None:
        super().__init__()
        self.gamma = gamma
        self.resize_factor = resize_factor
        self.rescale_factor = rescale_factor
        self.rescale_mode = rescale_mode
        self._weights = None

    def forward(self, flow_preds: 'List[Tensor]\n') ->Tensor:
        """
        Args:
            flow_preds: list of tensors of shape (batch_size, C, H, W)

        Returns:
            sequence consistency loss of shape (batch_size,)
        """
        loss, weights = _flow_sequence_consistency_loss_fn(flow_preds, gamma=self.gamma, resize_factor=self.resize_factor, rescale_factor=self.rescale_factor, rescale_mode=self.rescale_mode, weights=self._weights)
        self._weights = weights
        return loss

    def set_gamma(self, gamma: 'float\n') ->None:
        self.gamma.fill_(gamma)
        self._weights = None


def _psnr_loss_fn(source: 'torch.Tensor\n', target: 'torch.Tensor\n', max_val: 'float\n') ->torch.Tensor:
    torch._assert(source.shape == target.shape, 'psnr_loss: source and target must have the same shape, but got {} and {}'.format(source.shape, target.shape))
    return 10 * torch.log10(max_val ** 2 / (source - target).pow(2).mean(axis=(-3, -2, -1)))


class PSNRLoss(nn.Module):

    def __init__(self, max_val: 'float\n'=256) ->None:
        """
        Args:
            max_val: maximum value of the input tensor. This refers to the maximum domain value of the input tensor.

        """
        super().__init__()
        self.max_val = max_val

    def forward(self, source: 'Tensor\n', target: 'Tensor\n') ->Tensor:
        """
        Args:
            source: tensor of shape (D1, D2, ..., DN, C, H, W)
            target: tensor of shape (D1, D2, ..., DN, C, H, W)

        Returns:
            psnr loss of shape (D1, D2, ..., DN)
        """
        return -1 * _psnr_loss_fn(source, target, self.max_val)


class FlowPhotoMetricLoss(nn.Module):

    def __init__(self, ssim_weight: 'float\n'=0.85, ssim_window_size: 'int\n'=11, ssim_max_val: 'float\n'=1.0, ssim_sigma: 'float\n'=1.5, ssim_eps: 'float\n'=1e-12, ssim_use_padding: 'bool\n'=True, max_displacement_ratio: 'float\n'=0.15) ->None:
        super().__init__()
        self._ssim_loss = SSIM(kernel_size=ssim_window_size, max_val=ssim_max_val, sigma=ssim_sigma, eps=ssim_eps, use_padding=ssim_use_padding)
        self._L1_weight = 1 - ssim_weight
        self._SSIM_weight = ssim_weight
        self._max_displacement_ratio = max_displacement_ratio

    def forward(self, source: 'Tensor\n', reference: 'Tensor\n', flow_pred: 'Tensor\n', valid_mask: 'Optional[Tensor]\n'=None):
        """
        Args:
            source: tensor of shape (B, C, H, W)
            reference: tensor of shape (B, C, H, W)
            flow_pred: tensor of shape (B, 2, H, W)
            valid_mask: tensor of shape (B, H, W) or None

        Returns:
            photometric loss of shape

        """
        torch._assert(source.ndim == 4, 'FlowPhotoMetricLoss: source must have 4 dimensions, but got {}'.format(source.ndim))
        torch._assert(reference.ndim == source.ndim, 'FlowPhotoMetricLoss: source and other must have the same number of dimensions, but got {} and {}'.format(source.ndim, reference.ndim))
        torch._assert(flow_pred.shape[1] == 2, 'FlowPhotoMetricLoss: flow_pred must have 2 channels, but got {}'.format(flow_pred.shape[1]))
        torch._assert(flow_pred.ndim == 4, 'FlowPhotoMetricLoss: flow_pred must have 4 dimensions, but got {}'.format(flow_pred.ndim))
        B, C, H, W = source.shape
        flow_channels = flow_pred.shape[1]
        max_displacements = []
        for dim in range(flow_channels):
            shape_index = -1 - dim
            max_displacements.append(int(self._max_displacement_ratio * source.shape[shape_index]))
        max_flow_mask = torch.logical_and(*[(flow_pred[:, (dim), :, :] < max_displacements[dim]) for dim in range(flow_channels)])
        if valid_mask is not None:
            valid_mask = torch.logical_and(valid_mask, max_flow_mask).unsqueeze(1)
        else:
            valid_mask = max_flow_mask.unsqueeze(1)
        grid = make_coords_grid(B, H, W, device=str(source.device))
        resampled_grids = grid - flow_pred
        resampled_grids = resampled_grids.permute(0, 2, 3, 1)
        resampled_source = grid_sample(reference, resampled_grids, mode='bilinear')
        ssim_loss = self._ssim_loss(resampled_source * valid_mask, source * valid_mask)
        l1_loss = (resampled_source * valid_mask - source * valid_mask).abs().mean(axis=(-3, -2, -1))
        loss = self._L1_weight * l1_loss + self._SSIM_weight * ssim_loss
        return loss.mean()


class StereoMatchingEvalPreset(torch.nn.Module):

    def __init__(self, mean: 'float\n'=0.5, std: 'float\n'=0.5, resize_size: 'Optional[Tuple[(int, ...)]]\n'=None, max_disparity: 'Optional[float]\n'=None, interpolation_type: 'str\n'='bilinear', use_grayscale: 'bool\n'=False) ->None:
        super().__init__()
        transforms = [T.ToTensor(), T.ConvertImageDtype(torch.float32)]
        if use_grayscale:
            transforms.append(T.ConvertToGrayscale())
        if resize_size is not None:
            transforms.append(T.Resize(resize_size, interpolation_type=interpolation_type))
        transforms.extend([T.Normalize(mean=mean, std=std), T.MakeValidDisparityMask(max_disparity=max_disparity), T.ValidateModelInput()])
        self.transforms = T.Compose(transforms)

    def forward(self, images, disparities, masks):
        return self.transforms(images, disparities, masks)


class StereoMatchingTrainPreset(torch.nn.Module):

    def __init__(self, *, resize_size: Optional[Tuple[int, ...]], resize_interpolation_type: str='bilinear', crop_size: Tuple[int, int], rescale_prob: float=1.0, scaling_type: str='exponential', scale_range: Tuple[float, float]=(-0.2, 0.5), scale_interpolation_type: str='bilinear', use_grayscale: bool=False, mean: float=0.5, std: float=0.5, gpu_transforms: bool=False, max_disparity: Optional[int]=256, spatial_shift_prob: float=0.5, spatial_shift_max_angle: float=0.5, spatial_shift_max_displacement: float=0.5, spatial_shift_interpolation_type: str='bilinear', gamma_range: Tuple[float, float]=(0.8, 1.2), brightness: Union[int, Tuple[int, int]]=(0.8, 1.2), contrast: Union[int, Tuple[int, int]]=(0.8, 1.2), saturation: Union[int, Tuple[int, int]]=0.0, hue: Union[int, Tuple[int, int]]=0.0, asymmetric_jitter_prob: float=1.0, horizontal_flip_prob: float=0.5, occlusion_prob: float=0.0, occlusion_px_range: Tuple[int, int]=(50, 100), erase_prob: float=0.0, erase_px_range: Tuple[int, int]=(50, 100), erase_num_repeats: int=1) ->None:
        if scaling_type not in ['linear', 'exponential']:
            raise ValueError(f'Unknown scaling type: {scaling_type}. Available types: linear, exponential')
        super().__init__()
        transforms = [T.ToTensor()]
        if resize_size is not None:
            transforms.append(T.Resize(resize_size, interpolation_type=resize_interpolation_type))
        if gpu_transforms:
            transforms.append(T.ToGPU())
        color_transforms = [T.AsymmetricColorJitter(brightness=brightness, contrast=contrast, saturation=saturation, hue=hue, p=asymmetric_jitter_prob), T.AsymetricGammaAdjust(p=asymmetric_jitter_prob, gamma_range=gamma_range)]
        if use_grayscale:
            color_transforms.append(T.ConvertToGrayscale())
        transforms.extend(color_transforms)
        transforms.extend([T.RandomSpatialShift(p=spatial_shift_prob, max_angle=spatial_shift_max_angle, max_px_shift=spatial_shift_max_displacement, interpolation_type=spatial_shift_interpolation_type), T.ConvertImageDtype(torch.float32), T.RandomRescaleAndCrop(crop_size=crop_size, scale_range=scale_range, rescale_prob=rescale_prob, scaling_type=scaling_type, interpolation_type=scale_interpolation_type), T.RandomHorizontalFlip(horizontal_flip_prob), T.RandomOcclusion(p=occlusion_prob, occlusion_px_range=occlusion_px_range), T.RandomErase(p=erase_prob, erase_px_range=erase_px_range, max_erase=erase_num_repeats), T.Normalize(mean=mean, std=std), T.MakeValidDisparityMask(max_disparity), T.ValidateModelInput()])
        self.transforms = T.Compose(transforms)

    def forward(self, images, disparties, mask):
        return self.transforms(images, disparties, mask)


all = 'CREStereo', 'CREStereo_Base_Weights', 'crestereo_base'


class ValidateModelInput(torch.nn.Module):

    def forward(self, img1, img2, flow, valid_flow_mask):
        if not all(isinstance(arg, torch.Tensor) for arg in (img1, img2, flow, valid_flow_mask) if arg is not None):
            raise TypeError('This method expects all input arguments to be of type torch.Tensor.')
        if not all(arg.dtype == torch.float32 for arg in (img1, img2, flow) if arg is not None):
            raise TypeError('This method expects the tensors img1, img2 and flow of be of dtype torch.float32.')
        if img1.shape != img2.shape:
            raise ValueError('img1 and img2 should have the same shape.')
        h, w = img1.shape[-2:]
        if flow is not None and flow.shape != (2, h, w):
            raise ValueError(f'flow.shape should be (2, {h}, {w}) instead of {flow.shape}')
        if valid_flow_mask is not None:
            if valid_flow_mask.shape != (h, w):
                raise ValueError(f'valid_flow_mask.shape should be ({h}, {w}) instead of {valid_flow_mask.shape}')
            if valid_flow_mask.dtype != torch.bool:
                raise TypeError('valid_flow_mask should be of dtype torch.bool instead of {valid_flow_mask.dtype}')
        return img1, img2, flow, valid_flow_mask


T_FLOW = Union[Tensor, np.ndarray, None]


T_MASK = Union[Tensor, np.ndarray, None]


T_STEREO_TENSOR = Tuple[Tensor, Tensor]


class ConvertToGrayscale(torch.nn.Module):

    def __init__(self) ->None:
        super().__init__()

    def forward(self, images: 'Tuple[(PIL.Image.Image, PIL.Image.Image)]\n', disparities: 'Tuple[(T_FLOW, T_FLOW)]\n', masks: 'Tuple[(T_MASK, T_MASK)]\n') ->Tuple[T_STEREO_TENSOR, Tuple[T_FLOW, T_FLOW], Tuple[T_MASK, T_MASK]]:
        img_left = F.rgb_to_grayscale(images[0], num_output_channels=3)
        img_right = F.rgb_to_grayscale(images[1], num_output_channels=3)
        return (img_left, img_right), disparities, masks


class MakeValidDisparityMask(torch.nn.Module):

    def __init__(self, max_disparity: 'Optional[int]\n'=256) ->None:
        super().__init__()
        self.max_disparity = max_disparity

    def forward(self, images: 'T_STEREO_TENSOR\n', disparities: 'Tuple[(T_FLOW, T_FLOW)]\n', masks: 'Tuple[(T_MASK, T_MASK)]\n') ->Tuple[T_STEREO_TENSOR, Tuple[T_FLOW, T_FLOW], Tuple[T_MASK, T_MASK]]:
        valid_masks = tuple(torch.ones(images[idx].shape[-2:], dtype=torch.bool, device=images[idx].device) if mask is None else mask for idx, mask in enumerate(masks))
        valid_masks = tuple(torch.logical_and(mask, disparity > 0).squeeze(0) if disparity is not None else mask for mask, disparity in zip(valid_masks, disparities))
        if self.max_disparity is not None:
            valid_masks = tuple(torch.logical_and(mask, disparity < self.max_disparity).squeeze(0) if disparity is not None else mask for mask, disparity in zip(valid_masks, disparities))
        return images, disparities, valid_masks


class ToGPU(torch.nn.Module):

    def __init__(self) ->None:
        super().__init__()

    def forward(self, images: 'T_STEREO_TENSOR\n', disparities: 'Tuple[(T_FLOW, T_FLOW)]\n', masks: 'Tuple[(T_MASK, T_MASK)]\n') ->Tuple[T_STEREO_TENSOR, Tuple[T_FLOW, T_FLOW], Tuple[T_MASK, T_MASK]]:
        dev_images = tuple(image for image in images)
        dev_disparities = tuple(map(lambda x: x if x is not None else None, disparities))
        dev_masks = tuple(map(lambda x: x if x is not None else None, masks))
        return dev_images, dev_disparities, dev_masks


class ConvertImageDtype(torch.nn.Module):
    """Convert a tensor image to the given ``dtype`` and scale the values accordingly.

    This function does not support PIL Image.

    Args:
        dtype (torch.dtype): Desired data type of the output

    .. note::

        When converting from a smaller to a larger integer ``dtype`` the maximum values are **not** mapped exactly.
        If converted back and forth, this mismatch has no effect.

    Raises:
        RuntimeError: When trying to cast :class:`torch.float32` to :class:`torch.int32` or :class:`torch.int64` as
            well as for trying to cast :class:`torch.float64` to :class:`torch.int64`. These conversions might lead to
            overflow errors since the floating point ``dtype`` cannot store consecutive integers over the whole range
            of the integer ``dtype``.
    """

    def __init__(self, dtype: 'torch.dtype\n') ->None:
        super().__init__()
        _log_api_usage_once(self)
        self.dtype = dtype

    def forward(self, image):
        return F.convert_image_dtype(image, self.dtype)


class Normalize(torch.nn.Module):
    """Normalize a tensor image with mean and standard deviation.
    This transform does not support PIL Image.
    Given mean: ``(mean[1],...,mean[n])`` and std: ``(std[1],..,std[n])`` for ``n``
    channels, this transform will normalize each channel of the input
    ``torch.*Tensor`` i.e.,
    ``output[channel] = (input[channel] - mean[channel]) / std[channel]``

    .. note::
        This transform acts out of place, i.e., it does not mutate the input tensor.

    Args:
        mean (sequence): Sequence of means for each channel.
        std (sequence): Sequence of standard deviations for each channel.
        inplace(bool,optional): Bool to make this operation in-place.

    """

    def __init__(self, mean, std, inplace=False):
        super().__init__()
        _log_api_usage_once(self)
        self.mean = mean
        self.std = std
        self.inplace = inplace

    def forward(self, tensor: 'Tensor\n') ->Tensor:
        """
        Args:
            tensor (Tensor): Tensor image to be normalized.

        Returns:
            Tensor: Normalized Tensor image.
        """
        return F.normalize(tensor, self.mean, self.std, self.inplace)

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}(mean={self.mean}, std={self.std})'


class ToTensor:
    """Convert a PIL Image or ndarray to tensor and scale the values accordingly.

    This transform does not support torchscript.

    Converts a PIL Image or numpy.ndarray (H x W x C) in the range
    [0, 255] to a torch.FloatTensor of shape (C x H x W) in the range [0.0, 1.0]
    if the PIL Image belongs to one of the modes (L, LA, P, I, F, RGB, YCbCr, RGBA, CMYK, 1)
    or if the numpy.ndarray has dtype = np.uint8

    In the other cases, tensors are returned without scaling.

    .. note::
        Because the input image is scaled to [0.0, 1.0], this transformation should not be used when
        transforming target image masks. See the `references`_ for implementing the transforms for image masks.

    .. _references: https://github.com/pytorch/vision/tree/main/references/segmentation
    """

    def __init__(self) ->None:
        _log_api_usage_once(self)

    def __call__(self, pic):
        """
        Args:
            pic (PIL Image or numpy.ndarray): Image to be converted to tensor.

        Returns:
            Tensor: Converted image.
        """
        return F.to_tensor(pic)

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}()'


def rand_float_range(size: 'Sequence[int]\n', low: 'float\n', high: 'float\n') ->Tensor:
    return (low - high) * torch.rand(size) + high


class AsymetricGammaAdjust(torch.nn.Module):

    def __init__(self, p: 'float\n', gamma_range: 'Tuple[(float, float)]\n', gain: 'float\n'=1) ->None:
        super().__init__()
        self.gamma_range = gamma_range
        self.gain = gain
        self.p = p

    def forward(self, images: 'T_STEREO_TENSOR\n', disparities: 'Tuple[(T_FLOW, T_FLOW)]\n', masks: 'Tuple[(T_MASK, T_MASK)]\n') ->Tuple[T_STEREO_TENSOR, Tuple[T_FLOW, T_FLOW], Tuple[T_MASK, T_MASK]]:
        gamma = rand_float_range((1,), low=self.gamma_range[0], high=self.gamma_range[1]).item()
        if torch.rand(1) < self.p:
            img_left = F.adjust_gamma(images[0], gamma, gain=self.gain)
            img_right = F.adjust_gamma(images[1], gamma, gain=self.gain)
        else:
            batch = torch.stack(images)
            batch = F.adjust_gamma(batch, gamma, gain=self.gain)
            img_left, img_right = batch[0], batch[1]
        return (img_left, img_right), disparities, masks


class RandomErase(torch.nn.Module):

    def __init__(self, p: 'float\n'=0.5, erase_px_range: 'Tuple[(int, int)]\n'=(50, 100), value: 'Union[(Tensor, float)]\n'=0, inplace: 'bool\n'=False, max_erase: 'int\n'=2):
        super().__init__()
        self.min_px_erase = erase_px_range[0]
        self.max_px_erase = erase_px_range[1]
        if self.max_px_erase < 0:
            raise ValueError('erase_px_range[1] should be equal or greater than 0')
        if self.min_px_erase < 0:
            raise ValueError('erase_px_range[0] should be equal or greater than 0')
        if self.min_px_erase > self.max_px_erase:
            raise ValueError('erase_prx_range[0] should be equal or lower than erase_px_range[1]')
        self.p = p
        self.value = value
        self.inplace = inplace
        self.max_erase = max_erase

    def forward(self, images: 'T_STEREO_TENSOR\n', disparities: 'T_STEREO_TENSOR\n', masks: 'T_STEREO_TENSOR\n') ->Tuple[T_STEREO_TENSOR, Tuple[T_FLOW, T_FLOW], Tuple[T_MASK, T_MASK]]:
        if torch.rand(1) < self.p:
            return images, disparities, masks
        image_left, image_right = images
        mask_left, mask_right = masks
        for _ in range(torch.randint(self.max_erase, size=(1,)).item()):
            y, x, h, w, v = self._get_params(image_left)
            image_right = F.erase(image_right, y, x, h, w, v, self.inplace)
            image_left = F.erase(image_left, y, x, h, w, v, self.inplace)
            if mask_left is not None:
                mask_left = F.erase(mask_left, y, x, h, w, False, self.inplace)
            if mask_right is not None:
                mask_right = F.erase(mask_right, y, x, h, w, False, self.inplace)
        return (image_left, image_right), disparities, (mask_left, mask_right)

    def _get_params(self, img: 'torch.Tensor\n') ->Tuple[int, int, int, int, float]:
        img_h, img_w = img.shape[-2:]
        crop_h, crop_w = random.randint(self.min_px_erase, self.max_px_erase), random.randint(self.min_px_erase, self.max_px_erase)
        crop_x, crop_y = random.randint(0, img_w - crop_w), random.randint(0, img_h - crop_h)
        return crop_y, crop_x, crop_h, crop_w, self.value


class RandomOcclusion(torch.nn.Module):

    def __init__(self, p: 'float\n'=0.5, occlusion_px_range: 'Tuple[(int, int)]\n'=(50, 100), inplace: 'bool\n'=False):
        super().__init__()
        self.min_px_occlusion = occlusion_px_range[0]
        self.max_px_occlusion = occlusion_px_range[1]
        if self.max_px_occlusion < 0:
            raise ValueError('occlusion_px_range[1] should be greater or equal than 0')
        if self.min_px_occlusion < 0:
            raise ValueError('occlusion_px_range[0] should be greater or equal than 0')
        if self.min_px_occlusion > self.max_px_occlusion:
            raise ValueError('occlusion_px_range[0] should be lower than occlusion_px_range[1]')
        self.p = p
        self.inplace = inplace

    def forward(self, images: 'T_STEREO_TENSOR\n', disparities: 'T_STEREO_TENSOR\n', masks: 'T_STEREO_TENSOR\n') ->Tuple[T_STEREO_TENSOR, Tuple[T_FLOW, T_FLOW], Tuple[T_MASK, T_MASK]]:
        left_image, right_image = images
        if torch.rand(1) < self.p:
            return images, disparities, masks
        y, x, h, w, v = self._get_params(right_image)
        right_image = F.erase(right_image, y, x, h, w, v, self.inplace)
        return (left_image, right_image), disparities, masks

    def _get_params(self, img: 'torch.Tensor\n') ->Tuple[int, int, int, int, float]:
        img_h, img_w = img.shape[-2:]
        crop_h, crop_w = random.randint(self.min_px_occlusion, self.max_px_occlusion), random.randint(self.min_px_occlusion, self.max_px_occlusion)
        crop_x, crop_y = random.randint(0, img_w - crop_w), random.randint(0, img_h - crop_h)
        occlusion_value = img[(...), crop_y:crop_y + crop_h, crop_x:crop_x + crop_w].mean(dim=(-2, -1), keepdim=True)
        return crop_y, crop_x, crop_h, crop_w, occlusion_value


class InterpolationStrategy:
    _valid_modes: 'List[str]\n' = ['mixed', 'bicubic', 'bilinear']

    def __init__(self, mode: 'str\n'='mixed') ->None:
        if mode not in self._valid_modes:
            raise ValueError(f'Invalid interpolation mode: {mode}. Valid modes are: {self._valid_modes}')
        if mode == 'mixed':
            self.strategies = [F.InterpolationMode.BILINEAR, F.InterpolationMode.BICUBIC]
        elif mode == 'bicubic':
            self.strategies = [F.InterpolationMode.BICUBIC]
        elif mode == 'bilinear':
            self.strategies = [F.InterpolationMode.BILINEAR]

    def __call__(self) ->F.InterpolationMode:
        return random.choice(self.strategies)

    @classmethod
    def is_valid(mode: 'str\n') ->bool:
        return mode in InterpolationStrategy._valid_modes

    @property
    def valid_modes() ->List[str]:
        return InterpolationStrategy._valid_modes


class RandomSpatialShift(torch.nn.Module):

    def __init__(self, p: 'float\n'=0.5, max_angle: 'float\n'=0.1, max_px_shift: 'int\n'=2, interpolation_type: 'str\n'='bilinear') ->None:
        super().__init__()
        self.p = p
        self.max_angle = max_angle
        self.max_px_shift = max_px_shift
        self._interpolation_mode_strategy = InterpolationStrategy(interpolation_type)

    def forward(self, images: 'T_STEREO_TENSOR\n', disparities: 'T_STEREO_TENSOR\n', masks: 'T_STEREO_TENSOR\n') ->Tuple[T_STEREO_TENSOR, Tuple[T_FLOW, T_FLOW], Tuple[T_MASK, T_MASK]]:
        img_left, img_right = images
        INTERP_MODE = self._interpolation_mode_strategy()
        if torch.rand(1) < self.p:
            shift = rand_float_range((1,), low=-self.max_px_shift, high=self.max_px_shift).item()
            angle = rand_float_range((1,), low=-self.max_angle, high=self.max_angle).item()
            y = torch.randint(size=(1,), low=0, high=img_right.shape[-2]).item()
            x = torch.randint(size=(1,), low=0, high=img_right.shape[-1]).item()
            img_right = F.affine(img_right, angle=angle, translate=[0, shift], center=[x, y], scale=1.0, shear=0.0, interpolation=INTERP_MODE)
        return (img_left, img_right), disparities, masks


class RandomHorizontalFlip(torch.nn.Module):
    """Horizontally flip the given image randomly with a given probability.
    If the image is torch Tensor, it is expected
    to have [..., H, W] shape, where ... means an arbitrary number of leading
    dimensions

    Args:
        p (float): probability of the image being flipped. Default value is 0.5
    """

    def __init__(self, p=0.5):
        super().__init__()
        _log_api_usage_once(self)
        self.p = p

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Image to be flipped.

        Returns:
            PIL Image or Tensor: Randomly flipped image.
        """
        if torch.rand(1) < self.p:
            return F.hflip(img)
        return img

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}(p={self.p})'


class Resize(torch.nn.Module):
    """Resize the input image to the given size.
    If the image is torch Tensor, it is expected
    to have [..., H, W] shape, where ... means a maximum of two leading dimensions

    .. warning::
        The output image might be different depending on its type: when downsampling, the interpolation of PIL images
        and tensors is slightly different, because PIL applies antialiasing. This may lead to significant differences
        in the performance of a network. Therefore, it is preferable to train and serve a model with the same input
        types. See also below the ``antialias`` parameter, which can help making the output of PIL images and tensors
        closer.

    Args:
        size (sequence or int): Desired output size. If size is a sequence like
            (h, w), output size will be matched to this. If size is an int,
            smaller edge of the image will be matched to this number.
            i.e, if height > width, then image will be rescaled to
            (size * height / width, size).

            .. note::
                In torchscript mode size as single int is not supported, use a sequence of length 1: ``[size, ]``.
        interpolation (InterpolationMode): Desired interpolation enum defined by
            :class:`torchvision.transforms.InterpolationMode`. Default is ``InterpolationMode.BILINEAR``.
            If input is Tensor, only ``InterpolationMode.NEAREST``, ``InterpolationMode.NEAREST_EXACT``,
            ``InterpolationMode.BILINEAR`` and ``InterpolationMode.BICUBIC`` are supported.
            The corresponding Pillow integer constants, e.g. ``PIL.Image.BILINEAR`` are accepted as well.
        max_size (int, optional): The maximum allowed for the longer edge of
            the resized image. If the longer edge of the image is greater
            than ``max_size`` after being resized according to ``size``,
            ``size`` will be overruled so that the longer edge is equal to
            ``max_size``.
            As a result, the smaller edge may be shorter than ``size``. This
            is only supported if ``size`` is an int (or a sequence of length
            1 in torchscript mode).
        antialias (bool, optional): Whether to apply antialiasing.
            It only affects **tensors** with bilinear or bicubic modes and it is
            ignored otherwise: on PIL images, antialiasing is always applied on
            bilinear or bicubic modes; on other modes (for PIL images and
            tensors), antialiasing makes no sense and this parameter is ignored.
            Possible values are:

            - ``True``: will apply antialiasing for bilinear or bicubic modes.
              Other mode aren't affected. This is probably what you want to use.
            - ``False``: will not apply antialiasing for tensors on any mode. PIL
              images are still antialiased on bilinear or bicubic modes, because
              PIL doesn't support no antialias.
            - ``None``: equivalent to ``False`` for tensors and ``True`` for
              PIL images. This value exists for legacy reasons and you probably
              don't want to use it unless you really know what you are doing.

            The current default is ``None`` **but will change to** ``True`` **in
            v0.17** for the PIL and Tensor backends to be consistent.
    """

    def __init__(self, size, interpolation=InterpolationMode.BILINEAR, max_size=None, antialias='warn'):
        super().__init__()
        _log_api_usage_once(self)
        if not isinstance(size, (int, Sequence)):
            raise TypeError(f'Size should be int or sequence. Got {type(size)}')
        if isinstance(size, Sequence) and len(size) not in (1, 2):
            raise ValueError('If size is a sequence, it should have 1 or 2 values')
        self.size = size
        self.max_size = max_size
        if isinstance(interpolation, int):
            interpolation = _interpolation_modes_from_int(interpolation)
        self.interpolation = interpolation
        self.antialias = antialias

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Image to be scaled.

        Returns:
            PIL Image or Tensor: Rescaled image.
        """
        return F.resize(img, self.size, self.interpolation, self.max_size, self.antialias)

    def __repr__(self) ->str:
        detail = f'(size={self.size}, interpolation={self.interpolation.value}, max_size={self.max_size}, antialias={self.antialias})'
        return f'{self.__class__.__name__}{detail}'


def _resize_sparse_flow(flow: 'Tensor\n', valid_flow_mask: 'Tensor\n', scale_x: 'float\n'=1.0, scale_y: 'float\n'=0.0) ->Tuple[Tensor, Tensor]:
    h, w = flow.shape[-2:]
    h_new = int(round(h * scale_y))
    w_new = int(round(w * scale_x))
    flow_new = torch.zeros(size=[1, h_new, w_new], dtype=flow.dtype)
    valid_new = torch.zeros(size=[h_new, w_new], dtype=valid_flow_mask.dtype)
    jj, ii = torch.meshgrid(torch.arange(w), torch.arange(h), indexing='xy')
    ii_valid, jj_valid = ii[valid_flow_mask], jj[valid_flow_mask]
    ii_valid_new = torch.round(ii_valid.to(float) * scale_y)
    jj_valid_new = torch.round(jj_valid.to(float) * scale_x)
    within_bounds_mask = (0 <= ii_valid_new) & (ii_valid_new < h_new) & (0 <= jj_valid_new) & (jj_valid_new < w_new)
    ii_valid = ii_valid[within_bounds_mask]
    jj_valid = jj_valid[within_bounds_mask]
    ii_valid_new = ii_valid_new[within_bounds_mask]
    jj_valid_new = jj_valid_new[within_bounds_mask]
    valid_flow_new = flow[:, (ii_valid), (jj_valid)]
    valid_flow_new *= scale_x
    flow_new[:, (ii_valid_new), (jj_valid_new)] = valid_flow_new
    valid_new[ii_valid_new, jj_valid_new] = valid_flow_mask[ii_valid, jj_valid]
    return flow_new, valid_new.bool()


class RandomRescaleAndCrop(torch.nn.Module):

    def __init__(self, crop_size: 'Tuple[(int, int)]\n', scale_range: 'Tuple[(float, float)]\n'=(-0.2, 0.5), rescale_prob: 'float\n'=0.8, scaling_type: 'str\n'='exponential', interpolation_type: 'str\n'='bilinear') ->None:
        super().__init__()
        self.crop_size = crop_size
        self.min_scale = scale_range[0]
        self.max_scale = scale_range[1]
        self.rescale_prob = rescale_prob
        self.scaling_type = scaling_type
        self._interpolation_mode_strategy = InterpolationStrategy(interpolation_type)
        if self.scaling_type == 'linear' and self.min_scale < 0:
            raise ValueError('min_scale must be >= 0 for linear scaling')

    def forward(self, images: 'T_STEREO_TENSOR\n', disparities: 'Tuple[(T_FLOW, T_FLOW)]\n', masks: 'Tuple[(T_MASK, T_MASK)]\n') ->Tuple[T_STEREO_TENSOR, Tuple[T_FLOW, T_FLOW], Tuple[T_MASK, T_MASK]]:
        img_left, img_right = images
        dsp_left, dsp_right = disparities
        mask_left, mask_right = masks
        INTERP_MODE = self._interpolation_mode_strategy()
        h, w = img_left.shape[-2:]
        min_scale = max((self.crop_size[0] + 8) / h, (self.crop_size[1] + 8) / w)
        if self.scaling_type == 'exponential':
            scale = 2 ** torch.empty(1, dtype=torch.float32).uniform_(self.min_scale, self.max_scale).item()
        elif self.scaling_type == 'linear':
            scale = torch.empty(1, dtype=torch.float32).uniform_(self.min_scale, self.max_scale).item()
        scale = max(scale, min_scale)
        new_h, new_w = round(h * scale), round(w * scale)
        if torch.rand(1).item() < self.rescale_prob:
            img_left = F.resize(img_left, size=(new_h, new_w), interpolation=INTERP_MODE)
            img_right = F.resize(img_right, size=(new_h, new_w), interpolation=INTERP_MODE)
            resized_masks, resized_disparities = (), ()
            for disparity, mask in zip(disparities, masks):
                if disparity is not None:
                    if mask is None:
                        resized_disparity = F.resize(disparity, size=(new_h, new_w), interpolation=INTERP_MODE)
                        resized_disparity = resized_disparity * torch.tensor([scale], device=resized_disparity.device)[:, (None), (None)]
                        resized_mask = None
                    else:
                        resized_disparity, resized_mask = _resize_sparse_flow(disparity, mask, scale_x=scale, scale_y=scale)
                resized_masks += resized_mask,
                resized_disparities += resized_disparity,
        else:
            resized_disparities = disparities
            resized_masks = masks
        disparities = resized_disparities
        masks = resized_masks
        y0 = torch.randint(0, img_left.shape[1] - self.crop_size[0], size=(1,)).item()
        x0 = torch.randint(0, img_right.shape[2] - self.crop_size[1], size=(1,)).item()
        img_left = F.crop(img_left, y0, x0, self.crop_size[0], self.crop_size[1])
        img_right = F.crop(img_right, y0, x0, self.crop_size[0], self.crop_size[1])
        if dsp_left is not None:
            dsp_left = F.crop(disparities[0], y0, x0, self.crop_size[0], self.crop_size[1])
        if dsp_right is not None:
            dsp_right = F.crop(disparities[1], y0, x0, self.crop_size[0], self.crop_size[1])
        cropped_masks = ()
        for mask in masks:
            if mask is not None:
                mask = F.crop(mask, y0, x0, self.crop_size[0], self.crop_size[1])
            cropped_masks += mask,
        return (img_left, img_right), (dsp_left, dsp_right), cropped_masks


class Compose:
    """Composes several transforms together. This transform does not support torchscript.
    Please, see the note below.

    Args:
        transforms (list of ``Transform`` objects): list of transforms to compose.

    Example:
        >>> transforms.Compose([
        >>>     transforms.CenterCrop(10),
        >>>     transforms.PILToTensor(),
        >>>     transforms.ConvertImageDtype(torch.float),
        >>> ])

    .. note::
        In order to script the transformations, please use ``torch.nn.Sequential`` as below.

        >>> transforms = torch.nn.Sequential(
        >>>     transforms.CenterCrop(10),
        >>>     transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225)),
        >>> )
        >>> scripted_transforms = torch.jit.script(transforms)

        Make sure to use only scriptable transformations, i.e. that work with ``torch.Tensor``, does not require
        `lambda` functions or ``PIL.Image``.

    """

    def __init__(self, transforms):
        if not torch.jit.is_scripting() and not torch.jit.is_tracing():
            _log_api_usage_once(self)
        self.transforms = transforms

    def __call__(self, img):
        for t in self.transforms:
            img = t(img)
        return img

    def __repr__(self) ->str:
        format_string = self.__class__.__name__ + '('
        for t in self.transforms:
            format_string += '\n'
            format_string += f'    {t}'
        format_string += '\n)'
        return format_string


class PILToTensor:
    """Convert a PIL Image to a tensor of the same type - this does not scale values.

    This transform does not support torchscript.

    Converts a PIL Image (H x W x C) to a Tensor of shape (C x H x W).
    """

    def __init__(self) ->None:
        _log_api_usage_once(self)

    def __call__(self, pic):
        """
        .. note::

            A deep copy of the underlying array is performed.

        Args:
            pic (PIL Image): Image to be converted to tensor.

        Returns:
            Tensor: Converted image.
        """
        return F.pil_to_tensor(pic)

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}()'


class RandomIoUCrop(Transform):
    """[BETA] Random IoU crop transformation from
    `"SSD: Single Shot MultiBox Detector" <https://arxiv.org/abs/1512.02325>`_.

    .. v2betastatus:: RandomIoUCrop transform

    This transformation requires an image or video data and ``datapoints.BoundingBox`` in the input.

    .. warning::
        In order to properly remove the bounding boxes below the IoU threshold, `RandomIoUCrop`
        must be followed by :class:`~torchvision.transforms.v2.SanitizeBoundingBox`, either immediately
        after or later in the transforms pipeline.

    If the input is a :class:`torch.Tensor` or a ``Datapoint`` (e.g. :class:`~torchvision.datapoints.Image`,
    :class:`~torchvision.datapoints.Video`, :class:`~torchvision.datapoints.BoundingBox` etc.)
    it can have arbitrary number of leading batch dimensions. For example,
    the image can have ``[..., C, H, W]`` shape. A bounding box can have ``[..., 4]`` shape.

    Args:
        min_scale (float, optional): Minimum factors to scale the input size.
        max_scale (float, optional): Maximum factors to scale the input size.
        min_aspect_ratio (float, optional): Minimum aspect ratio for the cropped image or video.
        max_aspect_ratio (float, optional): Maximum aspect ratio for the cropped image or video.
        sampler_options (list of float, optional): List of minimal IoU (Jaccard) overlap between all the boxes and
            a cropped image or video. Default, ``None`` which corresponds to ``[0.0, 0.1, 0.3, 0.5, 0.7, 0.9, 1.0]``
        trials (int, optional): Number of trials to find a crop for a given value of minimal IoU (Jaccard) overlap.
            Default, 40.
    """

    def __init__(self, min_scale: 'float\n'=0.3, max_scale: 'float\n'=1.0, min_aspect_ratio: 'float\n'=0.5, max_aspect_ratio: 'float\n'=2.0, sampler_options: 'Optional[List[float]]\n'=None, trials: 'int\n'=40):
        super().__init__()
        self.min_scale = min_scale
        self.max_scale = max_scale
        self.min_aspect_ratio = min_aspect_ratio
        self.max_aspect_ratio = max_aspect_ratio
        if sampler_options is None:
            sampler_options = [0.0, 0.1, 0.3, 0.5, 0.7, 0.9, 1.0]
        self.options = sampler_options
        self.trials = trials

    def _check_inputs(self, flat_inputs: 'List[Any]\n') ->None:
        if not (has_all(flat_inputs, datapoints.BoundingBox) and has_any(flat_inputs, PIL.Image.Image, datapoints.Image, is_simple_tensor)):
            raise TypeError(f'{type(self).__name__}() requires input sample to contain tensor or PIL images and bounding boxes. Sample can also contain masks.')

    def _get_params(self, flat_inputs: 'List[Any]\n') ->Dict[str, Any]:
        orig_h, orig_w = query_spatial_size(flat_inputs)
        bboxes = query_bounding_box(flat_inputs)
        while True:
            idx = int(torch.randint(low=0, high=len(self.options), size=(1,)))
            min_jaccard_overlap = self.options[idx]
            if min_jaccard_overlap >= 1.0:
                return dict()
            for _ in range(self.trials):
                r = self.min_scale + (self.max_scale - self.min_scale) * torch.rand(2)
                new_w = int(orig_w * r[0])
                new_h = int(orig_h * r[1])
                aspect_ratio = new_w / new_h
                if not self.min_aspect_ratio <= aspect_ratio <= self.max_aspect_ratio:
                    continue
                r = torch.rand(2)
                left = int((orig_w - new_w) * r[0])
                top = int((orig_h - new_h) * r[1])
                right = left + new_w
                bottom = top + new_h
                if left == right or top == bottom:
                    continue
                xyxy_bboxes = F.convert_format_bounding_box(bboxes.as_subclass(torch.Tensor), bboxes.format, datapoints.BoundingBoxFormat.XYXY)
                cx = 0.5 * (xyxy_bboxes[..., 0] + xyxy_bboxes[..., 2])
                cy = 0.5 * (xyxy_bboxes[..., 1] + xyxy_bboxes[..., 3])
                is_within_crop_area = (left < cx) & (cx < right) & (top < cy) & (cy < bottom)
                if not is_within_crop_area.any():
                    continue
                xyxy_bboxes = xyxy_bboxes[is_within_crop_area]
                ious = box_iou(xyxy_bboxes, torch.tensor([[left, top, right, bottom]], dtype=xyxy_bboxes.dtype, device=xyxy_bboxes.device))
                if ious.max() < min_jaccard_overlap:
                    continue
                return dict(top=top, left=left, height=new_h, width=new_w, is_within_crop_area=is_within_crop_area)

    def _transform(self, inpt: 'Any\n', params: 'Dict[(str, Any)]\n') ->Any:
        if len(params) < 1:
            return inpt
        output = F.crop(inpt, top=params['top'], left=params['left'], height=params['height'], width=params['width'])
        if isinstance(output, datapoints.BoundingBox):
            output[~params['is_within_crop_area']] = 0
        return output


def _check_sequence_input(x, name, req_sizes):
    msg = req_sizes[0] if len(req_sizes) < 2 else ' or '.join([str(s) for s in req_sizes])
    if not isinstance(x, Sequence):
        raise TypeError(f'{name} should be a sequence of length {msg}.')
    if len(x) not in req_sizes:
        raise ValueError(f'{name} should be a sequence of length {msg}.')


class RandomZoomOut(_RandomApplyTransform):
    """[BETA] "Zoom out" transformation from
    `"SSD: Single Shot MultiBox Detector" <https://arxiv.org/abs/1512.02325>`_.

    .. v2betastatus:: RandomZoomOut transform

    This transformation randomly pads images, videos, bounding boxes and masks creating a zoom out effect.
    Output spatial size is randomly sampled from original size up to a maximum size configured
    with ``side_range`` parameter:

    .. code-block:: python

        r = uniform_sample(side_range[0], side_range[1])
        output_width = input_width * r
        output_height = input_height * r

    If the input is a :class:`torch.Tensor` or a ``Datapoint`` (e.g. :class:`~torchvision.datapoints.Image`,
    :class:`~torchvision.datapoints.Video`, :class:`~torchvision.datapoints.BoundingBox` etc.)
    it can have arbitrary number of leading batch dimensions. For example,
    the image can have ``[..., C, H, W]`` shape. A bounding box can have ``[..., 4]`` shape.

    Args:
        fill (number or tuple or dict, optional): Pixel fill value used when the  ``padding_mode`` is constant.
            Default is 0. If a tuple of length 3, it is used to fill R, G, B channels respectively.
            Fill value can be also a dictionary mapping data type to the fill value, e.g.
            ``fill={datapoints.Image: 127, datapoints.Mask: 0}`` where ``Image`` will be filled with 127 and
            ``Mask`` will be filled with 0.
        side_range (sequence of floats, optional): tuple of two floats defines minimum and maximum factors to
            scale the input size.
        p (float, optional): probability of the input being flipped. Default value is 0.5
    """

    def __init__(self, fill: 'Union[(datapoints._FillType, Dict[(Type, datapoints._FillType)])]\n'=0, side_range: 'Sequence[float]\n'=(1.0, 4.0), p: 'float\n'=0.5) ->None:
        super().__init__(p=p)
        self.fill = fill
        self._fill = _setup_fill_arg(fill)
        _check_sequence_input(side_range, 'side_range', req_sizes=(2,))
        self.side_range = side_range
        if side_range[0] < 1.0 or side_range[0] > side_range[1]:
            raise ValueError(f'Invalid canvas side range provided {side_range}.')

    def _get_params(self, flat_inputs: 'List[Any]\n') ->Dict[str, Any]:
        orig_h, orig_w = query_spatial_size(flat_inputs)
        r = self.side_range[0] + torch.rand(1) * (self.side_range[1] - self.side_range[0])
        canvas_width = int(orig_w * r)
        canvas_height = int(orig_h * r)
        r = torch.rand(2)
        left = int((canvas_width - orig_w) * r[0])
        top = int((canvas_height - orig_h) * r[1])
        right = canvas_width - (left + orig_w)
        bottom = canvas_height - (top + orig_h)
        padding = [left, top, right, bottom]
        return dict(padding=padding)

    def _transform(self, inpt: 'Any\n', params: 'Dict[(str, Any)]\n') ->Any:
        fill = self._fill[type(inpt)]
        return F.pad(inpt, **params, fill=fill)


class ColorJitter(torch.nn.Module):
    """Randomly change the brightness, contrast, saturation and hue of an image.
    If the image is torch Tensor, it is expected
    to have [..., 1 or 3, H, W] shape, where ... means an arbitrary number of leading dimensions.
    If img is PIL Image, mode "1", "I", "F" and modes with transparency (alpha channel) are not supported.

    Args:
        brightness (float or tuple of float (min, max)): How much to jitter brightness.
            brightness_factor is chosen uniformly from [max(0, 1 - brightness), 1 + brightness]
            or the given [min, max]. Should be non negative numbers.
        contrast (float or tuple of float (min, max)): How much to jitter contrast.
            contrast_factor is chosen uniformly from [max(0, 1 - contrast), 1 + contrast]
            or the given [min, max]. Should be non-negative numbers.
        saturation (float or tuple of float (min, max)): How much to jitter saturation.
            saturation_factor is chosen uniformly from [max(0, 1 - saturation), 1 + saturation]
            or the given [min, max]. Should be non negative numbers.
        hue (float or tuple of float (min, max)): How much to jitter hue.
            hue_factor is chosen uniformly from [-hue, hue] or the given [min, max].
            Should have 0<= hue <= 0.5 or -0.5 <= min <= max <= 0.5.
            To jitter hue, the pixel values of the input image has to be non-negative for conversion to HSV space;
            thus it does not work if you normalize your image to an interval with negative values,
            or use an interpolation that generates negative values before using this function.
    """

    def __init__(self, brightness: 'Union[(float, Tuple[(float, float)])]\n'=0, contrast: 'Union[(float, Tuple[(float, float)])]\n'=0, saturation: 'Union[(float, Tuple[(float, float)])]\n'=0, hue: 'Union[(float, Tuple[(float, float)])]\n'=0) ->None:
        super().__init__()
        _log_api_usage_once(self)
        self.brightness = self._check_input(brightness, 'brightness')
        self.contrast = self._check_input(contrast, 'contrast')
        self.saturation = self._check_input(saturation, 'saturation')
        self.hue = self._check_input(hue, 'hue', center=0, bound=(-0.5, 0.5), clip_first_on_zero=False)

    @torch.jit.unused
    def _check_input(self, value, name, center=1, bound=(0, float('inf')), clip_first_on_zero=True):
        if isinstance(value, numbers.Number):
            if value < 0:
                raise ValueError(f'If {name} is a single number, it must be non negative.')
            value = [center - float(value), center + float(value)]
            if clip_first_on_zero:
                value[0] = max(value[0], 0.0)
        elif isinstance(value, (tuple, list)) and len(value) == 2:
            value = [float(value[0]), float(value[1])]
        else:
            raise TypeError(f'{name} should be a single number or a list/tuple with length 2.')
        if not bound[0] <= value[0] <= value[1] <= bound[1]:
            raise ValueError(f'{name} values should be between {bound}, but got {value}.')
        if value[0] == value[1] == center:
            return None
        else:
            return tuple(value)

    @staticmethod
    def get_params(brightness: 'Optional[List[float]]\n', contrast: 'Optional[List[float]]\n', saturation: 'Optional[List[float]]\n', hue: 'Optional[List[float]]\n') ->Tuple[Tensor, Optional[float], Optional[float], Optional[float], Optional[float]]:
        """Get the parameters for the randomized transform to be applied on image.

        Args:
            brightness (tuple of float (min, max), optional): The range from which the brightness_factor is chosen
                uniformly. Pass None to turn off the transformation.
            contrast (tuple of float (min, max), optional): The range from which the contrast_factor is chosen
                uniformly. Pass None to turn off the transformation.
            saturation (tuple of float (min, max), optional): The range from which the saturation_factor is chosen
                uniformly. Pass None to turn off the transformation.
            hue (tuple of float (min, max), optional): The range from which the hue_factor is chosen uniformly.
                Pass None to turn off the transformation.

        Returns:
            tuple: The parameters used to apply the randomized transform
            along with their random order.
        """
        fn_idx = torch.randperm(4)
        b = None if brightness is None else float(torch.empty(1).uniform_(brightness[0], brightness[1]))
        c = None if contrast is None else float(torch.empty(1).uniform_(contrast[0], contrast[1]))
        s = None if saturation is None else float(torch.empty(1).uniform_(saturation[0], saturation[1]))
        h = None if hue is None else float(torch.empty(1).uniform_(hue[0], hue[1]))
        return fn_idx, b, c, s, h

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Input image.

        Returns:
            PIL Image or Tensor: Color jittered image.
        """
        fn_idx, brightness_factor, contrast_factor, saturation_factor, hue_factor = self.get_params(self.brightness, self.contrast, self.saturation, self.hue)
        for fn_id in fn_idx:
            if fn_id == 0 and brightness_factor is not None:
                img = F.adjust_brightness(img, brightness_factor)
            elif fn_id == 1 and contrast_factor is not None:
                img = F.adjust_contrast(img, contrast_factor)
            elif fn_id == 2 and saturation_factor is not None:
                img = F.adjust_saturation(img, saturation_factor)
            elif fn_id == 3 and hue_factor is not None:
                img = F.adjust_hue(img, hue_factor)
        return img

    def __repr__(self) ->str:
        s = f'{self.__class__.__name__}(brightness={self.brightness}, contrast={self.contrast}, saturation={self.saturation}, hue={self.hue})'
        return s


class ScaleJitter(Transform):
    """[BETA] Perform Large Scale Jitter on the input according to
    `"Simple Copy-Paste is a Strong Data Augmentation Method for Instance Segmentation" <https://arxiv.org/abs/2012.07177>`_.

    .. v2betastatus:: ScaleJitter transform

    If the input is a :class:`torch.Tensor` or a ``Datapoint`` (e.g. :class:`~torchvision.datapoints.Image`,
    :class:`~torchvision.datapoints.Video`, :class:`~torchvision.datapoints.BoundingBox` etc.)
    it can have arbitrary number of leading batch dimensions. For example,
    the image can have ``[..., C, H, W]`` shape. A bounding box can have ``[..., 4]`` shape.

    Args:
        target_size (tuple of int): Target size. This parameter defines base scale for jittering,
            e.g. ``min(target_size[0] / width, target_size[1] / height)``.
        scale_range (tuple of float, optional): Minimum and maximum of the scale range. Default, ``(0.1, 2.0)``.
        interpolation (InterpolationMode, optional): Desired interpolation enum defined by
            :class:`torchvision.transforms.InterpolationMode`. Default is ``InterpolationMode.BILINEAR``.
            If input is Tensor, only ``InterpolationMode.NEAREST``, ``InterpolationMode.NEAREST_EXACT``,
            ``InterpolationMode.BILINEAR`` and ``InterpolationMode.BICUBIC`` are supported.
            The corresponding Pillow integer constants, e.g. ``PIL.Image.BILINEAR`` are accepted as well.
        antialias (bool, optional): Whether to apply antialiasing.
            It only affects **tensors** with bilinear or bicubic modes and it is
            ignored otherwise: on PIL images, antialiasing is always applied on
            bilinear or bicubic modes; on other modes (for PIL images and
            tensors), antialiasing makes no sense and this parameter is ignored.
            Possible values are:

            - ``True``: will apply antialiasing for bilinear or bicubic modes.
              Other mode aren't affected. This is probably what you want to use.
            - ``False``: will not apply antialiasing for tensors on any mode. PIL
              images are still antialiased on bilinear or bicubic modes, because
              PIL doesn't support no antialias.
            - ``None``: equivalent to ``False`` for tensors and ``True`` for
              PIL images. This value exists for legacy reasons and you probably
              don't want to use it unless you really know what you are doing.

            The current default is ``None`` **but will change to** ``True`` **in
            v0.17** for the PIL and Tensor backends to be consistent.
    """

    def __init__(self, target_size: 'Tuple[(int, int)]\n', scale_range: 'Tuple[(float, float)]\n'=(0.1, 2.0), interpolation: 'Union[(InterpolationMode, int)]\n'=InterpolationMode.BILINEAR, antialias: 'Optional[Union[(str, bool)]]\n'='warn'):
        super().__init__()
        self.target_size = target_size
        self.scale_range = scale_range
        self.interpolation = _check_interpolation(interpolation)
        self.antialias = antialias

    def _get_params(self, flat_inputs: 'List[Any]\n') ->Dict[str, Any]:
        orig_height, orig_width = query_spatial_size(flat_inputs)
        scale = self.scale_range[0] + torch.rand(1) * (self.scale_range[1] - self.scale_range[0])
        r = min(self.target_size[1] / orig_height, self.target_size[0] / orig_width) * scale
        new_width = int(orig_width * r)
        new_height = int(orig_height * r)
        return dict(size=(new_height, new_width))

    def _transform(self, inpt: 'Any\n', params: 'Dict[(str, Any)]\n') ->Any:
        return F.resize(inpt, size=params['size'], interpolation=self.interpolation, antialias=self.antialias)


class FixedSizeCrop(Transform):

    def __init__(self, size: 'Union[(int, Sequence[int])]\n', fill: 'Union[(datapoints._FillType, Dict[(Type, datapoints._FillType)])]\n'=0, padding_mode: 'str\n'='constant') ->None:
        super().__init__()
        size = tuple(_setup_size(size, error_msg='Please provide only two dimensions (h, w) for size.'))
        self.crop_height = size[0]
        self.crop_width = size[1]
        self.fill = fill
        self._fill = _setup_fill_arg(fill)
        self.padding_mode = padding_mode

    def _check_inputs(self, flat_inputs: 'List[Any]\n') ->None:
        if not has_any(flat_inputs, PIL.Image.Image, datapoints.Image, is_simple_tensor, datapoints.Video):
            raise TypeError(f'{type(self).__name__}() requires input sample to contain an tensor or PIL image or a Video.')
        if has_any(flat_inputs, datapoints.BoundingBox) and not has_any(flat_inputs, Label, OneHotLabel):
            raise TypeError(f'If a BoundingBox is contained in the input sample, {type(self).__name__}() also requires it to contain a Label or OneHotLabel.')

    def _get_params(self, flat_inputs: 'List[Any]\n') ->Dict[str, Any]:
        height, width = query_spatial_size(flat_inputs)
        new_height = min(height, self.crop_height)
        new_width = min(width, self.crop_width)
        needs_crop = new_height != height or new_width != width
        offset_height = max(height - self.crop_height, 0)
        offset_width = max(width - self.crop_width, 0)
        r = torch.rand(1)
        top = int(offset_height * r)
        left = int(offset_width * r)
        bounding_boxes: 'Optional[torch.Tensor]\n'
        try:
            bounding_boxes = query_bounding_box(flat_inputs)
        except ValueError:
            bounding_boxes = None
        if needs_crop and bounding_boxes is not None:
            format = bounding_boxes.format
            bounding_boxes, spatial_size = F.crop_bounding_box(bounding_boxes.as_subclass(torch.Tensor), format=format, top=top, left=left, height=new_height, width=new_width)
            bounding_boxes = F.clamp_bounding_box(bounding_boxes, format=format, spatial_size=spatial_size)
            height_and_width = F.convert_format_bounding_box(bounding_boxes, old_format=format, new_format=datapoints.BoundingBoxFormat.XYWH)[(...), 2:]
            is_valid = torch.all(height_and_width > 0, dim=-1)
        else:
            is_valid = None
        pad_bottom = max(self.crop_height - new_height, 0)
        pad_right = max(self.crop_width - new_width, 0)
        needs_pad = pad_bottom != 0 or pad_right != 0
        return dict(needs_crop=needs_crop, top=top, left=left, height=new_height, width=new_width, is_valid=is_valid, padding=[0, 0, pad_right, pad_bottom], needs_pad=needs_pad)

    def _transform(self, inpt: 'Any\n', params: 'Dict[(str, Any)]\n') ->Any:
        if params['needs_crop']:
            inpt = F.crop(inpt, top=params['top'], left=params['left'], height=params['height'], width=params['width'])
        if params['is_valid'] is not None:
            if isinstance(inpt, (Label, OneHotLabel, datapoints.Mask)):
                inpt = inpt.wrap_like(inpt, inpt[params['is_valid']])
            elif isinstance(inpt, datapoints.BoundingBox):
                inpt = datapoints.BoundingBox.wrap_like(inpt, F.clamp_bounding_box(inpt[params['is_valid']], format=inpt.format, spatial_size=inpt.spatial_size))
        if params['needs_pad']:
            fill = self._fill[type(inpt)]
            inpt = F.pad(inpt, params['padding'], fill=fill, padding_mode=self.padding_mode)
        return inpt


class RandomShortestSize(Transform):
    """[BETA] Randomly resize the input.

    .. v2betastatus:: RandomShortestSize transform

    If the input is a :class:`torch.Tensor` or a ``Datapoint`` (e.g. :class:`~torchvision.datapoints.Image`,
    :class:`~torchvision.datapoints.Video`, :class:`~torchvision.datapoints.BoundingBox` etc.)
    it can have arbitrary number of leading batch dimensions. For example,
    the image can have ``[..., C, H, W]`` shape. A bounding box can have ``[..., 4]`` shape.

    Args:
        min_size (int or sequence of int): Minimum spatial size. Single integer value or a sequence of integer values.
        max_size (int, optional): Maximum spatial size. Default, None.
        interpolation (InterpolationMode, optional): Desired interpolation enum defined by
            :class:`torchvision.transforms.InterpolationMode`. Default is ``InterpolationMode.BILINEAR``.
            If input is Tensor, only ``InterpolationMode.NEAREST``, ``InterpolationMode.NEAREST_EXACT``,
            ``InterpolationMode.BILINEAR`` and ``InterpolationMode.BICUBIC`` are supported.
            The corresponding Pillow integer constants, e.g. ``PIL.Image.BILINEAR`` are accepted as well.
        antialias (bool, optional): Whether to apply antialiasing.
            It only affects **tensors** with bilinear or bicubic modes and it is
            ignored otherwise: on PIL images, antialiasing is always applied on
            bilinear or bicubic modes; on other modes (for PIL images and
            tensors), antialiasing makes no sense and this parameter is ignored.
            Possible values are:

            - ``True``: will apply antialiasing for bilinear or bicubic modes.
              Other mode aren't affected. This is probably what you want to use.
            - ``False``: will not apply antialiasing for tensors on any mode. PIL
              images are still antialiased on bilinear or bicubic modes, because
              PIL doesn't support no antialias.
            - ``None``: equivalent to ``False`` for tensors and ``True`` for
              PIL images. This value exists for legacy reasons and you probably
              don't want to use it unless you really know what you are doing.

            The current default is ``None`` **but will change to** ``True`` **in
            v0.17** for the PIL and Tensor backends to be consistent.
    """

    def __init__(self, min_size: 'Union[(List[int], Tuple[int], int)]\n', max_size: 'Optional[int]\n'=None, interpolation: 'Union[(InterpolationMode, int)]\n'=InterpolationMode.BILINEAR, antialias: 'Optional[Union[(str, bool)]]\n'='warn'):
        super().__init__()
        self.min_size = [min_size] if isinstance(min_size, int) else list(min_size)
        self.max_size = max_size
        self.interpolation = _check_interpolation(interpolation)
        self.antialias = antialias

    def _get_params(self, flat_inputs: 'List[Any]\n') ->Dict[str, Any]:
        orig_height, orig_width = query_spatial_size(flat_inputs)
        min_size = self.min_size[int(torch.randint(len(self.min_size), ()))]
        r = min_size / min(orig_height, orig_width)
        if self.max_size is not None:
            r = min(r, self.max_size / max(orig_height, orig_width))
        new_width = int(orig_width * r)
        new_height = int(orig_height * r)
        return dict(size=(new_height, new_width))

    def _transform(self, inpt: 'Any\n', params: 'Dict[(str, Any)]\n') ->Any:
        return F.resize(inpt, size=params['size'], interpolation=self.interpolation, antialias=self.antialias)


class OpticalFlowPresetEval(torch.nn.Module):

    def __init__(self):
        super().__init__()
        self.transforms = T.Compose([T.PILToTensor(), T.ConvertImageDtype(torch.float32), T.Normalize(mean=0.5, std=0.5), T.ValidateModelInput()])

    def forward(self, img1, img2, flow, valid):
        return self.transforms(img1, img2, flow, valid)


class OpticalFlowPresetTrain(torch.nn.Module):

    def __init__(self, *, crop_size, min_scale=-0.2, max_scale=0.5, stretch_prob=0.8, brightness=0.4, contrast=0.4, saturation=0.4, hue=0.5 / 3.14, asymmetric_jitter_prob=0.2, do_flip=True):
        super().__init__()
        transforms = [T.PILToTensor(), T.AsymmetricColorJitter(brightness=brightness, contrast=contrast, saturation=saturation, hue=hue, p=asymmetric_jitter_prob), T.RandomResizeAndCrop(crop_size=crop_size, min_scale=min_scale, max_scale=max_scale, stretch_prob=stretch_prob)]
        if do_flip:
            transforms += [T.RandomHorizontalFlip(p=0.5), T.RandomVerticalFlip(p=0.1)]
        transforms += [T.ConvertImageDtype(torch.float32), T.Normalize(mean=0.5, std=0.5), T.RandomErasing(max_erase=2), T.MakeValidFlowMask(), T.ValidateModelInput()]
        self.transforms = T.Compose(transforms)

    def forward(self, img1, img2, flow, valid):
        return self.transforms(img1, img2, flow, valid)


class MakeValidFlowMask(torch.nn.Module):

    def __init__(self, threshold=1000):
        super().__init__()
        self.threshold = threshold

    def forward(self, img1, img2, flow, valid_flow_mask):
        if flow is not None and valid_flow_mask is None:
            valid_flow_mask = (flow.abs() < self.threshold).all(axis=0)
        return img1, img2, flow, valid_flow_mask


class RandomResizeAndCrop(torch.nn.Module):

    def __init__(self, crop_size, min_scale=-0.2, max_scale=0.5, stretch_prob=0.8):
        super().__init__()
        self.crop_size = crop_size
        self.min_scale = min_scale
        self.max_scale = max_scale
        self.stretch_prob = stretch_prob
        self.resize_prob = 0.8
        self.max_stretch = 0.2

    def forward(self, img1, img2, flow, valid_flow_mask):
        h, w = img1.shape[-2:]
        min_scale = max((self.crop_size[0] + 8) / h, (self.crop_size[1] + 8) / w)
        scale = 2 ** torch.empty(1, dtype=torch.float32).uniform_(self.min_scale, self.max_scale).item()
        scale_x = scale
        scale_y = scale
        if torch.rand(1) < self.stretch_prob:
            scale_x *= 2 ** torch.empty(1, dtype=torch.float32).uniform_(-self.max_stretch, self.max_stretch).item()
            scale_y *= 2 ** torch.empty(1, dtype=torch.float32).uniform_(-self.max_stretch, self.max_stretch).item()
        scale_x = max(scale_x, min_scale)
        scale_y = max(scale_y, min_scale)
        new_h, new_w = round(h * scale_y), round(w * scale_x)
        if torch.rand(1).item() < self.resize_prob:
            img1 = F.resize(img1, size=(new_h, new_w), antialias=False)
            img2 = F.resize(img2, size=(new_h, new_w), antialias=False)
            if valid_flow_mask is None:
                flow = F.resize(flow, size=(new_h, new_w))
                flow = flow * torch.tensor([scale_x, scale_y])[:, (None), (None)]
            else:
                flow, valid_flow_mask = self._resize_sparse_flow(flow, valid_flow_mask, scale_x=scale_x, scale_y=scale_y)
        y0 = torch.randint(0, img1.shape[1] - self.crop_size[0], size=(1,)).item()
        x0 = torch.randint(0, img1.shape[2] - self.crop_size[1], size=(1,)).item()
        img1 = F.crop(img1, y0, x0, self.crop_size[0], self.crop_size[1])
        img2 = F.crop(img2, y0, x0, self.crop_size[0], self.crop_size[1])
        flow = F.crop(flow, y0, x0, self.crop_size[0], self.crop_size[1])
        if valid_flow_mask is not None:
            valid_flow_mask = F.crop(valid_flow_mask, y0, x0, self.crop_size[0], self.crop_size[1])
        return img1, img2, flow, valid_flow_mask

    def _resize_sparse_flow(self, flow, valid_flow_mask, scale_x=1.0, scale_y=1.0):
        h, w = flow.shape[-2:]
        h_new = int(round(h * scale_y))
        w_new = int(round(w * scale_x))
        flow_new = torch.zeros(size=[2, h_new, w_new], dtype=flow.dtype)
        valid_new = torch.zeros(size=[h_new, w_new], dtype=valid_flow_mask.dtype)
        jj, ii = torch.meshgrid(torch.arange(w), torch.arange(h), indexing='xy')
        ii_valid, jj_valid = ii[valid_flow_mask], jj[valid_flow_mask]
        ii_valid_new = torch.round(ii_valid.to(float) * scale_y)
        jj_valid_new = torch.round(jj_valid.to(float) * scale_x)
        within_bounds_mask = (0 <= ii_valid_new) & (ii_valid_new < h_new) & (0 <= jj_valid_new) & (jj_valid_new < w_new)
        ii_valid = ii_valid[within_bounds_mask]
        jj_valid = jj_valid[within_bounds_mask]
        ii_valid_new = ii_valid_new[within_bounds_mask]
        jj_valid_new = jj_valid_new[within_bounds_mask]
        valid_flow_new = flow[:, (ii_valid), (jj_valid)]
        valid_flow_new[0] *= scale_x
        valid_flow_new[1] *= scale_y
        flow_new[:, (ii_valid_new), (jj_valid_new)] = valid_flow_new
        valid_new[ii_valid_new, jj_valid_new] = 1
        return flow_new, valid_new


def _get_triplet_mask(labels):
    indices_equal = torch.eye(labels.size(0), dtype=torch.bool, device=labels.device)
    indices_not_equal = ~indices_equal
    i_not_equal_j = indices_not_equal.unsqueeze(2)
    i_not_equal_k = indices_not_equal.unsqueeze(1)
    j_not_equal_k = indices_not_equal.unsqueeze(0)
    distinct_indices = i_not_equal_j & i_not_equal_k & j_not_equal_k
    label_equal = labels.unsqueeze(0) == labels.unsqueeze(1)
    i_equal_j = label_equal.unsqueeze(2)
    i_equal_k = label_equal.unsqueeze(1)
    valid_labels = ~i_equal_k & i_equal_j
    return valid_labels & distinct_indices


def batch_all_triplet_loss(labels, embeddings, margin, p):
    pairwise_dist = torch.cdist(embeddings, embeddings, p=p)
    anchor_positive_dist = pairwise_dist.unsqueeze(2)
    anchor_negative_dist = pairwise_dist.unsqueeze(1)
    triplet_loss = anchor_positive_dist - anchor_negative_dist + margin
    mask = _get_triplet_mask(labels)
    triplet_loss = mask.float() * triplet_loss
    triplet_loss[triplet_loss < 0] = 0
    valid_triplets = triplet_loss[triplet_loss > 1e-16]
    num_positive_triplets = valid_triplets.size(0)
    num_valid_triplets = mask.sum()
    fraction_positive_triplets = num_positive_triplets / (num_valid_triplets.float() + 1e-16)
    triplet_loss = triplet_loss.sum() / (num_positive_triplets + 1e-16)
    return triplet_loss, fraction_positive_triplets


def _get_anchor_negative_triplet_mask(labels):
    return labels.unsqueeze(0) != labels.unsqueeze(1)


def _get_anchor_positive_triplet_mask(labels):
    indices_equal = torch.eye(labels.size(0), dtype=torch.bool, device=labels.device)
    indices_not_equal = ~indices_equal
    labels_equal = labels.unsqueeze(0) == labels.unsqueeze(1)
    return labels_equal & indices_not_equal


def batch_hard_triplet_loss(labels, embeddings, margin, p):
    pairwise_dist = torch.cdist(embeddings, embeddings, p=p)
    mask_anchor_positive = _get_anchor_positive_triplet_mask(labels).float()
    anchor_positive_dist = mask_anchor_positive * pairwise_dist
    hardest_positive_dist, _ = anchor_positive_dist.max(1, keepdim=True)
    mask_anchor_negative = _get_anchor_negative_triplet_mask(labels).float()
    max_anchor_negative_dist, _ = pairwise_dist.max(1, keepdim=True)
    anchor_negative_dist = pairwise_dist + max_anchor_negative_dist * (1.0 - mask_anchor_negative)
    hardest_negative_dist, _ = anchor_negative_dist.min(1, keepdim=True)
    triplet_loss = hardest_positive_dist - hardest_negative_dist + margin
    triplet_loss[triplet_loss < 0] = 0
    triplet_loss = triplet_loss.mean()
    return triplet_loss, -1


class TripletMarginLoss(nn.Module):

    def __init__(self, margin=1.0, p=2.0, mining='batch_all'):
        super().__init__()
        self.margin = margin
        self.p = p
        self.mining = mining
        if mining == 'batch_all':
            self.loss_fn = batch_all_triplet_loss
        if mining == 'batch_hard':
            self.loss_fn = batch_hard_triplet_loss

    def forward(self, embeddings, labels):
        return self.loss_fn(labels, embeddings, self.margin, self.p)


class EmbeddingNet(nn.Module):

    def __init__(self, backbone=None):
        super().__init__()
        if backbone is None:
            backbone = models.resnet50(num_classes=128)
        self.backbone = backbone

    def forward(self, x):
        x = self.backbone(x)
        x = nn.functional.normalize(x, dim=1)
        return x


class ConvertBCHWtoCBHW(nn.Module):
    """Convert tensor from (B, C, H, W) to (C, B, H, W)"""

    def forward(self, vid: 'torch.Tensor\n') ->torch.Tensor:
        return vid.permute(1, 0, 2, 3)


class TestSubModule(torch.nn.Module):

    def __init__(self):
        super().__init__()
        self.relu = torch.nn.ReLU()

    def forward(self, x):
        x = x + 1
        x = x + 1
        x = self.relu(x)
        x = self.relu(x)
        return x


class TestModule(torch.nn.Module):

    def __init__(self):
        super().__init__()
        self.submodule = TestSubModule()
        self.relu = torch.nn.ReLU()

    def forward(self, x):
        x = self.submodule(x)
        x = x + 1
        x = x + 1
        x = self.relu(x)
        x = self.relu(x)
        return x


class RoIOpTesterModuleWrapper(nn.Module):

    def __init__(self, obj):
        super().__init__()
        self.layer = obj
        self.n_inputs = 2

    def forward(self, a, b):
        self.layer(a, b)


class MultiScaleRoIAlignModuleWrapper(nn.Module):

    def __init__(self, obj):
        super().__init__()
        self.layer = obj
        self.n_inputs = 3

    def forward(self, a, b, c):
        self.layer(a, b, c)


class DeformConvModuleWrapper(nn.Module):

    def __init__(self, obj):
        super().__init__()
        self.layer = obj
        self.n_inputs = 3

    def forward(self, a, b, c):
        self.layer(a, b, c)


class StochasticDepthWrapper(nn.Module):

    def __init__(self, obj):
        super().__init__()
        self.layer = obj
        self.n_inputs = 1

    def forward(self, a):
        self.layer(a)


class DropBlockWrapper(nn.Module):

    def __init__(self, obj):
        super().__init__()
        self.layer = obj
        self.n_inputs = 1

    def forward(self, a):
        self.layer(a)


class PoolWrapper(nn.Module):

    def __init__(self, pool: 'nn.Module\n'):
        super().__init__()
        self.pool = pool

    def forward(self, imgs: 'Tensor\n', boxes: 'List[Tensor]\n') ->Tensor:
        return self.pool(imgs, boxes)


class AnchorGenerator(nn.Module):
    """
    Module that generates anchors for a set of feature maps and
    image sizes.

    The module support computing anchors at multiple sizes and aspect ratios
    per feature map. This module assumes aspect ratio = height / width for
    each anchor.

    sizes and aspect_ratios should have the same number of elements, and it should
    correspond to the number of feature maps.

    sizes[i] and aspect_ratios[i] can have an arbitrary number of elements,
    and AnchorGenerator will output a set of sizes[i] * aspect_ratios[i] anchors
    per spatial location for feature map i.

    Args:
        sizes (Tuple[Tuple[int]]):
        aspect_ratios (Tuple[Tuple[float]]):
    """
    __annotations__ = {'cell_anchors': List[torch.Tensor]}

    def __init__(self, sizes=((128, 256, 512),), aspect_ratios=((0.5, 1.0, 2.0),)):
        super().__init__()
        if not isinstance(sizes[0], (list, tuple)):
            sizes = tuple((s,) for s in sizes)
        if not isinstance(aspect_ratios[0], (list, tuple)):
            aspect_ratios = (aspect_ratios,) * len(sizes)
        self.sizes = sizes
        self.aspect_ratios = aspect_ratios
        self.cell_anchors = [self.generate_anchors(size, aspect_ratio) for size, aspect_ratio in zip(sizes, aspect_ratios)]

    def generate_anchors(self, scales: 'List[int]\n', aspect_ratios: 'List[float]\n', dtype: 'torch.dtype\n'=torch.float32, device: 'torch.device\n'=torch.device('cpu')) ->Tensor:
        scales = torch.as_tensor(scales, dtype=dtype, device=device)
        aspect_ratios = torch.as_tensor(aspect_ratios, dtype=dtype, device=device)
        h_ratios = torch.sqrt(aspect_ratios)
        w_ratios = 1 / h_ratios
        ws = (w_ratios[:, (None)] * scales[(None), :]).view(-1)
        hs = (h_ratios[:, (None)] * scales[(None), :]).view(-1)
        base_anchors = torch.stack([-ws, -hs, ws, hs], dim=1) / 2
        return base_anchors.round()

    def set_cell_anchors(self, dtype: 'torch.dtype\n', device: 'torch.device\n'):
        self.cell_anchors = [cell_anchor for cell_anchor in self.cell_anchors]

    def num_anchors_per_location(self) ->List[int]:
        return [(len(s) * len(a)) for s, a in zip(self.sizes, self.aspect_ratios)]

    def grid_anchors(self, grid_sizes: 'List[List[int]]\n', strides: 'List[List[Tensor]]\n') ->List[Tensor]:
        anchors = []
        cell_anchors = self.cell_anchors
        torch._assert(cell_anchors is not None, 'cell_anchors should not be None')
        torch._assert(len(grid_sizes) == len(strides) == len(cell_anchors), 'Anchors should be Tuple[Tuple[int]] because each feature map could potentially have different sizes and aspect ratios. There needs to be a match between the number of feature maps passed and the number of sizes / aspect ratios specified.')
        for size, stride, base_anchors in zip(grid_sizes, strides, cell_anchors):
            grid_height, grid_width = size
            stride_height, stride_width = stride
            device = base_anchors.device
            shifts_x = torch.arange(0, grid_width, dtype=torch.int32, device=device) * stride_width
            shifts_y = torch.arange(0, grid_height, dtype=torch.int32, device=device) * stride_height
            shift_y, shift_x = torch.meshgrid(shifts_y, shifts_x, indexing='ij')
            shift_x = shift_x.reshape(-1)
            shift_y = shift_y.reshape(-1)
            shifts = torch.stack((shift_x, shift_y, shift_x, shift_y), dim=1)
            anchors.append((shifts.view(-1, 1, 4) + base_anchors.view(1, -1, 4)).reshape(-1, 4))
        return anchors

    def forward(self, image_list: 'ImageList\n', feature_maps: 'List[Tensor]\n') ->List[Tensor]:
        grid_sizes = [feature_map.shape[-2:] for feature_map in feature_maps]
        image_size = image_list.tensors.shape[-2:]
        dtype, device = feature_maps[0].dtype, feature_maps[0].device
        strides = [[torch.empty((), dtype=torch.int64, device=device).fill_(image_size[0] // g[0]), torch.empty((), dtype=torch.int64, device=device).fill_(image_size[1] // g[1])] for g in grid_sizes]
        self.set_cell_anchors(dtype, device)
        anchors_over_all_feature_maps = self.grid_anchors(grid_sizes, strides)
        anchors: 'List[List[torch.Tensor]]\n' = []
        for _ in range(len(image_list.image_sizes)):
            anchors_in_image = [anchors_per_feature_map for anchors_per_feature_map in anchors_over_all_feature_maps]
            anchors.append(anchors_in_image)
        anchors = [torch.cat(anchors_per_image) for anchors_per_image in anchors]
        return anchors


class DefaultBoxGenerator(nn.Module):
    """
    This module generates the default boxes of SSD for a set of feature maps and image sizes.

    Args:
        aspect_ratios (List[List[int]]): A list with all the aspect ratios used in each feature map.
        min_ratio (float): The minimum scale :math:`	ext{s}_{	ext{min}}` of the default boxes used in the estimation
            of the scales of each feature map. It is used only if the ``scales`` parameter is not provided.
        max_ratio (float): The maximum scale :math:`	ext{s}_{	ext{max}}`  of the default boxes used in the estimation
            of the scales of each feature map. It is used only if the ``scales`` parameter is not provided.
        scales (List[float]], optional): The scales of the default boxes. If not provided it will be estimated using
            the ``min_ratio`` and ``max_ratio`` parameters.
        steps (List[int]], optional): It's a hyper-parameter that affects the tiling of default boxes. If not provided
            it will be estimated from the data.
        clip (bool): Whether the standardized values of default boxes should be clipped between 0 and 1. The clipping
            is applied while the boxes are encoded in format ``(cx, cy, w, h)``.
    """

    def __init__(self, aspect_ratios: 'List[List[int]]\n', min_ratio: 'float\n'=0.15, max_ratio: 'float\n'=0.9, scales: 'Optional[List[float]]\n'=None, steps: 'Optional[List[int]]\n'=None, clip: 'bool\n'=True):
        super().__init__()
        if steps is not None and len(aspect_ratios) != len(steps):
            raise ValueError('aspect_ratios and steps should have the same length')
        self.aspect_ratios = aspect_ratios
        self.steps = steps
        self.clip = clip
        num_outputs = len(aspect_ratios)
        if scales is None:
            if num_outputs > 1:
                range_ratio = max_ratio - min_ratio
                self.scales = [(min_ratio + range_ratio * k / (num_outputs - 1.0)) for k in range(num_outputs)]
                self.scales.append(1.0)
            else:
                self.scales = [min_ratio, max_ratio]
        else:
            self.scales = scales
        self._wh_pairs = self._generate_wh_pairs(num_outputs)

    def _generate_wh_pairs(self, num_outputs: 'int\n', dtype: 'torch.dtype\n'=torch.float32, device: 'torch.device\n'=torch.device('cpu')) ->List[Tensor]:
        _wh_pairs: 'List[Tensor]\n' = []
        for k in range(num_outputs):
            s_k = self.scales[k]
            s_prime_k = math.sqrt(self.scales[k] * self.scales[k + 1])
            wh_pairs = [[s_k, s_k], [s_prime_k, s_prime_k]]
            for ar in self.aspect_ratios[k]:
                sq_ar = math.sqrt(ar)
                w = self.scales[k] * sq_ar
                h = self.scales[k] / sq_ar
                wh_pairs.extend([[w, h], [h, w]])
            _wh_pairs.append(torch.as_tensor(wh_pairs, dtype=dtype, device=device))
        return _wh_pairs

    def num_anchors_per_location(self) ->List[int]:
        return [(2 + 2 * len(r)) for r in self.aspect_ratios]

    def _grid_default_boxes(self, grid_sizes: 'List[List[int]]\n', image_size: 'List[int]\n', dtype: 'torch.dtype\n'=torch.float32) ->Tensor:
        default_boxes = []
        for k, f_k in enumerate(grid_sizes):
            if self.steps is not None:
                x_f_k = image_size[1] / self.steps[k]
                y_f_k = image_size[0] / self.steps[k]
            else:
                y_f_k, x_f_k = f_k
            shifts_x = (torch.arange(0, f_k[1]) + 0.5) / x_f_k
            shifts_y = (torch.arange(0, f_k[0]) + 0.5) / y_f_k
            shift_y, shift_x = torch.meshgrid(shifts_y, shifts_x, indexing='ij')
            shift_x = shift_x.reshape(-1)
            shift_y = shift_y.reshape(-1)
            shifts = torch.stack((shift_x, shift_y) * len(self._wh_pairs[k]), dim=-1).reshape(-1, 2)
            _wh_pair = self._wh_pairs[k].clamp(min=0, max=1) if self.clip else self._wh_pairs[k]
            wh_pairs = _wh_pair.repeat(f_k[0] * f_k[1], 1)
            default_box = torch.cat((shifts, wh_pairs), dim=1)
            default_boxes.append(default_box)
        return torch.cat(default_boxes, dim=0)

    def __repr__(self) ->str:
        s = f'{self.__class__.__name__}(aspect_ratios={self.aspect_ratios}, clip={self.clip}, scales={self.scales}, steps={self.steps})'
        return s

    def forward(self, image_list: 'ImageList\n', feature_maps: 'List[Tensor]\n') ->List[Tensor]:
        grid_sizes = [feature_map.shape[-2:] for feature_map in feature_maps]
        image_size = image_list.tensors.shape[-2:]
        dtype, device = feature_maps[0].dtype, feature_maps[0].device
        default_boxes = self._grid_default_boxes(grid_sizes, image_size, dtype=dtype)
        default_boxes = default_boxes
        dboxes = []
        x_y_size = torch.tensor([image_size[1], image_size[0]], device=default_boxes.device)
        for _ in image_list.image_sizes:
            dboxes_in_image = default_boxes
            dboxes_in_image = torch.cat([(dboxes_in_image[:, :2] - 0.5 * dboxes_in_image[:, 2:]) * x_y_size, (dboxes_in_image[:, :2] + 0.5 * dboxes_in_image[:, 2:]) * x_y_size], -1)
            dboxes.append(dboxes_in_image)
        return dboxes


class BackboneWithFPN(nn.Module):
    """
    Adds a FPN on top of a model.
    Internally, it uses torchvision.models._utils.IntermediateLayerGetter to
    extract a submodel that returns the feature maps specified in return_layers.
    The same limitations of IntermediateLayerGetter apply here.
    Args:
        backbone (nn.Module)
        return_layers (Dict[name, new_name]): a dict containing the names
            of the modules for which the activations will be returned as
            the key of the dict, and the value of the dict is the name
            of the returned activation (which the user can specify).
        in_channels_list (List[int]): number of channels for each feature map
            that is returned, in the order they are present in the OrderedDict
        out_channels (int): number of channels in the FPN.
        norm_layer (callable, optional): Module specifying the normalization layer to use. Default: None
    Attributes:
        out_channels (int): the number of channels in the FPN
    """

    def __init__(self, backbone: 'nn.Module\n', return_layers: 'Dict[(str, str)]\n', in_channels_list: 'List[int]\n', out_channels: 'int\n', extra_blocks: 'Optional[ExtraFPNBlock]\n'=None, norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None) ->None:
        super().__init__()
        if extra_blocks is None:
            extra_blocks = LastLevelMaxPool()
        self.body = IntermediateLayerGetter(backbone, return_layers=return_layers)
        self.fpn = FeaturePyramidNetwork(in_channels_list=in_channels_list, out_channels=out_channels, extra_blocks=extra_blocks, norm_layer=norm_layer)
        self.out_channels = out_channels

    def forward(self, x: 'Tensor\n') ->Dict[str, Tensor]:
        x = self.body(x)
        x = self.fpn(x)
        return x


class TwoMLPHead(nn.Module):
    """
    Standard heads for FPN-based models

    Args:
        in_channels (int): number of input channels
        representation_size (int): size of the intermediate representation
    """

    def __init__(self, in_channels, representation_size):
        super().__init__()
        self.fc6 = nn.Linear(in_channels, representation_size)
        self.fc7 = nn.Linear(representation_size, representation_size)

    def forward(self, x):
        x = x.flatten(start_dim=1)
        x = F.relu(self.fc6(x))
        x = F.relu(self.fc7(x))
        return x


class FastRCNNConvFCHead(nn.Sequential):

    def __init__(self, input_size: 'Tuple[(int, int, int)]\n', conv_layers: 'List[int]\n', fc_layers: 'List[int]\n', norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None):
        """
        Args:
            input_size (Tuple[int, int, int]): the input size in CHW format.
            conv_layers (list): feature dimensions of each Convolution layer
            fc_layers (list): feature dimensions of each FCN layer
            norm_layer (callable, optional): Module specifying the normalization layer to use. Default: None
        """
        in_channels, in_height, in_width = input_size
        blocks = []
        previous_channels = in_channels
        for current_channels in conv_layers:
            blocks.append(misc_nn_ops.Conv2dNormActivation(previous_channels, current_channels, norm_layer=norm_layer))
            previous_channels = current_channels
        blocks.append(nn.Flatten())
        previous_channels = previous_channels * in_height * in_width
        for current_channels in fc_layers:
            blocks.append(nn.Linear(previous_channels, current_channels))
            blocks.append(nn.ReLU(inplace=True))
            previous_channels = current_channels
        super().__init__(*blocks)
        for layer in self.modules():
            if isinstance(layer, nn.Conv2d):
                nn.init.kaiming_normal_(layer.weight, mode='fan_out', nonlinearity='relu')
                if layer.bias is not None:
                    nn.init.zeros_(layer.bias)


class FastRCNNPredictor(nn.Module):
    """
    Standard classification + bounding box regression layers
    for Fast R-CNN.

    Args:
        in_channels (int): number of input channels
        num_classes (int): number of output classes (including background)
    """

    def __init__(self, in_channels, num_classes):
        super().__init__()
        self.cls_score = nn.Linear(in_channels, num_classes)
        self.bbox_pred = nn.Linear(in_channels, num_classes * 4)

    def forward(self, x):
        if x.dim() == 4:
            torch._assert(list(x.shape[2:]) == [1, 1], f'x has the wrong shape, expecting the last two dimensions to be [1,1] instead of {list(x.shape[2:])}')
        x = x.flatten(start_dim=1)
        scores = self.cls_score(x)
        bbox_deltas = self.bbox_pred(x)
        return scores, bbox_deltas


class FCOSClassificationHead(nn.Module):
    """
    A classification head for use in FCOS.

    Args:
        in_channels (int): number of channels of the input feature.
        num_anchors (int): number of anchors to be predicted.
        num_classes (int): number of classes to be predicted.
        num_convs (Optional[int]): number of conv layer. Default: 4.
        prior_probability (Optional[float]): probability of prior. Default: 0.01.
        norm_layer: Module specifying the normalization layer to use.
    """

    def __init__(self, in_channels: 'int\n', num_anchors: 'int\n', num_classes: 'int\n', num_convs: 'int\n'=4, prior_probability: 'float\n'=0.01, norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None) ->None:
        super().__init__()
        self.num_classes = num_classes
        self.num_anchors = num_anchors
        if norm_layer is None:
            norm_layer = partial(nn.GroupNorm, 32)
        conv = []
        for _ in range(num_convs):
            conv.append(nn.Conv2d(in_channels, in_channels, kernel_size=3, stride=1, padding=1))
            conv.append(norm_layer(in_channels))
            conv.append(nn.ReLU())
        self.conv = nn.Sequential(*conv)
        for layer in self.conv.children():
            if isinstance(layer, nn.Conv2d):
                torch.nn.init.normal_(layer.weight, std=0.01)
                torch.nn.init.constant_(layer.bias, 0)
        self.cls_logits = nn.Conv2d(in_channels, num_anchors * num_classes, kernel_size=3, stride=1, padding=1)
        torch.nn.init.normal_(self.cls_logits.weight, std=0.01)
        torch.nn.init.constant_(self.cls_logits.bias, -math.log((1 - prior_probability) / prior_probability))

    def forward(self, x: 'List[Tensor]\n') ->Tensor:
        all_cls_logits = []
        for features in x:
            cls_logits = self.conv(features)
            cls_logits = self.cls_logits(cls_logits)
            N, _, H, W = cls_logits.shape
            cls_logits = cls_logits.view(N, -1, self.num_classes, H, W)
            cls_logits = cls_logits.permute(0, 3, 4, 1, 2)
            cls_logits = cls_logits.reshape(N, -1, self.num_classes)
            all_cls_logits.append(cls_logits)
        return torch.cat(all_cls_logits, dim=1)


class FCOSRegressionHead(nn.Module):
    """
    A regression head for use in FCOS, which combines regression branch and center-ness branch.
    This can obtain better performance.

    Reference: `FCOS: A simple and strong anchor-free object detector <https://arxiv.org/abs/2006.09214>`_.

    Args:
        in_channels (int): number of channels of the input feature
        num_anchors (int): number of anchors to be predicted
        num_convs (Optional[int]): number of conv layer. Default: 4.
        norm_layer: Module specifying the normalization layer to use.
    """

    def __init__(self, in_channels: 'int\n', num_anchors: 'int\n', num_convs: 'int\n'=4, norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None):
        super().__init__()
        if norm_layer is None:
            norm_layer = partial(nn.GroupNorm, 32)
        conv = []
        for _ in range(num_convs):
            conv.append(nn.Conv2d(in_channels, in_channels, kernel_size=3, stride=1, padding=1))
            conv.append(norm_layer(in_channels))
            conv.append(nn.ReLU())
        self.conv = nn.Sequential(*conv)
        self.bbox_reg = nn.Conv2d(in_channels, num_anchors * 4, kernel_size=3, stride=1, padding=1)
        self.bbox_ctrness = nn.Conv2d(in_channels, num_anchors * 1, kernel_size=3, stride=1, padding=1)
        for layer in [self.bbox_reg, self.bbox_ctrness]:
            torch.nn.init.normal_(layer.weight, std=0.01)
            torch.nn.init.zeros_(layer.bias)
        for layer in self.conv.children():
            if isinstance(layer, nn.Conv2d):
                torch.nn.init.normal_(layer.weight, std=0.01)
                torch.nn.init.zeros_(layer.bias)

    def forward(self, x: 'List[Tensor]\n') ->Tuple[Tensor, Tensor]:
        all_bbox_regression = []
        all_bbox_ctrness = []
        for features in x:
            bbox_feature = self.conv(features)
            bbox_regression = nn.functional.relu(self.bbox_reg(bbox_feature))
            bbox_ctrness = self.bbox_ctrness(bbox_feature)
            N, _, H, W = bbox_regression.shape
            bbox_regression = bbox_regression.view(N, -1, 4, H, W)
            bbox_regression = bbox_regression.permute(0, 3, 4, 1, 2)
            bbox_regression = bbox_regression.reshape(N, -1, 4)
            all_bbox_regression.append(bbox_regression)
            bbox_ctrness = bbox_ctrness.view(N, -1, 1, H, W)
            bbox_ctrness = bbox_ctrness.permute(0, 3, 4, 1, 2)
            bbox_ctrness = bbox_ctrness.reshape(N, -1, 1)
            all_bbox_ctrness.append(bbox_ctrness)
        return torch.cat(all_bbox_regression, dim=1), torch.cat(all_bbox_ctrness, dim=1)


def sigmoid_focal_loss(inputs: 'torch.Tensor\n', targets: 'torch.Tensor\n', alpha: 'float\n'=0.25, gamma: 'float\n'=2, reduction: 'str\n'='none') ->torch.Tensor:
    """
    Loss used in RetinaNet for dense detection: https://arxiv.org/abs/1708.02002.

    Args:
        inputs (Tensor): A float tensor of arbitrary shape.
                The predictions for each example.
        targets (Tensor): A float tensor with the same shape as inputs. Stores the binary
                classification label for each element in inputs
                (0 for the negative class and 1 for the positive class).
        alpha (float): Weighting factor in range (0,1) to balance
                positive vs negative examples or -1 for ignore. Default: ``0.25``.
        gamma (float): Exponent of the modulating factor (1 - p_t) to
                balance easy vs hard examples. Default: ``2``.
        reduction (string): ``'none'`` | ``'mean'`` | ``'sum'``
                ``'none'``: No reduction will be applied to the output.
                ``'mean'``: The output will be averaged.
                ``'sum'``: The output will be summed. Default: ``'none'``.
    Returns:
        Loss tensor with the reduction option applied.
    """
    if not torch.jit.is_scripting() and not torch.jit.is_tracing():
        _log_api_usage_once(sigmoid_focal_loss)
    p = torch.sigmoid(inputs)
    ce_loss = F.binary_cross_entropy_with_logits(inputs, targets, reduction='none')
    p_t = p * targets + (1 - p) * (1 - targets)
    loss = ce_loss * (1 - p_t) ** gamma
    if alpha >= 0:
        alpha_t = alpha * targets + (1 - alpha) * (1 - targets)
        loss = alpha_t * loss
    if reduction == 'none':
        pass
    elif reduction == 'mean':
        loss = loss.mean()
    elif reduction == 'sum':
        loss = loss.sum()
    else:
        raise ValueError(f"Invalid Value for arg 'reduction': '{reduction} \n Supported reduction modes: 'none', 'mean', 'sum'")
    return loss


class GeneralizedRCNN(nn.Module):
    """
    Main class for Generalized R-CNN.

    Args:
        backbone (nn.Module):
        rpn (nn.Module):
        roi_heads (nn.Module): takes the features + the proposals from the RPN and computes
            detections / masks from it.
        transform (nn.Module): performs the data transformation from the inputs to feed into
            the model
    """

    def __init__(self, backbone: 'nn.Module\n', rpn: 'nn.Module\n', roi_heads: 'nn.Module\n', transform: 'nn.Module\n') ->None:
        super().__init__()
        _log_api_usage_once(self)
        self.transform = transform
        self.backbone = backbone
        self.rpn = rpn
        self.roi_heads = roi_heads
        self._has_warned = False

    @torch.jit.unused
    def eager_outputs(self, losses, detections):
        if self.training:
            return losses
        return detections

    def forward(self, images, targets=None):
        """
        Args:
            images (list[Tensor]): images to be processed
            targets (list[Dict[str, Tensor]]): ground-truth boxes present in the image (optional)

        Returns:
            result (list[BoxList] or dict[Tensor]): the output from the model.
                During training, it returns a dict[Tensor] which contains the losses.
                During testing, it returns list[BoxList] contains additional fields
                like `scores`, `labels` and `mask` (for Mask R-CNN models).

        """
        if self.training:
            if targets is None:
                torch._assert(False, 'targets should not be none when in training mode')
            else:
                for target in targets:
                    boxes = target['boxes']
                    if isinstance(boxes, torch.Tensor):
                        torch._assert(len(boxes.shape) == 2 and boxes.shape[-1] == 4, f'Expected target boxes to be a tensor of shape [N, 4], got {boxes.shape}.')
                    else:
                        torch._assert(False, f'Expected target boxes to be of type Tensor, got {type(boxes)}.')
        original_image_sizes: 'List[Tuple[(int, int)]]\n' = []
        for img in images:
            val = img.shape[-2:]
            torch._assert(len(val) == 2, f'expecting the last two dimensions of the Tensor to be H and W instead got {img.shape[-2:]}')
            original_image_sizes.append((val[0], val[1]))
        images, targets = self.transform(images, targets)
        if targets is not None:
            for target_idx, target in enumerate(targets):
                boxes = target['boxes']
                degenerate_boxes = boxes[:, 2:] <= boxes[:, :2]
                if degenerate_boxes.any():
                    bb_idx = torch.where(degenerate_boxes.any(dim=1))[0][0]
                    degen_bb: 'List[float]\n' = boxes[bb_idx].tolist()
                    torch._assert(False, f'All bounding boxes should have positive height and width. Found invalid box {degen_bb} for target at index {target_idx}.')
        features = self.backbone(images.tensors)
        if isinstance(features, torch.Tensor):
            features = OrderedDict([('0', features)])
        proposals, proposal_losses = self.rpn(images, features, targets)
        detections, detector_losses = self.roi_heads(features, proposals, images.image_sizes, targets)
        detections = self.transform.postprocess(detections, images.image_sizes, original_image_sizes)
        losses = {}
        losses.update(detector_losses)
        losses.update(proposal_losses)
        if torch.jit.is_scripting():
            if not self._has_warned:
                warnings.warn('RCNN always returns a (Losses, Detections) tuple in scripting')
                self._has_warned = True
            return losses, detections
        else:
            return self.eager_outputs(losses, detections)


class KeypointRCNNHeads(nn.Sequential):

    def __init__(self, in_channels, layers):
        d = []
        next_feature = in_channels
        for out_channels in layers:
            d.append(nn.Conv2d(next_feature, out_channels, 3, stride=1, padding=1))
            d.append(nn.ReLU(inplace=True))
            next_feature = out_channels
        super().__init__(*d)
        for m in self.children():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                nn.init.constant_(m.bias, 0)


class KeypointRCNNPredictor(nn.Module):

    def __init__(self, in_channels, num_keypoints):
        super().__init__()
        input_features = in_channels
        deconv_kernel = 4
        self.kps_score_lowres = nn.ConvTranspose2d(input_features, num_keypoints, deconv_kernel, stride=2, padding=deconv_kernel // 2 - 1)
        nn.init.kaiming_normal_(self.kps_score_lowres.weight, mode='fan_out', nonlinearity='relu')
        nn.init.constant_(self.kps_score_lowres.bias, 0)
        self.up_scale = 2
        self.out_channels = num_keypoints

    def forward(self, x):
        x = self.kps_score_lowres(x)
        return torch.nn.functional.interpolate(x, scale_factor=float(self.up_scale), mode='bilinear', align_corners=False, recompute_scale_factor=False)


class MaskRCNNHeads(nn.Sequential):
    _version = 2

    def __init__(self, in_channels, layers, dilation, norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None):
        """
        Args:
            in_channels (int): number of input channels
            layers (list): feature dimensions of each FCN layer
            dilation (int): dilation rate of kernel
            norm_layer (callable, optional): Module specifying the normalization layer to use. Default: None
        """
        blocks = []
        next_feature = in_channels
        for layer_features in layers:
            blocks.append(misc_nn_ops.Conv2dNormActivation(next_feature, layer_features, kernel_size=3, stride=1, padding=dilation, dilation=dilation, norm_layer=norm_layer))
            next_feature = layer_features
        super().__init__(*blocks)
        for layer in self.modules():
            if isinstance(layer, nn.Conv2d):
                nn.init.kaiming_normal_(layer.weight, mode='fan_out', nonlinearity='relu')
                if layer.bias is not None:
                    nn.init.zeros_(layer.bias)

    def _load_from_state_dict(self, state_dict, prefix, local_metadata, strict, missing_keys, unexpected_keys, error_msgs):
        version = local_metadata.get('version', None)
        if version is None or version < 2:
            num_blocks = len(self)
            for i in range(num_blocks):
                for type in ['weight', 'bias']:
                    old_key = f'{prefix}mask_fcn{i + 1}.{type}'
                    new_key = f'{prefix}{i}.0.{type}'
                    if old_key in state_dict:
                        state_dict[new_key] = state_dict.pop(old_key)
        super()._load_from_state_dict(state_dict, prefix, local_metadata, strict, missing_keys, unexpected_keys, error_msgs)


class MaskRCNNPredictor(nn.Sequential):

    def __init__(self, in_channels, dim_reduced, num_classes):
        super().__init__(OrderedDict([('conv5_mask', nn.ConvTranspose2d(in_channels, dim_reduced, 2, 2, 0)), ('relu', nn.ReLU(inplace=True)), ('mask_fcn_logits', nn.Conv2d(dim_reduced, num_classes, 1, 1, 0))]))
        for name, param in self.named_parameters():
            if 'weight' in name:
                nn.init.kaiming_normal_(param, mode='fan_out', nonlinearity='relu')


def _sum(x: 'List[Tensor]\n') ->Tensor:
    res = x[0]
    for i in x[1:]:
        res = res + i
    return res


def _v1_to_v2_weights(state_dict, prefix):
    for i in range(4):
        for type in ['weight', 'bias']:
            old_key = f'{prefix}conv.{2 * i}.{type}'
            new_key = f'{prefix}conv.{i}.0.{type}'
            if old_key in state_dict:
                state_dict[new_key] = state_dict.pop(old_key)


class RetinaNetClassificationHead(nn.Module):
    """
    A classification head for use in RetinaNet.

    Args:
        in_channels (int): number of channels of the input feature
        num_anchors (int): number of anchors to be predicted
        num_classes (int): number of classes to be predicted
        norm_layer (callable, optional): Module specifying the normalization layer to use. Default: None
    """
    _version = 2

    def __init__(self, in_channels, num_anchors, num_classes, prior_probability=0.01, norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None):
        super().__init__()
        conv = []
        for _ in range(4):
            conv.append(misc_nn_ops.Conv2dNormActivation(in_channels, in_channels, norm_layer=norm_layer))
        self.conv = nn.Sequential(*conv)
        for layer in self.conv.modules():
            if isinstance(layer, nn.Conv2d):
                torch.nn.init.normal_(layer.weight, std=0.01)
                if layer.bias is not None:
                    torch.nn.init.constant_(layer.bias, 0)
        self.cls_logits = nn.Conv2d(in_channels, num_anchors * num_classes, kernel_size=3, stride=1, padding=1)
        torch.nn.init.normal_(self.cls_logits.weight, std=0.01)
        torch.nn.init.constant_(self.cls_logits.bias, -math.log((1 - prior_probability) / prior_probability))
        self.num_classes = num_classes
        self.num_anchors = num_anchors
        self.BETWEEN_THRESHOLDS = det_utils.Matcher.BETWEEN_THRESHOLDS

    def _load_from_state_dict(self, state_dict, prefix, local_metadata, strict, missing_keys, unexpected_keys, error_msgs):
        version = local_metadata.get('version', None)
        if version is None or version < 2:
            _v1_to_v2_weights(state_dict, prefix)
        super()._load_from_state_dict(state_dict, prefix, local_metadata, strict, missing_keys, unexpected_keys, error_msgs)

    def compute_loss(self, targets, head_outputs, matched_idxs):
        losses = []
        cls_logits = head_outputs['cls_logits']
        for targets_per_image, cls_logits_per_image, matched_idxs_per_image in zip(targets, cls_logits, matched_idxs):
            foreground_idxs_per_image = matched_idxs_per_image >= 0
            num_foreground = foreground_idxs_per_image.sum()
            gt_classes_target = torch.zeros_like(cls_logits_per_image)
            gt_classes_target[foreground_idxs_per_image, targets_per_image['labels'][matched_idxs_per_image[foreground_idxs_per_image]]] = 1.0
            valid_idxs_per_image = matched_idxs_per_image != self.BETWEEN_THRESHOLDS
            losses.append(sigmoid_focal_loss(cls_logits_per_image[valid_idxs_per_image], gt_classes_target[valid_idxs_per_image], reduction='sum') / max(1, num_foreground))
        return _sum(losses) / len(targets)

    def forward(self, x):
        all_cls_logits = []
        for features in x:
            cls_logits = self.conv(features)
            cls_logits = self.cls_logits(cls_logits)
            N, _, H, W = cls_logits.shape
            cls_logits = cls_logits.view(N, -1, self.num_classes, H, W)
            cls_logits = cls_logits.permute(0, 3, 4, 1, 2)
            cls_logits = cls_logits.reshape(N, -1, self.num_classes)
            all_cls_logits.append(cls_logits)
        return torch.cat(all_cls_logits, dim=1)


def _box_loss(type: 'str\n', box_coder: 'BoxCoder\n', anchors_per_image: 'Tensor\n', matched_gt_boxes_per_image: 'Tensor\n', bbox_regression_per_image: 'Tensor\n', cnf: 'Optional[Dict[(str, float)]]\n'=None) ->Tensor:
    torch._assert(type in ['l1', 'smooth_l1', 'ciou', 'diou', 'giou'], f'Unsupported loss: {type}')
    if type == 'l1':
        target_regression = box_coder.encode_single(matched_gt_boxes_per_image, anchors_per_image)
        return F.l1_loss(bbox_regression_per_image, target_regression, reduction='sum')
    elif type == 'smooth_l1':
        target_regression = box_coder.encode_single(matched_gt_boxes_per_image, anchors_per_image)
        beta = cnf['beta'] if cnf is not None and 'beta' in cnf else 1.0
        return F.smooth_l1_loss(bbox_regression_per_image, target_regression, reduction='sum', beta=beta)
    else:
        bbox_per_image = box_coder.decode_single(bbox_regression_per_image, anchors_per_image)
        eps = cnf['eps'] if cnf is not None and 'eps' in cnf else 1e-07
        if type == 'ciou':
            return complete_box_iou_loss(bbox_per_image, matched_gt_boxes_per_image, reduction='sum', eps=eps)
        if type == 'diou':
            return distance_box_iou_loss(bbox_per_image, matched_gt_boxes_per_image, reduction='sum', eps=eps)
        return generalized_box_iou_loss(bbox_per_image, matched_gt_boxes_per_image, reduction='sum', eps=eps)


class RetinaNetHead(nn.Module):
    """
    A regression and classification head for use in RetinaNet.

    Args:
        in_channels (int): number of channels of the input feature
        num_anchors (int): number of anchors to be predicted
        num_classes (int): number of classes to be predicted
        norm_layer (callable, optional): Module specifying the normalization layer to use. Default: None
    """

    def __init__(self, in_channels, num_anchors, num_classes, norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None):
        super().__init__()
        self.classification_head = RetinaNetClassificationHead(in_channels, num_anchors, num_classes, norm_layer=norm_layer)
        self.regression_head = RetinaNetRegressionHead(in_channels, num_anchors, norm_layer=norm_layer)

    def compute_loss(self, targets, head_outputs, anchors, matched_idxs):
        return {'classification': self.classification_head.compute_loss(targets, head_outputs, matched_idxs), 'bbox_regression': self.regression_head.compute_loss(targets, head_outputs, anchors, matched_idxs)}

    def forward(self, x):
        return {'cls_logits': self.classification_head(x), 'bbox_regression': self.regression_head(x)}


def _default_anchorgen():
    anchor_sizes = tuple((x, int(x * 2 ** (1.0 / 3)), int(x * 2 ** (2.0 / 3))) for x in [32, 64, 128, 256, 512])
    aspect_ratios = ((0.5, 1.0, 2.0),) * len(anchor_sizes)
    anchor_generator = AnchorGenerator(anchor_sizes, aspect_ratios)
    return anchor_generator


def fastrcnn_loss(class_logits, box_regression, labels, regression_targets):
    """
    Computes the loss for Faster R-CNN.

    Args:
        class_logits (Tensor)
        box_regression (Tensor)
        labels (list[BoxList])
        regression_targets (Tensor)

    Returns:
        classification_loss (Tensor)
        box_loss (Tensor)
    """
    labels = torch.cat(labels, dim=0)
    regression_targets = torch.cat(regression_targets, dim=0)
    classification_loss = F.cross_entropy(class_logits, labels)
    sampled_pos_inds_subset = torch.where(labels > 0)[0]
    labels_pos = labels[sampled_pos_inds_subset]
    N, num_classes = class_logits.shape
    box_regression = box_regression.reshape(N, box_regression.size(-1) // 4, 4)
    box_loss = F.smooth_l1_loss(box_regression[sampled_pos_inds_subset, labels_pos], regression_targets[sampled_pos_inds_subset], beta=1 / 9, reduction='sum')
    box_loss = box_loss / labels.numel()
    return classification_loss, box_loss


def _onnx_heatmaps_to_keypoints(maps, maps_i, roi_map_width, roi_map_height, widths_i, heights_i, offset_x_i, offset_y_i):
    num_keypoints = torch.scalar_tensor(maps.size(1), dtype=torch.int64)
    width_correction = widths_i / roi_map_width
    height_correction = heights_i / roi_map_height
    roi_map = F.interpolate(maps_i[:, (None)], size=(int(roi_map_height), int(roi_map_width)), mode='bicubic', align_corners=False)[:, (0)]
    w = torch.scalar_tensor(roi_map.size(2), dtype=torch.int64)
    pos = roi_map.reshape(num_keypoints, -1).argmax(dim=1)
    x_int = pos % w
    y_int = (pos - x_int) // w
    x = (torch.tensor(0.5, dtype=torch.float32) + x_int) * width_correction
    y = (torch.tensor(0.5, dtype=torch.float32) + y_int) * height_correction
    xy_preds_i_0 = x + offset_x_i
    xy_preds_i_1 = y + offset_y_i
    xy_preds_i_2 = torch.ones(xy_preds_i_1.shape, dtype=torch.float32)
    xy_preds_i = torch.stack([xy_preds_i_0, xy_preds_i_1, xy_preds_i_2], 0)
    base = num_keypoints * num_keypoints + num_keypoints + 1
    ind = torch.arange(num_keypoints)
    ind = ind * base
    end_scores_i = roi_map.index_select(1, y_int).index_select(2, x_int).view(-1).index_select(0, ind)
    return xy_preds_i, end_scores_i


@torch.jit._script_if_tracing
def _onnx_heatmaps_to_keypoints_loop(maps, rois, widths_ceil, heights_ceil, widths, heights, offset_x, offset_y, num_keypoints):
    xy_preds = torch.zeros((0, 3, int(num_keypoints)), dtype=torch.float32, device=maps.device)
    end_scores = torch.zeros((0, int(num_keypoints)), dtype=torch.float32, device=maps.device)
    for i in range(int(rois.size(0))):
        xy_preds_i, end_scores_i = _onnx_heatmaps_to_keypoints(maps, maps[i], widths_ceil[i], heights_ceil[i], widths[i], heights[i], offset_x[i], offset_y[i])
        xy_preds = torch.cat((xy_preds, xy_preds_i.unsqueeze(0)), 0)
        end_scores = torch.cat((end_scores, end_scores_i.unsqueeze(0)), 0)
    return xy_preds, end_scores


def heatmaps_to_keypoints(maps, rois):
    """Extract predicted keypoint locations from heatmaps. Output has shape
    (#rois, 4, #keypoints) with the 4 rows corresponding to (x, y, logit, prob)
    for each keypoint.
    """
    offset_x = rois[:, (0)]
    offset_y = rois[:, (1)]
    widths = rois[:, (2)] - rois[:, (0)]
    heights = rois[:, (3)] - rois[:, (1)]
    widths = widths.clamp(min=1)
    heights = heights.clamp(min=1)
    widths_ceil = widths.ceil()
    heights_ceil = heights.ceil()
    num_keypoints = maps.shape[1]
    if torchvision._is_tracing():
        xy_preds, end_scores = _onnx_heatmaps_to_keypoints_loop(maps, rois, widths_ceil, heights_ceil, widths, heights, offset_x, offset_y, torch.scalar_tensor(num_keypoints, dtype=torch.int64))
        return xy_preds.permute(0, 2, 1), end_scores
    xy_preds = torch.zeros((len(rois), 3, num_keypoints), dtype=torch.float32, device=maps.device)
    end_scores = torch.zeros((len(rois), num_keypoints), dtype=torch.float32, device=maps.device)
    for i in range(len(rois)):
        roi_map_width = int(widths_ceil[i].item())
        roi_map_height = int(heights_ceil[i].item())
        width_correction = widths[i] / roi_map_width
        height_correction = heights[i] / roi_map_height
        roi_map = F.interpolate(maps[i][:, (None)], size=(roi_map_height, roi_map_width), mode='bicubic', align_corners=False)[:, (0)]
        w = roi_map.shape[2]
        pos = roi_map.reshape(num_keypoints, -1).argmax(dim=1)
        x_int = pos % w
        y_int = torch.div(pos - x_int, w, rounding_mode='floor')
        x = (x_int.float() + 0.5) * width_correction
        y = (y_int.float() + 0.5) * height_correction
        xy_preds[(i), (0), :] = x + offset_x[i]
        xy_preds[(i), (1), :] = y + offset_y[i]
        xy_preds[(i), (2), :] = 1
        end_scores[(i), :] = roi_map[torch.arange(num_keypoints, device=roi_map.device), y_int, x_int]
    return xy_preds.permute(0, 2, 1), end_scores


def keypointrcnn_inference(x, boxes):
    kp_probs = []
    kp_scores = []
    boxes_per_image = [box.size(0) for box in boxes]
    x2 = x.split(boxes_per_image, dim=0)
    for xx, bb in zip(x2, boxes):
        kp_prob, scores = heatmaps_to_keypoints(xx, bb)
        kp_probs.append(kp_prob)
        kp_scores.append(scores)
    return kp_probs, kp_scores


def keypoints_to_heatmap(keypoints, rois, heatmap_size):
    offset_x = rois[:, (0)]
    offset_y = rois[:, (1)]
    scale_x = heatmap_size / (rois[:, (2)] - rois[:, (0)])
    scale_y = heatmap_size / (rois[:, (3)] - rois[:, (1)])
    offset_x = offset_x[:, (None)]
    offset_y = offset_y[:, (None)]
    scale_x = scale_x[:, (None)]
    scale_y = scale_y[:, (None)]
    x = keypoints[..., 0]
    y = keypoints[..., 1]
    x_boundary_inds = x == rois[:, (2)][:, (None)]
    y_boundary_inds = y == rois[:, (3)][:, (None)]
    x = (x - offset_x) * scale_x
    x = x.floor().long()
    y = (y - offset_y) * scale_y
    y = y.floor().long()
    x[x_boundary_inds] = heatmap_size - 1
    y[y_boundary_inds] = heatmap_size - 1
    valid_loc = (x >= 0) & (y >= 0) & (x < heatmap_size) & (y < heatmap_size)
    vis = keypoints[..., 2] > 0
    valid = (valid_loc & vis).long()
    lin_ind = y * heatmap_size + x
    heatmaps = lin_ind * valid
    return heatmaps, valid


def keypointrcnn_loss(keypoint_logits, proposals, gt_keypoints, keypoint_matched_idxs):
    N, K, H, W = keypoint_logits.shape
    if H != W:
        raise ValueError(f'keypoint_logits height and width (last two elements of shape) should be equal. Instead got H = {H} and W = {W}')
    discretization_size = H
    heatmaps = []
    valid = []
    for proposals_per_image, gt_kp_in_image, midx in zip(proposals, gt_keypoints, keypoint_matched_idxs):
        kp = gt_kp_in_image[midx]
        heatmaps_per_image, valid_per_image = keypoints_to_heatmap(kp, proposals_per_image, discretization_size)
        heatmaps.append(heatmaps_per_image.view(-1))
        valid.append(valid_per_image.view(-1))
    keypoint_targets = torch.cat(heatmaps, dim=0)
    valid = torch.cat(valid, dim=0)
    valid = torch.where(valid)[0]
    if keypoint_targets.numel() == 0 or len(valid) == 0:
        return keypoint_logits.sum() * 0
    keypoint_logits = keypoint_logits.view(N * K, H * W)
    keypoint_loss = F.cross_entropy(keypoint_logits[valid], keypoint_targets[valid])
    return keypoint_loss


def maskrcnn_inference(x, labels):
    """
    From the results of the CNN, post process the masks
    by taking the mask corresponding to the class with max
    probability (which are of fixed size and directly output
    by the CNN) and return the masks in the mask field of the BoxList.

    Args:
        x (Tensor): the mask logits
        labels (list[BoxList]): bounding boxes that are used as
            reference, one for ech image

    Returns:
        results (list[BoxList]): one BoxList for each image, containing
            the extra field mask
    """
    mask_prob = x.sigmoid()
    num_masks = x.shape[0]
    boxes_per_image = [label.shape[0] for label in labels]
    labels = torch.cat(labels)
    index = torch.arange(num_masks, device=labels.device)
    mask_prob = mask_prob[index, labels][:, (None)]
    mask_prob = mask_prob.split(boxes_per_image, dim=0)
    return mask_prob


def project_masks_on_boxes(gt_masks, boxes, matched_idxs, M):
    """
    Given segmentation masks and the bounding boxes corresponding
    to the location of the masks in the image, this function
    crops and resizes the masks in the position defined by the
    boxes. This prepares the masks for them to be fed to the
    loss computation as the targets.
    """
    matched_idxs = matched_idxs
    rois = torch.cat([matched_idxs[:, (None)], boxes], dim=1)
    gt_masks = gt_masks[:, (None)]
    return roi_align(gt_masks, rois, (M, M), 1.0)[:, (0)]


def maskrcnn_loss(mask_logits, proposals, gt_masks, gt_labels, mask_matched_idxs):
    """
    Args:
        proposals (list[BoxList])
        mask_logits (Tensor)
        targets (list[BoxList])

    Return:
        mask_loss (Tensor): scalar tensor containing the loss
    """
    discretization_size = mask_logits.shape[-1]
    labels = [gt_label[idxs] for gt_label, idxs in zip(gt_labels, mask_matched_idxs)]
    mask_targets = [project_masks_on_boxes(m, p, i, discretization_size) for m, p, i in zip(gt_masks, proposals, mask_matched_idxs)]
    labels = torch.cat(labels, dim=0)
    mask_targets = torch.cat(mask_targets, dim=0)
    if mask_targets.numel() == 0:
        return mask_logits.sum() * 0
    mask_loss = F.binary_cross_entropy_with_logits(mask_logits[torch.arange(labels.shape[0], device=labels.device), labels], mask_targets)
    return mask_loss


class RPNHead(nn.Module):
    """
    Adds a simple RPN Head with classification and regression heads

    Args:
        in_channels (int): number of channels of the input feature
        num_anchors (int): number of anchors to be predicted
        conv_depth (int, optional): number of convolutions
    """
    _version = 2

    def __init__(self, in_channels: 'int\n', num_anchors: 'int\n', conv_depth=1) ->None:
        super().__init__()
        convs = []
        for _ in range(conv_depth):
            convs.append(Conv2dNormActivation(in_channels, in_channels, kernel_size=3, norm_layer=None))
        self.conv = nn.Sequential(*convs)
        self.cls_logits = nn.Conv2d(in_channels, num_anchors, kernel_size=1, stride=1)
        self.bbox_pred = nn.Conv2d(in_channels, num_anchors * 4, kernel_size=1, stride=1)
        for layer in self.modules():
            if isinstance(layer, nn.Conv2d):
                torch.nn.init.normal_(layer.weight, std=0.01)
                if layer.bias is not None:
                    torch.nn.init.constant_(layer.bias, 0)

    def _load_from_state_dict(self, state_dict, prefix, local_metadata, strict, missing_keys, unexpected_keys, error_msgs):
        version = local_metadata.get('version', None)
        if version is None or version < 2:
            for type in ['weight', 'bias']:
                old_key = f'{prefix}conv.{type}'
                new_key = f'{prefix}conv.0.0.{type}'
                if old_key in state_dict:
                    state_dict[new_key] = state_dict.pop(old_key)
        super()._load_from_state_dict(state_dict, prefix, local_metadata, strict, missing_keys, unexpected_keys, error_msgs)

    def forward(self, x: 'List[Tensor]\n') ->Tuple[List[Tensor], List[Tensor]]:
        logits = []
        bbox_reg = []
        for feature in x:
            t = self.conv(feature)
            logits.append(self.cls_logits(t))
            bbox_reg.append(self.bbox_pred(t))
        return logits, bbox_reg


def permute_and_flatten(layer: 'Tensor\n', N: 'int\n', A: 'int\n', C: 'int\n', H: 'int\n', W: 'int\n') ->Tensor:
    layer = layer.view(N, -1, C, H, W)
    layer = layer.permute(0, 3, 4, 1, 2)
    layer = layer.reshape(N, -1, C)
    return layer


def concat_box_prediction_layers(box_cls: 'List[Tensor]\n', box_regression: 'List[Tensor]\n') ->Tuple[Tensor, Tensor]:
    box_cls_flattened = []
    box_regression_flattened = []
    for box_cls_per_level, box_regression_per_level in zip(box_cls, box_regression):
        N, AxC, H, W = box_cls_per_level.shape
        Ax4 = box_regression_per_level.shape[1]
        A = Ax4 // 4
        C = AxC // A
        box_cls_per_level = permute_and_flatten(box_cls_per_level, N, A, C, H, W)
        box_cls_flattened.append(box_cls_per_level)
        box_regression_per_level = permute_and_flatten(box_regression_per_level, N, A, 4, H, W)
        box_regression_flattened.append(box_regression_per_level)
    box_cls = torch.cat(box_cls_flattened, dim=1).flatten(0, -2)
    box_regression = torch.cat(box_regression_flattened, dim=1).reshape(-1, 4)
    return box_cls, box_regression


class SSDScoringHead(nn.Module):

    def __init__(self, module_list: 'nn.ModuleList\n', num_columns: 'int\n'):
        super().__init__()
        self.module_list = module_list
        self.num_columns = num_columns

    def _get_result_from_module_list(self, x: 'Tensor\n', idx: 'int\n') ->Tensor:
        """
        This is equivalent to self.module_list[idx](x),
        but torchscript doesn't support this yet
        """
        num_blocks = len(self.module_list)
        if idx < 0:
            idx += num_blocks
        out = x
        for i, module in enumerate(self.module_list):
            if i == idx:
                out = module(x)
        return out

    def forward(self, x: 'List[Tensor]\n') ->Tensor:
        all_results = []
        for i, features in enumerate(x):
            results = self._get_result_from_module_list(features, i)
            N, _, H, W = results.shape
            results = results.view(N, -1, self.num_columns, H, W)
            results = results.permute(0, 3, 4, 1, 2)
            results = results.reshape(N, -1, self.num_columns)
            all_results.append(results)
        return torch.cat(all_results, dim=1)


def _xavier_init(conv: 'nn.Module\n'):
    for layer in conv.modules():
        if isinstance(layer, nn.Conv2d):
            torch.nn.init.xavier_uniform_(layer.weight)
            if layer.bias is not None:
                torch.nn.init.constant_(layer.bias, 0.0)


class SSDClassificationHead(SSDScoringHead):

    def __init__(self, in_channels: 'List[int]\n', num_anchors: 'List[int]\n', num_classes: 'int\n'):
        cls_logits = nn.ModuleList()
        for channels, anchors in zip(in_channels, num_anchors):
            cls_logits.append(nn.Conv2d(channels, num_classes * anchors, kernel_size=3, padding=1))
        _xavier_init(cls_logits)
        super().__init__(cls_logits, num_classes)


class SSDRegressionHead(SSDScoringHead):

    def __init__(self, in_channels: 'List[int]\n', num_anchors: 'List[int]\n'):
        bbox_reg = nn.ModuleList()
        for channels, anchors in zip(in_channels, num_anchors):
            bbox_reg.append(nn.Conv2d(channels, 4 * anchors, kernel_size=3, padding=1))
        _xavier_init(bbox_reg)
        super().__init__(bbox_reg, 4)


class SSDHead(nn.Module):

    def __init__(self, in_channels: 'List[int]\n', num_anchors: 'List[int]\n', num_classes: 'int\n'):
        super().__init__()
        self.classification_head = SSDClassificationHead(in_channels, num_anchors, num_classes)
        self.regression_head = SSDRegressionHead(in_channels, num_anchors)

    def forward(self, x: 'List[Tensor]\n') ->Dict[str, Tensor]:
        return {'bbox_regression': self.regression_head(x), 'cls_logits': self.classification_head(x)}


class SSDFeatureExtractorVGG(nn.Module):

    def __init__(self, backbone: 'nn.Module\n', highres: 'bool\n'):
        super().__init__()
        _, _, maxpool3_pos, maxpool4_pos, _ = (i for i, layer in enumerate(backbone) if isinstance(layer, nn.MaxPool2d))
        backbone[maxpool3_pos].ceil_mode = True
        self.scale_weight = nn.Parameter(torch.ones(512) * 20)
        self.features = nn.Sequential(*backbone[:maxpool4_pos])
        extra = nn.ModuleList([nn.Sequential(nn.Conv2d(1024, 256, kernel_size=1), nn.ReLU(inplace=True), nn.Conv2d(256, 512, kernel_size=3, padding=1, stride=2), nn.ReLU(inplace=True)), nn.Sequential(nn.Conv2d(512, 128, kernel_size=1), nn.ReLU(inplace=True), nn.Conv2d(128, 256, kernel_size=3, padding=1, stride=2), nn.ReLU(inplace=True)), nn.Sequential(nn.Conv2d(256, 128, kernel_size=1), nn.ReLU(inplace=True), nn.Conv2d(128, 256, kernel_size=3), nn.ReLU(inplace=True)), nn.Sequential(nn.Conv2d(256, 128, kernel_size=1), nn.ReLU(inplace=True), nn.Conv2d(128, 256, kernel_size=3), nn.ReLU(inplace=True))])
        if highres:
            extra.append(nn.Sequential(nn.Conv2d(256, 128, kernel_size=1), nn.ReLU(inplace=True), nn.Conv2d(128, 256, kernel_size=4), nn.ReLU(inplace=True)))
        _xavier_init(extra)
        fc = nn.Sequential(nn.MaxPool2d(kernel_size=3, stride=1, padding=1, ceil_mode=False), nn.Conv2d(in_channels=512, out_channels=1024, kernel_size=3, padding=6, dilation=6), nn.ReLU(inplace=True), nn.Conv2d(in_channels=1024, out_channels=1024, kernel_size=1), nn.ReLU(inplace=True))
        _xavier_init(fc)
        extra.insert(0, nn.Sequential(*backbone[maxpool4_pos:-1], fc))
        self.extra = extra

    def forward(self, x: 'Tensor\n') ->Dict[str, Tensor]:
        x = self.features(x)
        rescaled = self.scale_weight.view(1, -1, 1, 1) * F.normalize(x)
        output = [rescaled]
        for block in self.extra:
            x = block(x)
            output.append(x)
        return OrderedDict([(str(i), v) for i, v in enumerate(output)])


def _normal_init(conv: 'nn.Module\n'):
    for layer in conv.modules():
        if isinstance(layer, nn.Conv2d):
            torch.nn.init.normal_(layer.weight, mean=0.0, std=0.03)
            if layer.bias is not None:
                torch.nn.init.constant_(layer.bias, 0.0)


def _prediction_block(in_channels: 'int\n', out_channels: 'int\n', kernel_size: 'int\n', norm_layer: 'Callable[(..., nn.Module)]\n') ->nn.Sequential:
    return nn.Sequential(Conv2dNormActivation(in_channels, in_channels, kernel_size=kernel_size, groups=in_channels, norm_layer=norm_layer, activation_layer=nn.ReLU6), nn.Conv2d(in_channels, out_channels, 1))


class SSDLiteClassificationHead(SSDScoringHead):

    def __init__(self, in_channels: 'List[int]\n', num_anchors: 'List[int]\n', num_classes: 'int\n', norm_layer: 'Callable[(..., nn.Module)]\n'):
        cls_logits = nn.ModuleList()
        for channels, anchors in zip(in_channels, num_anchors):
            cls_logits.append(_prediction_block(channels, num_classes * anchors, 3, norm_layer))
        _normal_init(cls_logits)
        super().__init__(cls_logits, num_classes)


class SSDLiteRegressionHead(SSDScoringHead):

    def __init__(self, in_channels: 'List[int]\n', num_anchors: 'List[int]\n', norm_layer: 'Callable[(..., nn.Module)]\n'):
        bbox_reg = nn.ModuleList()
        for channels, anchors in zip(in_channels, num_anchors):
            bbox_reg.append(_prediction_block(channels, 4 * anchors, 3, norm_layer))
        _normal_init(bbox_reg)
        super().__init__(bbox_reg, 4)


class SSDLiteHead(nn.Module):

    def __init__(self, in_channels: 'List[int]\n', num_anchors: 'List[int]\n', num_classes: 'int\n', norm_layer: 'Callable[(..., nn.Module)]\n'):
        super().__init__()
        self.classification_head = SSDLiteClassificationHead(in_channels, num_anchors, num_classes, norm_layer)
        self.regression_head = SSDLiteRegressionHead(in_channels, num_anchors, norm_layer)

    def forward(self, x: 'List[Tensor]\n') ->Dict[str, Tensor]:
        return {'bbox_regression': self.regression_head(x), 'cls_logits': self.classification_head(x)}


def _extra_block(in_channels: 'int\n', out_channels: 'int\n', norm_layer: 'Callable[(..., nn.Module)]\n') ->nn.Sequential:
    activation = nn.ReLU6
    intermediate_channels = out_channels // 2
    return nn.Sequential(Conv2dNormActivation(in_channels, intermediate_channels, kernel_size=1, norm_layer=norm_layer, activation_layer=activation), Conv2dNormActivation(intermediate_channels, intermediate_channels, kernel_size=3, stride=2, groups=intermediate_channels, norm_layer=norm_layer, activation_layer=activation), Conv2dNormActivation(intermediate_channels, out_channels, kernel_size=1, norm_layer=norm_layer, activation_layer=activation))


class SSDLiteFeatureExtractorMobileNet(nn.Module):

    def __init__(self, backbone: 'nn.Module\n', c4_pos: 'int\n', norm_layer: 'Callable[(..., nn.Module)]\n', width_mult: 'float\n'=1.0, min_depth: 'int\n'=16):
        super().__init__()
        _log_api_usage_once(self)
        if backbone[c4_pos].use_res_connect:
            raise ValueError('backbone[c4_pos].use_res_connect should be False')
        self.features = nn.Sequential(nn.Sequential(*backbone[:c4_pos], backbone[c4_pos].block[0]), nn.Sequential(backbone[c4_pos].block[1:], *backbone[c4_pos + 1:]))
        get_depth = lambda d: max(min_depth, int(d * width_mult))
        extra = nn.ModuleList([_extra_block(backbone[-1].out_channels, get_depth(512), norm_layer), _extra_block(get_depth(512), get_depth(256), norm_layer), _extra_block(get_depth(256), get_depth(256), norm_layer), _extra_block(get_depth(256), get_depth(128), norm_layer)])
        _normal_init(extra)
        self.extra = extra

    def forward(self, x: 'Tensor\n') ->Dict[str, Tensor]:
        output = []
        for block in self.features:
            x = block(x)
            output.append(x)
        for block in self.extra:
            x = block(x)
            output.append(x)
        return OrderedDict([(str(i), v) for i, v in enumerate(output)])


@torch.jit.unused
def _fake_cast_onnx(v: 'Tensor\n') ->float:
    return v


@torch.jit.unused
def _get_shape_onnx(image: 'Tensor\n') ->Tensor:
    from torch.onnx import operators
    return operators.shape_as_tensor(image)[-2:]


def _resize_image_and_masks(image: 'Tensor\n', self_min_size: 'int\n', self_max_size: 'int\n', target: 'Optional[Dict[(str, Tensor)]]\n'=None, fixed_size: 'Optional[Tuple[(int, int)]]\n'=None) ->Tuple[Tensor, Optional[Dict[str, Tensor]]]:
    if torchvision._is_tracing():
        im_shape = _get_shape_onnx(image)
    else:
        im_shape = torch.tensor(image.shape[-2:])
    size: 'Optional[List[int]]\n' = None
    scale_factor: 'Optional[float]\n' = None
    recompute_scale_factor: 'Optional[bool]\n' = None
    if fixed_size is not None:
        size = [fixed_size[1], fixed_size[0]]
    else:
        if torch.jit.is_scripting() or torchvision._is_tracing():
            min_size = torch.min(im_shape)
            max_size = torch.max(im_shape)
            self_min_size_f = float(self_min_size)
            self_max_size_f = float(self_max_size)
            scale = torch.min(self_min_size_f / min_size, self_max_size_f / max_size)
            if torchvision._is_tracing():
                scale_factor = _fake_cast_onnx(scale)
            else:
                scale_factor = scale.item()
        else:
            min_size = min(im_shape)
            max_size = max(im_shape)
            scale_factor = min(self_min_size / min_size, self_max_size / max_size)
        recompute_scale_factor = True
    image = torch.nn.functional.interpolate(image[None], size=size, scale_factor=scale_factor, mode='bilinear', recompute_scale_factor=recompute_scale_factor, align_corners=False)[0]
    if target is None:
        return image, target
    if 'masks' in target:
        mask = target['masks']
        mask = torch.nn.functional.interpolate(mask[:, (None)].float(), size=size, scale_factor=scale_factor, recompute_scale_factor=recompute_scale_factor)[:, (0)].byte()
        target['masks'] = mask
    return image, target


def _onnx_paste_mask_in_image(mask, box, im_h, im_w):
    one = torch.ones(1, dtype=torch.int64)
    zero = torch.zeros(1, dtype=torch.int64)
    w = box[2] - box[0] + one
    h = box[3] - box[1] + one
    w = torch.max(torch.cat((w, one)))
    h = torch.max(torch.cat((h, one)))
    mask = mask.expand((1, 1, mask.size(0), mask.size(1)))
    mask = F.interpolate(mask, size=(int(h), int(w)), mode='bilinear', align_corners=False)
    mask = mask[0][0]
    x_0 = torch.max(torch.cat((box[0].unsqueeze(0), zero)))
    x_1 = torch.min(torch.cat((box[2].unsqueeze(0) + one, im_w.unsqueeze(0))))
    y_0 = torch.max(torch.cat((box[1].unsqueeze(0), zero)))
    y_1 = torch.min(torch.cat((box[3].unsqueeze(0) + one, im_h.unsqueeze(0))))
    unpaded_im_mask = mask[y_0 - box[1]:y_1 - box[1], x_0 - box[0]:x_1 - box[0]]
    zeros_y0 = torch.zeros(y_0, unpaded_im_mask.size(1))
    zeros_y1 = torch.zeros(im_h - y_1, unpaded_im_mask.size(1))
    concat_0 = torch.cat((zeros_y0, unpaded_im_mask, zeros_y1), 0)[0:im_h, :]
    zeros_x0 = torch.zeros(concat_0.size(0), x_0)
    zeros_x1 = torch.zeros(concat_0.size(0), im_w - x_1)
    im_mask = torch.cat((zeros_x0, concat_0, zeros_x1), 1)[:, :im_w]
    return im_mask


@torch.jit._script_if_tracing
def _onnx_paste_masks_in_image_loop(masks, boxes, im_h, im_w):
    res_append = torch.zeros(0, im_h, im_w)
    for i in range(masks.size(0)):
        mask_res = _onnx_paste_mask_in_image(masks[i][0], boxes[i], im_h, im_w)
        mask_res = mask_res.unsqueeze(0)
        res_append = torch.cat((res_append, mask_res))
    return res_append


def _onnx_expand_boxes(boxes, scale):
    w_half = (boxes[:, (2)] - boxes[:, (0)]) * 0.5
    h_half = (boxes[:, (3)] - boxes[:, (1)]) * 0.5
    x_c = (boxes[:, (2)] + boxes[:, (0)]) * 0.5
    y_c = (boxes[:, (3)] + boxes[:, (1)]) * 0.5
    w_half = w_half * scale
    h_half = h_half * scale
    boxes_exp0 = x_c - w_half
    boxes_exp1 = y_c - h_half
    boxes_exp2 = x_c + w_half
    boxes_exp3 = y_c + h_half
    boxes_exp = torch.stack((boxes_exp0, boxes_exp1, boxes_exp2, boxes_exp3), 1)
    return boxes_exp


def expand_boxes(boxes, scale):
    if torchvision._is_tracing():
        return _onnx_expand_boxes(boxes, scale)
    w_half = (boxes[:, (2)] - boxes[:, (0)]) * 0.5
    h_half = (boxes[:, (3)] - boxes[:, (1)]) * 0.5
    x_c = (boxes[:, (2)] + boxes[:, (0)]) * 0.5
    y_c = (boxes[:, (3)] + boxes[:, (1)]) * 0.5
    w_half *= scale
    h_half *= scale
    boxes_exp = torch.zeros_like(boxes)
    boxes_exp[:, (0)] = x_c - w_half
    boxes_exp[:, (2)] = x_c + w_half
    boxes_exp[:, (1)] = y_c - h_half
    boxes_exp[:, (3)] = y_c + h_half
    return boxes_exp


@torch.jit.unused
def expand_masks_tracing_scale(M, padding):
    return torch.tensor(M + 2 * padding) / torch.tensor(M)


def expand_masks(mask, padding):
    M = mask.shape[-1]
    if torch._C._get_tracing_state():
        scale = expand_masks_tracing_scale(M, padding)
    else:
        scale = float(M + 2 * padding) / M
    padded_mask = F.pad(mask, (padding,) * 4)
    return padded_mask, scale


def paste_mask_in_image(mask, box, im_h, im_w):
    TO_REMOVE = 1
    w = int(box[2] - box[0] + TO_REMOVE)
    h = int(box[3] - box[1] + TO_REMOVE)
    w = max(w, 1)
    h = max(h, 1)
    mask = mask.expand((1, 1, -1, -1))
    mask = F.interpolate(mask, size=(h, w), mode='bilinear', align_corners=False)
    mask = mask[0][0]
    im_mask = torch.zeros((im_h, im_w), dtype=mask.dtype, device=mask.device)
    x_0 = max(box[0], 0)
    x_1 = min(box[2] + 1, im_w)
    y_0 = max(box[1], 0)
    y_1 = min(box[3] + 1, im_h)
    im_mask[y_0:y_1, x_0:x_1] = mask[y_0 - box[1]:y_1 - box[1], x_0 - box[0]:x_1 - box[0]]
    return im_mask


def paste_masks_in_image(masks, boxes, img_shape, padding=1):
    masks, scale = expand_masks(masks, padding=padding)
    boxes = expand_boxes(boxes, scale)
    im_h, im_w = img_shape
    if torchvision._is_tracing():
        return _onnx_paste_masks_in_image_loop(masks, boxes, torch.scalar_tensor(im_h, dtype=torch.int64), torch.scalar_tensor(im_w, dtype=torch.int64))[:, (None)]
    res = [paste_mask_in_image(m[0], b, im_h, im_w) for m, b in zip(masks, boxes)]
    if len(res) > 0:
        ret = torch.stack(res, dim=0)[:, (None)]
    else:
        ret = masks.new_empty((0, 1, im_h, im_w))
    return ret


def resize_boxes(boxes: 'Tensor\n', original_size: 'List[int]\n', new_size: 'List[int]\n') ->Tensor:
    ratios = [(torch.tensor(s, dtype=torch.float32, device=boxes.device) / torch.tensor(s_orig, dtype=torch.float32, device=boxes.device)) for s, s_orig in zip(new_size, original_size)]
    ratio_height, ratio_width = ratios
    xmin, ymin, xmax, ymax = boxes.unbind(1)
    xmin = xmin * ratio_width
    xmax = xmax * ratio_width
    ymin = ymin * ratio_height
    ymax = ymax * ratio_height
    return torch.stack((xmin, ymin, xmax, ymax), dim=1)


def resize_keypoints(keypoints: 'Tensor\n', original_size: 'List[int]\n', new_size: 'List[int]\n') ->Tensor:
    ratios = [(torch.tensor(s, dtype=torch.float32, device=keypoints.device) / torch.tensor(s_orig, dtype=torch.float32, device=keypoints.device)) for s, s_orig in zip(new_size, original_size)]
    ratio_h, ratio_w = ratios
    resized_data = keypoints.clone()
    if torch._C._get_tracing_state():
        resized_data_0 = resized_data[:, :, (0)] * ratio_w
        resized_data_1 = resized_data[:, :, (1)] * ratio_h
        resized_data = torch.stack((resized_data_0, resized_data_1, resized_data[:, :, (2)]), dim=2)
    else:
        resized_data[..., 0] *= ratio_w
        resized_data[..., 1] *= ratio_h
    return resized_data


class GeneralizedRCNNTransform(nn.Module):
    """
    Performs input / target transformation before feeding the data to a GeneralizedRCNN
    model.

    The transformations it performs are:
        - input normalization (mean subtraction and std division)
        - input / target resizing to match min_size / max_size

    It returns a ImageList for the inputs, and a List[Dict[Tensor]] for the targets
    """

    def __init__(self, min_size: 'int\n', max_size: 'int\n', image_mean: 'List[float]\n', image_std: 'List[float]\n', size_divisible: 'int\n'=32, fixed_size: 'Optional[Tuple[(int, int)]]\n'=None, **kwargs: Any):
        super().__init__()
        if not isinstance(min_size, (list, tuple)):
            min_size = min_size,
        self.min_size = min_size
        self.max_size = max_size
        self.image_mean = image_mean
        self.image_std = image_std
        self.size_divisible = size_divisible
        self.fixed_size = fixed_size
        self._skip_resize = kwargs.pop('_skip_resize', False)

    def forward(self, images: 'List[Tensor]\n', targets: 'Optional[List[Dict[(str, Tensor)]]]\n'=None) ->Tuple[ImageList, Optional[List[Dict[str, Tensor]]]]:
        images = [img for img in images]
        if targets is not None:
            targets_copy: 'List[Dict[(str, Tensor)]]\n' = []
            for t in targets:
                data: 'Dict[(str, Tensor)]\n' = {}
                for k, v in t.items():
                    data[k] = v
                targets_copy.append(data)
            targets = targets_copy
        for i in range(len(images)):
            image = images[i]
            target_index = targets[i] if targets is not None else None
            if image.dim() != 3:
                raise ValueError(f'images is expected to be a list of 3d tensors of shape [C, H, W], got {image.shape}')
            image = self.normalize(image)
            image, target_index = self.resize(image, target_index)
            images[i] = image
            if targets is not None and target_index is not None:
                targets[i] = target_index
        image_sizes = [img.shape[-2:] for img in images]
        images = self.batch_images(images, size_divisible=self.size_divisible)
        image_sizes_list: 'List[Tuple[(int, int)]]\n' = []
        for image_size in image_sizes:
            torch._assert(len(image_size) == 2, f'Input tensors expected to have in the last two elements H and W, instead got {image_size}')
            image_sizes_list.append((image_size[0], image_size[1]))
        image_list = ImageList(images, image_sizes_list)
        return image_list, targets

    def normalize(self, image: 'Tensor\n') ->Tensor:
        if not image.is_floating_point():
            raise TypeError(f'Expected input images to be of floating type (in range [0, 1]), but found type {image.dtype} instead')
        dtype, device = image.dtype, image.device
        mean = torch.as_tensor(self.image_mean, dtype=dtype, device=device)
        std = torch.as_tensor(self.image_std, dtype=dtype, device=device)
        return (image - mean[:, (None), (None)]) / std[:, (None), (None)]

    def torch_choice(self, k: 'List[int]\n') ->int:
        """
        Implements `random.choice` via torch ops, so it can be compiled with
        TorchScript and we use PyTorch's RNG (not native RNG)
        """
        index = int(torch.empty(1).uniform_(0.0, float(len(k))).item())
        return k[index]

    def resize(self, image: 'Tensor\n', target: 'Optional[Dict[(str, Tensor)]]\n'=None) ->Tuple[Tensor, Optional[Dict[str, Tensor]]]:
        h, w = image.shape[-2:]
        if self.training:
            if self._skip_resize:
                return image, target
            size = self.torch_choice(self.min_size)
        else:
            size = self.min_size[-1]
        image, target = _resize_image_and_masks(image, size, self.max_size, target, self.fixed_size)
        if target is None:
            return image, target
        bbox = target['boxes']
        bbox = resize_boxes(bbox, (h, w), image.shape[-2:])
        target['boxes'] = bbox
        if 'keypoints' in target:
            keypoints = target['keypoints']
            keypoints = resize_keypoints(keypoints, (h, w), image.shape[-2:])
            target['keypoints'] = keypoints
        return image, target

    @torch.jit.unused
    def _onnx_batch_images(self, images: 'List[Tensor]\n', size_divisible: 'int\n'=32) ->Tensor:
        max_size = []
        for i in range(images[0].dim()):
            max_size_i = torch.max(torch.stack([img.shape[i] for img in images]).to(torch.float32))
            max_size.append(max_size_i)
        stride = size_divisible
        max_size[1] = torch.ceil(max_size[1].to(torch.float32) / stride) * stride
        max_size[2] = torch.ceil(max_size[2].to(torch.float32) / stride) * stride
        max_size = tuple(max_size)
        padded_imgs = []
        for img in images:
            padding = [(s1 - s2) for s1, s2 in zip(max_size, tuple(img.shape))]
            padded_img = torch.nn.functional.pad(img, (0, padding[2], 0, padding[1], 0, padding[0]))
            padded_imgs.append(padded_img)
        return torch.stack(padded_imgs)

    def max_by_axis(self, the_list: 'List[List[int]]\n') ->List[int]:
        maxes = the_list[0]
        for sublist in the_list[1:]:
            for index, item in enumerate(sublist):
                maxes[index] = max(maxes[index], item)
        return maxes

    def batch_images(self, images: 'List[Tensor]\n', size_divisible: 'int\n'=32) ->Tensor:
        if torchvision._is_tracing():
            return self._onnx_batch_images(images, size_divisible)
        max_size = self.max_by_axis([list(img.shape) for img in images])
        stride = float(size_divisible)
        max_size = list(max_size)
        max_size[1] = int(math.ceil(float(max_size[1]) / stride) * stride)
        max_size[2] = int(math.ceil(float(max_size[2]) / stride) * stride)
        batch_shape = [len(images)] + max_size
        batched_imgs = images[0].new_full(batch_shape, 0)
        for i in range(batched_imgs.shape[0]):
            img = images[i]
            batched_imgs[(i), :img.shape[0], :img.shape[1], :img.shape[2]].copy_(img)
        return batched_imgs

    def postprocess(self, result: 'List[Dict[(str, Tensor)]]\n', image_shapes: 'List[Tuple[(int, int)]]\n', original_image_sizes: 'List[Tuple[(int, int)]]\n') ->List[Dict[str, Tensor]]:
        if self.training:
            return result
        for i, (pred, im_s, o_im_s) in enumerate(zip(result, image_shapes, original_image_sizes)):
            boxes = pred['boxes']
            boxes = resize_boxes(boxes, im_s, o_im_s)
            result[i]['boxes'] = boxes
            if 'masks' in pred:
                masks = pred['masks']
                masks = paste_masks_in_image(masks, boxes, o_im_s)
                result[i]['masks'] = masks
            if 'keypoints' in pred:
                keypoints = pred['keypoints']
                keypoints = resize_keypoints(keypoints, im_s, o_im_s)
                result[i]['keypoints'] = keypoints
        return result

    def __repr__(self) ->str:
        format_string = f'{self.__class__.__name__}('
        _indent = '\n    '
        format_string += f'{_indent}Normalize(mean={self.image_mean}, std={self.image_std})'
        format_string += f"{_indent}Resize(min_size={self.min_size}, max_size={self.max_size}, mode='bilinear')"
        format_string += '\n)'
        return format_string


class ResidualBlock(nn.Module):
    """Slightly modified Residual block with extra relu and biases."""

    def __init__(self, in_channels, out_channels, *, norm_layer, stride=1, always_project: bool=False):
        super().__init__()
        self.convnormrelu1 = Conv2dNormActivation(in_channels, out_channels, norm_layer=norm_layer, kernel_size=3, stride=stride, bias=True)
        self.convnormrelu2 = Conv2dNormActivation(out_channels, out_channels, norm_layer=norm_layer, kernel_size=3, bias=True)
        self.downsample: 'nn.Module\n'
        if stride == 1 and not always_project:
            self.downsample = nn.Identity()
        else:
            self.downsample = Conv2dNormActivation(in_channels, out_channels, norm_layer=norm_layer, kernel_size=1, stride=stride, bias=True, activation_layer=None)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        y = x
        y = self.convnormrelu1(y)
        y = self.convnormrelu2(y)
        x = self.downsample(x)
        return self.relu(x + y)


class BottleneckBlock(nn.Module):
    """Slightly modified BottleNeck block (extra relu and biases)"""

    def __init__(self, in_channels, out_channels, *, norm_layer, stride=1):
        super().__init__()
        self.convnormrelu1 = Conv2dNormActivation(in_channels, out_channels // 4, norm_layer=norm_layer, kernel_size=1, bias=True)
        self.convnormrelu2 = Conv2dNormActivation(out_channels // 4, out_channels // 4, norm_layer=norm_layer, kernel_size=3, stride=stride, bias=True)
        self.convnormrelu3 = Conv2dNormActivation(out_channels // 4, out_channels, norm_layer=norm_layer, kernel_size=1, bias=True)
        self.relu = nn.ReLU(inplace=True)
        if stride == 1:
            self.downsample = nn.Identity()
        else:
            self.downsample = Conv2dNormActivation(in_channels, out_channels, norm_layer=norm_layer, kernel_size=1, stride=stride, bias=True, activation_layer=None)

    def forward(self, x):
        y = x
        y = self.convnormrelu1(y)
        y = self.convnormrelu2(y)
        y = self.convnormrelu3(y)
        x = self.downsample(x)
        return self.relu(x + y)


class FeatureEncoder(nn.Module):
    """Feature Encoder for Raft-Stereo (see paper section 3.1) that may have shared weight with the Context Encoder.

    The FeatureEncoder takes concatenation of left and right image as input. It produces feature embedding that later
    will be used to construct correlation volume.
    """

    def __init__(self, base_encoder: 'BaseEncoder\n', output_dim: 'int\n'=256, shared_base: 'bool\n'=False, block: 'Callable[(..., nn.Module)]\n'=ResidualBlock):
        super().__init__()
        self.base_encoder = base_encoder
        self.base_downsampling_ratio = base_encoder.downsampling_ratio
        base_dim = base_encoder.output_dim
        if not shared_base:
            self.residual_block: 'nn.Module\n' = nn.Identity()
            self.conv = nn.Conv2d(base_dim, output_dim, kernel_size=1)
        else:
            self.residual_block = block(base_dim, base_dim, norm_layer=nn.InstanceNorm2d, stride=1)
            self.conv = nn.Conv2d(base_dim, output_dim, kernel_size=3, padding=1)

    def forward(self, x: 'Tensor\n') ->Tensor:
        x = self.base_encoder(x)
        x = self.residual_block(x)
        x = self.conv(x)
        return x


class MotionEncoder(nn.Module):
    """The motion encoder, part of the update block.

    Takes the current predicted flow and the correlation features as input and returns an encoded version of these.
    """

    def __init__(self, *, in_channels_corr, corr_layers=(256, 192), flow_layers=(128, 64), out_channels=128):
        super().__init__()
        if len(flow_layers) != 2:
            raise ValueError(f'The expected number of flow_layers is 2, instead got {len(flow_layers)}')
        if len(corr_layers) not in (1, 2):
            raise ValueError(f'The number of corr_layers should be 1 or 2, instead got {len(corr_layers)}')
        self.convcorr1 = Conv2dNormActivation(in_channels_corr, corr_layers[0], norm_layer=None, kernel_size=1)
        if len(corr_layers) == 2:
            self.convcorr2 = Conv2dNormActivation(corr_layers[0], corr_layers[1], norm_layer=None, kernel_size=3)
        else:
            self.convcorr2 = nn.Identity()
        self.convflow1 = Conv2dNormActivation(2, flow_layers[0], norm_layer=None, kernel_size=7)
        self.convflow2 = Conv2dNormActivation(flow_layers[0], flow_layers[1], norm_layer=None, kernel_size=3)
        self.conv = Conv2dNormActivation(corr_layers[-1] + flow_layers[-1], out_channels - 2, norm_layer=None, kernel_size=3)
        self.out_channels = out_channels

    def forward(self, flow, corr_features):
        corr = self.convcorr1(corr_features)
        corr = self.convcorr2(corr)
        flow_orig = flow
        flow = self.convflow1(flow)
        flow = self.convflow2(flow)
        corr_flow = torch.cat([corr, flow], dim=1)
        corr_flow = self.conv(corr_flow)
        return torch.cat([corr_flow, flow_orig], dim=1)


class ConvGRU(raft.ConvGRU):
    """Convolutional Gru unit."""

    def forward(self, h: 'Tensor\n', x: 'Tensor\n', context: 'List[Tensor]\n') ->Tensor:
        hx = torch.cat([h, x], dim=1)
        z = torch.sigmoid(self.convz(hx) + context[0])
        r = torch.sigmoid(self.convr(hx) + context[1])
        q = torch.tanh(self.convq(torch.cat([r * h, x], dim=1)) + context[2])
        h = (1 - z) * h + z * q
        return h


def _pass_through_h(h, _):
    return h


class RecurrentBlock(nn.Module):
    """Recurrent block, part of the update block.

    Takes the current hidden state and the concatenation of (motion encoder output, context) as input.
    Returns an updated hidden state.
    """

    def __init__(self, *, input_size, hidden_size, kernel_size=((1, 5), (5, 1)), padding=((0, 2), (2, 0))):
        super().__init__()
        if len(kernel_size) != len(padding):
            raise ValueError(f'kernel_size should have the same length as padding, instead got len(kernel_size) = {len(kernel_size)} and len(padding) = {len(padding)}')
        if len(kernel_size) not in (1, 2):
            raise ValueError(f'kernel_size should either 1 or 2, instead got {len(kernel_size)}')
        self.convgru1 = ConvGRU(input_size=input_size, hidden_size=hidden_size, kernel_size=kernel_size[0], padding=padding[0])
        if len(kernel_size) == 2:
            self.convgru2 = ConvGRU(input_size=input_size, hidden_size=hidden_size, kernel_size=kernel_size[1], padding=padding[1])
        else:
            self.convgru2 = _pass_through_h
        self.hidden_size = hidden_size

    def forward(self, h, x):
        h = self.convgru1(h, x)
        h = self.convgru2(h, x)
        return h


class FlowHead(nn.Module):
    """Flow head, part of the update block.

    Takes the hidden state of the recurrent unit as input, and outputs the predicted "delta flow".
    """

    def __init__(self, *, in_channels, hidden_size):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, hidden_size, 3, padding=1)
        self.conv2 = nn.Conv2d(hidden_size, 2, 3, padding=1)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        return self.conv2(self.relu(self.conv1(x)))


class UpdateBlock(nn.Module):
    """The update block which contains the motion encoder, the recurrent block, and the flow head.

    It must expose a ``hidden_state_size`` attribute which is the hidden state size of its recurrent block.
    """

    def __init__(self, *, motion_encoder, recurrent_block, flow_head):
        super().__init__()
        self.motion_encoder = motion_encoder
        self.recurrent_block = recurrent_block
        self.flow_head = flow_head
        self.hidden_state_size = recurrent_block.hidden_size

    def forward(self, hidden_state, context, corr_features, flow):
        motion_features = self.motion_encoder(flow, corr_features)
        x = torch.cat([context, motion_features], dim=1)
        hidden_state = self.recurrent_block(hidden_state, x)
        delta_flow = self.flow_head(hidden_state)
        return hidden_state, delta_flow


class MaskPredictor(raft.MaskPredictor):
    """Mask predictor to be used when upsampling the predicted disparity."""

    def __init__(self, *, in_channels: int, hidden_size: int, out_channels: int, multiplier: float=0.25):
        super(raft.MaskPredictor, self).__init__()
        self.convrelu = Conv2dNormActivation(in_channels, hidden_size, norm_layer=None, kernel_size=3)
        self.conv = nn.Conv2d(hidden_size, out_channels, kernel_size=1, padding=0)
        self.multiplier = multiplier


class CorrBlock(nn.Module):
    """The correlation block.

    Creates a correlation pyramid with ``num_levels`` levels from the outputs of the feature encoder,
    and then indexes from this pyramid to create correlation features.
    The "indexing" of a given centroid pixel x' is done by concatenating its surrounding neighbors that
    are within a ``radius``, according to the infinity norm (see paper section 3.2).
    Note: typo in the paper, it should be infinity norm, not 1-norm.
    """

    def __init__(self, *, num_levels: int=4, radius: int=4):
        super().__init__()
        self.num_levels = num_levels
        self.radius = radius
        self.corr_pyramid: 'List[Tensor]\n' = [torch.tensor(0)]
        self.out_channels = num_levels * (2 * radius + 1) ** 2

    def build_pyramid(self, fmap1, fmap2):
        """Build the correlation pyramid from two feature maps.

        The correlation volume is first computed as the dot product of each pair (pixel_in_fmap1, pixel_in_fmap2)
        The last 2 dimensions of the correlation volume are then pooled num_levels times at different resolutions
        to build the correlation pyramid.
        """
        if fmap1.shape != fmap2.shape:
            raise ValueError(f'Input feature maps should have the same shape, instead got {fmap1.shape} (fmap1.shape) != {fmap2.shape} (fmap2.shape)')
        min_fmap_size = 2 * 2 ** (self.num_levels - 1)
        if any(fmap_size < min_fmap_size for fmap_size in fmap1.shape[-2:]):
            raise ValueError(f'Feature maps are too small to be down-sampled by the correlation pyramid. H and W of feature maps should be at least {min_fmap_size}; got: {fmap1.shape[-2:]}. Remember that input images to the model are downsampled by 8, so that means their dimensions should be at least 8 * {min_fmap_size} = {8 * min_fmap_size}.')
        corr_volume = self._compute_corr_volume(fmap1, fmap2)
        batch_size, h, w, num_channels, _, _ = corr_volume.shape
        corr_volume = corr_volume.reshape(batch_size * h * w, num_channels, h, w)
        self.corr_pyramid = [corr_volume]
        for _ in range(self.num_levels - 1):
            corr_volume = F.avg_pool2d(corr_volume, kernel_size=2, stride=2)
            self.corr_pyramid.append(corr_volume)

    def index_pyramid(self, centroids_coords):
        """Return correlation features by indexing from the pyramid."""
        neighborhood_side_len = 2 * self.radius + 1
        di = torch.linspace(-self.radius, self.radius, neighborhood_side_len)
        dj = torch.linspace(-self.radius, self.radius, neighborhood_side_len)
        delta = torch.stack(torch.meshgrid(di, dj, indexing='ij'), dim=-1)
        delta = delta.view(1, neighborhood_side_len, neighborhood_side_len, 2)
        batch_size, _, h, w = centroids_coords.shape
        centroids_coords = centroids_coords.permute(0, 2, 3, 1).reshape(batch_size * h * w, 1, 1, 2)
        indexed_pyramid = []
        for corr_volume in self.corr_pyramid:
            sampling_coords = centroids_coords + delta
            indexed_corr_volume = grid_sample(corr_volume, sampling_coords, align_corners=True, mode='bilinear').view(batch_size, h, w, -1)
            indexed_pyramid.append(indexed_corr_volume)
            centroids_coords = centroids_coords / 2
        corr_features = torch.cat(indexed_pyramid, dim=-1).permute(0, 3, 1, 2).contiguous()
        expected_output_shape = batch_size, self.out_channels, h, w
        if corr_features.shape != expected_output_shape:
            raise ValueError(f'Output shape of index pyramid is incorrect. Should be {expected_output_shape}, got {corr_features.shape}')
        return corr_features

    def _compute_corr_volume(self, fmap1, fmap2):
        batch_size, num_channels, h, w = fmap1.shape
        fmap1 = fmap1.view(batch_size, num_channels, h * w)
        fmap2 = fmap2.view(batch_size, num_channels, h * w)
        corr = torch.matmul(fmap1.transpose(1, 2), fmap2)
        corr = corr.view(batch_size, h, w, 1, h, w)
        return corr / torch.sqrt(torch.tensor(num_channels))


class RAFT(nn.Module):

    def __init__(self, *, feature_encoder, context_encoder, corr_block, update_block, mask_predictor=None):
        """RAFT model from
        `RAFT: Recurrent All Pairs Field Transforms for Optical Flow <https://arxiv.org/abs/2003.12039>`_.

        args:
            feature_encoder (nn.Module): The feature encoder. It must downsample the input by 8.
                Its input is the concatenation of ``image1`` and ``image2``.
            context_encoder (nn.Module): The context encoder. It must downsample the input by 8.
                Its input is ``image1``. As in the original implementation, its output will be split into 2 parts:

                - one part will be used as the actual "context", passed to the recurrent unit of the ``update_block``
                - one part will be used to initialize the hidden state of the recurrent unit of
                  the ``update_block``

                These 2 parts are split according to the ``hidden_state_size`` of the ``update_block``, so the output
                of the ``context_encoder`` must be strictly greater than ``hidden_state_size``.

            corr_block (nn.Module): The correlation block, which creates a correlation pyramid from the output of the
                ``feature_encoder``, and then indexes from this pyramid to create correlation features. It must expose
                2 methods:

                - a ``build_pyramid`` method that takes ``feature_map_1`` and ``feature_map_2`` as input (these are the
                  output of the ``feature_encoder``).
                - a ``index_pyramid`` method that takes the coordinates of the centroid pixels as input, and returns
                  the correlation features. See paper section 3.2.

                It must expose an ``out_channels`` attribute.

            update_block (nn.Module): The update block, which contains the motion encoder, the recurrent unit, and the
                flow head. It takes as input the hidden state of its recurrent unit, the context, the correlation
                features, and the current predicted flow. It outputs an updated hidden state, and the ``delta_flow``
                prediction (see paper appendix A). It must expose a ``hidden_state_size`` attribute.
            mask_predictor (nn.Module, optional): Predicts the mask that will be used to upsample the predicted flow.
                The output channel must be 8 * 8 * 9 - see paper section 3.3, and Appendix B.
                If ``None`` (default), the flow is upsampled using interpolation.
        """
        super().__init__()
        _log_api_usage_once(self)
        self.feature_encoder = feature_encoder
        self.context_encoder = context_encoder
        self.corr_block = corr_block
        self.update_block = update_block
        self.mask_predictor = mask_predictor
        if not hasattr(self.update_block, 'hidden_state_size'):
            raise ValueError("The update_block parameter should expose a 'hidden_state_size' attribute.")

    def forward(self, image1, image2, num_flow_updates: 'int\n'=12):
        batch_size, _, h, w = image1.shape
        if (h, w) != image2.shape[-2:]:
            raise ValueError(f'input images should have the same shape, instead got ({h}, {w}) != {image2.shape[-2:]}')
        if not h % 8 == 0 and w % 8 == 0:
            raise ValueError(f'input image H and W should be divisible by 8, instead got {h} (h) and {w} (w)')
        fmaps = self.feature_encoder(torch.cat([image1, image2], dim=0))
        fmap1, fmap2 = torch.chunk(fmaps, chunks=2, dim=0)
        if fmap1.shape[-2:] != (h // 8, w // 8):
            raise ValueError('The feature encoder should downsample H and W by 8')
        self.corr_block.build_pyramid(fmap1, fmap2)
        context_out = self.context_encoder(image1)
        if context_out.shape[-2:] != (h // 8, w // 8):
            raise ValueError('The context encoder should downsample H and W by 8')
        hidden_state_size = self.update_block.hidden_state_size
        out_channels_context = context_out.shape[1] - hidden_state_size
        if out_channels_context <= 0:
            raise ValueError(f'The context encoder outputs {context_out.shape[1]} channels, but it should have at strictly more than hidden_state={hidden_state_size} channels')
        hidden_state, context = torch.split(context_out, [hidden_state_size, out_channels_context], dim=1)
        hidden_state = torch.tanh(hidden_state)
        context = F.relu(context)
        coords0 = make_coords_grid(batch_size, h // 8, w // 8)
        coords1 = make_coords_grid(batch_size, h // 8, w // 8)
        flow_predictions = []
        for _ in range(num_flow_updates):
            coords1 = coords1.detach()
            corr_features = self.corr_block.index_pyramid(centroids_coords=coords1)
            flow = coords1 - coords0
            hidden_state, delta_flow = self.update_block(hidden_state, context, corr_features, flow)
            coords1 = coords1 + delta_flow
            up_mask = None if self.mask_predictor is None else self.mask_predictor(hidden_state)
            upsampled_flow = upsample_flow(flow=coords1 - coords0, up_mask=up_mask)
            flow_predictions.append(upsampled_flow)
        return flow_predictions


class _SimpleSegmentationModel(nn.Module):
    __constants__ = ['aux_classifier']

    def __init__(self, backbone: 'nn.Module\n', classifier: 'nn.Module\n', aux_classifier: 'Optional[nn.Module]\n'=None) ->None:
        super().__init__()
        _log_api_usage_once(self)
        self.backbone = backbone
        self.classifier = classifier
        self.aux_classifier = aux_classifier

    def forward(self, x: 'Tensor\n') ->Dict[str, Tensor]:
        input_shape = x.shape[-2:]
        features = self.backbone(x)
        result = OrderedDict()
        x = features['out']
        x = self.classifier(x)
        x = F.interpolate(x, size=input_shape, mode='bilinear', align_corners=False)
        result['out'] = x
        if self.aux_classifier is not None:
            x = features['aux']
            x = self.aux_classifier(x)
            x = F.interpolate(x, size=input_shape, mode='bilinear', align_corners=False)
            result['aux'] = x
        return result


class DeepLabV3(_SimpleSegmentationModel):
    """
    Implements DeepLabV3 model from
    `"Rethinking Atrous Convolution for Semantic Image Segmentation"
    <https://arxiv.org/abs/1706.05587>`_.

    Args:
        backbone (nn.Module): the network used to compute the features for the model.
            The backbone should return an OrderedDict[Tensor], with the key being
            "out" for the last feature map used, and "aux" if an auxiliary classifier
            is used.
        classifier (nn.Module): module that takes the "out" element returned from
            the backbone and returns a dense prediction.
        aux_classifier (nn.Module, optional): auxiliary classifier used during training
    """
    pass


class ASPPConv(nn.Sequential):

    def __init__(self, in_channels: 'int\n', out_channels: 'int\n', dilation: 'int\n') ->None:
        modules = [nn.Conv2d(in_channels, out_channels, 3, padding=dilation, dilation=dilation, bias=False), nn.BatchNorm2d(out_channels), nn.ReLU()]
        super().__init__(*modules)


class ASPPPooling(nn.Sequential):

    def __init__(self, in_channels: 'int\n', out_channels: 'int\n') ->None:
        super().__init__(nn.AdaptiveAvgPool2d(1), nn.Conv2d(in_channels, out_channels, 1, bias=False), nn.BatchNorm2d(out_channels), nn.ReLU())

    def forward(self, x: 'torch.Tensor\n') ->torch.Tensor:
        size = x.shape[-2:]
        for mod in self:
            x = mod(x)
        return F.interpolate(x, size=size, mode='bilinear', align_corners=False)


class ASPP(nn.Module):

    def __init__(self, in_channels: 'int\n', atrous_rates: 'List[int]\n', out_channels: 'int\n'=256) ->None:
        super().__init__()
        modules = []
        modules.append(nn.Sequential(nn.Conv2d(in_channels, out_channels, 1, bias=False), nn.BatchNorm2d(out_channels), nn.ReLU()))
        rates = tuple(atrous_rates)
        for rate in rates:
            modules.append(ASPPConv(in_channels, out_channels, rate))
        modules.append(ASPPPooling(in_channels, out_channels))
        self.convs = nn.ModuleList(modules)
        self.project = nn.Sequential(nn.Conv2d(len(self.convs) * out_channels, out_channels, 1, bias=False), nn.BatchNorm2d(out_channels), nn.ReLU(), nn.Dropout(0.5))

    def forward(self, x: 'torch.Tensor\n') ->torch.Tensor:
        _res = []
        for conv in self.convs:
            _res.append(conv(x))
        res = torch.cat(_res, dim=1)
        return self.project(res)


class DeepLabHead(nn.Sequential):

    def __init__(self, in_channels: 'int\n', num_classes: 'int\n') ->None:
        super().__init__(ASPP(in_channels, [12, 24, 36]), nn.Conv2d(256, 256, 3, padding=1, bias=False), nn.BatchNorm2d(256), nn.ReLU(), nn.Conv2d(256, num_classes, 1))


class FCN(_SimpleSegmentationModel):
    """
    Implements FCN model from
    `"Fully Convolutional Networks for Semantic Segmentation"
    <https://arxiv.org/abs/1411.4038>`_.

    Args:
        backbone (nn.Module): the network used to compute the features for the model.
            The backbone should return an OrderedDict[Tensor], with the key being
            "out" for the last feature map used, and "aux" if an auxiliary classifier
            is used.
        classifier (nn.Module): module that takes the "out" element returned from
            the backbone and returns a dense prediction.
        aux_classifier (nn.Module, optional): auxiliary classifier used during training
    """
    pass


class FCNHead(nn.Sequential):

    def __init__(self, in_channels: 'int\n', channels: 'int\n') ->None:
        inter_channels = in_channels // 4
        layers = [nn.Conv2d(in_channels, inter_channels, 3, padding=1, bias=False), nn.BatchNorm2d(inter_channels), nn.ReLU(), nn.Dropout(0.1), nn.Conv2d(inter_channels, channels, 1)]
        super().__init__(*layers)


class LRASPPHead(nn.Module):

    def __init__(self, low_channels: 'int\n', high_channels: 'int\n', num_classes: 'int\n', inter_channels: 'int\n') ->None:
        super().__init__()
        self.cbr = nn.Sequential(nn.Conv2d(high_channels, inter_channels, 1, bias=False), nn.BatchNorm2d(inter_channels), nn.ReLU(inplace=True))
        self.scale = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Conv2d(high_channels, inter_channels, 1, bias=False), nn.Sigmoid())
        self.low_classifier = nn.Conv2d(low_channels, num_classes, 1)
        self.high_classifier = nn.Conv2d(inter_channels, num_classes, 1)

    def forward(self, input: 'Dict[(str, Tensor)]\n') ->Tensor:
        low = input['low']
        high = input['high']
        x = self.cbr(high)
        s = self.scale(high)
        x = x * s
        x = F.interpolate(x, size=low.shape[-2:], mode='bilinear', align_corners=False)
        return self.low_classifier(low) + self.high_classifier(x)


class LRASPP(nn.Module):
    """
    Implements a Lite R-ASPP Network for semantic segmentation from
    `"Searching for MobileNetV3"
    <https://arxiv.org/abs/1905.02244>`_.

    Args:
        backbone (nn.Module): the network used to compute the features for the model.
            The backbone should return an OrderedDict[Tensor], with the key being
            "high" for the high level feature map and "low" for the low level feature map.
        low_channels (int): the number of channels of the low level features.
        high_channels (int): the number of channels of the high level features.
        num_classes (int, optional): number of output classes of the model (including the background).
        inter_channels (int, optional): the number of channels for intermediate computations.
    """

    def __init__(self, backbone: 'nn.Module\n', low_channels: 'int\n', high_channels: 'int\n', num_classes: 'int\n', inter_channels: 'int\n'=128) ->None:
        super().__init__()
        _log_api_usage_once(self)
        self.backbone = backbone
        self.classifier = LRASPPHead(low_channels, high_channels, num_classes, inter_channels)

    def forward(self, input: 'Tensor\n') ->Dict[str, Tensor]:
        features = self.backbone(input)
        out = self.classifier(features)
        out = F.interpolate(out, size=input.shape[-2:], mode='bilinear', align_corners=False)
        result = OrderedDict()
        result['out'] = out
        return result


def _squeeze(x: 'torch.Tensor\n', target_dim: 'int\n', expand_dim: 'int\n', tensor_dim: 'int\n') ->torch.Tensor:
    if tensor_dim == target_dim - 1:
        x = x.squeeze(expand_dim)
    return x


def _unsqueeze(x: 'torch.Tensor\n', target_dim: 'int\n', expand_dim: 'int\n') ->Tuple[torch.Tensor, int]:
    tensor_dim = x.dim()
    if tensor_dim == target_dim - 1:
        x = x.unsqueeze(expand_dim)
    elif tensor_dim != target_dim:
        raise ValueError(f'Unsupported input dimension {x.shape}')
    return x, tensor_dim


class Pool(nn.Module):

    def __init__(self, pool: 'nn.Module\n', norm: 'Optional[nn.Module]\n', activation: 'Optional[nn.Module]\n'=None, norm_before_pool: 'bool\n'=False) ->None:
        super().__init__()
        self.pool = pool
        layers = []
        if norm is not None:
            layers.append(norm)
        if activation is not None:
            layers.append(activation)
        self.norm_act = nn.Sequential(*layers) if layers else None
        self.norm_before_pool = norm_before_pool

    def forward(self, x: 'torch.Tensor\n', thw: 'Tuple[(int, int, int)]\n') ->Tuple[torch.Tensor, Tuple[int, int, int]]:
        x, tensor_dim = _unsqueeze(x, 4, 1)
        class_token, x = torch.tensor_split(x, indices=(1,), dim=2)
        x = x.transpose(2, 3)
        B, N, C = x.shape[:3]
        x = x.reshape((B * N, C) + thw).contiguous()
        if self.norm_before_pool and self.norm_act is not None:
            x = self.norm_act(x)
        x = self.pool(x)
        T, H, W = x.shape[2:]
        x = x.reshape(B, N, C, -1).transpose(2, 3)
        x = torch.cat((class_token, x), dim=2)
        if not self.norm_before_pool and self.norm_act is not None:
            x = self.norm_act(x)
        x = _squeeze(x, 4, 1, tensor_dim)
        return x, (T, H, W)


def _interpolate(embedding: 'torch.Tensor\n', d: 'int\n') ->torch.Tensor:
    if embedding.shape[0] == d:
        return embedding
    return nn.functional.interpolate(embedding.permute(1, 0).unsqueeze(0), size=d, mode='linear').squeeze(0).permute(1, 0)


def _add_rel_pos(attn: 'torch.Tensor\n', q: 'torch.Tensor\n', q_thw: 'Tuple[(int, int, int)]\n', k_thw: 'Tuple[(int, int, int)]\n', rel_pos_h: 'torch.Tensor\n', rel_pos_w: 'torch.Tensor\n', rel_pos_t: 'torch.Tensor\n') ->torch.Tensor:
    q_t, q_h, q_w = q_thw
    k_t, k_h, k_w = k_thw
    dh = int(2 * max(q_h, k_h) - 1)
    dw = int(2 * max(q_w, k_w) - 1)
    dt = int(2 * max(q_t, k_t) - 1)
    q_h_ratio = max(k_h / q_h, 1.0)
    k_h_ratio = max(q_h / k_h, 1.0)
    dist_h = torch.arange(q_h)[:, (None)] * q_h_ratio - (torch.arange(k_h)[(None), :] + (1.0 - k_h)) * k_h_ratio
    q_w_ratio = max(k_w / q_w, 1.0)
    k_w_ratio = max(q_w / k_w, 1.0)
    dist_w = torch.arange(q_w)[:, (None)] * q_w_ratio - (torch.arange(k_w)[(None), :] + (1.0 - k_w)) * k_w_ratio
    q_t_ratio = max(k_t / q_t, 1.0)
    k_t_ratio = max(q_t / k_t, 1.0)
    dist_t = torch.arange(q_t)[:, (None)] * q_t_ratio - (torch.arange(k_t)[(None), :] + (1.0 - k_t)) * k_t_ratio
    rel_pos_h = _interpolate(rel_pos_h, dh)
    rel_pos_w = _interpolate(rel_pos_w, dw)
    rel_pos_t = _interpolate(rel_pos_t, dt)
    Rh = rel_pos_h[dist_h.long()]
    Rw = rel_pos_w[dist_w.long()]
    Rt = rel_pos_t[dist_t.long()]
    B, n_head, _, dim = q.shape
    r_q = q[:, :, 1:].reshape(B, n_head, q_t, q_h, q_w, dim)
    rel_h_q = torch.einsum('bythwc,hkc->bythwk', r_q, Rh)
    rel_w_q = torch.einsum('bythwc,wkc->bythwk', r_q, Rw)
    r_q = r_q.permute(2, 0, 1, 3, 4, 5).reshape(q_t, B * n_head * q_h * q_w, dim)
    rel_q_t = torch.matmul(r_q, Rt.transpose(1, 2)).transpose(0, 1)
    rel_q_t = rel_q_t.view(B, n_head, q_h, q_w, q_t, k_t).permute(0, 1, 4, 2, 3, 5)
    rel_pos = (rel_h_q[:, :, :, :, :, (None), :, (None)] + rel_w_q[:, :, :, :, :, (None), (None), :] + rel_q_t[:, :, :, :, :, :, (None), (None)]).reshape(B, n_head, q_t * q_h * q_w, k_t * k_h * k_w)
    attn[:, :, 1:, 1:] += rel_pos
    return attn


def _add_shortcut(x: 'torch.Tensor\n', shortcut: 'torch.Tensor\n', residual_with_cls_embed: 'bool\n'):
    if residual_with_cls_embed:
        x.add_(shortcut)
    else:
        x[:, :, 1:, :] += shortcut[:, :, 1:, :]
    return x


def _prod(s: 'Sequence[int]\n') ->int:
    product = 1
    for v in s:
        product *= v
    return product


class MultiscaleAttention(nn.Module):

    def __init__(self, input_size: 'List[int]\n', embed_dim: 'int\n', output_dim: 'int\n', num_heads: 'int\n', kernel_q: 'List[int]\n', kernel_kv: 'List[int]\n', stride_q: 'List[int]\n', stride_kv: 'List[int]\n', residual_pool: 'bool\n', residual_with_cls_embed: 'bool\n', rel_pos_embed: 'bool\n', dropout: 'float\n'=0.0, norm_layer: 'Callable[(..., nn.Module)]\n'=nn.LayerNorm) ->None:
        super().__init__()
        self.embed_dim = embed_dim
        self.output_dim = output_dim
        self.num_heads = num_heads
        self.head_dim = output_dim // num_heads
        self.scaler = 1.0 / math.sqrt(self.head_dim)
        self.residual_pool = residual_pool
        self.residual_with_cls_embed = residual_with_cls_embed
        self.qkv = nn.Linear(embed_dim, 3 * output_dim)
        layers: 'List[nn.Module]\n' = [nn.Linear(output_dim, output_dim)]
        if dropout > 0.0:
            layers.append(nn.Dropout(dropout, inplace=True))
        self.project = nn.Sequential(*layers)
        self.pool_q: 'Optional[nn.Module]\n' = None
        if _prod(kernel_q) > 1 or _prod(stride_q) > 1:
            padding_q = [int(q // 2) for q in kernel_q]
            self.pool_q = Pool(nn.Conv3d(self.head_dim, self.head_dim, kernel_q, stride=stride_q, padding=padding_q, groups=self.head_dim, bias=False), norm_layer(self.head_dim))
        self.pool_k: 'Optional[nn.Module]\n' = None
        self.pool_v: 'Optional[nn.Module]\n' = None
        if _prod(kernel_kv) > 1 or _prod(stride_kv) > 1:
            padding_kv = [int(kv // 2) for kv in kernel_kv]
            self.pool_k = Pool(nn.Conv3d(self.head_dim, self.head_dim, kernel_kv, stride=stride_kv, padding=padding_kv, groups=self.head_dim, bias=False), norm_layer(self.head_dim))
            self.pool_v = Pool(nn.Conv3d(self.head_dim, self.head_dim, kernel_kv, stride=stride_kv, padding=padding_kv, groups=self.head_dim, bias=False), norm_layer(self.head_dim))
        self.rel_pos_h: 'Optional[nn.Parameter]\n' = None
        self.rel_pos_w: 'Optional[nn.Parameter]\n' = None
        self.rel_pos_t: 'Optional[nn.Parameter]\n' = None
        if rel_pos_embed:
            size = max(input_size[1:])
            q_size = size // stride_q[1] if len(stride_q) > 0 else size
            kv_size = size // stride_kv[1] if len(stride_kv) > 0 else size
            spatial_dim = 2 * max(q_size, kv_size) - 1
            temporal_dim = 2 * input_size[0] - 1
            self.rel_pos_h = nn.Parameter(torch.zeros(spatial_dim, self.head_dim))
            self.rel_pos_w = nn.Parameter(torch.zeros(spatial_dim, self.head_dim))
            self.rel_pos_t = nn.Parameter(torch.zeros(temporal_dim, self.head_dim))
            nn.init.trunc_normal_(self.rel_pos_h, std=0.02)
            nn.init.trunc_normal_(self.rel_pos_w, std=0.02)
            nn.init.trunc_normal_(self.rel_pos_t, std=0.02)

    def forward(self, x: 'torch.Tensor\n', thw: 'Tuple[(int, int, int)]\n') ->Tuple[torch.Tensor, Tuple[int, int, int]]:
        B, N, C = x.shape
        q, k, v = self.qkv(x).reshape(B, N, 3, self.num_heads, self.head_dim).transpose(1, 3).unbind(dim=2)
        if self.pool_k is not None:
            k, k_thw = self.pool_k(k, thw)
        else:
            k_thw = thw
        if self.pool_v is not None:
            v = self.pool_v(v, thw)[0]
        if self.pool_q is not None:
            q, thw = self.pool_q(q, thw)
        attn = torch.matmul(self.scaler * q, k.transpose(2, 3))
        if self.rel_pos_h is not None and self.rel_pos_w is not None and self.rel_pos_t is not None:
            attn = _add_rel_pos(attn, q, thw, k_thw, self.rel_pos_h, self.rel_pos_w, self.rel_pos_t)
        attn = attn.softmax(dim=-1)
        x = torch.matmul(attn, v)
        if self.residual_pool:
            _add_shortcut(x, q, self.residual_with_cls_embed)
        x = x.transpose(1, 2).reshape(B, -1, self.output_dim)
        x = self.project(x)
        return x, thw


class MLP(torch.nn.Sequential):
    """This block implements the multi-layer perceptron (MLP) module.

    Args:
        in_channels (int): Number of channels of the input
        hidden_channels (List[int]): List of the hidden channel dimensions
        norm_layer (Callable[..., torch.nn.Module], optional): Norm layer that will be stacked on top of the linear layer. If ``None`` this layer won't be used. Default: ``None``
        activation_layer (Callable[..., torch.nn.Module], optional): Activation function which will be stacked on top of the normalization layer (if not None), otherwise on top of the linear layer. If ``None`` this layer won't be used. Default: ``torch.nn.ReLU``
        inplace (bool, optional): Parameter for the activation layer, which can optionally do the operation in-place.
            Default is ``None``, which uses the respective default values of the ``activation_layer`` and Dropout layer.
        bias (bool): Whether to use bias in the linear layer. Default ``True``
        dropout (float): The probability for the dropout layer. Default: 0.0
    """

    def __init__(self, in_channels: 'int\n', hidden_channels: 'List[int]\n', norm_layer: 'Optional[Callable[(..., torch.nn.Module)]]\n'=None, activation_layer: 'Optional[Callable[(..., torch.nn.Module)]]\n'=torch.nn.ReLU, inplace: 'Optional[bool]\n'=None, bias: 'bool\n'=True, dropout: 'float\n'=0.0):
        params = {} if inplace is None else {'inplace': inplace}
        layers = []
        in_dim = in_channels
        for hidden_dim in hidden_channels[:-1]:
            layers.append(torch.nn.Linear(in_dim, hidden_dim, bias=bias))
            if norm_layer is not None:
                layers.append(norm_layer(hidden_dim))
            layers.append(activation_layer(**params))
            layers.append(torch.nn.Dropout(dropout, **params))
            in_dim = hidden_dim
        layers.append(torch.nn.Linear(in_dim, hidden_channels[-1], bias=bias))
        layers.append(torch.nn.Dropout(dropout, **params))
        super().__init__(*layers)
        _log_api_usage_once(self)


class MultiscaleBlock(nn.Module):

    def __init__(self, input_size: 'List[int]\n', cnf: 'MSBlockConfig\n', residual_pool: 'bool\n', residual_with_cls_embed: 'bool\n', rel_pos_embed: 'bool\n', proj_after_attn: 'bool\n', dropout: 'float\n'=0.0, stochastic_depth_prob: 'float\n'=0.0, norm_layer: 'Callable[(..., nn.Module)]\n'=nn.LayerNorm) ->None:
        super().__init__()
        self.proj_after_attn = proj_after_attn
        self.pool_skip: 'Optional[nn.Module]\n' = None
        if _prod(cnf.stride_q) > 1:
            kernel_skip = [(s + 1 if s > 1 else s) for s in cnf.stride_q]
            padding_skip = [int(k // 2) for k in kernel_skip]
            self.pool_skip = Pool(nn.MaxPool3d(kernel_skip, stride=cnf.stride_q, padding=padding_skip), None)
        attn_dim = cnf.output_channels if proj_after_attn else cnf.input_channels
        self.norm1 = norm_layer(cnf.input_channels)
        self.norm2 = norm_layer(attn_dim)
        self.needs_transposal = isinstance(self.norm1, nn.BatchNorm1d)
        self.attn = MultiscaleAttention(input_size, cnf.input_channels, attn_dim, cnf.num_heads, kernel_q=cnf.kernel_q, kernel_kv=cnf.kernel_kv, stride_q=cnf.stride_q, stride_kv=cnf.stride_kv, rel_pos_embed=rel_pos_embed, residual_pool=residual_pool, residual_with_cls_embed=residual_with_cls_embed, dropout=dropout, norm_layer=norm_layer)
        self.mlp = MLP(attn_dim, [4 * attn_dim, cnf.output_channels], activation_layer=nn.GELU, dropout=dropout, inplace=None)
        self.stochastic_depth = StochasticDepth(stochastic_depth_prob, 'row')
        self.project: 'Optional[nn.Module]\n' = None
        if cnf.input_channels != cnf.output_channels:
            self.project = nn.Linear(cnf.input_channels, cnf.output_channels)

    def forward(self, x: 'torch.Tensor\n', thw: 'Tuple[(int, int, int)]\n') ->Tuple[torch.Tensor, Tuple[int, int, int]]:
        x_norm1 = self.norm1(x.transpose(1, 2)).transpose(1, 2) if self.needs_transposal else self.norm1(x)
        x_attn, thw_new = self.attn(x_norm1, thw)
        x = x if self.project is None or not self.proj_after_attn else self.project(x_norm1)
        x_skip = x if self.pool_skip is None else self.pool_skip(x, thw)[0]
        x = x_skip + self.stochastic_depth(x_attn)
        x_norm2 = self.norm2(x.transpose(1, 2)).transpose(1, 2) if self.needs_transposal else self.norm2(x)
        x_proj = x if self.project is None or self.proj_after_attn else self.project(x_norm2)
        return x_proj + self.stochastic_depth(self.mlp(x_norm2)), thw_new


class PositionalEncoding(nn.Module):

    def __init__(self, embed_size: 'int\n', spatial_size: 'Tuple[(int, int)]\n', temporal_size: 'int\n', rel_pos_embed: 'bool\n') ->None:
        super().__init__()
        self.spatial_size = spatial_size
        self.temporal_size = temporal_size
        self.class_token = nn.Parameter(torch.zeros(embed_size))
        self.spatial_pos: 'Optional[nn.Parameter]\n' = None
        self.temporal_pos: 'Optional[nn.Parameter]\n' = None
        self.class_pos: 'Optional[nn.Parameter]\n' = None
        if not rel_pos_embed:
            self.spatial_pos = nn.Parameter(torch.zeros(self.spatial_size[0] * self.spatial_size[1], embed_size))
            self.temporal_pos = nn.Parameter(torch.zeros(self.temporal_size, embed_size))
            self.class_pos = nn.Parameter(torch.zeros(embed_size))

    def forward(self, x: 'torch.Tensor\n') ->torch.Tensor:
        class_token = self.class_token.expand(x.size(0), -1).unsqueeze(1)
        x = torch.cat((class_token, x), dim=1)
        if self.spatial_pos is not None and self.temporal_pos is not None and self.class_pos is not None:
            hw_size, embed_size = self.spatial_pos.shape
            pos_embedding = torch.repeat_interleave(self.temporal_pos, hw_size, dim=0)
            pos_embedding.add_(self.spatial_pos.unsqueeze(0).expand(self.temporal_size, -1, -1).reshape(-1, embed_size))
            pos_embedding = torch.cat((self.class_pos.unsqueeze(0), pos_embedding), dim=0).unsqueeze(0)
            x.add_(pos_embedding)
        return x


class MViT(nn.Module):

    def __init__(self, spatial_size: 'Tuple[(int, int)]\n', temporal_size: 'int\n', block_setting: 'Sequence[MSBlockConfig]\n', residual_pool: 'bool\n', residual_with_cls_embed: 'bool\n', rel_pos_embed: 'bool\n', proj_after_attn: 'bool\n', dropout: 'float\n'=0.5, attention_dropout: 'float\n'=0.0, stochastic_depth_prob: 'float\n'=0.0, num_classes: 'int\n'=400, block: 'Optional[Callable[(..., nn.Module)]]\n'=None, norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None, patch_embed_kernel: 'Tuple[(int, int, int)]\n'=(3, 7, 7), patch_embed_stride: 'Tuple[(int, int, int)]\n'=(2, 4, 4), patch_embed_padding: 'Tuple[(int, int, int)]\n'=(1, 3, 3)) ->None:
        """
        MViT main class.

        Args:
            spatial_size (tuple of ints): The spacial size of the input as ``(H, W)``.
            temporal_size (int): The temporal size ``T`` of the input.
            block_setting (sequence of MSBlockConfig): The Network structure.
            residual_pool (bool): If True, use MViTv2 pooling residual connection.
            residual_with_cls_embed (bool): If True, the addition on the residual connection will include
                the class embedding.
            rel_pos_embed (bool): If True, use MViTv2's relative positional embeddings.
            proj_after_attn (bool): If True, apply the projection after the attention.
            dropout (float): Dropout rate. Default: 0.0.
            attention_dropout (float): Attention dropout rate. Default: 0.0.
            stochastic_depth_prob: (float): Stochastic depth rate. Default: 0.0.
            num_classes (int): The number of classes.
            block (callable, optional): Module specifying the layer which consists of the attention and mlp.
            norm_layer (callable, optional): Module specifying the normalization layer to use.
            patch_embed_kernel (tuple of ints): The kernel of the convolution that patchifies the input.
            patch_embed_stride (tuple of ints): The stride of the convolution that patchifies the input.
            patch_embed_padding (tuple of ints): The padding of the convolution that patchifies the input.
        """
        super().__init__()
        _log_api_usage_once(self)
        total_stage_blocks = len(block_setting)
        if total_stage_blocks == 0:
            raise ValueError("The configuration parameter can't be empty.")
        if block is None:
            block = MultiscaleBlock
        if norm_layer is None:
            norm_layer = partial(nn.LayerNorm, eps=1e-06)
        self.conv_proj = nn.Conv3d(in_channels=3, out_channels=block_setting[0].input_channels, kernel_size=patch_embed_kernel, stride=patch_embed_stride, padding=patch_embed_padding)
        input_size = [(size // stride) for size, stride in zip((temporal_size,) + spatial_size, self.conv_proj.stride)]
        self.pos_encoding = PositionalEncoding(embed_size=block_setting[0].input_channels, spatial_size=(input_size[1], input_size[2]), temporal_size=input_size[0], rel_pos_embed=rel_pos_embed)
        self.blocks = nn.ModuleList()
        for stage_block_id, cnf in enumerate(block_setting):
            sd_prob = stochastic_depth_prob * stage_block_id / (total_stage_blocks - 1.0)
            self.blocks.append(block(input_size=input_size, cnf=cnf, residual_pool=residual_pool, residual_with_cls_embed=residual_with_cls_embed, rel_pos_embed=rel_pos_embed, proj_after_attn=proj_after_attn, dropout=attention_dropout, stochastic_depth_prob=sd_prob, norm_layer=norm_layer))
            if len(cnf.stride_q) > 0:
                input_size = [(size // stride) for size, stride in zip(input_size, cnf.stride_q)]
        self.norm = norm_layer(block_setting[-1].output_channels)
        self.head = nn.Sequential(nn.Dropout(dropout, inplace=True), nn.Linear(block_setting[-1].output_channels, num_classes))
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.trunc_normal_(m.weight, std=0.02)
                if isinstance(m, nn.Linear) and m.bias is not None:
                    nn.init.constant_(m.bias, 0.0)
            elif isinstance(m, nn.LayerNorm):
                if m.weight is not None:
                    nn.init.constant_(m.weight, 1.0)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0.0)
            elif isinstance(m, PositionalEncoding):
                for weights in m.parameters():
                    nn.init.trunc_normal_(weights, std=0.02)

    def forward(self, x: 'torch.Tensor\n') ->torch.Tensor:
        x = _unsqueeze(x, 5, 2)[0]
        x = self.conv_proj(x)
        x = x.flatten(2).transpose(1, 2)
        x = self.pos_encoding(x)
        thw = (self.pos_encoding.temporal_size,) + self.pos_encoding.spatial_size
        for block in self.blocks:
            x, thw = block(x, thw)
        x = self.norm(x)
        x = x[:, (0)]
        x = self.head(x)
        return x


class Conv3DSimple(nn.Conv3d):

    def __init__(self, in_planes: 'int\n', out_planes: 'int\n', midplanes: 'Optional[int]\n'=None, stride: 'int\n'=1, padding: 'int\n'=1) ->None:
        super().__init__(in_channels=in_planes, out_channels=out_planes, kernel_size=(3, 3, 3), stride=stride, padding=padding, bias=False)

    @staticmethod
    def get_downsample_stride(stride: 'int\n') ->Tuple[int, int, int]:
        return stride, stride, stride


class Conv2Plus1D(nn.Sequential):

    def __init__(self, in_planes: 'int\n', out_planes: 'int\n', midplanes: 'int\n', stride: 'int\n'=1, padding: 'int\n'=1) ->None:
        super().__init__(nn.Conv3d(in_planes, midplanes, kernel_size=(1, 3, 3), stride=(1, stride, stride), padding=(0, padding, padding), bias=False), nn.BatchNorm3d(midplanes), nn.ReLU(inplace=True), nn.Conv3d(midplanes, out_planes, kernel_size=(3, 1, 1), stride=(stride, 1, 1), padding=(padding, 0, 0), bias=False))

    @staticmethod
    def get_downsample_stride(stride: 'int\n') ->Tuple[int, int, int]:
        return stride, stride, stride


class Conv3DNoTemporal(nn.Conv3d):

    def __init__(self, in_planes: 'int\n', out_planes: 'int\n', midplanes: 'Optional[int]\n'=None, stride: 'int\n'=1, padding: 'int\n'=1) ->None:
        super().__init__(in_channels=in_planes, out_channels=out_planes, kernel_size=(1, 3, 3), stride=(1, stride, stride), padding=(0, padding, padding), bias=False)

    @staticmethod
    def get_downsample_stride(stride: 'int\n') ->Tuple[int, int, int]:
        return 1, stride, stride


def conv3x3(in_planes: 'int\n', out_planes: 'int\n', stride: 'int\n'=1, groups: 'int\n'=1, dilation: 'int\n'=1) ->nn.Conv2d:
    """3x3 convolution with padding"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride, padding=dilation, groups=groups, bias=False, dilation=dilation)


class BasicBlock(nn.Module):
    expansion: 'int\n' = 1

    def __init__(self, inplanes: 'int\n', planes: 'int\n', stride: 'int\n'=1, downsample: 'Optional[nn.Module]\n'=None, groups: 'int\n'=1, base_width: 'int\n'=64, dilation: 'int\n'=1, norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None) ->None:
        super().__init__()
        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        if groups != 1 or base_width != 64:
            raise ValueError('BasicBlock only supports groups=1 and base_width=64')
        if dilation > 1:
            raise NotImplementedError('Dilation > 1 not supported in BasicBlock')
        self.conv1 = conv3x3(inplanes, planes, stride)
        self.bn1 = norm_layer(planes)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = conv3x3(planes, planes)
        self.bn2 = norm_layer(planes)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x: 'Tensor\n') ->Tensor:
        identity = x
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        out = self.conv2(out)
        out = self.bn2(out)
        if self.downsample is not None:
            identity = self.downsample(x)
        out += identity
        out = self.relu(out)
        return out


def conv1x1(in_planes: 'int\n', out_planes: 'int\n', stride: 'int\n'=1) ->nn.Conv2d:
    """1x1 convolution"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=1, stride=stride, bias=False)


class Bottleneck(nn.Module):
    expansion: 'int\n' = 4

    def __init__(self, inplanes: 'int\n', planes: 'int\n', stride: 'int\n'=1, downsample: 'Optional[nn.Module]\n'=None, groups: 'int\n'=1, base_width: 'int\n'=64, dilation: 'int\n'=1, norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None) ->None:
        super().__init__()
        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        width = int(planes * (base_width / 64.0)) * groups
        self.conv1 = conv1x1(inplanes, width)
        self.bn1 = norm_layer(width)
        self.conv2 = conv3x3(width, width, stride, groups, dilation)
        self.bn2 = norm_layer(width)
        self.conv3 = conv1x1(width, planes * self.expansion)
        self.bn3 = norm_layer(planes * self.expansion)
        self.relu = nn.ReLU(inplace=True)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x: 'Tensor\n') ->Tensor:
        identity = x
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)
        out = self.conv3(out)
        out = self.bn3(out)
        if self.downsample is not None:
            identity = self.downsample(x)
        out += identity
        out = self.relu(out)
        return out


class BasicStem(nn.Sequential):
    """The default conv-batchnorm-relu stem"""

    def __init__(self) ->None:
        super().__init__(nn.Conv3d(3, 64, kernel_size=(3, 7, 7), stride=(1, 2, 2), padding=(1, 3, 3), bias=False), nn.BatchNorm3d(64), nn.ReLU(inplace=True))


class R2Plus1dStem(nn.Sequential):
    """R(2+1)D stem is different than the default one as it uses separated 3D convolution"""

    def __init__(self) ->None:
        super().__init__(nn.Conv3d(3, 45, kernel_size=(1, 7, 7), stride=(1, 2, 2), padding=(0, 3, 3), bias=False), nn.BatchNorm3d(45), nn.ReLU(inplace=True), nn.Conv3d(45, 64, kernel_size=(3, 1, 1), stride=(1, 1, 1), padding=(1, 0, 0), bias=False), nn.BatchNorm3d(64), nn.ReLU(inplace=True))


class VideoResNet(nn.Module):

    def __init__(self, block: 'Type[Union[(BasicBlock, Bottleneck)]]\n', conv_makers: 'Sequence[Type[Union[(Conv3DSimple, Conv3DNoTemporal, Conv2Plus1D)]]]\n', layers: 'List[int]\n', stem: 'Callable[(..., nn.Module)]\n', num_classes: 'int\n'=400, zero_init_residual: 'bool\n'=False) ->None:
        """Generic resnet video generator.

        Args:
            block (Type[Union[BasicBlock, Bottleneck]]): resnet building block
            conv_makers (List[Type[Union[Conv3DSimple, Conv3DNoTemporal, Conv2Plus1D]]]): generator
                function for each layer
            layers (List[int]): number of blocks per layer
            stem (Callable[..., nn.Module]): module specifying the ResNet stem.
            num_classes (int, optional): Dimension of the final FC layer. Defaults to 400.
            zero_init_residual (bool, optional): Zero init bottleneck residual BN. Defaults to False.
        """
        super().__init__()
        _log_api_usage_once(self)
        self.inplanes = 64
        self.stem = stem()
        self.layer1 = self._make_layer(block, conv_makers[0], 64, layers[0], stride=1)
        self.layer2 = self._make_layer(block, conv_makers[1], 128, layers[1], stride=2)
        self.layer3 = self._make_layer(block, conv_makers[2], 256, layers[2], stride=2)
        self.layer4 = self._make_layer(block, conv_makers[3], 512, layers[3], stride=2)
        self.avgpool = nn.AdaptiveAvgPool3d((1, 1, 1))
        self.fc = nn.Linear(512 * block.expansion, num_classes)
        for m in self.modules():
            if isinstance(m, nn.Conv3d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm3d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)
        if zero_init_residual:
            for m in self.modules():
                if isinstance(m, Bottleneck):
                    nn.init.constant_(m.bn3.weight, 0)

    def forward(self, x: 'Tensor\n') ->Tensor:
        x = self.stem(x)
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = self.avgpool(x)
        x = x.flatten(1)
        x = self.fc(x)
        return x

    def _make_layer(self, block: 'Type[Union[(BasicBlock, Bottleneck)]]\n', conv_builder: 'Type[Union[(Conv3DSimple, Conv3DNoTemporal, Conv2Plus1D)]]\n', planes: 'int\n', blocks: 'int\n', stride: 'int\n'=1) ->nn.Sequential:
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            ds_stride = conv_builder.get_downsample_stride(stride)
            downsample = nn.Sequential(nn.Conv3d(self.inplanes, planes * block.expansion, kernel_size=1, stride=ds_stride, bias=False), nn.BatchNorm3d(planes * block.expansion))
        layers = []
        layers.append(block(self.inplanes, planes, conv_builder, stride, downsample))
        self.inplanes = planes * block.expansion
        for i in range(1, blocks):
            layers.append(block(self.inplanes, planes, conv_builder))
        return nn.Sequential(*layers)


class TemporalSeparableConv(nn.Sequential):

    def __init__(self, in_planes: 'int\n', out_planes: 'int\n', kernel_size: 'int\n', stride: 'int\n', padding: 'int\n', norm_layer: 'Callable[(..., nn.Module)]\n'):
        super().__init__(Conv3dNormActivation(in_planes, out_planes, kernel_size=(1, kernel_size, kernel_size), stride=(1, stride, stride), padding=(0, padding, padding), bias=False, norm_layer=norm_layer), Conv3dNormActivation(out_planes, out_planes, kernel_size=(kernel_size, 1, 1), stride=(stride, 1, 1), padding=(padding, 0, 0), bias=False, norm_layer=norm_layer))


class SepInceptionBlock3D(nn.Module):

    def __init__(self, in_planes: 'int\n', b0_out: 'int\n', b1_mid: 'int\n', b1_out: 'int\n', b2_mid: 'int\n', b2_out: 'int\n', b3_out: 'int\n', norm_layer: 'Callable[(..., nn.Module)]\n'):
        super().__init__()
        self.branch0 = Conv3dNormActivation(in_planes, b0_out, kernel_size=1, stride=1, norm_layer=norm_layer)
        self.branch1 = nn.Sequential(Conv3dNormActivation(in_planes, b1_mid, kernel_size=1, stride=1, norm_layer=norm_layer), TemporalSeparableConv(b1_mid, b1_out, kernel_size=3, stride=1, padding=1, norm_layer=norm_layer))
        self.branch2 = nn.Sequential(Conv3dNormActivation(in_planes, b2_mid, kernel_size=1, stride=1, norm_layer=norm_layer), TemporalSeparableConv(b2_mid, b2_out, kernel_size=3, stride=1, padding=1, norm_layer=norm_layer))
        self.branch3 = nn.Sequential(nn.MaxPool3d(kernel_size=(3, 3, 3), stride=1, padding=1), Conv3dNormActivation(in_planes, b3_out, kernel_size=1, stride=1, norm_layer=norm_layer))

    def forward(self, x):
        x0 = self.branch0(x)
        x1 = self.branch1(x)
        x2 = self.branch2(x)
        x3 = self.branch3(x)
        out = torch.cat((x0, x1, x2, x3), 1)
        return out


class S3D(nn.Module):
    """S3D main class.

    Args:
        num_class (int): number of classes for the classification task.
        dropout (float): dropout probability.
        norm_layer (Optional[Callable]): Module specifying the normalization layer to use.

    Inputs:
        x (Tensor): batch of videos with dimensions (batch, channel, time, height, width)
    """

    def __init__(self, num_classes: 'int\n'=400, dropout: 'float\n'=0.2, norm_layer: 'Optional[Callable[(..., torch.nn.Module)]]\n'=None) ->None:
        super().__init__()
        _log_api_usage_once(self)
        if norm_layer is None:
            norm_layer = partial(nn.BatchNorm3d, eps=0.001, momentum=0.001)
        self.features = nn.Sequential(TemporalSeparableConv(3, 64, 7, 2, 3, norm_layer), nn.MaxPool3d(kernel_size=(1, 3, 3), stride=(1, 2, 2), padding=(0, 1, 1)), Conv3dNormActivation(64, 64, kernel_size=1, stride=1, norm_layer=norm_layer), TemporalSeparableConv(64, 192, 3, 1, 1, norm_layer), nn.MaxPool3d(kernel_size=(1, 3, 3), stride=(1, 2, 2), padding=(0, 1, 1)), SepInceptionBlock3D(192, 64, 96, 128, 16, 32, 32, norm_layer), SepInceptionBlock3D(256, 128, 128, 192, 32, 96, 64, norm_layer), nn.MaxPool3d(kernel_size=(3, 3, 3), stride=(2, 2, 2), padding=(1, 1, 1)), SepInceptionBlock3D(480, 192, 96, 208, 16, 48, 64, norm_layer), SepInceptionBlock3D(512, 160, 112, 224, 24, 64, 64, norm_layer), SepInceptionBlock3D(512, 128, 128, 256, 24, 64, 64, norm_layer), SepInceptionBlock3D(512, 112, 144, 288, 32, 64, 64, norm_layer), SepInceptionBlock3D(528, 256, 160, 320, 32, 128, 128, norm_layer), nn.MaxPool3d(kernel_size=(2, 2, 2), stride=(2, 2, 2), padding=(0, 0, 0)), SepInceptionBlock3D(832, 256, 160, 320, 32, 128, 128, norm_layer), SepInceptionBlock3D(832, 384, 192, 384, 48, 128, 128, norm_layer))
        self.avgpool = nn.AvgPool3d(kernel_size=(2, 7, 7), stride=1)
        self.classifier = nn.Sequential(nn.Dropout(p=dropout), nn.Conv3d(1024, num_classes, kernel_size=1, stride=1, bias=True))

    def forward(self, x):
        x = self.features(x)
        x = self.avgpool(x)
        x = self.classifier(x)
        x = torch.mean(x, dim=(2, 3, 4))
        return x


def _get_relative_position_bias(relative_position_bias_table: 'torch.Tensor\n', relative_position_index: 'torch.Tensor\n', window_size: 'List[int]\n') ->torch.Tensor:
    N = window_size[0] * window_size[1]
    relative_position_bias = relative_position_bias_table[relative_position_index]
    relative_position_bias = relative_position_bias.view(N, N, -1)
    relative_position_bias = relative_position_bias.permute(2, 0, 1).contiguous().unsqueeze(0)
    return relative_position_bias


def _get_window_and_shift_size(shift_size: 'List[int]\n', size_dhw: 'List[int]\n', window_size: 'List[int]\n') ->Tuple[List[int], List[int]]:
    for i in range(3):
        if size_dhw[i] <= window_size[i]:
            window_size[i] = size_dhw[i]
            shift_size[i] = 0
    return window_size, shift_size


def _compute_attention_mask_3d(x: 'Tensor\n', size_dhw: 'Tuple[(int, int, int)]\n', window_size: 'Tuple[(int, int, int)]\n', shift_size: 'Tuple[(int, int, int)]\n') ->Tensor:
    attn_mask = x.new_zeros(*size_dhw)
    num_windows = size_dhw[0] // window_size[0] * (size_dhw[1] // window_size[1]) * (size_dhw[2] // window_size[2])
    slices = [((0, -window_size[i]), (-window_size[i], -shift_size[i]), (-shift_size[i], None)) for i in range(3)]
    count = 0
    for d in slices[0]:
        for h in slices[1]:
            for w in slices[2]:
                attn_mask[d[0]:d[1], h[0]:h[1], w[0]:w[1]] = count
                count += 1
    attn_mask = attn_mask.view(size_dhw[0] // window_size[0], window_size[0], size_dhw[1] // window_size[1], window_size[1], size_dhw[2] // window_size[2], window_size[2])
    attn_mask = attn_mask.permute(0, 2, 4, 1, 3, 5).reshape(num_windows, window_size[0] * window_size[1] * window_size[2])
    attn_mask = attn_mask.unsqueeze(1) - attn_mask.unsqueeze(2)
    attn_mask = attn_mask.masked_fill(attn_mask != 0, float(-100.0)).masked_fill(attn_mask == 0, float(0.0))
    return attn_mask


def _compute_pad_size_3d(size_dhw: 'Tuple[(int, int, int)]\n', patch_size: 'Tuple[(int, int, int)]\n') ->Tuple[int, int, int]:
    pad_size = [((patch_size[i] - size_dhw[i] % patch_size[i]) % patch_size[i]) for i in range(3)]
    return pad_size[0], pad_size[1], pad_size[2]


def shifted_window_attention_3d(input: 'Tensor\n', qkv_weight: 'Tensor\n', proj_weight: 'Tensor\n', relative_position_bias: 'Tensor\n', window_size: 'List[int]\n', num_heads: 'int\n', shift_size: 'List[int]\n', attention_dropout: 'float\n'=0.0, dropout: 'float\n'=0.0, qkv_bias: 'Optional[Tensor]\n'=None, proj_bias: 'Optional[Tensor]\n'=None, training: 'bool\n'=True) ->Tensor:
    """
    Window based multi-head self attention (W-MSA) module with relative position bias.
    It supports both of shifted and non-shifted window.
    Args:
        input (Tensor[B, T, H, W, C]): The input tensor, 5-dimensions.
        qkv_weight (Tensor[in_dim, out_dim]): The weight tensor of query, key, value.
        proj_weight (Tensor[out_dim, out_dim]): The weight tensor of projection.
        relative_position_bias (Tensor): The learned relative position bias added to attention.
        window_size (List[int]): 3-dimensions window size, T, H, W .
        num_heads (int): Number of attention heads.
        shift_size (List[int]): Shift size for shifted window attention (T, H, W).
        attention_dropout (float): Dropout ratio of attention weight. Default: 0.0.
        dropout (float): Dropout ratio of output. Default: 0.0.
        qkv_bias (Tensor[out_dim], optional): The bias tensor of query, key, value. Default: None.
        proj_bias (Tensor[out_dim], optional): The bias tensor of projection. Default: None.
        training (bool, optional): Training flag used by the dropout parameters. Default: True.
    Returns:
        Tensor[B, T, H, W, C]: The output tensor after shifted window attention.
    """
    b, t, h, w, c = input.shape
    pad_size = _compute_pad_size_3d((t, h, w), (window_size[0], window_size[1], window_size[2]))
    x = F.pad(input, (0, 0, 0, pad_size[2], 0, pad_size[1], 0, pad_size[0]))
    _, tp, hp, wp, _ = x.shape
    padded_size = tp, hp, wp
    if sum(shift_size) > 0:
        x = torch.roll(x, shifts=(-shift_size[0], -shift_size[1], -shift_size[2]), dims=(1, 2, 3))
    num_windows = padded_size[0] // window_size[0] * (padded_size[1] // window_size[1]) * (padded_size[2] // window_size[2])
    x = x.view(b, padded_size[0] // window_size[0], window_size[0], padded_size[1] // window_size[1], window_size[1], padded_size[2] // window_size[2], window_size[2], c)
    x = x.permute(0, 1, 3, 5, 2, 4, 6, 7).reshape(b * num_windows, window_size[0] * window_size[1] * window_size[2], c)
    qkv = F.linear(x, qkv_weight, qkv_bias)
    qkv = qkv.reshape(x.size(0), x.size(1), 3, num_heads, c // num_heads).permute(2, 0, 3, 1, 4)
    q, k, v = qkv[0], qkv[1], qkv[2]
    q = q * (c // num_heads) ** -0.5
    attn = q.matmul(k.transpose(-2, -1))
    attn = attn + relative_position_bias
    if sum(shift_size) > 0:
        attn_mask = _compute_attention_mask_3d(x, (padded_size[0], padded_size[1], padded_size[2]), (window_size[0], window_size[1], window_size[2]), (shift_size[0], shift_size[1], shift_size[2]))
        attn = attn.view(x.size(0) // num_windows, num_windows, num_heads, x.size(1), x.size(1))
        attn = attn + attn_mask.unsqueeze(1).unsqueeze(0)
        attn = attn.view(-1, num_heads, x.size(1), x.size(1))
    attn = F.softmax(attn, dim=-1)
    attn = F.dropout(attn, p=attention_dropout, training=training)
    x = attn.matmul(v).transpose(1, 2).reshape(x.size(0), x.size(1), c)
    x = F.linear(x, proj_weight, proj_bias)
    x = F.dropout(x, p=dropout, training=training)
    x = x.view(b, padded_size[0] // window_size[0], padded_size[1] // window_size[1], padded_size[2] // window_size[2], window_size[0], window_size[1], window_size[2], c)
    x = x.permute(0, 1, 4, 2, 5, 3, 6, 7).reshape(b, tp, hp, wp, c)
    if sum(shift_size) > 0:
        x = torch.roll(x, shifts=(shift_size[0], shift_size[1], shift_size[2]), dims=(1, 2, 3))
    x = x[:, :t, :h, :w, :].contiguous()
    return x


class ShiftedWindowAttention3d(nn.Module):
    """
    See :func:`shifted_window_attention_3d`.
    """

    def __init__(self, dim: 'int\n', window_size: 'List[int]\n', shift_size: 'List[int]\n', num_heads: 'int\n', qkv_bias: 'bool\n'=True, proj_bias: 'bool\n'=True, attention_dropout: 'float\n'=0.0, dropout: 'float\n'=0.0) ->None:
        super().__init__()
        if len(window_size) != 3 or len(shift_size) != 3:
            raise ValueError('window_size and shift_size must be of length 2')
        self.window_size = window_size
        self.shift_size = shift_size
        self.num_heads = num_heads
        self.attention_dropout = attention_dropout
        self.dropout = dropout
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.proj = nn.Linear(dim, dim, bias=proj_bias)
        self.define_relative_position_bias_table()
        self.define_relative_position_index()

    def define_relative_position_bias_table(self) ->None:
        self.relative_position_bias_table = nn.Parameter(torch.zeros((2 * self.window_size[0] - 1) * (2 * self.window_size[1] - 1) * (2 * self.window_size[2] - 1), self.num_heads))
        nn.init.trunc_normal_(self.relative_position_bias_table, std=0.02)

    def define_relative_position_index(self) ->None:
        coords_dhw = [torch.arange(self.window_size[i]) for i in range(3)]
        coords = torch.stack(torch.meshgrid(coords_dhw[0], coords_dhw[1], coords_dhw[2], indexing='ij'))
        coords_flatten = torch.flatten(coords, 1)
        relative_coords = coords_flatten[:, :, (None)] - coords_flatten[:, (None), :]
        relative_coords = relative_coords.permute(1, 2, 0).contiguous()
        relative_coords[:, :, (0)] += self.window_size[0] - 1
        relative_coords[:, :, (1)] += self.window_size[1] - 1
        relative_coords[:, :, (2)] += self.window_size[2] - 1
        relative_coords[:, :, (0)] *= (2 * self.window_size[1] - 1) * (2 * self.window_size[2] - 1)
        relative_coords[:, :, (1)] *= 2 * self.window_size[2] - 1
        relative_position_index = relative_coords.sum(-1)
        self.register_buffer('relative_position_index', relative_position_index)

    def get_relative_position_bias(self, window_size: 'List[int]\n') ->torch.Tensor:
        return _get_relative_position_bias(self.relative_position_bias_table, self.relative_position_index, window_size)

    def forward(self, x: 'Tensor\n') ->Tensor:
        _, t, h, w, _ = x.shape
        size_dhw = [t, h, w]
        window_size, shift_size = self.window_size.copy(), self.shift_size.copy()
        window_size, shift_size = _get_window_and_shift_size(shift_size, size_dhw, window_size)
        relative_position_bias = self.get_relative_position_bias(window_size)
        return shifted_window_attention_3d(x, self.qkv.weight, self.proj.weight, relative_position_bias, window_size, self.num_heads, shift_size=shift_size, attention_dropout=self.attention_dropout, dropout=self.dropout, qkv_bias=self.qkv.bias, proj_bias=self.proj.bias, training=self.training)


class PatchEmbed3d(nn.Module):
    """Video to Patch Embedding.

    Args:
        patch_size (List[int]): Patch token size.
        in_channels (int): Number of input channels. Default: 3
        embed_dim (int): Number of linear projection output channels. Default: 96.
        norm_layer (nn.Module, optional): Normalization layer. Default: None
    """

    def __init__(self, patch_size: 'List[int]\n', in_channels: 'int\n'=3, embed_dim: 'int\n'=96, norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None) ->None:
        super().__init__()
        _log_api_usage_once(self)
        self.tuple_patch_size = patch_size[0], patch_size[1], patch_size[2]
        self.proj = nn.Conv3d(in_channels, embed_dim, kernel_size=self.tuple_patch_size, stride=self.tuple_patch_size)
        if norm_layer is not None:
            self.norm = norm_layer(embed_dim)
        else:
            self.norm = nn.Identity()

    def forward(self, x: 'Tensor\n') ->Tensor:
        """Forward function."""
        _, _, t, h, w = x.size()
        pad_size = _compute_pad_size_3d((t, h, w), self.tuple_patch_size)
        x = F.pad(x, (0, pad_size[2], 0, pad_size[1], 0, pad_size[0]))
        x = self.proj(x)
        x = x.permute(0, 2, 3, 4, 1)
        if self.norm is not None:
            x = self.norm(x)
        return x


def _patch_merging_pad(x: 'torch.Tensor\n') ->torch.Tensor:
    H, W, _ = x.shape[-3:]
    x = F.pad(x, (0, 0, 0, W % 2, 0, H % 2))
    x0 = x[(...), 0::2, 0::2, :]
    x1 = x[(...), 1::2, 0::2, :]
    x2 = x[(...), 0::2, 1::2, :]
    x3 = x[(...), 1::2, 1::2, :]
    x = torch.cat([x0, x1, x2, x3], -1)
    return x


class PatchMerging(nn.Module):
    """Patch Merging Layer.
    Args:
        dim (int): Number of input channels.
        norm_layer (nn.Module): Normalization layer. Default: nn.LayerNorm.
    """

    def __init__(self, dim: 'int\n', norm_layer: 'Callable[(..., nn.Module)]\n'=nn.LayerNorm):
        super().__init__()
        _log_api_usage_once(self)
        self.dim = dim
        self.reduction = nn.Linear(4 * dim, 2 * dim, bias=False)
        self.norm = norm_layer(4 * dim)

    def forward(self, x: 'Tensor\n'):
        """
        Args:
            x (Tensor): input tensor with expected layout of [..., H, W, C]
        Returns:
            Tensor with layout of [..., H/2, W/2, 2*C]
        """
        x = _patch_merging_pad(x)
        x = self.norm(x)
        x = self.reduction(x)
        return x


def shifted_window_attention(input: 'Tensor\n', qkv_weight: 'Tensor\n', proj_weight: 'Tensor\n', relative_position_bias: 'Tensor\n', window_size: 'List[int]\n', num_heads: 'int\n', shift_size: 'List[int]\n', attention_dropout: 'float\n'=0.0, dropout: 'float\n'=0.0, qkv_bias: 'Optional[Tensor]\n'=None, proj_bias: 'Optional[Tensor]\n'=None, logit_scale: 'Optional[torch.Tensor]\n'=None, training: 'bool\n'=True) ->Tensor:
    """
    Window based multi-head self attention (W-MSA) module with relative position bias.
    It supports both of shifted and non-shifted window.
    Args:
        input (Tensor[N, H, W, C]): The input tensor or 4-dimensions.
        qkv_weight (Tensor[in_dim, out_dim]): The weight tensor of query, key, value.
        proj_weight (Tensor[out_dim, out_dim]): The weight tensor of projection.
        relative_position_bias (Tensor): The learned relative position bias added to attention.
        window_size (List[int]): Window size.
        num_heads (int): Number of attention heads.
        shift_size (List[int]): Shift size for shifted window attention.
        attention_dropout (float): Dropout ratio of attention weight. Default: 0.0.
        dropout (float): Dropout ratio of output. Default: 0.0.
        qkv_bias (Tensor[out_dim], optional): The bias tensor of query, key, value. Default: None.
        proj_bias (Tensor[out_dim], optional): The bias tensor of projection. Default: None.
        logit_scale (Tensor[out_dim], optional): Logit scale of cosine attention for Swin Transformer V2. Default: None.
        training (bool, optional): Training flag used by the dropout parameters. Default: True.
    Returns:
        Tensor[N, H, W, C]: The output tensor after shifted window attention.
    """
    B, H, W, C = input.shape
    pad_r = (window_size[1] - W % window_size[1]) % window_size[1]
    pad_b = (window_size[0] - H % window_size[0]) % window_size[0]
    x = F.pad(input, (0, 0, 0, pad_r, 0, pad_b))
    _, pad_H, pad_W, _ = x.shape
    shift_size = shift_size.copy()
    if window_size[0] >= pad_H:
        shift_size[0] = 0
    if window_size[1] >= pad_W:
        shift_size[1] = 0
    if sum(shift_size) > 0:
        x = torch.roll(x, shifts=(-shift_size[0], -shift_size[1]), dims=(1, 2))
    num_windows = pad_H // window_size[0] * (pad_W // window_size[1])
    x = x.view(B, pad_H // window_size[0], window_size[0], pad_W // window_size[1], window_size[1], C)
    x = x.permute(0, 1, 3, 2, 4, 5).reshape(B * num_windows, window_size[0] * window_size[1], C)
    if logit_scale is not None and qkv_bias is not None:
        qkv_bias = qkv_bias.clone()
        length = qkv_bias.numel() // 3
        qkv_bias[length:2 * length].zero_()
    qkv = F.linear(x, qkv_weight, qkv_bias)
    qkv = qkv.reshape(x.size(0), x.size(1), 3, num_heads, C // num_heads).permute(2, 0, 3, 1, 4)
    q, k, v = qkv[0], qkv[1], qkv[2]
    if logit_scale is not None:
        attn = F.normalize(q, dim=-1) @ F.normalize(k, dim=-1).transpose(-2, -1)
        logit_scale = torch.clamp(logit_scale, max=math.log(100.0)).exp()
        attn = attn * logit_scale
    else:
        q = q * (C // num_heads) ** -0.5
        attn = q.matmul(k.transpose(-2, -1))
    attn = attn + relative_position_bias
    if sum(shift_size) > 0:
        attn_mask = x.new_zeros((pad_H, pad_W))
        h_slices = (0, -window_size[0]), (-window_size[0], -shift_size[0]), (-shift_size[0], None)
        w_slices = (0, -window_size[1]), (-window_size[1], -shift_size[1]), (-shift_size[1], None)
        count = 0
        for h in h_slices:
            for w in w_slices:
                attn_mask[h[0]:h[1], w[0]:w[1]] = count
                count += 1
        attn_mask = attn_mask.view(pad_H // window_size[0], window_size[0], pad_W // window_size[1], window_size[1])
        attn_mask = attn_mask.permute(0, 2, 1, 3).reshape(num_windows, window_size[0] * window_size[1])
        attn_mask = attn_mask.unsqueeze(1) - attn_mask.unsqueeze(2)
        attn_mask = attn_mask.masked_fill(attn_mask != 0, float(-100.0)).masked_fill(attn_mask == 0, float(0.0))
        attn = attn.view(x.size(0) // num_windows, num_windows, num_heads, x.size(1), x.size(1))
        attn = attn + attn_mask.unsqueeze(1).unsqueeze(0)
        attn = attn.view(-1, num_heads, x.size(1), x.size(1))
    attn = F.softmax(attn, dim=-1)
    attn = F.dropout(attn, p=attention_dropout, training=training)
    x = attn.matmul(v).transpose(1, 2).reshape(x.size(0), x.size(1), C)
    x = F.linear(x, proj_weight, proj_bias)
    x = F.dropout(x, p=dropout, training=training)
    x = x.view(B, pad_H // window_size[0], pad_W // window_size[1], window_size[0], window_size[1], C)
    x = x.permute(0, 1, 3, 2, 4, 5).reshape(B, pad_H, pad_W, C)
    if sum(shift_size) > 0:
        x = torch.roll(x, shifts=(shift_size[0], shift_size[1]), dims=(1, 2))
    x = x[:, :H, :W, :].contiguous()
    return x


class ShiftedWindowAttention(nn.Module):
    """
    See :func:`shifted_window_attention`.
    """

    def __init__(self, dim: 'int\n', window_size: 'List[int]\n', shift_size: 'List[int]\n', num_heads: 'int\n', qkv_bias: 'bool\n'=True, proj_bias: 'bool\n'=True, attention_dropout: 'float\n'=0.0, dropout: 'float\n'=0.0):
        super().__init__()
        if len(window_size) != 2 or len(shift_size) != 2:
            raise ValueError('window_size and shift_size must be of length 2')
        self.window_size = window_size
        self.shift_size = shift_size
        self.num_heads = num_heads
        self.attention_dropout = attention_dropout
        self.dropout = dropout
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.proj = nn.Linear(dim, dim, bias=proj_bias)
        self.define_relative_position_bias_table()
        self.define_relative_position_index()

    def define_relative_position_bias_table(self):
        self.relative_position_bias_table = nn.Parameter(torch.zeros((2 * self.window_size[0] - 1) * (2 * self.window_size[1] - 1), self.num_heads))
        nn.init.trunc_normal_(self.relative_position_bias_table, std=0.02)

    def define_relative_position_index(self):
        coords_h = torch.arange(self.window_size[0])
        coords_w = torch.arange(self.window_size[1])
        coords = torch.stack(torch.meshgrid(coords_h, coords_w, indexing='ij'))
        coords_flatten = torch.flatten(coords, 1)
        relative_coords = coords_flatten[:, :, (None)] - coords_flatten[:, (None), :]
        relative_coords = relative_coords.permute(1, 2, 0).contiguous()
        relative_coords[:, :, (0)] += self.window_size[0] - 1
        relative_coords[:, :, (1)] += self.window_size[1] - 1
        relative_coords[:, :, (0)] *= 2 * self.window_size[1] - 1
        relative_position_index = relative_coords.sum(-1).flatten()
        self.register_buffer('relative_position_index', relative_position_index)

    def get_relative_position_bias(self) ->torch.Tensor:
        return _get_relative_position_bias(self.relative_position_bias_table, self.relative_position_index, self.window_size)

    def forward(self, x: 'Tensor\n') ->Tensor:
        """
        Args:
            x (Tensor): Tensor with layout of [B, H, W, C]
        Returns:
            Tensor with same layout as input, i.e. [B, H, W, C]
        """
        relative_position_bias = self.get_relative_position_bias()
        return shifted_window_attention(x, self.qkv.weight, self.proj.weight, relative_position_bias, self.window_size, self.num_heads, shift_size=self.shift_size, attention_dropout=self.attention_dropout, dropout=self.dropout, qkv_bias=self.qkv.bias, proj_bias=self.proj.bias, training=self.training)


class SwinTransformerBlock(nn.Module):
    """
    Swin Transformer Block.
    Args:
        dim (int): Number of input channels.
        num_heads (int): Number of attention heads.
        window_size (List[int]): Window size.
        shift_size (List[int]): Shift size for shifted window attention.
        mlp_ratio (float): Ratio of mlp hidden dim to embedding dim. Default: 4.0.
        dropout (float): Dropout rate. Default: 0.0.
        attention_dropout (float): Attention dropout rate. Default: 0.0.
        stochastic_depth_prob: (float): Stochastic depth rate. Default: 0.0.
        norm_layer (nn.Module): Normalization layer.  Default: nn.LayerNorm.
        attn_layer (nn.Module): Attention layer. Default: ShiftedWindowAttention
    """

    def __init__(self, dim: 'int\n', num_heads: 'int\n', window_size: 'List[int]\n', shift_size: 'List[int]\n', mlp_ratio: 'float\n'=4.0, dropout: 'float\n'=0.0, attention_dropout: 'float\n'=0.0, stochastic_depth_prob: 'float\n'=0.0, norm_layer: 'Callable[(..., nn.Module)]\n'=nn.LayerNorm, attn_layer: 'Callable[(..., nn.Module)]\n'=ShiftedWindowAttention):
        super().__init__()
        _log_api_usage_once(self)
        self.norm1 = norm_layer(dim)
        self.attn = attn_layer(dim, window_size, shift_size, num_heads, attention_dropout=attention_dropout, dropout=dropout)
        self.stochastic_depth = StochasticDepth(stochastic_depth_prob, 'row')
        self.norm2 = norm_layer(dim)
        self.mlp = MLP(dim, [int(dim * mlp_ratio), dim], activation_layer=nn.GELU, inplace=None, dropout=dropout)
        for m in self.mlp.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.normal_(m.bias, std=1e-06)

    def forward(self, x: 'Tensor\n'):
        x = x + self.stochastic_depth(self.attn(self.norm1(x)))
        x = x + self.stochastic_depth(self.mlp(self.norm2(x)))
        return x


class SwinTransformer3d(nn.Module):
    """
    Implements 3D Swin Transformer from the `"Video Swin Transformer" <https://arxiv.org/abs/2106.13230>`_ paper.
    Args:
        patch_size (List[int]): Patch size.
        embed_dim (int): Patch embedding dimension.
        depths (List(int)): Depth of each Swin Transformer layer.
        num_heads (List(int)): Number of attention heads in different layers.
        window_size (List[int]): Window size.
        mlp_ratio (float): Ratio of mlp hidden dim to embedding dim. Default: 4.0.
        dropout (float): Dropout rate. Default: 0.0.
        attention_dropout (float): Attention dropout rate. Default: 0.0.
        stochastic_depth_prob (float): Stochastic depth rate. Default: 0.1.
        num_classes (int): Number of classes for classification head. Default: 400.
        norm_layer (nn.Module, optional): Normalization layer. Default: None.
        block (nn.Module, optional): SwinTransformer Block. Default: None.
        downsample_layer (nn.Module): Downsample layer (patch merging). Default: PatchMerging.
        patch_embed (nn.Module, optional): Patch Embedding layer. Default: None.
    """

    def __init__(self, patch_size: 'List[int]\n', embed_dim: 'int\n', depths: 'List[int]\n', num_heads: 'List[int]\n', window_size: 'List[int]\n', mlp_ratio: 'float\n'=4.0, dropout: 'float\n'=0.0, attention_dropout: 'float\n'=0.0, stochastic_depth_prob: 'float\n'=0.1, num_classes: 'int\n'=400, norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None, block: 'Optional[Callable[(..., nn.Module)]]\n'=None, downsample_layer: 'Callable[(..., nn.Module)]\n'=PatchMerging, patch_embed: 'Optional[Callable[(..., nn.Module)]]\n'=None) ->None:
        super().__init__()
        _log_api_usage_once(self)
        self.num_classes = num_classes
        if block is None:
            block = partial(SwinTransformerBlock, attn_layer=ShiftedWindowAttention3d)
        if norm_layer is None:
            norm_layer = partial(nn.LayerNorm, eps=1e-05)
        if patch_embed is None:
            patch_embed = PatchEmbed3d
        self.patch_embed = patch_embed(patch_size=patch_size, embed_dim=embed_dim, norm_layer=norm_layer)
        self.pos_drop = nn.Dropout(p=dropout)
        layers: 'List[nn.Module]\n' = []
        total_stage_blocks = sum(depths)
        stage_block_id = 0
        for i_stage in range(len(depths)):
            stage: 'List[nn.Module]\n' = []
            dim = embed_dim * 2 ** i_stage
            for i_layer in range(depths[i_stage]):
                sd_prob = stochastic_depth_prob * float(stage_block_id) / (total_stage_blocks - 1)
                stage.append(block(dim, num_heads[i_stage], window_size=window_size, shift_size=[(0 if i_layer % 2 == 0 else w // 2) for w in window_size], mlp_ratio=mlp_ratio, dropout=dropout, attention_dropout=attention_dropout, stochastic_depth_prob=sd_prob, norm_layer=norm_layer, attn_layer=ShiftedWindowAttention3d))
                stage_block_id += 1
            layers.append(nn.Sequential(*stage))
            if i_stage < len(depths) - 1:
                layers.append(downsample_layer(dim, norm_layer))
        self.features = nn.Sequential(*layers)
        self.num_features = embed_dim * 2 ** (len(depths) - 1)
        self.norm = norm_layer(self.num_features)
        self.avgpool = nn.AdaptiveAvgPool3d(1)
        self.head = nn.Linear(self.num_features, num_classes)
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.trunc_normal_(m.weight, std=0.02)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x: 'Tensor\n') ->Tensor:
        x = self.patch_embed(x)
        x = self.pos_drop(x)
        x = self.features(x)
        x = self.norm(x)
        x = x.permute(0, 4, 1, 2, 3)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.head(x)
        return x


class IntermediateLayerGetter(nn.ModuleDict):
    """
    Module wrapper that returns intermediate layers from a model

    It has a strong assumption that the modules have been registered
    into the model in the same order as they are used.
    This means that one should **not** reuse the same nn.Module
    twice in the forward if you want this to work.

    Additionally, it is only able to query submodules that are directly
    assigned to the model. So if `model` is passed, `model.feature1` can
    be returned, but not `model.feature1.layer2`.

    Args:
        model (nn.Module): model on which we will extract the features
        return_layers (Dict[name, new_name]): a dict containing the names
            of the modules for which the activations will be returned as
            the key of the dict, and the value of the dict is the name
            of the returned activation (which the user can specify).

    Examples::

        >>> m = torchvision.models.resnet18(weights=ResNet18_Weights.DEFAULT)
        >>> # extract layer1 and layer3, giving as names `feat1` and feat2`
        >>> new_m = torchvision.models._utils.IntermediateLayerGetter(m,
        >>>     {'layer1': 'feat1', 'layer3': 'feat2'})
        >>> out = new_m(torch.rand(1, 3, 224, 224))
        >>> print([(k, v.shape) for k, v in out.items()])
        >>>     [('feat1', torch.Size([1, 64, 56, 56])),
        >>>      ('feat2', torch.Size([1, 256, 14, 14]))]
    """
    _version = 2
    __annotations__ = {'return_layers': Dict[str, str]}

    def __init__(self, model: 'nn.Module\n', return_layers: 'Dict[(str, str)]\n') ->None:
        if not set(return_layers).issubset([name for name, _ in model.named_children()]):
            raise ValueError('return_layers are not present in model')
        orig_return_layers = return_layers
        return_layers = {str(k): str(v) for k, v in return_layers.items()}
        layers = OrderedDict()
        for name, module in model.named_children():
            layers[name] = module
            if name in return_layers:
                del return_layers[name]
            if not return_layers:
                break
        super().__init__(layers)
        self.return_layers = orig_return_layers

    def forward(self, x):
        out = OrderedDict()
        for name, module in self.items():
            x = module(x)
            if name in self.return_layers:
                out_name = self.return_layers[name]
                out[out_name] = x
        return out


class AlexNet(nn.Module):

    def __init__(self, num_classes: 'int\n'=1000, dropout: 'float\n'=0.5) ->None:
        super().__init__()
        _log_api_usage_once(self)
        self.features = nn.Sequential(nn.Conv2d(3, 64, kernel_size=11, stride=4, padding=2), nn.ReLU(inplace=True), nn.MaxPool2d(kernel_size=3, stride=2), nn.Conv2d(64, 192, kernel_size=5, padding=2), nn.ReLU(inplace=True), nn.MaxPool2d(kernel_size=3, stride=2), nn.Conv2d(192, 384, kernel_size=3, padding=1), nn.ReLU(inplace=True), nn.Conv2d(384, 256, kernel_size=3, padding=1), nn.ReLU(inplace=True), nn.Conv2d(256, 256, kernel_size=3, padding=1), nn.ReLU(inplace=True), nn.MaxPool2d(kernel_size=3, stride=2))
        self.avgpool = nn.AdaptiveAvgPool2d((6, 6))
        self.classifier = nn.Sequential(nn.Dropout(p=dropout), nn.Linear(256 * 6 * 6, 4096), nn.ReLU(inplace=True), nn.Dropout(p=dropout), nn.Linear(4096, 4096), nn.ReLU(inplace=True), nn.Linear(4096, num_classes))

    def forward(self, x: 'torch.Tensor\n') ->torch.Tensor:
        x = self.features(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x


class LayerNorm2d(nn.LayerNorm):

    def forward(self, x: 'Tensor\n') ->Tensor:
        x = x.permute(0, 2, 3, 1)
        x = F.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)
        x = x.permute(0, 3, 1, 2)
        return x


class Permute(torch.nn.Module):
    """This module returns a view of the tensor input with its dimensions permuted.

    Args:
        dims (List[int]): The desired ordering of dimensions
    """

    def __init__(self, dims: 'List[int]\n'):
        super().__init__()
        self.dims = dims

    def forward(self, x: 'Tensor\n') ->Tensor:
        return torch.permute(x, self.dims)


class CNBlock(nn.Module):

    def __init__(self, dim, layer_scale: 'float\n', stochastic_depth_prob: 'float\n', norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None) ->None:
        super().__init__()
        if norm_layer is None:
            norm_layer = partial(nn.LayerNorm, eps=1e-06)
        self.block = nn.Sequential(nn.Conv2d(dim, dim, kernel_size=7, padding=3, groups=dim, bias=True), Permute([0, 2, 3, 1]), norm_layer(dim), nn.Linear(in_features=dim, out_features=4 * dim, bias=True), nn.GELU(), nn.Linear(in_features=4 * dim, out_features=dim, bias=True), Permute([0, 3, 1, 2]))
        self.layer_scale = nn.Parameter(torch.ones(dim, 1, 1) * layer_scale)
        self.stochastic_depth = StochasticDepth(stochastic_depth_prob, 'row')

    def forward(self, input: 'Tensor\n') ->Tensor:
        result = self.layer_scale * self.block(input)
        result = self.stochastic_depth(result)
        result += input
        return result


class CNBlockConfig:

    def __init__(self, input_channels: 'int\n', out_channels: 'Optional[int]\n', num_layers: 'int\n') ->None:
        self.input_channels = input_channels
        self.out_channels = out_channels
        self.num_layers = num_layers

    def __repr__(self) ->str:
        s = self.__class__.__name__ + '('
        s += 'input_channels={input_channels}'
        s += ', out_channels={out_channels}'
        s += ', num_layers={num_layers}'
        s += ')'
        return s.format(**self.__dict__)


class ConvNeXt(nn.Module):

    def __init__(self, block_setting: 'List[CNBlockConfig]\n', stochastic_depth_prob: 'float\n'=0.0, layer_scale: 'float\n'=1e-06, num_classes: 'int\n'=1000, block: 'Optional[Callable[(..., nn.Module)]]\n'=None, norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None, **kwargs: Any) ->None:
        super().__init__()
        _log_api_usage_once(self)
        if not block_setting:
            raise ValueError('The block_setting should not be empty')
        elif not (isinstance(block_setting, Sequence) and all([isinstance(s, CNBlockConfig) for s in block_setting])):
            raise TypeError('The block_setting should be List[CNBlockConfig]')
        if block is None:
            block = CNBlock
        if norm_layer is None:
            norm_layer = partial(LayerNorm2d, eps=1e-06)
        layers: 'List[nn.Module]\n' = []
        firstconv_output_channels = block_setting[0].input_channels
        layers.append(Conv2dNormActivation(3, firstconv_output_channels, kernel_size=4, stride=4, padding=0, norm_layer=norm_layer, activation_layer=None, bias=True))
        total_stage_blocks = sum(cnf.num_layers for cnf in block_setting)
        stage_block_id = 0
        for cnf in block_setting:
            stage: 'List[nn.Module]\n' = []
            for _ in range(cnf.num_layers):
                sd_prob = stochastic_depth_prob * stage_block_id / (total_stage_blocks - 1.0)
                stage.append(block(cnf.input_channels, layer_scale, sd_prob))
                stage_block_id += 1
            layers.append(nn.Sequential(*stage))
            if cnf.out_channels is not None:
                layers.append(nn.Sequential(norm_layer(cnf.input_channels), nn.Conv2d(cnf.input_channels, cnf.out_channels, kernel_size=2, stride=2)))
        self.features = nn.Sequential(*layers)
        self.avgpool = nn.AdaptiveAvgPool2d(1)
        lastblock = block_setting[-1]
        lastconv_output_channels = lastblock.out_channels if lastblock.out_channels is not None else lastblock.input_channels
        self.classifier = nn.Sequential(norm_layer(lastconv_output_channels), nn.Flatten(1), nn.Linear(lastconv_output_channels, num_classes))
        for m in self.modules():
            if isinstance(m, (nn.Conv2d, nn.Linear)):
                nn.init.trunc_normal_(m.weight, std=0.02)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def _forward_impl(self, x: 'Tensor\n') ->Tensor:
        x = self.features(x)
        x = self.avgpool(x)
        x = self.classifier(x)
        return x

    def forward(self, x: 'Tensor\n') ->Tensor:
        return self._forward_impl(x)


class _DenseLayer(nn.Module):

    def __init__(self, num_input_features: 'int\n', growth_rate: 'int\n', bn_size: 'int\n', drop_rate: 'float\n', memory_efficient: 'bool\n'=False) ->None:
        super().__init__()
        self.norm1 = nn.BatchNorm2d(num_input_features)
        self.relu1 = nn.ReLU(inplace=True)
        self.conv1 = nn.Conv2d(num_input_features, bn_size * growth_rate, kernel_size=1, stride=1, bias=False)
        self.norm2 = nn.BatchNorm2d(bn_size * growth_rate)
        self.relu2 = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(bn_size * growth_rate, growth_rate, kernel_size=3, stride=1, padding=1, bias=False)
        self.drop_rate = float(drop_rate)
        self.memory_efficient = memory_efficient

    def bn_function(self, inputs: 'List[Tensor]\n') ->Tensor:
        concated_features = torch.cat(inputs, 1)
        bottleneck_output = self.conv1(self.relu1(self.norm1(concated_features)))
        return bottleneck_output

    def any_requires_grad(self, input: 'List[Tensor]\n') ->bool:
        for tensor in input:
            if tensor.requires_grad:
                return True
        return False

    @torch.jit.unused
    def call_checkpoint_bottleneck(self, input: 'List[Tensor]\n') ->Tensor:

        def closure(*inputs):
            return self.bn_function(inputs)
        return cp.checkpoint(closure, *input)

    @torch.jit._overload_method
    def forward(self, input: 'List[Tensor]\n') ->Tensor:
        pass

    @torch.jit._overload_method
    def forward(self, input: 'Tensor\n') ->Tensor:
        pass

    def forward(self, input: 'Tensor\n') ->Tensor:
        if isinstance(input, Tensor):
            prev_features = [input]
        else:
            prev_features = input
        if self.memory_efficient and self.any_requires_grad(prev_features):
            if torch.jit.is_scripting():
                raise Exception('Memory Efficient not supported in JIT')
            bottleneck_output = self.call_checkpoint_bottleneck(prev_features)
        else:
            bottleneck_output = self.bn_function(prev_features)
        new_features = self.conv2(self.relu2(self.norm2(bottleneck_output)))
        if self.drop_rate > 0:
            new_features = F.dropout(new_features, p=self.drop_rate, training=self.training)
        return new_features


class _DenseBlock(nn.ModuleDict):
    _version = 2

    def __init__(self, num_layers: 'int\n', num_input_features: 'int\n', bn_size: 'int\n', growth_rate: 'int\n', drop_rate: 'float\n', memory_efficient: 'bool\n'=False) ->None:
        super().__init__()
        for i in range(num_layers):
            layer = _DenseLayer(num_input_features + i * growth_rate, growth_rate=growth_rate, bn_size=bn_size, drop_rate=drop_rate, memory_efficient=memory_efficient)
            self.add_module('denselayer%d' % (i + 1), layer)

    def forward(self, init_features: 'Tensor\n') ->Tensor:
        features = [init_features]
        for name, layer in self.items():
            new_features = layer(features)
            features.append(new_features)
        return torch.cat(features, 1)


class _Transition(nn.Sequential):

    def __init__(self, num_input_features: 'int\n', num_output_features: 'int\n') ->None:
        super().__init__()
        self.norm = nn.BatchNorm2d(num_input_features)
        self.relu = nn.ReLU(inplace=True)
        self.conv = nn.Conv2d(num_input_features, num_output_features, kernel_size=1, stride=1, bias=False)
        self.pool = nn.AvgPool2d(kernel_size=2, stride=2)


class DenseNet(nn.Module):
    """Densenet-BC model class, based on
    `"Densely Connected Convolutional Networks" <https://arxiv.org/pdf/1608.06993.pdf>`_.

    Args:
        growth_rate (int) - how many filters to add each layer (`k` in paper)
        block_config (list of 4 ints) - how many layers in each pooling block
        num_init_features (int) - the number of filters to learn in the first convolution layer
        bn_size (int) - multiplicative factor for number of bottle neck layers
          (i.e. bn_size * k features in the bottleneck layer)
        drop_rate (float) - dropout rate after each dense layer
        num_classes (int) - number of classification classes
        memory_efficient (bool) - If True, uses checkpointing. Much more memory efficient,
          but slower. Default: *False*. See `"paper" <https://arxiv.org/pdf/1707.06990.pdf>`_.
    """

    def __init__(self, growth_rate: 'int\n'=32, block_config: 'Tuple[(int, int, int, int)]\n'=(6, 12, 24, 16), num_init_features: 'int\n'=64, bn_size: 'int\n'=4, drop_rate: 'float\n'=0, num_classes: 'int\n'=1000, memory_efficient: 'bool\n'=False) ->None:
        super().__init__()
        _log_api_usage_once(self)
        self.features = nn.Sequential(OrderedDict([('conv0', nn.Conv2d(3, num_init_features, kernel_size=7, stride=2, padding=3, bias=False)), ('norm0', nn.BatchNorm2d(num_init_features)), ('relu0', nn.ReLU(inplace=True)), ('pool0', nn.MaxPool2d(kernel_size=3, stride=2, padding=1))]))
        num_features = num_init_features
        for i, num_layers in enumerate(block_config):
            block = _DenseBlock(num_layers=num_layers, num_input_features=num_features, bn_size=bn_size, growth_rate=growth_rate, drop_rate=drop_rate, memory_efficient=memory_efficient)
            self.features.add_module('denseblock%d' % (i + 1), block)
            num_features = num_features + num_layers * growth_rate
            if i != len(block_config) - 1:
                trans = _Transition(num_input_features=num_features, num_output_features=num_features // 2)
                self.features.add_module('transition%d' % (i + 1), trans)
                num_features = num_features // 2
        self.features.add_module('norm5', nn.BatchNorm2d(num_features))
        self.classifier = nn.Linear(num_features, num_classes)
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.constant_(m.bias, 0)

    def forward(self, x: 'Tensor\n') ->Tensor:
        features = self.features(x)
        out = F.relu(features, inplace=True)
        out = F.adaptive_avg_pool2d(out, (1, 1))
        out = torch.flatten(out, 1)
        out = self.classifier(out)
        return out


class MBConv(nn.Module):
    """MBConv: Mobile Inverted Residual Bottleneck.

    Args:
        in_channels (int): Number of input channels.
        out_channels (int): Number of output channels.
        expansion_ratio (float): Expansion ratio in the bottleneck.
        squeeze_ratio (float): Squeeze ratio in the SE Layer.
        stride (int): Stride of the depthwise convolution.
        activation_layer (Callable[..., nn.Module]): Activation function.
        norm_layer (Callable[..., nn.Module]): Normalization function.
        p_stochastic_dropout (float): Probability of stochastic depth.
    """

    def __init__(self, in_channels: 'int\n', out_channels: 'int\n', expansion_ratio: 'float\n', squeeze_ratio: 'float\n', stride: 'int\n', activation_layer: 'Callable[(..., nn.Module)]\n', norm_layer: 'Callable[(..., nn.Module)]\n', p_stochastic_dropout: 'float\n'=0.0) ->None:
        super().__init__()
        proj: 'Sequence[nn.Module]\n'
        self.proj: 'nn.Module\n'
        should_proj = stride != 1 or in_channels != out_channels
        if should_proj:
            proj = [nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=1, bias=True)]
            if stride == 2:
                proj = [nn.AvgPool2d(kernel_size=3, stride=stride, padding=1)] + proj
            self.proj = nn.Sequential(*proj)
        else:
            self.proj = nn.Identity()
        mid_channels = int(out_channels * expansion_ratio)
        sqz_channels = int(out_channels * squeeze_ratio)
        if p_stochastic_dropout:
            self.stochastic_depth = StochasticDepth(p_stochastic_dropout, mode='row')
        else:
            self.stochastic_depth = nn.Identity()
        _layers = OrderedDict()
        _layers['pre_norm'] = norm_layer(in_channels)
        _layers['conv_a'] = Conv2dNormActivation(in_channels, mid_channels, kernel_size=1, stride=1, padding=0, activation_layer=activation_layer, norm_layer=norm_layer, inplace=None)
        _layers['conv_b'] = Conv2dNormActivation(mid_channels, mid_channels, kernel_size=3, stride=stride, padding=1, activation_layer=activation_layer, norm_layer=norm_layer, groups=mid_channels, inplace=None)
        _layers['squeeze_excitation'] = SqueezeExcitation(mid_channels, sqz_channels, activation=nn.SiLU)
        _layers['conv_c'] = nn.Conv2d(in_channels=mid_channels, out_channels=out_channels, kernel_size=1, bias=True)
        self.layers = nn.Sequential(_layers)

    def forward(self, x: 'Tensor\n') ->Tensor:
        """
        Args:
            x (Tensor): Input tensor with expected layout of [B, C, H, W].
        Returns:
            Tensor: Output tensor with expected layout of [B, C, H / stride, W / stride].
        """
        res = self.proj(x)
        x = self.stochastic_depth(self.layers(x))
        return res + x


class FusedMBConv(nn.Module):

    def __init__(self, cnf: 'FusedMBConvConfig\n', stochastic_depth_prob: 'float\n', norm_layer: 'Callable[(..., nn.Module)]\n') ->None:
        super().__init__()
        if not 1 <= cnf.stride <= 2:
            raise ValueError('illegal stride value')
        self.use_res_connect = cnf.stride == 1 and cnf.input_channels == cnf.out_channels
        layers: 'List[nn.Module]\n' = []
        activation_layer = nn.SiLU
        expanded_channels = cnf.adjust_channels(cnf.input_channels, cnf.expand_ratio)
        if expanded_channels != cnf.input_channels:
            layers.append(Conv2dNormActivation(cnf.input_channels, expanded_channels, kernel_size=cnf.kernel, stride=cnf.stride, norm_layer=norm_layer, activation_layer=activation_layer))
            layers.append(Conv2dNormActivation(expanded_channels, cnf.out_channels, kernel_size=1, norm_layer=norm_layer, activation_layer=None))
        else:
            layers.append(Conv2dNormActivation(cnf.input_channels, cnf.out_channels, kernel_size=cnf.kernel, stride=cnf.stride, norm_layer=norm_layer, activation_layer=activation_layer))
        self.block = nn.Sequential(*layers)
        self.stochastic_depth = StochasticDepth(stochastic_depth_prob, 'row')
        self.out_channels = cnf.out_channels

    def forward(self, input: 'Tensor\n') ->Tensor:
        result = self.block(input)
        if self.use_res_connect:
            result = self.stochastic_depth(result)
            result += input
        return result


def _make_divisible(v: 'float\n', divisor: 'int\n', min_value: 'Optional[int]\n'=None) ->int:
    """
    This function is taken from the original tf repo.
    It ensures that all layers have a channel number that is divisible by 8
    It can be seen here:
    https://github.com/tensorflow/models/blob/master/research/slim/nets/mobilenet/mobilenet.py
    """
    if min_value is None:
        min_value = divisor
    new_v = max(min_value, int(v + divisor / 2) // divisor * divisor)
    if new_v < 0.9 * v:
        new_v += divisor
    return new_v


class EfficientNet(nn.Module):

    def __init__(self, inverted_residual_setting: 'Sequence[Union[(MBConvConfig, FusedMBConvConfig)]]\n', dropout: 'float\n', stochastic_depth_prob: 'float\n'=0.2, num_classes: 'int\n'=1000, norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None, last_channel: 'Optional[int]\n'=None) ->None:
        """
        EfficientNet V1 and V2 main class

        Args:
            inverted_residual_setting (Sequence[Union[MBConvConfig, FusedMBConvConfig]]): Network structure
            dropout (float): The droupout probability
            stochastic_depth_prob (float): The stochastic depth probability
            num_classes (int): Number of classes
            norm_layer (Optional[Callable[..., nn.Module]]): Module specifying the normalization layer to use
            last_channel (int): The number of channels on the penultimate layer
        """
        super().__init__()
        _log_api_usage_once(self)
        if not inverted_residual_setting:
            raise ValueError('The inverted_residual_setting should not be empty')
        elif not (isinstance(inverted_residual_setting, Sequence) and all([isinstance(s, _MBConvConfig) for s in inverted_residual_setting])):
            raise TypeError('The inverted_residual_setting should be List[MBConvConfig]')
        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        layers: 'List[nn.Module]\n' = []
        firstconv_output_channels = inverted_residual_setting[0].input_channels
        layers.append(Conv2dNormActivation(3, firstconv_output_channels, kernel_size=3, stride=2, norm_layer=norm_layer, activation_layer=nn.SiLU))
        total_stage_blocks = sum(cnf.num_layers for cnf in inverted_residual_setting)
        stage_block_id = 0
        for cnf in inverted_residual_setting:
            stage: 'List[nn.Module]\n' = []
            for _ in range(cnf.num_layers):
                block_cnf = copy.copy(cnf)
                if stage:
                    block_cnf.input_channels = block_cnf.out_channels
                    block_cnf.stride = 1
                sd_prob = stochastic_depth_prob * float(stage_block_id) / total_stage_blocks
                stage.append(block_cnf.block(block_cnf, sd_prob, norm_layer))
                stage_block_id += 1
            layers.append(nn.Sequential(*stage))
        lastconv_input_channels = inverted_residual_setting[-1].out_channels
        lastconv_output_channels = last_channel if last_channel is not None else 4 * lastconv_input_channels
        layers.append(Conv2dNormActivation(lastconv_input_channels, lastconv_output_channels, kernel_size=1, norm_layer=norm_layer, activation_layer=nn.SiLU))
        self.features = nn.Sequential(*layers)
        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.classifier = nn.Sequential(nn.Dropout(p=dropout, inplace=True), nn.Linear(lastconv_output_channels, num_classes))
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, (nn.BatchNorm2d, nn.GroupNorm)):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                init_range = 1.0 / math.sqrt(m.out_features)
                nn.init.uniform_(m.weight, -init_range, init_range)
                nn.init.zeros_(m.bias)

    def _forward_impl(self, x: 'Tensor\n') ->Tensor:
        x = self.features(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x

    def forward(self, x: 'Tensor\n') ->Tensor:
        return self._forward_impl(x)


class DualGraphModule(fx.GraphModule):
    """
    A derivative of `fx.GraphModule`. Differs in the following ways:
    - Requires a train and eval version of the underlying graph
    - Copies submodules according to the nodes of both train and eval graphs.
    - Calling train(mode) switches between train graph and eval graph.
    """

    def __init__(self, root: 'torch.nn.Module\n', train_graph: 'fx.Graph\n', eval_graph: 'fx.Graph\n', class_name: 'str\n'='GraphModule'):
        """
        Args:
            root (nn.Module): module from which the copied module hierarchy is
                built
            train_graph (fx.Graph): the graph that should be used in train mode
            eval_graph (fx.Graph): the graph that should be used in eval mode
        """
        super(fx.GraphModule, self).__init__()
        self.__class__.__name__ = class_name
        self.train_graph = train_graph
        self.eval_graph = eval_graph
        for node in chain(iter(train_graph.nodes), iter(eval_graph.nodes)):
            if node.op in ['get_attr', 'call_module']:
                if not isinstance(node.target, str):
                    raise TypeError(f'node.target should be of type str instead of {type(node.target)}')
                _copy_attr(root, self, node.target)
        self.train()
        self.graph = train_graph
        if self.eval_graph._tracer_cls != self.train_graph._tracer_cls:
            raise TypeError(f'Train mode and eval mode should use the same tracer class. Instead got {self.eval_graph._tracer_cls} for eval vs {self.train_graph._tracer_cls} for train')
        self._tracer_cls = None
        if self.graph._tracer_cls and '<locals>' not in self.graph._tracer_cls.__qualname__:
            self._tracer_cls = self.graph._tracer_cls

    def train(self, mode=True):
        """
        Swap out the graph depending on the selected training mode.
        NOTE this should be safe when calling model.eval() because that just
        calls this with mode == False.
        """
        if mode and not self.training:
            self.graph = self.train_graph
        elif not mode and self.training:
            self.graph = self.eval_graph
        return super().train(mode=mode)


class BasicConv2d(nn.Module):

    def __init__(self, in_channels: 'int\n', out_channels: 'int\n', **kwargs: Any) ->None:
        super().__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, bias=False, **kwargs)
        self.bn = nn.BatchNorm2d(out_channels, eps=0.001)

    def forward(self, x: 'Tensor\n') ->Tensor:
        x = self.conv(x)
        x = self.bn(x)
        return F.relu(x, inplace=True)


GoogLeNetOutputs = namedtuple('GoogLeNetOutputs', ['logits', 'aux_logits2', 'aux_logits1'])


class Inception(nn.Module):

    def __init__(self, in_channels: 'int\n', ch1x1: 'int\n', ch3x3red: 'int\n', ch3x3: 'int\n', ch5x5red: 'int\n', ch5x5: 'int\n', pool_proj: 'int\n', conv_block: 'Optional[Callable[(..., nn.Module)]]\n'=None) ->None:
        super().__init__()
        if conv_block is None:
            conv_block = BasicConv2d
        self.branch1 = conv_block(in_channels, ch1x1, kernel_size=1)
        self.branch2 = nn.Sequential(conv_block(in_channels, ch3x3red, kernel_size=1), conv_block(ch3x3red, ch3x3, kernel_size=3, padding=1))
        self.branch3 = nn.Sequential(conv_block(in_channels, ch5x5red, kernel_size=1), conv_block(ch5x5red, ch5x5, kernel_size=3, padding=1))
        self.branch4 = nn.Sequential(nn.MaxPool2d(kernel_size=3, stride=1, padding=1, ceil_mode=True), conv_block(in_channels, pool_proj, kernel_size=1))

    def _forward(self, x: 'Tensor\n') ->List[Tensor]:
        branch1 = self.branch1(x)
        branch2 = self.branch2(x)
        branch3 = self.branch3(x)
        branch4 = self.branch4(x)
        outputs = [branch1, branch2, branch3, branch4]
        return outputs

    def forward(self, x: 'Tensor\n') ->Tensor:
        outputs = self._forward(x)
        return torch.cat(outputs, 1)


class InceptionAux(nn.Module):

    def __init__(self, in_channels: 'int\n', num_classes: 'int\n', conv_block: 'Optional[Callable[(..., nn.Module)]]\n'=None) ->None:
        super().__init__()
        if conv_block is None:
            conv_block = BasicConv2d
        self.conv0 = conv_block(in_channels, 128, kernel_size=1)
        self.conv1 = conv_block(128, 768, kernel_size=5)
        self.conv1.stddev = 0.01
        self.fc = nn.Linear(768, num_classes)
        self.fc.stddev = 0.001

    def forward(self, x: 'Tensor\n') ->Tensor:
        x = F.avg_pool2d(x, kernel_size=5, stride=3)
        x = self.conv0(x)
        x = self.conv1(x)
        x = F.adaptive_avg_pool2d(x, (1, 1))
        x = torch.flatten(x, 1)
        x = self.fc(x)
        return x


_GoogLeNetOutputs = GoogLeNetOutputs


class GoogLeNet(nn.Module):
    __constants__ = ['aux_logits', 'transform_input']

    def __init__(self, num_classes: 'int\n'=1000, aux_logits: 'bool\n'=True, transform_input: 'bool\n'=False, init_weights: 'Optional[bool]\n'=None, blocks: 'Optional[List[Callable[(..., nn.Module)]]]\n'=None, dropout: 'float\n'=0.2, dropout_aux: 'float\n'=0.7) ->None:
        super().__init__()
        _log_api_usage_once(self)
        if blocks is None:
            blocks = [BasicConv2d, Inception, InceptionAux]
        if init_weights is None:
            warnings.warn('The default weight initialization of GoogleNet will be changed in future releases of torchvision. If you wish to keep the old behavior (which leads to long initialization times due to scipy/scipy#11299), please set init_weights=True.', FutureWarning)
            init_weights = True
        if len(blocks) != 3:
            raise ValueError(f'blocks length should be 3 instead of {len(blocks)}')
        conv_block = blocks[0]
        inception_block = blocks[1]
        inception_aux_block = blocks[2]
        self.aux_logits = aux_logits
        self.transform_input = transform_input
        self.conv1 = conv_block(3, 64, kernel_size=7, stride=2, padding=3)
        self.maxpool1 = nn.MaxPool2d(3, stride=2, ceil_mode=True)
        self.conv2 = conv_block(64, 64, kernel_size=1)
        self.conv3 = conv_block(64, 192, kernel_size=3, padding=1)
        self.maxpool2 = nn.MaxPool2d(3, stride=2, ceil_mode=True)
        self.inception3a = inception_block(192, 64, 96, 128, 16, 32, 32)
        self.inception3b = inception_block(256, 128, 128, 192, 32, 96, 64)
        self.maxpool3 = nn.MaxPool2d(3, stride=2, ceil_mode=True)
        self.inception4a = inception_block(480, 192, 96, 208, 16, 48, 64)
        self.inception4b = inception_block(512, 160, 112, 224, 24, 64, 64)
        self.inception4c = inception_block(512, 128, 128, 256, 24, 64, 64)
        self.inception4d = inception_block(512, 112, 144, 288, 32, 64, 64)
        self.inception4e = inception_block(528, 256, 160, 320, 32, 128, 128)
        self.maxpool4 = nn.MaxPool2d(2, stride=2, ceil_mode=True)
        self.inception5a = inception_block(832, 256, 160, 320, 32, 128, 128)
        self.inception5b = inception_block(832, 384, 192, 384, 48, 128, 128)
        if aux_logits:
            self.aux1 = inception_aux_block(512, num_classes, dropout=dropout_aux)
            self.aux2 = inception_aux_block(528, num_classes, dropout=dropout_aux)
        else:
            self.aux1 = None
            self.aux2 = None
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.dropout = nn.Dropout(p=dropout)
        self.fc = nn.Linear(1024, num_classes)
        if init_weights:
            for m in self.modules():
                if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
                    torch.nn.init.trunc_normal_(m.weight, mean=0.0, std=0.01, a=-2, b=2)
                elif isinstance(m, nn.BatchNorm2d):
                    nn.init.constant_(m.weight, 1)
                    nn.init.constant_(m.bias, 0)

    def _transform_input(self, x: 'Tensor\n') ->Tensor:
        if self.transform_input:
            x_ch0 = torch.unsqueeze(x[:, (0)], 1) * (0.229 / 0.5) + (0.485 - 0.5) / 0.5
            x_ch1 = torch.unsqueeze(x[:, (1)], 1) * (0.224 / 0.5) + (0.456 - 0.5) / 0.5
            x_ch2 = torch.unsqueeze(x[:, (2)], 1) * (0.225 / 0.5) + (0.406 - 0.5) / 0.5
            x = torch.cat((x_ch0, x_ch1, x_ch2), 1)
        return x

    def _forward(self, x: 'Tensor\n') ->Tuple[Tensor, Optional[Tensor], Optional[Tensor]]:
        x = self.conv1(x)
        x = self.maxpool1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.maxpool2(x)
        x = self.inception3a(x)
        x = self.inception3b(x)
        x = self.maxpool3(x)
        x = self.inception4a(x)
        aux1: 'Optional[Tensor]\n' = None
        if self.aux1 is not None:
            if self.training:
                aux1 = self.aux1(x)
        x = self.inception4b(x)
        x = self.inception4c(x)
        x = self.inception4d(x)
        aux2: 'Optional[Tensor]\n' = None
        if self.aux2 is not None:
            if self.training:
                aux2 = self.aux2(x)
        x = self.inception4e(x)
        x = self.maxpool4(x)
        x = self.inception5a(x)
        x = self.inception5b(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.dropout(x)
        x = self.fc(x)
        return x, aux2, aux1

    @torch.jit.unused
    def eager_outputs(self, x: 'Tensor\n', aux2: 'Tensor\n', aux1: 'Optional[Tensor]\n') ->GoogLeNetOutputs:
        if self.training and self.aux_logits:
            return _GoogLeNetOutputs(x, aux2, aux1)
        else:
            return x

    def forward(self, x: 'Tensor\n') ->GoogLeNetOutputs:
        x = self._transform_input(x)
        x, aux1, aux2 = self._forward(x)
        aux_defined = self.training and self.aux_logits
        if torch.jit.is_scripting():
            if not aux_defined:
                warnings.warn('Scripted GoogleNet always returns GoogleNetOutputs Tuple')
            return GoogLeNetOutputs(x, aux2, aux1)
        else:
            return self.eager_outputs(x, aux2, aux1)


class InceptionA(nn.Module):

    def __init__(self, in_channels: 'int\n', pool_features: 'int\n', conv_block: 'Optional[Callable[(..., nn.Module)]]\n'=None) ->None:
        super().__init__()
        if conv_block is None:
            conv_block = BasicConv2d
        self.branch1x1 = conv_block(in_channels, 64, kernel_size=1)
        self.branch5x5_1 = conv_block(in_channels, 48, kernel_size=1)
        self.branch5x5_2 = conv_block(48, 64, kernel_size=5, padding=2)
        self.branch3x3dbl_1 = conv_block(in_channels, 64, kernel_size=1)
        self.branch3x3dbl_2 = conv_block(64, 96, kernel_size=3, padding=1)
        self.branch3x3dbl_3 = conv_block(96, 96, kernel_size=3, padding=1)
        self.branch_pool = conv_block(in_channels, pool_features, kernel_size=1)

    def _forward(self, x: 'Tensor\n') ->List[Tensor]:
        branch1x1 = self.branch1x1(x)
        branch5x5 = self.branch5x5_1(x)
        branch5x5 = self.branch5x5_2(branch5x5)
        branch3x3dbl = self.branch3x3dbl_1(x)
        branch3x3dbl = self.branch3x3dbl_2(branch3x3dbl)
        branch3x3dbl = self.branch3x3dbl_3(branch3x3dbl)
        branch_pool = F.avg_pool2d(x, kernel_size=3, stride=1, padding=1)
        branch_pool = self.branch_pool(branch_pool)
        outputs = [branch1x1, branch5x5, branch3x3dbl, branch_pool]
        return outputs

    def forward(self, x: 'Tensor\n') ->Tensor:
        outputs = self._forward(x)
        return torch.cat(outputs, 1)


class InceptionB(nn.Module):

    def __init__(self, in_channels: 'int\n', conv_block: 'Optional[Callable[(..., nn.Module)]]\n'=None) ->None:
        super().__init__()
        if conv_block is None:
            conv_block = BasicConv2d
        self.branch3x3 = conv_block(in_channels, 384, kernel_size=3, stride=2)
        self.branch3x3dbl_1 = conv_block(in_channels, 64, kernel_size=1)
        self.branch3x3dbl_2 = conv_block(64, 96, kernel_size=3, padding=1)
        self.branch3x3dbl_3 = conv_block(96, 96, kernel_size=3, stride=2)

    def _forward(self, x: 'Tensor\n') ->List[Tensor]:
        branch3x3 = self.branch3x3(x)
        branch3x3dbl = self.branch3x3dbl_1(x)
        branch3x3dbl = self.branch3x3dbl_2(branch3x3dbl)
        branch3x3dbl = self.branch3x3dbl_3(branch3x3dbl)
        branch_pool = F.max_pool2d(x, kernel_size=3, stride=2)
        outputs = [branch3x3, branch3x3dbl, branch_pool]
        return outputs

    def forward(self, x: 'Tensor\n') ->Tensor:
        outputs = self._forward(x)
        return torch.cat(outputs, 1)


class InceptionC(nn.Module):

    def __init__(self, in_channels: 'int\n', channels_7x7: 'int\n', conv_block: 'Optional[Callable[(..., nn.Module)]]\n'=None) ->None:
        super().__init__()
        if conv_block is None:
            conv_block = BasicConv2d
        self.branch1x1 = conv_block(in_channels, 192, kernel_size=1)
        c7 = channels_7x7
        self.branch7x7_1 = conv_block(in_channels, c7, kernel_size=1)
        self.branch7x7_2 = conv_block(c7, c7, kernel_size=(1, 7), padding=(0, 3))
        self.branch7x7_3 = conv_block(c7, 192, kernel_size=(7, 1), padding=(3, 0))
        self.branch7x7dbl_1 = conv_block(in_channels, c7, kernel_size=1)
        self.branch7x7dbl_2 = conv_block(c7, c7, kernel_size=(7, 1), padding=(3, 0))
        self.branch7x7dbl_3 = conv_block(c7, c7, kernel_size=(1, 7), padding=(0, 3))
        self.branch7x7dbl_4 = conv_block(c7, c7, kernel_size=(7, 1), padding=(3, 0))
        self.branch7x7dbl_5 = conv_block(c7, 192, kernel_size=(1, 7), padding=(0, 3))
        self.branch_pool = conv_block(in_channels, 192, kernel_size=1)

    def _forward(self, x: 'Tensor\n') ->List[Tensor]:
        branch1x1 = self.branch1x1(x)
        branch7x7 = self.branch7x7_1(x)
        branch7x7 = self.branch7x7_2(branch7x7)
        branch7x7 = self.branch7x7_3(branch7x7)
        branch7x7dbl = self.branch7x7dbl_1(x)
        branch7x7dbl = self.branch7x7dbl_2(branch7x7dbl)
        branch7x7dbl = self.branch7x7dbl_3(branch7x7dbl)
        branch7x7dbl = self.branch7x7dbl_4(branch7x7dbl)
        branch7x7dbl = self.branch7x7dbl_5(branch7x7dbl)
        branch_pool = F.avg_pool2d(x, kernel_size=3, stride=1, padding=1)
        branch_pool = self.branch_pool(branch_pool)
        outputs = [branch1x1, branch7x7, branch7x7dbl, branch_pool]
        return outputs

    def forward(self, x: 'Tensor\n') ->Tensor:
        outputs = self._forward(x)
        return torch.cat(outputs, 1)


class InceptionD(nn.Module):

    def __init__(self, in_channels: 'int\n', conv_block: 'Optional[Callable[(..., nn.Module)]]\n'=None) ->None:
        super().__init__()
        if conv_block is None:
            conv_block = BasicConv2d
        self.branch3x3_1 = conv_block(in_channels, 192, kernel_size=1)
        self.branch3x3_2 = conv_block(192, 320, kernel_size=3, stride=2)
        self.branch7x7x3_1 = conv_block(in_channels, 192, kernel_size=1)
        self.branch7x7x3_2 = conv_block(192, 192, kernel_size=(1, 7), padding=(0, 3))
        self.branch7x7x3_3 = conv_block(192, 192, kernel_size=(7, 1), padding=(3, 0))
        self.branch7x7x3_4 = conv_block(192, 192, kernel_size=3, stride=2)

    def _forward(self, x: 'Tensor\n') ->List[Tensor]:
        branch3x3 = self.branch3x3_1(x)
        branch3x3 = self.branch3x3_2(branch3x3)
        branch7x7x3 = self.branch7x7x3_1(x)
        branch7x7x3 = self.branch7x7x3_2(branch7x7x3)
        branch7x7x3 = self.branch7x7x3_3(branch7x7x3)
        branch7x7x3 = self.branch7x7x3_4(branch7x7x3)
        branch_pool = F.max_pool2d(x, kernel_size=3, stride=2)
        outputs = [branch3x3, branch7x7x3, branch_pool]
        return outputs

    def forward(self, x: 'Tensor\n') ->Tensor:
        outputs = self._forward(x)
        return torch.cat(outputs, 1)


class InceptionE(nn.Module):

    def __init__(self, in_channels: 'int\n', conv_block: 'Optional[Callable[(..., nn.Module)]]\n'=None) ->None:
        super().__init__()
        if conv_block is None:
            conv_block = BasicConv2d
        self.branch1x1 = conv_block(in_channels, 320, kernel_size=1)
        self.branch3x3_1 = conv_block(in_channels, 384, kernel_size=1)
        self.branch3x3_2a = conv_block(384, 384, kernel_size=(1, 3), padding=(0, 1))
        self.branch3x3_2b = conv_block(384, 384, kernel_size=(3, 1), padding=(1, 0))
        self.branch3x3dbl_1 = conv_block(in_channels, 448, kernel_size=1)
        self.branch3x3dbl_2 = conv_block(448, 384, kernel_size=3, padding=1)
        self.branch3x3dbl_3a = conv_block(384, 384, kernel_size=(1, 3), padding=(0, 1))
        self.branch3x3dbl_3b = conv_block(384, 384, kernel_size=(3, 1), padding=(1, 0))
        self.branch_pool = conv_block(in_channels, 192, kernel_size=1)

    def _forward(self, x: 'Tensor\n') ->List[Tensor]:
        branch1x1 = self.branch1x1(x)
        branch3x3 = self.branch3x3_1(x)
        branch3x3 = [self.branch3x3_2a(branch3x3), self.branch3x3_2b(branch3x3)]
        branch3x3 = torch.cat(branch3x3, 1)
        branch3x3dbl = self.branch3x3dbl_1(x)
        branch3x3dbl = self.branch3x3dbl_2(branch3x3dbl)
        branch3x3dbl = [self.branch3x3dbl_3a(branch3x3dbl), self.branch3x3dbl_3b(branch3x3dbl)]
        branch3x3dbl = torch.cat(branch3x3dbl, 1)
        branch_pool = F.avg_pool2d(x, kernel_size=3, stride=1, padding=1)
        branch_pool = self.branch_pool(branch_pool)
        outputs = [branch1x1, branch3x3, branch3x3dbl, branch_pool]
        return outputs

    def forward(self, x: 'Tensor\n') ->Tensor:
        outputs = self._forward(x)
        return torch.cat(outputs, 1)


class Inception3(nn.Module):

    def __init__(self, num_classes: 'int\n'=1000, aux_logits: 'bool\n'=True, transform_input: 'bool\n'=False, inception_blocks: 'Optional[List[Callable[(..., nn.Module)]]]\n'=None, init_weights: 'Optional[bool]\n'=None, dropout: 'float\n'=0.5) ->None:
        super().__init__()
        _log_api_usage_once(self)
        if inception_blocks is None:
            inception_blocks = [BasicConv2d, InceptionA, InceptionB, InceptionC, InceptionD, InceptionE, InceptionAux]
        if init_weights is None:
            warnings.warn('The default weight initialization of inception_v3 will be changed in future releases of torchvision. If you wish to keep the old behavior (which leads to long initialization times due to scipy/scipy#11299), please set init_weights=True.', FutureWarning)
            init_weights = True
        if len(inception_blocks) != 7:
            raise ValueError(f'length of inception_blocks should be 7 instead of {len(inception_blocks)}')
        conv_block = inception_blocks[0]
        inception_a = inception_blocks[1]
        inception_b = inception_blocks[2]
        inception_c = inception_blocks[3]
        inception_d = inception_blocks[4]
        inception_e = inception_blocks[5]
        inception_aux = inception_blocks[6]
        self.aux_logits = aux_logits
        self.transform_input = transform_input
        self.Conv2d_1a_3x3 = conv_block(3, 32, kernel_size=3, stride=2)
        self.Conv2d_2a_3x3 = conv_block(32, 32, kernel_size=3)
        self.Conv2d_2b_3x3 = conv_block(32, 64, kernel_size=3, padding=1)
        self.maxpool1 = nn.MaxPool2d(kernel_size=3, stride=2)
        self.Conv2d_3b_1x1 = conv_block(64, 80, kernel_size=1)
        self.Conv2d_4a_3x3 = conv_block(80, 192, kernel_size=3)
        self.maxpool2 = nn.MaxPool2d(kernel_size=3, stride=2)
        self.Mixed_5b = inception_a(192, pool_features=32)
        self.Mixed_5c = inception_a(256, pool_features=64)
        self.Mixed_5d = inception_a(288, pool_features=64)
        self.Mixed_6a = inception_b(288)
        self.Mixed_6b = inception_c(768, channels_7x7=128)
        self.Mixed_6c = inception_c(768, channels_7x7=160)
        self.Mixed_6d = inception_c(768, channels_7x7=160)
        self.Mixed_6e = inception_c(768, channels_7x7=192)
        self.AuxLogits: 'Optional[nn.Module]\n' = None
        if aux_logits:
            self.AuxLogits = inception_aux(768, num_classes)
        self.Mixed_7a = inception_d(768)
        self.Mixed_7b = inception_e(1280)
        self.Mixed_7c = inception_e(2048)
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.dropout = nn.Dropout(p=dropout)
        self.fc = nn.Linear(2048, num_classes)
        if init_weights:
            for m in self.modules():
                if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
                    stddev = float(m.stddev) if hasattr(m, 'stddev') else 0.1
                    torch.nn.init.trunc_normal_(m.weight, mean=0.0, std=stddev, a=-2, b=2)
                elif isinstance(m, nn.BatchNorm2d):
                    nn.init.constant_(m.weight, 1)
                    nn.init.constant_(m.bias, 0)

    def _transform_input(self, x: 'Tensor\n') ->Tensor:
        if self.transform_input:
            x_ch0 = torch.unsqueeze(x[:, (0)], 1) * (0.229 / 0.5) + (0.485 - 0.5) / 0.5
            x_ch1 = torch.unsqueeze(x[:, (1)], 1) * (0.224 / 0.5) + (0.456 - 0.5) / 0.5
            x_ch2 = torch.unsqueeze(x[:, (2)], 1) * (0.225 / 0.5) + (0.406 - 0.5) / 0.5
            x = torch.cat((x_ch0, x_ch1, x_ch2), 1)
        return x

    def _forward(self, x: 'Tensor\n') ->Tuple[Tensor, Optional[Tensor]]:
        x = self.Conv2d_1a_3x3(x)
        x = self.Conv2d_2a_3x3(x)
        x = self.Conv2d_2b_3x3(x)
        x = self.maxpool1(x)
        x = self.Conv2d_3b_1x1(x)
        x = self.Conv2d_4a_3x3(x)
        x = self.maxpool2(x)
        x = self.Mixed_5b(x)
        x = self.Mixed_5c(x)
        x = self.Mixed_5d(x)
        x = self.Mixed_6a(x)
        x = self.Mixed_6b(x)
        x = self.Mixed_6c(x)
        x = self.Mixed_6d(x)
        x = self.Mixed_6e(x)
        aux: 'Optional[Tensor]\n' = None
        if self.AuxLogits is not None:
            if self.training:
                aux = self.AuxLogits(x)
        x = self.Mixed_7a(x)
        x = self.Mixed_7b(x)
        x = self.Mixed_7c(x)
        x = self.avgpool(x)
        x = self.dropout(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)
        return x, aux

    @torch.jit.unused
    def eager_outputs(self, x: 'Tensor\n', aux: 'Optional[Tensor]\n') ->InceptionOutputs:
        if self.training and self.aux_logits:
            return InceptionOutputs(x, aux)
        else:
            return x

    def forward(self, x: 'Tensor\n') ->InceptionOutputs:
        x = self._transform_input(x)
        x, aux = self._forward(x)
        aux_defined = self.training and self.aux_logits
        if torch.jit.is_scripting():
            if not aux_defined:
                warnings.warn('Scripted Inception3 always returns Inception3 Tuple')
            return InceptionOutputs(x, aux)
        else:
            return self.eager_outputs(x, aux)


def _get_relative_position_index(height: 'int\n', width: 'int\n') ->torch.Tensor:
    coords = torch.stack(torch.meshgrid([torch.arange(height), torch.arange(width)]))
    coords_flat = torch.flatten(coords, 1)
    relative_coords = coords_flat[:, :, (None)] - coords_flat[:, (None), :]
    relative_coords = relative_coords.permute(1, 2, 0).contiguous()
    relative_coords[:, :, (0)] += height - 1
    relative_coords[:, :, (1)] += width - 1
    relative_coords[:, :, (0)] *= 2 * width - 1
    return relative_coords.sum(-1)


class RelativePositionalMultiHeadAttention(nn.Module):
    """Relative Positional Multi-Head Attention.

    Args:
        feat_dim (int): Number of input features.
        head_dim (int): Number of features per head.
        max_seq_len (int): Maximum sequence length.
    """

    def __init__(self, feat_dim: 'int\n', head_dim: 'int\n', max_seq_len: 'int\n') ->None:
        super().__init__()
        if feat_dim % head_dim != 0:
            raise ValueError(f'feat_dim: {feat_dim} must be divisible by head_dim: {head_dim}')
        self.n_heads = feat_dim // head_dim
        self.head_dim = head_dim
        self.size = int(math.sqrt(max_seq_len))
        self.max_seq_len = max_seq_len
        self.to_qkv = nn.Linear(feat_dim, self.n_heads * self.head_dim * 3)
        self.scale_factor = feat_dim ** -0.5
        self.merge = nn.Linear(self.head_dim * self.n_heads, feat_dim)
        self.relative_position_bias_table = nn.parameter.Parameter(torch.empty(((2 * self.size - 1) * (2 * self.size - 1), self.n_heads), dtype=torch.float32))
        self.register_buffer('relative_position_index', _get_relative_position_index(self.size, self.size))
        torch.nn.init.trunc_normal_(self.relative_position_bias_table, std=0.02)

    def get_relative_positional_bias(self) ->torch.Tensor:
        bias_index = self.relative_position_index.view(-1)
        relative_bias = self.relative_position_bias_table[bias_index].view(self.max_seq_len, self.max_seq_len, -1)
        relative_bias = relative_bias.permute(2, 0, 1).contiguous()
        return relative_bias.unsqueeze(0)

    def forward(self, x: 'Tensor\n') ->Tensor:
        """
        Args:
            x (Tensor): Input tensor with expected layout of [B, G, P, D].
        Returns:
            Tensor: Output tensor with expected layout of [B, G, P, D].
        """
        B, G, P, D = x.shape
        H, DH = self.n_heads, self.head_dim
        qkv = self.to_qkv(x)
        q, k, v = torch.chunk(qkv, 3, dim=-1)
        q = q.reshape(B, G, P, H, DH).permute(0, 1, 3, 2, 4)
        k = k.reshape(B, G, P, H, DH).permute(0, 1, 3, 2, 4)
        v = v.reshape(B, G, P, H, DH).permute(0, 1, 3, 2, 4)
        k = k * self.scale_factor
        dot_prod = torch.einsum('B G H I D, B G H J D -> B G H I J', q, k)
        pos_bias = self.get_relative_positional_bias()
        dot_prod = F.softmax(dot_prod + pos_bias, dim=-1)
        out = torch.einsum('B G H I J, B G H J D -> B G H I D', dot_prod, v)
        out = out.permute(0, 1, 3, 2, 4).reshape(B, G, P, D)
        out = self.merge(out)
        return out


class SwapAxes(nn.Module):
    """Permute the axes of a tensor."""

    def __init__(self, a: 'int\n', b: 'int\n') ->None:
        super().__init__()
        self.a = a
        self.b = b

    def forward(self, x: 'torch.Tensor\n') ->torch.Tensor:
        res = torch.swapaxes(x, self.a, self.b)
        return res


class WindowPartition(nn.Module):
    """
    Partition the input tensor into non-overlapping windows.
    """

    def __init__(self) ->None:
        super().__init__()

    def forward(self, x: 'Tensor\n', p: 'int\n') ->Tensor:
        """
        Args:
            x (Tensor): Input tensor with expected layout of [B, C, H, W].
            p (int): Number of partitions.
        Returns:
            Tensor: Output tensor with expected layout of [B, H/P, W/P, P*P, C].
        """
        B, C, H, W = x.shape
        P = p
        x = x.reshape(B, C, H // P, P, W // P, P)
        x = x.permute(0, 2, 4, 3, 5, 1)
        x = x.reshape(B, H // P * (W // P), P * P, C)
        return x


class WindowDepartition(nn.Module):
    """
    Departition the input tensor of non-overlapping windows into a feature volume of layout [B, C, H, W].
    """

    def __init__(self) ->None:
        super().__init__()

    def forward(self, x: 'Tensor\n', p: 'int\n', h_partitions: 'int\n', w_partitions: 'int\n') ->Tensor:
        """
        Args:
            x (Tensor): Input tensor with expected layout of [B, (H/P * W/P), P*P, C].
            p (int): Number of partitions.
            h_partitions (int): Number of vertical partitions.
            w_partitions (int): Number of horizontal partitions.
        Returns:
            Tensor: Output tensor with expected layout of [B, C, H, W].
        """
        B, G, PP, C = x.shape
        P = p
        HP, WP = h_partitions, w_partitions
        x = x.reshape(B, HP, WP, P, P, C)
        x = x.permute(0, 5, 1, 3, 2, 4)
        x = x.reshape(B, C, HP * P, WP * P)
        return x


class PartitionAttentionLayer(nn.Module):
    """
    Layer for partitioning the input tensor into non-overlapping windows and applying attention to each window.

    Args:
        in_channels (int): Number of input channels.
        head_dim (int): Dimension of each attention head.
        partition_size (int): Size of the partitions.
        partition_type (str): Type of partitioning to use. Can be either "grid" or "window".
        grid_size (Tuple[int, int]): Size of the grid to partition the input tensor into.
        mlp_ratio (int): Ratio of the  feature size expansion in the MLP layer.
        activation_layer (Callable[..., nn.Module]): Activation function to use.
        norm_layer (Callable[..., nn.Module]): Normalization function to use.
        attention_dropout (float): Dropout probability for the attention layer.
        mlp_dropout (float): Dropout probability for the MLP layer.
        p_stochastic_dropout (float): Probability of dropping out a partition.
    """

    def __init__(self, in_channels: 'int\n', head_dim: 'int\n', partition_size: 'int\n', partition_type: 'str\n', grid_size: 'Tuple[(int, int)]\n', mlp_ratio: 'int\n', activation_layer: 'Callable[(..., nn.Module)]\n', norm_layer: 'Callable[(..., nn.Module)]\n', attention_dropout: 'float\n', mlp_dropout: 'float\n', p_stochastic_dropout: 'float\n') ->None:
        super().__init__()
        self.n_heads = in_channels // head_dim
        self.head_dim = head_dim
        self.n_partitions = grid_size[0] // partition_size
        self.partition_type = partition_type
        self.grid_size = grid_size
        if partition_type not in ['grid', 'window']:
            raise ValueError("partition_type must be either 'grid' or 'window'")
        if partition_type == 'window':
            self.p, self.g = partition_size, self.n_partitions
        else:
            self.p, self.g = self.n_partitions, partition_size
        self.partition_op = WindowPartition()
        self.departition_op = WindowDepartition()
        self.partition_swap = SwapAxes(-2, -3) if partition_type == 'grid' else nn.Identity()
        self.departition_swap = SwapAxes(-2, -3) if partition_type == 'grid' else nn.Identity()
        self.attn_layer = nn.Sequential(norm_layer(in_channels), RelativePositionalMultiHeadAttention(in_channels, head_dim, partition_size ** 2), nn.Dropout(attention_dropout))
        self.mlp_layer = nn.Sequential(nn.LayerNorm(in_channels), nn.Linear(in_channels, in_channels * mlp_ratio), activation_layer(), nn.Linear(in_channels * mlp_ratio, in_channels), nn.Dropout(mlp_dropout))
        self.stochastic_dropout = StochasticDepth(p_stochastic_dropout, mode='row')

    def forward(self, x: 'Tensor\n') ->Tensor:
        """
        Args:
            x (Tensor): Input tensor with expected layout of [B, C, H, W].
        Returns:
            Tensor: Output tensor with expected layout of [B, C, H, W].
        """
        gh, gw = self.grid_size[0] // self.p, self.grid_size[1] // self.p
        torch._assert(self.grid_size[0] % self.p == 0 and self.grid_size[1] % self.p == 0, 'Grid size must be divisible by partition size. Got grid size of {} and partition size of {}'.format(self.grid_size, self.p))
        x = self.partition_op(x, self.p)
        x = self.partition_swap(x)
        x = x + self.stochastic_dropout(self.attn_layer(x))
        x = x + self.stochastic_dropout(self.mlp_layer(x))
        x = self.departition_swap(x)
        x = self.departition_op(x, self.p, gh, gw)
        return x


class MaxVitLayer(nn.Module):
    """
    MaxVit layer consisting of a MBConv layer followed by a PartitionAttentionLayer with `window` and a PartitionAttentionLayer with `grid`.

    Args:
        in_channels (int): Number of input channels.
        out_channels (int): Number of output channels.
        expansion_ratio (float): Expansion ratio in the bottleneck.
        squeeze_ratio (float): Squeeze ratio in the SE Layer.
        stride (int): Stride of the depthwise convolution.
        activation_layer (Callable[..., nn.Module]): Activation function.
        norm_layer (Callable[..., nn.Module]): Normalization function.
        head_dim (int): Dimension of the attention heads.
        mlp_ratio (int): Ratio of the MLP layer.
        mlp_dropout (float): Dropout probability for the MLP layer.
        attention_dropout (float): Dropout probability for the attention layer.
        p_stochastic_dropout (float): Probability of stochastic depth.
        partition_size (int): Size of the partitions.
        grid_size (Tuple[int, int]): Size of the input feature grid.
    """

    def __init__(self, in_channels: 'int\n', out_channels: 'int\n', squeeze_ratio: 'float\n', expansion_ratio: 'float\n', stride: 'int\n', norm_layer: 'Callable[(..., nn.Module)]\n', activation_layer: 'Callable[(..., nn.Module)]\n', head_dim: 'int\n', mlp_ratio: 'int\n', mlp_dropout: 'float\n', attention_dropout: 'float\n', p_stochastic_dropout: 'float\n', partition_size: 'int\n', grid_size: 'Tuple[(int, int)]\n') ->None:
        super().__init__()
        layers: 'OrderedDict\n' = OrderedDict()
        layers['MBconv'] = MBConv(in_channels=in_channels, out_channels=out_channels, expansion_ratio=expansion_ratio, squeeze_ratio=squeeze_ratio, stride=stride, activation_layer=activation_layer, norm_layer=norm_layer, p_stochastic_dropout=p_stochastic_dropout)
        layers['window_attention'] = PartitionAttentionLayer(in_channels=out_channels, head_dim=head_dim, partition_size=partition_size, partition_type='window', grid_size=grid_size, mlp_ratio=mlp_ratio, activation_layer=activation_layer, norm_layer=nn.LayerNorm, attention_dropout=attention_dropout, mlp_dropout=mlp_dropout, p_stochastic_dropout=p_stochastic_dropout)
        layers['grid_attention'] = PartitionAttentionLayer(in_channels=out_channels, head_dim=head_dim, partition_size=partition_size, partition_type='grid', grid_size=grid_size, mlp_ratio=mlp_ratio, activation_layer=activation_layer, norm_layer=nn.LayerNorm, attention_dropout=attention_dropout, mlp_dropout=mlp_dropout, p_stochastic_dropout=p_stochastic_dropout)
        self.layers = nn.Sequential(layers)

    def forward(self, x: 'Tensor\n') ->Tensor:
        """
        Args:
            x (Tensor): Input tensor of shape (B, C, H, W).
        Returns:
            Tensor: Output tensor of shape (B, C, H, W).
        """
        x = self.layers(x)
        return x


def _get_conv_output_shape(input_size: 'Tuple[(int, int)]\n', kernel_size: 'int\n', stride: 'int\n', padding: 'int\n') ->Tuple[int, int]:
    return (input_size[0] - kernel_size + 2 * padding) // stride + 1, (input_size[1] - kernel_size + 2 * padding) // stride + 1


class MaxVitBlock(nn.Module):
    """
    A MaxVit block consisting of `n_layers` MaxVit layers.

     Args:
        in_channels (int): Number of input channels.
        out_channels (int): Number of output channels.
        expansion_ratio (float): Expansion ratio in the bottleneck.
        squeeze_ratio (float): Squeeze ratio in the SE Layer.
        activation_layer (Callable[..., nn.Module]): Activation function.
        norm_layer (Callable[..., nn.Module]): Normalization function.
        head_dim (int): Dimension of the attention heads.
        mlp_ratio (int): Ratio of the MLP layer.
        mlp_dropout (float): Dropout probability for the MLP layer.
        attention_dropout (float): Dropout probability for the attention layer.
        p_stochastic_dropout (float): Probability of stochastic depth.
        partition_size (int): Size of the partitions.
        input_grid_size (Tuple[int, int]): Size of the input feature grid.
        n_layers (int): Number of layers in the block.
        p_stochastic (List[float]): List of probabilities for stochastic depth for each layer.
    """

    def __init__(self, in_channels: 'int\n', out_channels: 'int\n', squeeze_ratio: 'float\n', expansion_ratio: 'float\n', norm_layer: 'Callable[(..., nn.Module)]\n', activation_layer: 'Callable[(..., nn.Module)]\n', head_dim: 'int\n', mlp_ratio: 'int\n', mlp_dropout: 'float\n', attention_dropout: 'float\n', partition_size: 'int\n', input_grid_size: 'Tuple[(int, int)]\n', n_layers: 'int\n', p_stochastic: 'List[float]\n') ->None:
        super().__init__()
        if not len(p_stochastic) == n_layers:
            raise ValueError(f'p_stochastic must have length n_layers={n_layers}, got p_stochastic={p_stochastic}.')
        self.layers = nn.ModuleList()
        self.grid_size = _get_conv_output_shape(input_grid_size, kernel_size=3, stride=2, padding=1)
        for idx, p in enumerate(p_stochastic):
            stride = 2 if idx == 0 else 1
            self.layers += [MaxVitLayer(in_channels=in_channels if idx == 0 else out_channels, out_channels=out_channels, squeeze_ratio=squeeze_ratio, expansion_ratio=expansion_ratio, stride=stride, norm_layer=norm_layer, activation_layer=activation_layer, head_dim=head_dim, mlp_ratio=mlp_ratio, mlp_dropout=mlp_dropout, attention_dropout=attention_dropout, partition_size=partition_size, grid_size=self.grid_size, p_stochastic_dropout=p)]

    def forward(self, x: 'Tensor\n') ->Tensor:
        """
        Args:
            x (Tensor): Input tensor of shape (B, C, H, W).
        Returns:
            Tensor: Output tensor of shape (B, C, H, W).
        """
        for layer in self.layers:
            x = layer(x)
        return x


def _make_block_input_shapes(input_size: 'Tuple[(int, int)]\n', n_blocks: 'int\n') ->List[Tuple[int, int]]:
    """Util function to check that the input size is correct for a MaxVit configuration."""
    shapes = []
    block_input_shape = _get_conv_output_shape(input_size, 3, 2, 1)
    for _ in range(n_blocks):
        block_input_shape = _get_conv_output_shape(block_input_shape, 3, 2, 1)
        shapes.append(block_input_shape)
    return shapes


class MaxVit(nn.Module):
    """
    Implements MaxVit Transformer from the `MaxViT: Multi-Axis Vision Transformer <https://arxiv.org/abs/2204.01697>`_ paper.
    Args:
        input_size (Tuple[int, int]): Size of the input image.
        stem_channels (int): Number of channels in the stem.
        partition_size (int): Size of the partitions.
        block_channels (List[int]): Number of channels in each block.
        block_layers (List[int]): Number of layers in each block.
        stochastic_depth_prob (float): Probability of stochastic depth. Expands to a list of probabilities for each layer that scales linearly to the specified value.
        squeeze_ratio (float): Squeeze ratio in the SE Layer. Default: 0.25.
        expansion_ratio (float): Expansion ratio in the MBConv bottleneck. Default: 4.
        norm_layer (Callable[..., nn.Module]): Normalization function. Default: None (setting to None will produce a `BatchNorm2d(eps=1e-3, momentum=0.99)`).
        activation_layer (Callable[..., nn.Module]): Activation function Default: nn.GELU.
        head_dim (int): Dimension of the attention heads.
        mlp_ratio (int): Expansion ratio of the MLP layer. Default: 4.
        mlp_dropout (float): Dropout probability for the MLP layer. Default: 0.0.
        attention_dropout (float): Dropout probability for the attention layer. Default: 0.0.
        num_classes (int): Number of classes. Default: 1000.
    """

    def __init__(self, input_size: 'Tuple[(int, int)]\n', stem_channels: 'int\n', partition_size: 'int\n', block_channels: 'List[int]\n', block_layers: 'List[int]\n', head_dim: 'int\n', stochastic_depth_prob: 'float\n', norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None, activation_layer: 'Callable[(..., nn.Module)]\n'=nn.GELU, squeeze_ratio: 'float\n'=0.25, expansion_ratio: 'float\n'=4, mlp_ratio: 'int\n'=4, mlp_dropout: 'float\n'=0.0, attention_dropout: 'float\n'=0.0, num_classes: 'int\n'=1000) ->None:
        super().__init__()
        _log_api_usage_once(self)
        input_channels = 3
        if norm_layer is None:
            norm_layer = partial(nn.BatchNorm2d, eps=0.001, momentum=0.99)
        block_input_sizes = _make_block_input_shapes(input_size, len(block_channels))
        for idx, block_input_size in enumerate(block_input_sizes):
            if block_input_size[0] % partition_size != 0 or block_input_size[1] % partition_size != 0:
                raise ValueError(f'Input size {block_input_size} of block {idx} is not divisible by partition size {partition_size}. Consider changing the partition size or the input size.\nCurrent configuration yields the following block input sizes: {block_input_sizes}.')
        self.stem = nn.Sequential(Conv2dNormActivation(input_channels, stem_channels, 3, stride=2, norm_layer=norm_layer, activation_layer=activation_layer, bias=False, inplace=None), Conv2dNormActivation(stem_channels, stem_channels, 3, stride=1, norm_layer=None, activation_layer=None, bias=True))
        input_size = _get_conv_output_shape(input_size, kernel_size=3, stride=2, padding=1)
        self.partition_size = partition_size
        self.blocks = nn.ModuleList()
        in_channels = [stem_channels] + block_channels[:-1]
        out_channels = block_channels
        p_stochastic = np.linspace(0, stochastic_depth_prob, sum(block_layers)).tolist()
        p_idx = 0
        for in_channel, out_channel, num_layers in zip(in_channels, out_channels, block_layers):
            self.blocks.append(MaxVitBlock(in_channels=in_channel, out_channels=out_channel, squeeze_ratio=squeeze_ratio, expansion_ratio=expansion_ratio, norm_layer=norm_layer, activation_layer=activation_layer, head_dim=head_dim, mlp_ratio=mlp_ratio, mlp_dropout=mlp_dropout, attention_dropout=attention_dropout, partition_size=partition_size, input_grid_size=input_size, n_layers=num_layers, p_stochastic=p_stochastic[p_idx:p_idx + num_layers]))
            input_size = self.blocks[-1].grid_size
            p_idx += num_layers
        self.classifier = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.LayerNorm(block_channels[-1]), nn.Linear(block_channels[-1], block_channels[-1]), nn.Tanh(), nn.Linear(block_channels[-1], num_classes, bias=False))
        self._init_weights()

    def forward(self, x: 'Tensor\n') ->Tensor:
        x = self.stem(x)
        for block in self.blocks:
            x = block(x)
        x = self.classifier(x)
        return x

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.normal_(m.weight, std=0.02)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, std=0.02)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)


class _InvertedResidual(nn.Module):

    def __init__(self, in_ch: 'int\n', out_ch: 'int\n', kernel_size: 'int\n', stride: 'int\n', expansion_factor: 'int\n', bn_momentum: 'float\n'=0.1) ->None:
        super().__init__()
        if stride not in [1, 2]:
            raise ValueError(f'stride should be 1 or 2 instead of {stride}')
        if kernel_size not in [3, 5]:
            raise ValueError(f'kernel_size should be 3 or 5 instead of {kernel_size}')
        mid_ch = in_ch * expansion_factor
        self.apply_residual = in_ch == out_ch and stride == 1
        self.layers = nn.Sequential(nn.Conv2d(in_ch, mid_ch, 1, bias=False), nn.BatchNorm2d(mid_ch, momentum=bn_momentum), nn.ReLU(inplace=True), nn.Conv2d(mid_ch, mid_ch, kernel_size, padding=kernel_size // 2, stride=stride, groups=mid_ch, bias=False), nn.BatchNorm2d(mid_ch, momentum=bn_momentum), nn.ReLU(inplace=True), nn.Conv2d(mid_ch, out_ch, 1, bias=False), nn.BatchNorm2d(out_ch, momentum=bn_momentum))

    def forward(self, input: 'Tensor\n') ->Tensor:
        if self.apply_residual:
            return self.layers(input) + input
        else:
            return self.layers(input)


_BN_MOMENTUM = 1 - 0.9997


def _round_to_multiple_of(val: 'float\n', divisor: 'int\n', round_up_bias: 'float\n'=0.9) ->int:
    """Asymmetric rounding to make `val` divisible by `divisor`. With default
    bias, will round up, unless the number is no more than 10% greater than the
    smaller divisible value, i.e. (83, 8) -> 80, but (84, 8) -> 88."""
    if not 0.0 < round_up_bias < 1.0:
        raise ValueError(f'round_up_bias should be greater than 0.0 and smaller than 1.0 instead of {round_up_bias}')
    new_val = max(divisor, int(val + divisor / 2) // divisor * divisor)
    return new_val if new_val >= round_up_bias * val else new_val + divisor


def _get_depths(alpha: 'float\n') ->List[int]:
    """Scales tensor depths as in reference MobileNet code, prefers rounding up
    rather than down."""
    depths = [32, 16, 24, 40, 80, 96, 192, 320]
    return [_round_to_multiple_of(depth * alpha, 8) for depth in depths]


def _stack(in_ch: 'int\n', out_ch: 'int\n', kernel_size: 'int\n', stride: 'int\n', exp_factor: 'int\n', repeats: 'int\n', bn_momentum: 'float\n') ->nn.Sequential:
    """Creates a stack of inverted residuals."""
    if repeats < 1:
        raise ValueError(f'repeats should be >= 1, instead got {repeats}')
    first = _InvertedResidual(in_ch, out_ch, kernel_size, stride, exp_factor, bn_momentum=bn_momentum)
    remaining = []
    for _ in range(1, repeats):
        remaining.append(_InvertedResidual(out_ch, out_ch, kernel_size, 1, exp_factor, bn_momentum=bn_momentum))
    return nn.Sequential(first, *remaining)


class MNASNet(torch.nn.Module):
    """MNASNet, as described in https://arxiv.org/abs/1807.11626. This
    implements the B1 variant of the model.
    >>> model = MNASNet(1.0, num_classes=1000)
    >>> x = torch.rand(1, 3, 224, 224)
    >>> y = model(x)
    >>> y.dim()
    2
    >>> y.nelement()
    1000
    """
    _version = 2

    def __init__(self, alpha: 'float\n', num_classes: 'int\n'=1000, dropout: 'float\n'=0.2) ->None:
        super().__init__()
        _log_api_usage_once(self)
        if alpha <= 0.0:
            raise ValueError(f'alpha should be greater than 0.0 instead of {alpha}')
        self.alpha = alpha
        self.num_classes = num_classes
        depths = _get_depths(alpha)
        layers = [nn.Conv2d(3, depths[0], 3, padding=1, stride=2, bias=False), nn.BatchNorm2d(depths[0], momentum=_BN_MOMENTUM), nn.ReLU(inplace=True), nn.Conv2d(depths[0], depths[0], 3, padding=1, stride=1, groups=depths[0], bias=False), nn.BatchNorm2d(depths[0], momentum=_BN_MOMENTUM), nn.ReLU(inplace=True), nn.Conv2d(depths[0], depths[1], 1, padding=0, stride=1, bias=False), nn.BatchNorm2d(depths[1], momentum=_BN_MOMENTUM), _stack(depths[1], depths[2], 3, 2, 3, 3, _BN_MOMENTUM), _stack(depths[2], depths[3], 5, 2, 3, 3, _BN_MOMENTUM), _stack(depths[3], depths[4], 5, 2, 6, 3, _BN_MOMENTUM), _stack(depths[4], depths[5], 3, 1, 6, 2, _BN_MOMENTUM), _stack(depths[5], depths[6], 5, 2, 6, 4, _BN_MOMENTUM), _stack(depths[6], depths[7], 3, 1, 6, 1, _BN_MOMENTUM), nn.Conv2d(depths[7], 1280, 1, padding=0, stride=1, bias=False), nn.BatchNorm2d(1280, momentum=_BN_MOMENTUM), nn.ReLU(inplace=True)]
        self.layers = nn.Sequential(*layers)
        self.classifier = nn.Sequential(nn.Dropout(p=dropout, inplace=True), nn.Linear(1280, num_classes))
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.kaiming_uniform_(m.weight, mode='fan_out', nonlinearity='sigmoid')
                nn.init.zeros_(m.bias)

    def forward(self, x: 'Tensor\n') ->Tensor:
        x = self.layers(x)
        x = x.mean([2, 3])
        return self.classifier(x)

    def _load_from_state_dict(self, state_dict: 'Dict\n', prefix: 'str\n', local_metadata: 'Dict\n', strict: 'bool\n', missing_keys: 'List[str]\n', unexpected_keys: 'List[str]\n', error_msgs: 'List[str]\n') ->None:
        version = local_metadata.get('version', None)
        if version not in [1, 2]:
            raise ValueError(f'version shluld be set to 1 or 2 instead of {version}')
        if version == 1 and not self.alpha == 1.0:
            depths = _get_depths(self.alpha)
            v1_stem = [nn.Conv2d(3, 32, 3, padding=1, stride=2, bias=False), nn.BatchNorm2d(32, momentum=_BN_MOMENTUM), nn.ReLU(inplace=True), nn.Conv2d(32, 32, 3, padding=1, stride=1, groups=32, bias=False), nn.BatchNorm2d(32, momentum=_BN_MOMENTUM), nn.ReLU(inplace=True), nn.Conv2d(32, 16, 1, padding=0, stride=1, bias=False), nn.BatchNorm2d(16, momentum=_BN_MOMENTUM), _stack(16, depths[2], 3, 2, 3, 3, _BN_MOMENTUM)]
            for idx, layer in enumerate(v1_stem):
                self.layers[idx] = layer
            self._version = 1
            warnings.warn('A new version of MNASNet model has been implemented. Your checkpoint was saved using the previous version. This checkpoint will load and work as before, but you may want to upgrade by training a newer model or transfer learning from an updated ImageNet checkpoint.', UserWarning)
        super()._load_from_state_dict(state_dict, prefix, local_metadata, strict, missing_keys, unexpected_keys, error_msgs)


def channel_shuffle(x: 'Tensor\n', groups: 'int\n') ->Tensor:
    batchsize, num_channels, height, width = x.size()
    channels_per_group = num_channels // groups
    x = x.view(batchsize, groups, channels_per_group, height, width)
    x = torch.transpose(x, 1, 2).contiguous()
    x = x.view(batchsize, num_channels, height, width)
    return x


class InvertedResidual(nn.Module):

    def __init__(self, inp: 'int\n', oup: 'int\n', stride: 'int\n') ->None:
        super().__init__()
        if not 1 <= stride <= 3:
            raise ValueError('illegal stride value')
        self.stride = stride
        branch_features = oup // 2
        if self.stride == 1 and inp != branch_features << 1:
            raise ValueError(f'Invalid combination of stride {stride}, inp {inp} and oup {oup} values. If stride == 1 then inp should be equal to oup // 2 << 1.')
        if self.stride > 1:
            self.branch1 = nn.Sequential(self.depthwise_conv(inp, inp, kernel_size=3, stride=self.stride, padding=1), nn.BatchNorm2d(inp), nn.Conv2d(inp, branch_features, kernel_size=1, stride=1, padding=0, bias=False), nn.BatchNorm2d(branch_features), nn.ReLU(inplace=True))
        else:
            self.branch1 = nn.Sequential()
        self.branch2 = nn.Sequential(nn.Conv2d(inp if self.stride > 1 else branch_features, branch_features, kernel_size=1, stride=1, padding=0, bias=False), nn.BatchNorm2d(branch_features), nn.ReLU(inplace=True), self.depthwise_conv(branch_features, branch_features, kernel_size=3, stride=self.stride, padding=1), nn.BatchNorm2d(branch_features), nn.Conv2d(branch_features, branch_features, kernel_size=1, stride=1, padding=0, bias=False), nn.BatchNorm2d(branch_features), nn.ReLU(inplace=True))

    @staticmethod
    def depthwise_conv(i: 'int\n', o: 'int\n', kernel_size: 'int\n', stride: 'int\n'=1, padding: 'int\n'=0, bias: 'bool\n'=False) ->nn.Conv2d:
        return nn.Conv2d(i, o, kernel_size, stride, padding, bias=bias, groups=i)

    def forward(self, x: 'Tensor\n') ->Tensor:
        if self.stride == 1:
            x1, x2 = x.chunk(2, dim=1)
            out = torch.cat((x1, self.branch2(x2)), dim=1)
        else:
            out = torch.cat((self.branch1(x), self.branch2(x)), dim=1)
        out = channel_shuffle(out, 2)
        return out


class MobileNetV2(nn.Module):

    def __init__(self, num_classes: 'int\n'=1000, width_mult: 'float\n'=1.0, inverted_residual_setting: 'Optional[List[List[int]]]\n'=None, round_nearest: 'int\n'=8, block: 'Optional[Callable[(..., nn.Module)]]\n'=None, norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None, dropout: 'float\n'=0.2) ->None:
        """
        MobileNet V2 main class

        Args:
            num_classes (int): Number of classes
            width_mult (float): Width multiplier - adjusts number of channels in each layer by this amount
            inverted_residual_setting: Network structure
            round_nearest (int): Round the number of channels in each layer to be a multiple of this number
            Set to 1 to turn off rounding
            block: Module specifying inverted residual building block for mobilenet
            norm_layer: Module specifying the normalization layer to use
            dropout (float): The droupout probability

        """
        super().__init__()
        _log_api_usage_once(self)
        if block is None:
            block = InvertedResidual
        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        input_channel = 32
        last_channel = 1280
        if inverted_residual_setting is None:
            inverted_residual_setting = [[1, 16, 1, 1], [6, 24, 2, 2], [6, 32, 3, 2], [6, 64, 4, 2], [6, 96, 3, 1], [6, 160, 3, 2], [6, 320, 1, 1]]
        if len(inverted_residual_setting) == 0 or len(inverted_residual_setting[0]) != 4:
            raise ValueError(f'inverted_residual_setting should be non-empty or a 4-element list, got {inverted_residual_setting}')
        input_channel = _make_divisible(input_channel * width_mult, round_nearest)
        self.last_channel = _make_divisible(last_channel * max(1.0, width_mult), round_nearest)
        features: 'List[nn.Module]\n' = [Conv2dNormActivation(3, input_channel, stride=2, norm_layer=norm_layer, activation_layer=nn.ReLU6)]
        for t, c, n, s in inverted_residual_setting:
            output_channel = _make_divisible(c * width_mult, round_nearest)
            for i in range(n):
                stride = s if i == 0 else 1
                features.append(block(input_channel, output_channel, stride, expand_ratio=t, norm_layer=norm_layer))
                input_channel = output_channel
        features.append(Conv2dNormActivation(input_channel, self.last_channel, kernel_size=1, norm_layer=norm_layer, activation_layer=nn.ReLU6))
        self.features = nn.Sequential(*features)
        self.classifier = nn.Sequential(nn.Dropout(p=dropout), nn.Linear(self.last_channel, num_classes))
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, (nn.BatchNorm2d, nn.GroupNorm)):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.zeros_(m.bias)

    def _forward_impl(self, x: 'Tensor\n') ->Tensor:
        x = self.features(x)
        x = nn.functional.adaptive_avg_pool2d(x, (1, 1))
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x

    def forward(self, x: 'Tensor\n') ->Tensor:
        return self._forward_impl(x)


class InvertedResidualConfig:

    def __init__(self, input_channels: 'int\n', kernel: 'int\n', expanded_channels: 'int\n', out_channels: 'int\n', use_se: 'bool\n', activation: 'str\n', stride: 'int\n', dilation: 'int\n', width_mult: 'float\n'):
        self.input_channels = self.adjust_channels(input_channels, width_mult)
        self.kernel = kernel
        self.expanded_channels = self.adjust_channels(expanded_channels, width_mult)
        self.out_channels = self.adjust_channels(out_channels, width_mult)
        self.use_se = use_se
        self.use_hs = activation == 'HS'
        self.stride = stride
        self.dilation = dilation

    @staticmethod
    def adjust_channels(channels: 'int\n', width_mult: 'float\n'):
        return _make_divisible(channels * width_mult, 8)


class MobileNetV3(nn.Module):

    def __init__(self, inverted_residual_setting: 'List[InvertedResidualConfig]\n', last_channel: 'int\n', num_classes: 'int\n'=1000, block: 'Optional[Callable[(..., nn.Module)]]\n'=None, norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None, dropout: 'float\n'=0.2, **kwargs: Any) ->None:
        """
        MobileNet V3 main class

        Args:
            inverted_residual_setting (List[InvertedResidualConfig]): Network structure
            last_channel (int): The number of channels on the penultimate layer
            num_classes (int): Number of classes
            block (Optional[Callable[..., nn.Module]]): Module specifying inverted residual building block for mobilenet
            norm_layer (Optional[Callable[..., nn.Module]]): Module specifying the normalization layer to use
            dropout (float): The droupout probability
        """
        super().__init__()
        _log_api_usage_once(self)
        if not inverted_residual_setting:
            raise ValueError('The inverted_residual_setting should not be empty')
        elif not (isinstance(inverted_residual_setting, Sequence) and all([isinstance(s, InvertedResidualConfig) for s in inverted_residual_setting])):
            raise TypeError('The inverted_residual_setting should be List[InvertedResidualConfig]')
        if block is None:
            block = InvertedResidual
        if norm_layer is None:
            norm_layer = partial(nn.BatchNorm2d, eps=0.001, momentum=0.01)
        layers: 'List[nn.Module]\n' = []
        firstconv_output_channels = inverted_residual_setting[0].input_channels
        layers.append(Conv2dNormActivation(3, firstconv_output_channels, kernel_size=3, stride=2, norm_layer=norm_layer, activation_layer=nn.Hardswish))
        for cnf in inverted_residual_setting:
            layers.append(block(cnf, norm_layer))
        lastconv_input_channels = inverted_residual_setting[-1].out_channels
        lastconv_output_channels = 6 * lastconv_input_channels
        layers.append(Conv2dNormActivation(lastconv_input_channels, lastconv_output_channels, kernel_size=1, norm_layer=norm_layer, activation_layer=nn.Hardswish))
        self.features = nn.Sequential(*layers)
        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.classifier = nn.Sequential(nn.Linear(lastconv_output_channels, last_channel), nn.Hardswish(inplace=True), nn.Dropout(p=dropout, inplace=True), nn.Linear(last_channel, num_classes))
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, (nn.BatchNorm2d, nn.GroupNorm)):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.zeros_(m.bias)

    def _forward_impl(self, x: 'Tensor\n') ->Tensor:
        x = self.features(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x

    def forward(self, x: 'Tensor\n') ->Tensor:
        return self._forward_impl(x)


class BottleneckTransform(nn.Sequential):
    """Bottleneck transformation: 1x1, 3x3 [+SE], 1x1."""

    def __init__(self, width_in: 'int\n', width_out: 'int\n', stride: 'int\n', norm_layer: 'Callable[(..., nn.Module)]\n', activation_layer: 'Callable[(..., nn.Module)]\n', group_width: 'int\n', bottleneck_multiplier: 'float\n', se_ratio: 'Optional[float]\n') ->None:
        layers: 'OrderedDict[(str, nn.Module)]\n' = OrderedDict()
        w_b = int(round(width_out * bottleneck_multiplier))
        g = w_b // group_width
        layers['a'] = Conv2dNormActivation(width_in, w_b, kernel_size=1, stride=1, norm_layer=norm_layer, activation_layer=activation_layer)
        layers['b'] = Conv2dNormActivation(w_b, w_b, kernel_size=3, stride=stride, groups=g, norm_layer=norm_layer, activation_layer=activation_layer)
        if se_ratio:
            width_se_out = int(round(se_ratio * width_in))
            layers['se'] = SqueezeExcitation(input_channels=w_b, squeeze_channels=width_se_out, activation=activation_layer)
        layers['c'] = Conv2dNormActivation(w_b, width_out, kernel_size=1, stride=1, norm_layer=norm_layer, activation_layer=None)
        super().__init__(layers)


class ResBottleneckBlock(nn.Module):
    """Residual bottleneck block: x + F(x), F = bottleneck transform."""

    def __init__(self, width_in: 'int\n', width_out: 'int\n', stride: 'int\n', norm_layer: 'Callable[(..., nn.Module)]\n', activation_layer: 'Callable[(..., nn.Module)]\n', group_width: 'int\n'=1, bottleneck_multiplier: 'float\n'=1.0, se_ratio: 'Optional[float]\n'=None) ->None:
        super().__init__()
        self.proj = None
        should_proj = width_in != width_out or stride != 1
        if should_proj:
            self.proj = Conv2dNormActivation(width_in, width_out, kernel_size=1, stride=stride, norm_layer=norm_layer, activation_layer=None)
        self.f = BottleneckTransform(width_in, width_out, stride, norm_layer, activation_layer, group_width, bottleneck_multiplier, se_ratio)
        self.activation = activation_layer(inplace=True)

    def forward(self, x: 'Tensor\n') ->Tensor:
        if self.proj is not None:
            x = self.proj(x) + self.f(x)
        else:
            x = x + self.f(x)
        return self.activation(x)


class AnyStage(nn.Sequential):
    """AnyNet stage (sequence of blocks w/ the same output shape)."""

    def __init__(self, width_in: 'int\n', width_out: 'int\n', stride: 'int\n', depth: 'int\n', block_constructor: 'Callable[(..., nn.Module)]\n', norm_layer: 'Callable[(..., nn.Module)]\n', activation_layer: 'Callable[(..., nn.Module)]\n', group_width: 'int\n', bottleneck_multiplier: 'float\n', se_ratio: 'Optional[float]\n'=None, stage_index: 'int\n'=0) ->None:
        super().__init__()
        for i in range(depth):
            block = block_constructor(width_in if i == 0 else width_out, width_out, stride if i == 0 else 1, norm_layer, activation_layer, group_width, bottleneck_multiplier, se_ratio)
            self.add_module(f'block{stage_index}-{i}', block)


class SimpleStemIN(Conv2dNormActivation):
    """Simple stem for ImageNet: 3x3, BN, ReLU."""

    def __init__(self, width_in: 'int\n', width_out: 'int\n', norm_layer: 'Callable[(..., nn.Module)]\n', activation_layer: 'Callable[(..., nn.Module)]\n') ->None:
        super().__init__(width_in, width_out, kernel_size=3, stride=2, norm_layer=norm_layer, activation_layer=activation_layer)


class RegNet(nn.Module):

    def __init__(self, block_params: 'BlockParams\n', num_classes: 'int\n'=1000, stem_width: 'int\n'=32, stem_type: 'Optional[Callable[(..., nn.Module)]]\n'=None, block_type: 'Optional[Callable[(..., nn.Module)]]\n'=None, norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None, activation: 'Optional[Callable[(..., nn.Module)]]\n'=None) ->None:
        super().__init__()
        _log_api_usage_once(self)
        if stem_type is None:
            stem_type = SimpleStemIN
        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        if block_type is None:
            block_type = ResBottleneckBlock
        if activation is None:
            activation = nn.ReLU
        self.stem = stem_type(3, stem_width, norm_layer, activation)
        current_width = stem_width
        blocks = []
        for i, (width_out, stride, depth, group_width, bottleneck_multiplier) in enumerate(block_params._get_expanded_params()):
            blocks.append((f'block{i + 1}', AnyStage(current_width, width_out, stride, depth, block_type, norm_layer, activation, group_width, bottleneck_multiplier, block_params.se_ratio, stage_index=i + 1)))
            current_width = width_out
        self.trunk_output = nn.Sequential(OrderedDict(blocks))
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(in_features=current_width, out_features=num_classes)
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                nn.init.normal_(m.weight, mean=0.0, std=math.sqrt(2.0 / fan_out))
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, mean=0.0, std=0.01)
                nn.init.zeros_(m.bias)

    def forward(self, x: 'Tensor\n') ->Tensor:
        x = self.stem(x)
        x = self.trunk_output(x)
        x = self.avgpool(x)
        x = x.flatten(start_dim=1)
        x = self.fc(x)
        return x


class ResNet(nn.Module):

    def __init__(self, block: 'Type[Union[(BasicBlock, Bottleneck)]]\n', layers: 'List[int]\n', num_classes: 'int\n'=1000, zero_init_residual: 'bool\n'=False, groups: 'int\n'=1, width_per_group: 'int\n'=64, replace_stride_with_dilation: 'Optional[List[bool]]\n'=None, norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None) ->None:
        super().__init__()
        _log_api_usage_once(self)
        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        self._norm_layer = norm_layer
        self.inplanes = 64
        self.dilation = 1
        if replace_stride_with_dilation is None:
            replace_stride_with_dilation = [False, False, False]
        if len(replace_stride_with_dilation) != 3:
            raise ValueError(f'replace_stride_with_dilation should be None or a 3-element tuple, got {replace_stride_with_dilation}')
        self.groups = groups
        self.base_width = width_per_group
        self.conv1 = nn.Conv2d(3, self.inplanes, kernel_size=7, stride=2, padding=3, bias=False)
        self.bn1 = norm_layer(self.inplanes)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.layer1 = self._make_layer(block, 64, layers[0])
        self.layer2 = self._make_layer(block, 128, layers[1], stride=2, dilate=replace_stride_with_dilation[0])
        self.layer3 = self._make_layer(block, 256, layers[2], stride=2, dilate=replace_stride_with_dilation[1])
        self.layer4 = self._make_layer(block, 512, layers[3], stride=2, dilate=replace_stride_with_dilation[2])
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(512 * block.expansion, num_classes)
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, (nn.BatchNorm2d, nn.GroupNorm)):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
        if zero_init_residual:
            for m in self.modules():
                if isinstance(m, Bottleneck) and m.bn3.weight is not None:
                    nn.init.constant_(m.bn3.weight, 0)
                elif isinstance(m, BasicBlock) and m.bn2.weight is not None:
                    nn.init.constant_(m.bn2.weight, 0)

    def _make_layer(self, block: 'Type[Union[(BasicBlock, Bottleneck)]]\n', planes: 'int\n', blocks: 'int\n', stride: 'int\n'=1, dilate: 'bool\n'=False) ->nn.Sequential:
        norm_layer = self._norm_layer
        downsample = None
        previous_dilation = self.dilation
        if dilate:
            self.dilation *= stride
            stride = 1
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(conv1x1(self.inplanes, planes * block.expansion, stride), norm_layer(planes * block.expansion))
        layers = []
        layers.append(block(self.inplanes, planes, stride, downsample, self.groups, self.base_width, previous_dilation, norm_layer))
        self.inplanes = planes * block.expansion
        for _ in range(1, blocks):
            layers.append(block(self.inplanes, planes, groups=self.groups, base_width=self.base_width, dilation=self.dilation, norm_layer=norm_layer))
        return nn.Sequential(*layers)

    def _forward_impl(self, x: 'Tensor\n') ->Tensor:
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)
        return x

    def forward(self, x: 'Tensor\n') ->Tensor:
        return self._forward_impl(x)


class ShuffleNetV2(nn.Module):

    def __init__(self, stages_repeats: 'List[int]\n', stages_out_channels: 'List[int]\n', num_classes: 'int\n'=1000, inverted_residual: 'Callable[(..., nn.Module)]\n'=InvertedResidual) ->None:
        super().__init__()
        _log_api_usage_once(self)
        if len(stages_repeats) != 3:
            raise ValueError('expected stages_repeats as list of 3 positive ints')
        if len(stages_out_channels) != 5:
            raise ValueError('expected stages_out_channels as list of 5 positive ints')
        self._stage_out_channels = stages_out_channels
        input_channels = 3
        output_channels = self._stage_out_channels[0]
        self.conv1 = nn.Sequential(nn.Conv2d(input_channels, output_channels, 3, 2, 1, bias=False), nn.BatchNorm2d(output_channels), nn.ReLU(inplace=True))
        input_channels = output_channels
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.stage2: 'nn.Sequential\n'
        self.stage3: 'nn.Sequential\n'
        self.stage4: 'nn.Sequential\n'
        stage_names = [f'stage{i}' for i in [2, 3, 4]]
        for name, repeats, output_channels in zip(stage_names, stages_repeats, self._stage_out_channels[1:]):
            seq = [inverted_residual(input_channels, output_channels, 2)]
            for i in range(repeats - 1):
                seq.append(inverted_residual(output_channels, output_channels, 1))
            setattr(self, name, nn.Sequential(*seq))
            input_channels = output_channels
        output_channels = self._stage_out_channels[-1]
        self.conv5 = nn.Sequential(nn.Conv2d(input_channels, output_channels, 1, 1, 0, bias=False), nn.BatchNorm2d(output_channels), nn.ReLU(inplace=True))
        self.fc = nn.Linear(output_channels, num_classes)

    def _forward_impl(self, x: 'Tensor\n') ->Tensor:
        x = self.conv1(x)
        x = self.maxpool(x)
        x = self.stage2(x)
        x = self.stage3(x)
        x = self.stage4(x)
        x = self.conv5(x)
        x = x.mean([2, 3])
        x = self.fc(x)
        return x

    def forward(self, x: 'Tensor\n') ->Tensor:
        return self._forward_impl(x)


class Fire(nn.Module):

    def __init__(self, inplanes: 'int\n', squeeze_planes: 'int\n', expand1x1_planes: 'int\n', expand3x3_planes: 'int\n') ->None:
        super().__init__()
        self.inplanes = inplanes
        self.squeeze = nn.Conv2d(inplanes, squeeze_planes, kernel_size=1)
        self.squeeze_activation = nn.ReLU(inplace=True)
        self.expand1x1 = nn.Conv2d(squeeze_planes, expand1x1_planes, kernel_size=1)
        self.expand1x1_activation = nn.ReLU(inplace=True)
        self.expand3x3 = nn.Conv2d(squeeze_planes, expand3x3_planes, kernel_size=3, padding=1)
        self.expand3x3_activation = nn.ReLU(inplace=True)

    def forward(self, x: 'torch.Tensor\n') ->torch.Tensor:
        x = self.squeeze_activation(self.squeeze(x))
        return torch.cat([self.expand1x1_activation(self.expand1x1(x)), self.expand3x3_activation(self.expand3x3(x))], 1)


class SqueezeNet(nn.Module):

    def __init__(self, version: 'str\n'='1_0', num_classes: 'int\n'=1000, dropout: 'float\n'=0.5) ->None:
        super().__init__()
        _log_api_usage_once(self)
        self.num_classes = num_classes
        if version == '1_0':
            self.features = nn.Sequential(nn.Conv2d(3, 96, kernel_size=7, stride=2), nn.ReLU(inplace=True), nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True), Fire(96, 16, 64, 64), Fire(128, 16, 64, 64), Fire(128, 32, 128, 128), nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True), Fire(256, 32, 128, 128), Fire(256, 48, 192, 192), Fire(384, 48, 192, 192), Fire(384, 64, 256, 256), nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True), Fire(512, 64, 256, 256))
        elif version == '1_1':
            self.features = nn.Sequential(nn.Conv2d(3, 64, kernel_size=3, stride=2), nn.ReLU(inplace=True), nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True), Fire(64, 16, 64, 64), Fire(128, 16, 64, 64), nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True), Fire(128, 32, 128, 128), Fire(256, 32, 128, 128), nn.MaxPool2d(kernel_size=3, stride=2, ceil_mode=True), Fire(256, 48, 192, 192), Fire(384, 48, 192, 192), Fire(384, 64, 256, 256), Fire(512, 64, 256, 256))
        else:
            raise ValueError(f'Unsupported SqueezeNet version {version}: 1_0 or 1_1 expected')
        final_conv = nn.Conv2d(512, self.num_classes, kernel_size=1)
        self.classifier = nn.Sequential(nn.Dropout(p=dropout), final_conv, nn.ReLU(inplace=True), nn.AdaptiveAvgPool2d((1, 1)))
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                if m is final_conv:
                    init.normal_(m.weight, mean=0.0, std=0.01)
                else:
                    init.kaiming_uniform_(m.weight)
                if m.bias is not None:
                    init.constant_(m.bias, 0)

    def forward(self, x: 'torch.Tensor\n') ->torch.Tensor:
        x = self.features(x)
        x = self.classifier(x)
        return torch.flatten(x, 1)


class PatchMergingV2(nn.Module):
    """Patch Merging Layer for Swin Transformer V2.
    Args:
        dim (int): Number of input channels.
        norm_layer (nn.Module): Normalization layer. Default: nn.LayerNorm.
    """

    def __init__(self, dim: 'int\n', norm_layer: 'Callable[(..., nn.Module)]\n'=nn.LayerNorm):
        super().__init__()
        _log_api_usage_once(self)
        self.dim = dim
        self.reduction = nn.Linear(4 * dim, 2 * dim, bias=False)
        self.norm = norm_layer(2 * dim)

    def forward(self, x: 'Tensor\n'):
        """
        Args:
            x (Tensor): input tensor with expected layout of [..., H, W, C]
        Returns:
            Tensor with layout of [..., H/2, W/2, 2*C]
        """
        x = _patch_merging_pad(x)
        x = self.reduction(x)
        x = self.norm(x)
        return x


class ShiftedWindowAttentionV2(ShiftedWindowAttention):
    """
    See :func:`shifted_window_attention_v2`.
    """

    def __init__(self, dim: 'int\n', window_size: 'List[int]\n', shift_size: 'List[int]\n', num_heads: 'int\n', qkv_bias: 'bool\n'=True, proj_bias: 'bool\n'=True, attention_dropout: 'float\n'=0.0, dropout: 'float\n'=0.0):
        super().__init__(dim, window_size, shift_size, num_heads, qkv_bias=qkv_bias, proj_bias=proj_bias, attention_dropout=attention_dropout, dropout=dropout)
        self.logit_scale = nn.Parameter(torch.log(10 * torch.ones((num_heads, 1, 1))))
        self.cpb_mlp = nn.Sequential(nn.Linear(2, 512, bias=True), nn.ReLU(inplace=True), nn.Linear(512, num_heads, bias=False))
        if qkv_bias:
            length = self.qkv.bias.numel() // 3
            self.qkv.bias[length:2 * length].data.zero_()

    def define_relative_position_bias_table(self):
        relative_coords_h = torch.arange(-(self.window_size[0] - 1), self.window_size[0], dtype=torch.float32)
        relative_coords_w = torch.arange(-(self.window_size[1] - 1), self.window_size[1], dtype=torch.float32)
        relative_coords_table = torch.stack(torch.meshgrid([relative_coords_h, relative_coords_w], indexing='ij'))
        relative_coords_table = relative_coords_table.permute(1, 2, 0).contiguous().unsqueeze(0)
        relative_coords_table[:, :, :, (0)] /= self.window_size[0] - 1
        relative_coords_table[:, :, :, (1)] /= self.window_size[1] - 1
        relative_coords_table *= 8
        relative_coords_table = torch.sign(relative_coords_table) * torch.log2(torch.abs(relative_coords_table) + 1.0) / 3.0
        self.register_buffer('relative_coords_table', relative_coords_table)

    def get_relative_position_bias(self) ->torch.Tensor:
        relative_position_bias = _get_relative_position_bias(self.cpb_mlp(self.relative_coords_table).view(-1, self.num_heads), self.relative_position_index, self.window_size)
        relative_position_bias = 16 * torch.sigmoid(relative_position_bias)
        return relative_position_bias

    def forward(self, x: 'Tensor\n'):
        """
        Args:
            x (Tensor): Tensor with layout of [B, H, W, C]
        Returns:
            Tensor with same layout as input, i.e. [B, H, W, C]
        """
        relative_position_bias = self.get_relative_position_bias()
        return shifted_window_attention(x, self.qkv.weight, self.proj.weight, relative_position_bias, self.window_size, self.num_heads, shift_size=self.shift_size, attention_dropout=self.attention_dropout, dropout=self.dropout, qkv_bias=self.qkv.bias, proj_bias=self.proj.bias, logit_scale=self.logit_scale, training=self.training)


class SwinTransformerBlockV2(SwinTransformerBlock):
    """
    Swin Transformer V2 Block.
    Args:
        dim (int): Number of input channels.
        num_heads (int): Number of attention heads.
        window_size (List[int]): Window size.
        shift_size (List[int]): Shift size for shifted window attention.
        mlp_ratio (float): Ratio of mlp hidden dim to embedding dim. Default: 4.0.
        dropout (float): Dropout rate. Default: 0.0.
        attention_dropout (float): Attention dropout rate. Default: 0.0.
        stochastic_depth_prob: (float): Stochastic depth rate. Default: 0.0.
        norm_layer (nn.Module): Normalization layer.  Default: nn.LayerNorm.
        attn_layer (nn.Module): Attention layer. Default: ShiftedWindowAttentionV2.
    """

    def __init__(self, dim: 'int\n', num_heads: 'int\n', window_size: 'List[int]\n', shift_size: 'List[int]\n', mlp_ratio: 'float\n'=4.0, dropout: 'float\n'=0.0, attention_dropout: 'float\n'=0.0, stochastic_depth_prob: 'float\n'=0.0, norm_layer: 'Callable[(..., nn.Module)]\n'=nn.LayerNorm, attn_layer: 'Callable[(..., nn.Module)]\n'=ShiftedWindowAttentionV2):
        super().__init__(dim, num_heads, window_size, shift_size, mlp_ratio=mlp_ratio, dropout=dropout, attention_dropout=attention_dropout, stochastic_depth_prob=stochastic_depth_prob, norm_layer=norm_layer, attn_layer=attn_layer)

    def forward(self, x: 'Tensor\n'):
        x = x + self.stochastic_depth(self.norm1(self.attn(x)))
        x = x + self.stochastic_depth(self.norm2(self.mlp(x)))
        return x


class SwinTransformer(nn.Module):
    """
    Implements Swin Transformer from the `"Swin Transformer: Hierarchical Vision Transformer using
    Shifted Windows" <https://arxiv.org/abs/2103.14030>`_ paper.
    Args:
        patch_size (List[int]): Patch size.
        embed_dim (int): Patch embedding dimension.
        depths (List(int)): Depth of each Swin Transformer layer.
        num_heads (List(int)): Number of attention heads in different layers.
        window_size (List[int]): Window size.
        mlp_ratio (float): Ratio of mlp hidden dim to embedding dim. Default: 4.0.
        dropout (float): Dropout rate. Default: 0.0.
        attention_dropout (float): Attention dropout rate. Default: 0.0.
        stochastic_depth_prob (float): Stochastic depth rate. Default: 0.1.
        num_classes (int): Number of classes for classification head. Default: 1000.
        block (nn.Module, optional): SwinTransformer Block. Default: None.
        norm_layer (nn.Module, optional): Normalization layer. Default: None.
        downsample_layer (nn.Module): Downsample layer (patch merging). Default: PatchMerging.
    """

    def __init__(self, patch_size: 'List[int]\n', embed_dim: 'int\n', depths: 'List[int]\n', num_heads: 'List[int]\n', window_size: 'List[int]\n', mlp_ratio: 'float\n'=4.0, dropout: 'float\n'=0.0, attention_dropout: 'float\n'=0.0, stochastic_depth_prob: 'float\n'=0.1, num_classes: 'int\n'=1000, norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None, block: 'Optional[Callable[(..., nn.Module)]]\n'=None, downsample_layer: 'Callable[(..., nn.Module)]\n'=PatchMerging):
        super().__init__()
        _log_api_usage_once(self)
        self.num_classes = num_classes
        if block is None:
            block = SwinTransformerBlock
        if norm_layer is None:
            norm_layer = partial(nn.LayerNorm, eps=1e-05)
        layers: 'List[nn.Module]\n' = []
        layers.append(nn.Sequential(nn.Conv2d(3, embed_dim, kernel_size=(patch_size[0], patch_size[1]), stride=(patch_size[0], patch_size[1])), Permute([0, 2, 3, 1]), norm_layer(embed_dim)))
        total_stage_blocks = sum(depths)
        stage_block_id = 0
        for i_stage in range(len(depths)):
            stage: 'List[nn.Module]\n' = []
            dim = embed_dim * 2 ** i_stage
            for i_layer in range(depths[i_stage]):
                sd_prob = stochastic_depth_prob * float(stage_block_id) / (total_stage_blocks - 1)
                stage.append(block(dim, num_heads[i_stage], window_size=window_size, shift_size=[(0 if i_layer % 2 == 0 else w // 2) for w in window_size], mlp_ratio=mlp_ratio, dropout=dropout, attention_dropout=attention_dropout, stochastic_depth_prob=sd_prob, norm_layer=norm_layer))
                stage_block_id += 1
            layers.append(nn.Sequential(*stage))
            if i_stage < len(depths) - 1:
                layers.append(downsample_layer(dim, norm_layer))
        self.features = nn.Sequential(*layers)
        num_features = embed_dim * 2 ** (len(depths) - 1)
        self.norm = norm_layer(num_features)
        self.permute = Permute([0, 3, 1, 2])
        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.flatten = nn.Flatten(1)
        self.head = nn.Linear(num_features, num_classes)
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.trunc_normal_(m.weight, std=0.02)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x):
        x = self.features(x)
        x = self.norm(x)
        x = self.permute(x)
        x = self.avgpool(x)
        x = self.flatten(x)
        x = self.head(x)
        return x


class VGG(nn.Module):

    def __init__(self, features: 'nn.Module\n', num_classes: 'int\n'=1000, init_weights: 'bool\n'=True, dropout: 'float\n'=0.5) ->None:
        super().__init__()
        _log_api_usage_once(self)
        self.features = features
        self.avgpool = nn.AdaptiveAvgPool2d((7, 7))
        self.classifier = nn.Sequential(nn.Linear(512 * 7 * 7, 4096), nn.ReLU(True), nn.Dropout(p=dropout), nn.Linear(4096, 4096), nn.ReLU(True), nn.Dropout(p=dropout), nn.Linear(4096, num_classes))
        if init_weights:
            for m in self.modules():
                if isinstance(m, nn.Conv2d):
                    nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                    if m.bias is not None:
                        nn.init.constant_(m.bias, 0)
                elif isinstance(m, nn.BatchNorm2d):
                    nn.init.constant_(m.weight, 1)
                    nn.init.constant_(m.bias, 0)
                elif isinstance(m, nn.Linear):
                    nn.init.normal_(m.weight, 0, 0.01)
                    nn.init.constant_(m.bias, 0)

    def forward(self, x: 'torch.Tensor\n') ->torch.Tensor:
        x = self.features(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x


class MLPBlock(MLP):
    """Transformer MLP block."""
    _version = 2

    def __init__(self, in_dim: 'int\n', mlp_dim: 'int\n', dropout: 'float\n'):
        super().__init__(in_dim, [mlp_dim, in_dim], activation_layer=nn.GELU, inplace=None, dropout=dropout)
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.normal_(m.bias, std=1e-06)

    def _load_from_state_dict(self, state_dict, prefix, local_metadata, strict, missing_keys, unexpected_keys, error_msgs):
        version = local_metadata.get('version', None)
        if version is None or version < 2:
            for i in range(2):
                for type in ['weight', 'bias']:
                    old_key = f'{prefix}linear_{i + 1}.{type}'
                    new_key = f'{prefix}{3 * i}.{type}'
                    if old_key in state_dict:
                        state_dict[new_key] = state_dict.pop(old_key)
        super()._load_from_state_dict(state_dict, prefix, local_metadata, strict, missing_keys, unexpected_keys, error_msgs)


class EncoderBlock(nn.Module):
    """Transformer encoder block."""

    def __init__(self, num_heads: 'int\n', hidden_dim: 'int\n', mlp_dim: 'int\n', dropout: 'float\n', attention_dropout: 'float\n', norm_layer: 'Callable[(..., torch.nn.Module)]\n'=partial(nn.LayerNorm, eps=1e-06)):
        super().__init__()
        self.num_heads = num_heads
        self.ln_1 = norm_layer(hidden_dim)
        self.self_attention = nn.MultiheadAttention(hidden_dim, num_heads, dropout=attention_dropout, batch_first=True)
        self.dropout = nn.Dropout(dropout)
        self.ln_2 = norm_layer(hidden_dim)
        self.mlp = MLPBlock(hidden_dim, mlp_dim, dropout)

    def forward(self, input: 'torch.Tensor\n'):
        torch._assert(input.dim() == 3, f'Expected (batch_size, seq_length, hidden_dim) got {input.shape}')
        x = self.ln_1(input)
        x, _ = self.self_attention(x, x, x, need_weights=False)
        x = self.dropout(x)
        x = x + input
        y = self.ln_2(x)
        y = self.mlp(y)
        return x + y


class Encoder(nn.Module):
    """Transformer Model Encoder for sequence to sequence translation."""

    def __init__(self, seq_length: 'int\n', num_layers: 'int\n', num_heads: 'int\n', hidden_dim: 'int\n', mlp_dim: 'int\n', dropout: 'float\n', attention_dropout: 'float\n', norm_layer: 'Callable[(..., torch.nn.Module)]\n'=partial(nn.LayerNorm, eps=1e-06)):
        super().__init__()
        self.pos_embedding = nn.Parameter(torch.empty(1, seq_length, hidden_dim).normal_(std=0.02))
        self.dropout = nn.Dropout(dropout)
        layers: 'OrderedDict[(str, nn.Module)]\n' = OrderedDict()
        for i in range(num_layers):
            layers[f'encoder_layer_{i}'] = EncoderBlock(num_heads, hidden_dim, mlp_dim, dropout, attention_dropout, norm_layer)
        self.layers = nn.Sequential(layers)
        self.ln = norm_layer(hidden_dim)

    def forward(self, input: 'torch.Tensor\n'):
        torch._assert(input.dim() == 3, f'Expected (batch_size, seq_length, hidden_dim) got {input.shape}')
        input = input + self.pos_embedding
        return self.ln(self.layers(self.dropout(input)))


class VisionTransformer(nn.Module):
    """Vision Transformer as per https://arxiv.org/abs/2010.11929."""

    def __init__(self, image_size: 'int\n', patch_size: 'int\n', num_layers: 'int\n', num_heads: 'int\n', hidden_dim: 'int\n', mlp_dim: 'int\n', dropout: 'float\n'=0.0, attention_dropout: 'float\n'=0.0, num_classes: 'int\n'=1000, representation_size: 'Optional[int]\n'=None, norm_layer: 'Callable[(..., torch.nn.Module)]\n'=partial(nn.LayerNorm, eps=1e-06), conv_stem_configs: 'Optional[List[ConvStemConfig]]\n'=None):
        super().__init__()
        _log_api_usage_once(self)
        torch._assert(image_size % patch_size == 0, 'Input shape indivisible by patch size!')
        self.image_size = image_size
        self.patch_size = patch_size
        self.hidden_dim = hidden_dim
        self.mlp_dim = mlp_dim
        self.attention_dropout = attention_dropout
        self.dropout = dropout
        self.num_classes = num_classes
        self.representation_size = representation_size
        self.norm_layer = norm_layer
        if conv_stem_configs is not None:
            seq_proj = nn.Sequential()
            prev_channels = 3
            for i, conv_stem_layer_config in enumerate(conv_stem_configs):
                seq_proj.add_module(f'conv_bn_relu_{i}', Conv2dNormActivation(in_channels=prev_channels, out_channels=conv_stem_layer_config.out_channels, kernel_size=conv_stem_layer_config.kernel_size, stride=conv_stem_layer_config.stride, norm_layer=conv_stem_layer_config.norm_layer, activation_layer=conv_stem_layer_config.activation_layer))
                prev_channels = conv_stem_layer_config.out_channels
            seq_proj.add_module('conv_last', nn.Conv2d(in_channels=prev_channels, out_channels=hidden_dim, kernel_size=1))
            self.conv_proj: 'nn.Module\n' = seq_proj
        else:
            self.conv_proj = nn.Conv2d(in_channels=3, out_channels=hidden_dim, kernel_size=patch_size, stride=patch_size)
        seq_length = (image_size // patch_size) ** 2
        self.class_token = nn.Parameter(torch.zeros(1, 1, hidden_dim))
        seq_length += 1
        self.encoder = Encoder(seq_length, num_layers, num_heads, hidden_dim, mlp_dim, dropout, attention_dropout, norm_layer)
        self.seq_length = seq_length
        heads_layers: 'OrderedDict[(str, nn.Module)]\n' = OrderedDict()
        if representation_size is None:
            heads_layers['head'] = nn.Linear(hidden_dim, num_classes)
        else:
            heads_layers['pre_logits'] = nn.Linear(hidden_dim, representation_size)
            heads_layers['act'] = nn.Tanh()
            heads_layers['head'] = nn.Linear(representation_size, num_classes)
        self.heads = nn.Sequential(heads_layers)
        if isinstance(self.conv_proj, nn.Conv2d):
            fan_in = self.conv_proj.in_channels * self.conv_proj.kernel_size[0] * self.conv_proj.kernel_size[1]
            nn.init.trunc_normal_(self.conv_proj.weight, std=math.sqrt(1 / fan_in))
            if self.conv_proj.bias is not None:
                nn.init.zeros_(self.conv_proj.bias)
        elif self.conv_proj.conv_last is not None and isinstance(self.conv_proj.conv_last, nn.Conv2d):
            nn.init.normal_(self.conv_proj.conv_last.weight, mean=0.0, std=math.sqrt(2.0 / self.conv_proj.conv_last.out_channels))
            if self.conv_proj.conv_last.bias is not None:
                nn.init.zeros_(self.conv_proj.conv_last.bias)
        if hasattr(self.heads, 'pre_logits') and isinstance(self.heads.pre_logits, nn.Linear):
            fan_in = self.heads.pre_logits.in_features
            nn.init.trunc_normal_(self.heads.pre_logits.weight, std=math.sqrt(1 / fan_in))
            nn.init.zeros_(self.heads.pre_logits.bias)
        if isinstance(self.heads.head, nn.Linear):
            nn.init.zeros_(self.heads.head.weight)
            nn.init.zeros_(self.heads.head.bias)

    def _process_input(self, x: 'torch.Tensor\n') ->torch.Tensor:
        n, c, h, w = x.shape
        p = self.patch_size
        torch._assert(h == self.image_size, f'Wrong image height! Expected {self.image_size} but got {h}!')
        torch._assert(w == self.image_size, f'Wrong image width! Expected {self.image_size} but got {w}!')
        n_h = h // p
        n_w = w // p
        x = self.conv_proj(x)
        x = x.reshape(n, self.hidden_dim, n_h * n_w)
        x = x.permute(0, 2, 1)
        return x

    def forward(self, x: 'torch.Tensor\n'):
        x = self._process_input(x)
        n = x.shape[0]
        batch_class_token = self.class_token.expand(n, -1, -1)
        x = torch.cat([batch_class_token, x], dim=1)
        x = self.encoder(x)
        x = x[:, (0)]
        x = self.heads(x)
        return x


def deform_conv2d(input: 'Tensor\n', offset: 'Tensor\n', weight: 'Tensor\n', bias: 'Optional[Tensor]\n'=None, stride: 'Tuple[(int, int)]\n'=(1, 1), padding: 'Tuple[(int, int)]\n'=(0, 0), dilation: 'Tuple[(int, int)]\n'=(1, 1), mask: 'Optional[Tensor]\n'=None) ->Tensor:
    """
    Performs Deformable Convolution v2, described in
    `Deformable ConvNets v2: More Deformable, Better Results
    <https://arxiv.org/abs/1811.11168>`__ if :attr:`mask` is not ``None`` and
    Performs Deformable Convolution, described in
    `Deformable Convolutional Networks
    <https://arxiv.org/abs/1703.06211>`__ if :attr:`mask` is ``None``.

    Args:
        input (Tensor[batch_size, in_channels, in_height, in_width]): input tensor
        offset (Tensor[batch_size, 2 * offset_groups * kernel_height * kernel_width, out_height, out_width]):
            offsets to be applied for each position in the convolution kernel.
        weight (Tensor[out_channels, in_channels // groups, kernel_height, kernel_width]): convolution weights,
            split into groups of size (in_channels // groups)
        bias (Tensor[out_channels]): optional bias of shape (out_channels,). Default: None
        stride (int or Tuple[int, int]): distance between convolution centers. Default: 1
        padding (int or Tuple[int, int]): height/width of padding of zeroes around
            each image. Default: 0
        dilation (int or Tuple[int, int]): the spacing between kernel elements. Default: 1
        mask (Tensor[batch_size, offset_groups * kernel_height * kernel_width, out_height, out_width]):
            masks to be applied for each position in the convolution kernel. Default: None

    Returns:
        Tensor[batch_sz, out_channels, out_h, out_w]: result of convolution

    Examples::
        >>> input = torch.rand(4, 3, 10, 10)
        >>> kh, kw = 3, 3
        >>> weight = torch.rand(5, 3, kh, kw)
        >>> # offset and mask should have the same spatial size as the output
        >>> # of the convolution. In this case, for an input of 10, stride of 1
        >>> # and kernel size of 3, without padding, the output size is 8
        >>> offset = torch.rand(4, 2 * kh * kw, 8, 8)
        >>> mask = torch.rand(4, kh * kw, 8, 8)
        >>> out = deform_conv2d(input, offset, weight, mask=mask)
        >>> print(out.shape)
        >>> # returns
        >>>  torch.Size([4, 5, 8, 8])
    """
    if not torch.jit.is_scripting() and not torch.jit.is_tracing():
        _log_api_usage_once(deform_conv2d)
    _assert_has_ops()
    out_channels = weight.shape[0]
    use_mask = mask is not None
    if mask is None:
        mask = torch.zeros((input.shape[0], 1), device=input.device, dtype=input.dtype)
    if bias is None:
        bias = torch.zeros(out_channels, device=input.device, dtype=input.dtype)
    stride_h, stride_w = _pair(stride)
    pad_h, pad_w = _pair(padding)
    dil_h, dil_w = _pair(dilation)
    weights_h, weights_w = weight.shape[-2:]
    _, n_in_channels, _, _ = input.shape
    n_offset_grps = offset.shape[1] // (2 * weights_h * weights_w)
    n_weight_grps = n_in_channels // weight.shape[1]
    if n_offset_grps == 0:
        raise RuntimeError(f'the shape of the offset tensor at dimension 1 is not valid. It should be a multiple of 2 * weight.size[2] * weight.size[3].\nGot offset.shape[1]={offset.shape[1]}, while 2 * weight.size[2] * weight.size[3]={2 * weights_h * weights_w}')
    return torch.ops.torchvision.deform_conv2d(input, weight, offset, mask, bias, stride_h, stride_w, pad_h, pad_w, dil_h, dil_w, n_weight_grps, n_offset_grps, use_mask)


class DeformConv2d(nn.Module):
    """
    See :func:`deform_conv2d`.
    """

    def __init__(self, in_channels: 'int\n', out_channels: 'int\n', kernel_size: 'int\n', stride: 'int\n'=1, padding: 'int\n'=0, dilation: 'int\n'=1, groups: 'int\n'=1, bias: 'bool\n'=True):
        super().__init__()
        _log_api_usage_once(self)
        if in_channels % groups != 0:
            raise ValueError('in_channels must be divisible by groups')
        if out_channels % groups != 0:
            raise ValueError('out_channels must be divisible by groups')
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = _pair(kernel_size)
        self.stride = _pair(stride)
        self.padding = _pair(padding)
        self.dilation = _pair(dilation)
        self.groups = groups
        self.weight = Parameter(torch.empty(out_channels, in_channels // groups, self.kernel_size[0], self.kernel_size[1]))
        if bias:
            self.bias = Parameter(torch.empty(out_channels))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self) ->None:
        init.kaiming_uniform_(self.weight, a=math.sqrt(5))
        if self.bias is not None:
            fan_in, _ = init._calculate_fan_in_and_fan_out(self.weight)
            bound = 1 / math.sqrt(fan_in)
            init.uniform_(self.bias, -bound, bound)

    def forward(self, input: 'Tensor\n', offset: 'Tensor\n', mask: 'Optional[Tensor]\n'=None) ->Tensor:
        """
        Args:
            input (Tensor[batch_size, in_channels, in_height, in_width]): input tensor
            offset (Tensor[batch_size, 2 * offset_groups * kernel_height * kernel_width, out_height, out_width]):
                offsets to be applied for each position in the convolution kernel.
            mask (Tensor[batch_size, offset_groups * kernel_height * kernel_width, out_height, out_width]):
                masks to be applied for each position in the convolution kernel.
        """
        return deform_conv2d(input, offset, self.weight, self.bias, stride=self.stride, padding=self.padding, dilation=self.dilation, mask=mask)

    def __repr__(self) ->str:
        s = f'{self.__class__.__name__}({self.in_channels}, {self.out_channels}, kernel_size={self.kernel_size}, stride={self.stride}'
        s += f', padding={self.padding}' if self.padding != (0, 0) else ''
        s += f', dilation={self.dilation}' if self.dilation != (1, 1) else ''
        s += f', groups={self.groups}' if self.groups != 1 else ''
        s += ', bias=False' if self.bias is None else ''
        s += ')'
        return s


def drop_block2d(input: 'Tensor\n', p: 'float\n', block_size: 'int\n', inplace: 'bool\n'=False, eps: 'float\n'=1e-06, training: 'bool\n'=True) ->Tensor:
    """
    Implements DropBlock2d from `"DropBlock: A regularization method for convolutional networks"
    <https://arxiv.org/abs/1810.12890>`.

    Args:
        input (Tensor[N, C, H, W]): The input tensor or 4-dimensions with the first one
                    being its batch i.e. a batch with ``N`` rows.
        p (float): Probability of an element to be dropped.
        block_size (int): Size of the block to drop.
        inplace (bool): If set to ``True``, will do this operation in-place. Default: ``False``.
        eps (float): A value added to the denominator for numerical stability. Default: 1e-6.
        training (bool): apply dropblock if is ``True``. Default: ``True``.

    Returns:
        Tensor[N, C, H, W]: The randomly zeroed tensor after dropblock.
    """
    if not torch.jit.is_scripting() and not torch.jit.is_tracing():
        _log_api_usage_once(drop_block2d)
    if p < 0.0 or p > 1.0:
        raise ValueError(f'drop probability has to be between 0 and 1, but got {p}.')
    if input.ndim != 4:
        raise ValueError(f'input should be 4 dimensional. Got {input.ndim} dimensions.')
    if not training or p == 0.0:
        return input
    N, C, H, W = input.size()
    block_size = min(block_size, W, H)
    gamma = p * H * W / (block_size ** 2 * ((H - block_size + 1) * (W - block_size + 1)))
    noise = torch.empty((N, C, H - block_size + 1, W - block_size + 1), dtype=input.dtype, device=input.device)
    noise.bernoulli_(gamma)
    noise = F.pad(noise, [block_size // 2] * 4, value=0)
    noise = F.max_pool2d(noise, stride=(1, 1), kernel_size=(block_size, block_size), padding=block_size // 2)
    noise = 1 - noise
    normalize_scale = noise.numel() / (eps + noise.sum())
    if inplace:
        input.mul_(noise).mul_(normalize_scale)
    else:
        input = input * noise * normalize_scale
    return input


class DropBlock2d(nn.Module):
    """
    See :func:`drop_block2d`.
    """

    def __init__(self, p: 'float\n', block_size: 'int\n', inplace: 'bool\n'=False, eps: 'float\n'=1e-06) ->None:
        super().__init__()
        self.p = p
        self.block_size = block_size
        self.inplace = inplace
        self.eps = eps

    def forward(self, input: 'Tensor\n') ->Tensor:
        """
        Args:
            input (Tensor): Input feature map on which some areas will be randomly
                dropped.
        Returns:
            Tensor: The tensor after DropBlock layer.
        """
        return drop_block2d(input, self.p, self.block_size, self.inplace, self.eps, self.training)

    def __repr__(self) ->str:
        s = f'{self.__class__.__name__}(p={self.p}, block_size={self.block_size}, inplace={self.inplace})'
        return s


def drop_block3d(input: 'Tensor\n', p: 'float\n', block_size: 'int\n', inplace: 'bool\n'=False, eps: 'float\n'=1e-06, training: 'bool\n'=True) ->Tensor:
    """
    Implements DropBlock3d from `"DropBlock: A regularization method for convolutional networks"
    <https://arxiv.org/abs/1810.12890>`.

    Args:
        input (Tensor[N, C, D, H, W]): The input tensor or 5-dimensions with the first one
                    being its batch i.e. a batch with ``N`` rows.
        p (float): Probability of an element to be dropped.
        block_size (int): Size of the block to drop.
        inplace (bool): If set to ``True``, will do this operation in-place. Default: ``False``.
        eps (float): A value added to the denominator for numerical stability. Default: 1e-6.
        training (bool): apply dropblock if is ``True``. Default: ``True``.

    Returns:
        Tensor[N, C, D, H, W]: The randomly zeroed tensor after dropblock.
    """
    if not torch.jit.is_scripting() and not torch.jit.is_tracing():
        _log_api_usage_once(drop_block3d)
    if p < 0.0 or p > 1.0:
        raise ValueError(f'drop probability has to be between 0 and 1, but got {p}.')
    if input.ndim != 5:
        raise ValueError(f'input should be 5 dimensional. Got {input.ndim} dimensions.')
    if not training or p == 0.0:
        return input
    N, C, D, H, W = input.size()
    block_size = min(block_size, D, H, W)
    gamma = p * D * H * W / (block_size ** 3 * ((D - block_size + 1) * (H - block_size + 1) * (W - block_size + 1)))
    noise = torch.empty((N, C, D - block_size + 1, H - block_size + 1, W - block_size + 1), dtype=input.dtype, device=input.device)
    noise.bernoulli_(gamma)
    noise = F.pad(noise, [block_size // 2] * 6, value=0)
    noise = F.max_pool3d(noise, stride=(1, 1, 1), kernel_size=(block_size, block_size, block_size), padding=block_size // 2)
    noise = 1 - noise
    normalize_scale = noise.numel() / (eps + noise.sum())
    if inplace:
        input.mul_(noise).mul_(normalize_scale)
    else:
        input = input * noise * normalize_scale
    return input


class DropBlock3d(DropBlock2d):
    """
    See :func:`drop_block3d`.
    """

    def __init__(self, p: 'float\n', block_size: 'int\n', inplace: 'bool\n'=False, eps: 'float\n'=1e-06) ->None:
        super().__init__(p, block_size, inplace, eps)

    def forward(self, input: 'Tensor\n') ->Tensor:
        """
        Args:
            input (Tensor): Input feature map on which some areas will be randomly
                dropped.
        Returns:
            Tensor: The tensor after DropBlock layer.
        """
        return drop_block3d(input, self.p, self.block_size, self.inplace, self.eps, self.training)


class ExtraFPNBlock(nn.Module):
    """
    Base class for the extra block in the FPN.

    Args:
        results (List[Tensor]): the result of the FPN
        x (List[Tensor]): the original feature maps
        names (List[str]): the names for each one of the
            original feature maps

    Returns:
        results (List[Tensor]): the extended set of results
            of the FPN
        names (List[str]): the extended set of names for the results
    """

    def forward(self, results: 'List[Tensor]\n', x: 'List[Tensor]\n', names: 'List[str]\n') ->Tuple[List[Tensor], List[str]]:
        pass


class FeaturePyramidNetwork(nn.Module):
    """
    Module that adds a FPN from on top of a set of feature maps. This is based on
    `"Feature Pyramid Network for Object Detection" <https://arxiv.org/abs/1612.03144>`_.

    The feature maps are currently supposed to be in increasing depth
    order.

    The input to the model is expected to be an OrderedDict[Tensor], containing
    the feature maps on top of which the FPN will be added.

    Args:
        in_channels_list (list[int]): number of channels for each feature map that
            is passed to the module
        out_channels (int): number of channels of the FPN representation
        extra_blocks (ExtraFPNBlock or None): if provided, extra operations will
            be performed. It is expected to take the fpn features, the original
            features and the names of the original features as input, and returns
            a new list of feature maps and their corresponding names
        norm_layer (callable, optional): Module specifying the normalization layer to use. Default: None

    Examples::

        >>> m = torchvision.ops.FeaturePyramidNetwork([10, 20, 30], 5)
        >>> # get some dummy data
        >>> x = OrderedDict()
        >>> x['feat0'] = torch.rand(1, 10, 64, 64)
        >>> x['feat2'] = torch.rand(1, 20, 16, 16)
        >>> x['feat3'] = torch.rand(1, 30, 8, 8)
        >>> # compute the FPN on top of x
        >>> output = m(x)
        >>> print([(k, v.shape) for k, v in output.items()])
        >>> # returns
        >>>   [('feat0', torch.Size([1, 5, 64, 64])),
        >>>    ('feat2', torch.Size([1, 5, 16, 16])),
        >>>    ('feat3', torch.Size([1, 5, 8, 8]))]

    """
    _version = 2

    def __init__(self, in_channels_list: 'List[int]\n', out_channels: 'int\n', extra_blocks: 'Optional[ExtraFPNBlock]\n'=None, norm_layer: 'Optional[Callable[(..., nn.Module)]]\n'=None):
        super().__init__()
        _log_api_usage_once(self)
        self.inner_blocks = nn.ModuleList()
        self.layer_blocks = nn.ModuleList()
        for in_channels in in_channels_list:
            if in_channels == 0:
                raise ValueError('in_channels=0 is currently not supported')
            inner_block_module = Conv2dNormActivation(in_channels, out_channels, kernel_size=1, padding=0, norm_layer=norm_layer, activation_layer=None)
            layer_block_module = Conv2dNormActivation(out_channels, out_channels, kernel_size=3, norm_layer=norm_layer, activation_layer=None)
            self.inner_blocks.append(inner_block_module)
            self.layer_blocks.append(layer_block_module)
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_uniform_(m.weight, a=1)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
        if extra_blocks is not None:
            if not isinstance(extra_blocks, ExtraFPNBlock):
                raise TypeError(f'extra_blocks should be of type ExtraFPNBlock not {type(extra_blocks)}')
        self.extra_blocks = extra_blocks

    def _load_from_state_dict(self, state_dict, prefix, local_metadata, strict, missing_keys, unexpected_keys, error_msgs):
        version = local_metadata.get('version', None)
        if version is None or version < 2:
            num_blocks = len(self.inner_blocks)
            for block in ['inner_blocks', 'layer_blocks']:
                for i in range(num_blocks):
                    for type in ['weight', 'bias']:
                        old_key = f'{prefix}{block}.{i}.{type}'
                        new_key = f'{prefix}{block}.{i}.0.{type}'
                        if old_key in state_dict:
                            state_dict[new_key] = state_dict.pop(old_key)
        super()._load_from_state_dict(state_dict, prefix, local_metadata, strict, missing_keys, unexpected_keys, error_msgs)

    def get_result_from_inner_blocks(self, x: 'Tensor\n', idx: 'int\n') ->Tensor:
        """
        This is equivalent to self.inner_blocks[idx](x),
        but torchscript doesn't support this yet
        """
        num_blocks = len(self.inner_blocks)
        if idx < 0:
            idx += num_blocks
        out = x
        for i, module in enumerate(self.inner_blocks):
            if i == idx:
                out = module(x)
        return out

    def get_result_from_layer_blocks(self, x: 'Tensor\n', idx: 'int\n') ->Tensor:
        """
        This is equivalent to self.layer_blocks[idx](x),
        but torchscript doesn't support this yet
        """
        num_blocks = len(self.layer_blocks)
        if idx < 0:
            idx += num_blocks
        out = x
        for i, module in enumerate(self.layer_blocks):
            if i == idx:
                out = module(x)
        return out

    def forward(self, x: 'Dict[(str, Tensor)]\n') ->Dict[str, Tensor]:
        """
        Computes the FPN for a set of feature maps.

        Args:
            x (OrderedDict[Tensor]): feature maps for each feature level.

        Returns:
            results (OrderedDict[Tensor]): feature maps after FPN layers.
                They are ordered from the highest resolution first.
        """
        names = list(x.keys())
        x = list(x.values())
        last_inner = self.get_result_from_inner_blocks(x[-1], -1)
        results = []
        results.append(self.get_result_from_layer_blocks(last_inner, -1))
        for idx in range(len(x) - 2, -1, -1):
            inner_lateral = self.get_result_from_inner_blocks(x[idx], idx)
            feat_shape = inner_lateral.shape[-2:]
            inner_top_down = F.interpolate(last_inner, size=feat_shape, mode='nearest')
            last_inner = inner_lateral + inner_top_down
            results.insert(0, self.get_result_from_layer_blocks(last_inner, idx))
        if self.extra_blocks is not None:
            results, names = self.extra_blocks(results, x, names)
        out = OrderedDict([(k, v) for k, v in zip(names, results)])
        return out


class LastLevelMaxPool(ExtraFPNBlock):
    """
    Applies a max_pool2d (not actual max_pool2d, we just subsample) on top of the last feature map
    """

    def forward(self, x: 'List[Tensor]\n', y: 'List[Tensor]\n', names: 'List[str]\n') ->Tuple[List[Tensor], List[str]]:
        names.append('pool')
        x.append(F.max_pool2d(x[-1], kernel_size=1, stride=2, padding=0))
        return x, names


class LastLevelP6P7(ExtraFPNBlock):
    """
    This module is used in RetinaNet to generate extra layers, P6 and P7.
    """

    def __init__(self, in_channels: 'int\n', out_channels: 'int\n'):
        super().__init__()
        self.p6 = nn.Conv2d(in_channels, out_channels, 3, 2, 1)
        self.p7 = nn.Conv2d(out_channels, out_channels, 3, 2, 1)
        for module in [self.p6, self.p7]:
            nn.init.kaiming_uniform_(module.weight, a=1)
            nn.init.constant_(module.bias, 0)
        self.use_P5 = in_channels == out_channels

    def forward(self, p: 'List[Tensor]\n', c: 'List[Tensor]\n', names: 'List[str]\n') ->Tuple[List[Tensor], List[str]]:
        p5, c5 = p[-1], c[-1]
        x = p5 if self.use_P5 else c5
        p6 = self.p6(x)
        p7 = self.p7(F.relu(p6))
        p.extend([p6, p7])
        names.extend(['p6', 'p7'])
        return p, names


class FrozenBatchNorm2d(torch.nn.Module):
    """
    BatchNorm2d where the batch statistics and the affine parameters are fixed

    Args:
        num_features (int): Number of features ``C`` from an expected input of size ``(N, C, H, W)``
        eps (float): a value added to the denominator for numerical stability. Default: 1e-5
    """

    def __init__(self, num_features: 'int\n', eps: 'float\n'=1e-05):
        super().__init__()
        _log_api_usage_once(self)
        self.eps = eps
        self.register_buffer('weight', torch.ones(num_features))
        self.register_buffer('bias', torch.zeros(num_features))
        self.register_buffer('running_mean', torch.zeros(num_features))
        self.register_buffer('running_var', torch.ones(num_features))

    def _load_from_state_dict(self, state_dict: 'dict\n', prefix: 'str\n', local_metadata: 'dict\n', strict: 'bool\n', missing_keys: 'List[str]\n', unexpected_keys: 'List[str]\n', error_msgs: 'List[str]\n'):
        num_batches_tracked_key = prefix + 'num_batches_tracked'
        if num_batches_tracked_key in state_dict:
            del state_dict[num_batches_tracked_key]
        super()._load_from_state_dict(state_dict, prefix, local_metadata, strict, missing_keys, unexpected_keys, error_msgs)

    def forward(self, x: 'Tensor\n') ->Tensor:
        w = self.weight.reshape(1, -1, 1, 1)
        b = self.bias.reshape(1, -1, 1, 1)
        rv = self.running_var.reshape(1, -1, 1, 1)
        rm = self.running_mean.reshape(1, -1, 1, 1)
        scale = w * (rv + self.eps).rsqrt()
        bias = b - rm * scale
        return x * scale + bias

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}({self.weight.shape[0]}, eps={self.eps})'


def _make_ntuple(x: 'Any\n', n: 'int\n') ->Tuple[Any, ...]:
    """
    Make n-tuple from input x. If x is an iterable, then we just convert it to tuple.
    Otherwise, we will make a tuple of length n, all with value of x.
    reference: https://github.com/pytorch/pytorch/blob/master/torch/nn/modules/utils.py#L8

    Args:
        x (Any): input value
        n (int): length of the resulting tuple
    """
    if isinstance(x, collections.abc.Iterable):
        return tuple(x)
    return tuple(repeat(x, n))


class ConvNormActivation(torch.nn.Sequential):

    def __init__(self, in_channels: 'int\n', out_channels: 'int\n', kernel_size: 'Union[(int, Tuple[(int, ...)])]\n'=3, stride: 'Union[(int, Tuple[(int, ...)])]\n'=1, padding: 'Optional[Union[(int, Tuple[(int, ...)], str)]]\n'=None, groups: 'int\n'=1, norm_layer: 'Optional[Callable[(..., torch.nn.Module)]]\n'=torch.nn.BatchNorm2d, activation_layer: 'Optional[Callable[(..., torch.nn.Module)]]\n'=torch.nn.ReLU, dilation: 'Union[(int, Tuple[(int, ...)])]\n'=1, inplace: 'Optional[bool]\n'=True, bias: 'Optional[bool]\n'=None, conv_layer: 'Callable[(..., torch.nn.Module)]\n'=torch.nn.Conv2d) ->None:
        if padding is None:
            if isinstance(kernel_size, int) and isinstance(dilation, int):
                padding = (kernel_size - 1) // 2 * dilation
            else:
                _conv_dim = len(kernel_size) if isinstance(kernel_size, Sequence) else len(dilation)
                kernel_size = _make_ntuple(kernel_size, _conv_dim)
                dilation = _make_ntuple(dilation, _conv_dim)
                padding = tuple((kernel_size[i] - 1) // 2 * dilation[i] for i in range(_conv_dim))
        if bias is None:
            bias = norm_layer is None
        layers = [conv_layer(in_channels, out_channels, kernel_size, stride, padding, dilation=dilation, groups=groups, bias=bias)]
        if norm_layer is not None:
            layers.append(norm_layer(out_channels))
        if activation_layer is not None:
            params = {} if inplace is None else {'inplace': inplace}
            layers.append(activation_layer(**params))
        super().__init__(*layers)
        _log_api_usage_once(self)
        self.out_channels = out_channels
        if self.__class__ == ConvNormActivation:
            warnings.warn("Don't use ConvNormActivation directly, please use Conv2dNormActivation and Conv3dNormActivation instead.")


class Conv2dNormActivation(ConvNormActivation):
    """
    Configurable block used for Convolution2d-Normalization-Activation blocks.

    Args:
        in_channels (int): Number of channels in the input image
        out_channels (int): Number of channels produced by the Convolution-Normalization-Activation block
        kernel_size: (int, optional): Size of the convolving kernel. Default: 3
        stride (int, optional): Stride of the convolution. Default: 1
        padding (int, tuple or str, optional): Padding added to all four sides of the input. Default: None, in which case it will be calculated as ``padding = (kernel_size - 1) // 2 * dilation``
        groups (int, optional): Number of blocked connections from input channels to output channels. Default: 1
        norm_layer (Callable[..., torch.nn.Module], optional): Norm layer that will be stacked on top of the convolution layer. If ``None`` this layer won't be used. Default: ``torch.nn.BatchNorm2d``
        activation_layer (Callable[..., torch.nn.Module], optional): Activation function which will be stacked on top of the normalization layer (if not None), otherwise on top of the conv layer. If ``None`` this layer won't be used. Default: ``torch.nn.ReLU``
        dilation (int): Spacing between kernel elements. Default: 1
        inplace (bool): Parameter for the activation layer, which can optionally do the operation in-place. Default ``True``
        bias (bool, optional): Whether to use bias in the convolution layer. By default, biases are included if ``norm_layer is None``.

    """

    def __init__(self, in_channels: 'int\n', out_channels: 'int\n', kernel_size: 'Union[(int, Tuple[(int, int)])]\n'=3, stride: 'Union[(int, Tuple[(int, int)])]\n'=1, padding: 'Optional[Union[(int, Tuple[(int, int)], str)]]\n'=None, groups: 'int\n'=1, norm_layer: 'Optional[Callable[(..., torch.nn.Module)]]\n'=torch.nn.BatchNorm2d, activation_layer: 'Optional[Callable[(..., torch.nn.Module)]]\n'=torch.nn.ReLU, dilation: 'Union[(int, Tuple[(int, int)])]\n'=1, inplace: 'Optional[bool]\n'=True, bias: 'Optional[bool]\n'=None) ->None:
        super().__init__(in_channels, out_channels, kernel_size, stride, padding, groups, norm_layer, activation_layer, dilation, inplace, bias, torch.nn.Conv2d)


class Conv3dNormActivation(ConvNormActivation):
    """
    Configurable block used for Convolution3d-Normalization-Activation blocks.

    Args:
        in_channels (int): Number of channels in the input video.
        out_channels (int): Number of channels produced by the Convolution-Normalization-Activation block
        kernel_size: (int, optional): Size of the convolving kernel. Default: 3
        stride (int, optional): Stride of the convolution. Default: 1
        padding (int, tuple or str, optional): Padding added to all four sides of the input. Default: None, in which case it will be calculated as ``padding = (kernel_size - 1) // 2 * dilation``
        groups (int, optional): Number of blocked connections from input channels to output channels. Default: 1
        norm_layer (Callable[..., torch.nn.Module], optional): Norm layer that will be stacked on top of the convolution layer. If ``None`` this layer won't be used. Default: ``torch.nn.BatchNorm3d``
        activation_layer (Callable[..., torch.nn.Module], optional): Activation function which will be stacked on top of the normalization layer (if not None), otherwise on top of the conv layer. If ``None`` this layer won't be used. Default: ``torch.nn.ReLU``
        dilation (int): Spacing between kernel elements. Default: 1
        inplace (bool): Parameter for the activation layer, which can optionally do the operation in-place. Default ``True``
        bias (bool, optional): Whether to use bias in the convolution layer. By default, biases are included if ``norm_layer is None``.
    """

    def __init__(self, in_channels: 'int\n', out_channels: 'int\n', kernel_size: 'Union[(int, Tuple[(int, int, int)])]\n'=3, stride: 'Union[(int, Tuple[(int, int, int)])]\n'=1, padding: 'Optional[Union[(int, Tuple[(int, int, int)], str)]]\n'=None, groups: 'int\n'=1, norm_layer: 'Optional[Callable[(..., torch.nn.Module)]]\n'=torch.nn.BatchNorm3d, activation_layer: 'Optional[Callable[(..., torch.nn.Module)]]\n'=torch.nn.ReLU, dilation: 'Union[(int, Tuple[(int, int, int)])]\n'=1, inplace: 'Optional[bool]\n'=True, bias: 'Optional[bool]\n'=None) ->None:
        super().__init__(in_channels, out_channels, kernel_size, stride, padding, groups, norm_layer, activation_layer, dilation, inplace, bias, torch.nn.Conv3d)


class SqueezeExcitation(torch.nn.Module):
    """
    This block implements the Squeeze-and-Excitation block from https://arxiv.org/abs/1709.01507 (see Fig. 1).
    Parameters ``activation``, and ``scale_activation`` correspond to ``delta`` and ``sigma`` in eq. 3.

    Args:
        input_channels (int): Number of channels in the input image
        squeeze_channels (int): Number of squeeze channels
        activation (Callable[..., torch.nn.Module], optional): ``delta`` activation. Default: ``torch.nn.ReLU``
        scale_activation (Callable[..., torch.nn.Module]): ``sigma`` activation. Default: ``torch.nn.Sigmoid``
    """

    def __init__(self, input_channels: 'int\n', squeeze_channels: 'int\n', activation: 'Callable[(..., torch.nn.Module)]\n'=torch.nn.ReLU, scale_activation: 'Callable[(..., torch.nn.Module)]\n'=torch.nn.Sigmoid) ->None:
        super().__init__()
        _log_api_usage_once(self)
        self.avgpool = torch.nn.AdaptiveAvgPool2d(1)
        self.fc1 = torch.nn.Conv2d(input_channels, squeeze_channels, 1)
        self.fc2 = torch.nn.Conv2d(squeeze_channels, input_channels, 1)
        self.activation = activation()
        self.scale_activation = scale_activation()

    def _scale(self, input: 'Tensor\n') ->Tensor:
        scale = self.avgpool(input)
        scale = self.fc1(scale)
        scale = self.activation(scale)
        scale = self.fc2(scale)
        return self.scale_activation(scale)

    def forward(self, input: 'Tensor\n') ->Tensor:
        scale = self._scale(input)
        return scale * input


class LevelMapper:
    """Determine which FPN level each RoI in a set of RoIs should map to based
    on the heuristic in the FPN paper.

    Args:
        k_min (int)
        k_max (int)
        canonical_scale (int)
        canonical_level (int)
        eps (float)
    """

    def __init__(self, k_min: 'int\n', k_max: 'int\n', canonical_scale: 'int\n'=224, canonical_level: 'int\n'=4, eps: 'float\n'=1e-06):
        self.k_min = k_min
        self.k_max = k_max
        self.s0 = canonical_scale
        self.lvl0 = canonical_level
        self.eps = eps

    def __call__(self, boxlists: 'List[Tensor]\n') ->Tensor:
        """
        Args:
            boxlists (list[BoxList])
        """
        s = torch.sqrt(torch.cat([box_area(boxlist) for boxlist in boxlists]))
        target_lvls = torch.floor(self.lvl0 + torch.log2(s / self.s0) + torch.tensor(self.eps, dtype=s.dtype))
        target_lvls = torch.clamp(target_lvls, min=self.k_min, max=self.k_max)
        return target_lvls.to(torch.int64) - self.k_min


@torch.fx.wrap
def _filter_input(x: 'Dict[(str, Tensor)]\n', featmap_names: 'List[str]\n') ->List[Tensor]:
    x_filtered = []
    for k, v in x.items():
        if k in featmap_names:
            x_filtered.append(v)
    return x_filtered


def _convert_to_roi_format(boxes: 'List[Tensor]\n') ->Tensor:
    concat_boxes = torch.cat(boxes, dim=0)
    device, dtype = concat_boxes.device, concat_boxes.dtype
    ids = torch.cat([torch.full_like(b[:, :1], i, dtype=dtype, layout=torch.strided, device=device) for i, b in enumerate(boxes)], dim=0)
    rois = torch.cat([ids, concat_boxes], dim=1)
    return rois


@torch.jit.unused
def _onnx_merge_levels(levels: 'Tensor\n', unmerged_results: 'List[Tensor]\n') ->Tensor:
    first_result = unmerged_results[0]
    dtype, device = first_result.dtype, first_result.device
    res = torch.zeros((levels.size(0), first_result.size(1), first_result.size(2), first_result.size(3)), dtype=dtype, device=device)
    for level in range(len(unmerged_results)):
        index = torch.where(levels == level)[0].view(-1, 1, 1, 1)
        index = index.expand(index.size(0), unmerged_results[level].size(1), unmerged_results[level].size(2), unmerged_results[level].size(3))
        res = res.scatter(0, index, unmerged_results[level])
    return res


@torch.fx.wrap
def _multiscale_roi_align(x_filtered: 'List[Tensor]\n', boxes: 'List[Tensor]\n', output_size: 'List[int]\n', sampling_ratio: 'int\n', scales: 'Optional[List[float]]\n', mapper: 'Optional[LevelMapper]\n') ->Tensor:
    """
    Args:
        x_filtered (List[Tensor]): List of input tensors.
        boxes (List[Tensor[N, 4]]): boxes to be used to perform the pooling operation, in
            (x1, y1, x2, y2) format and in the image reference size, not the feature map
            reference. The coordinate must satisfy ``0 <= x1 < x2`` and ``0 <= y1 < y2``.
        output_size (Union[List[Tuple[int, int]], List[int]]): size of the output
        sampling_ratio (int): sampling ratio for ROIAlign
        scales (Optional[List[float]]): If None, scales will be automatically inferred. Default value is None.
        mapper (Optional[LevelMapper]): If none, mapper will be automatically inferred. Default value is None.
    Returns:
        result (Tensor)
    """
    if scales is None or mapper is None:
        raise ValueError('scales and mapper should not be None')
    num_levels = len(x_filtered)
    rois = _convert_to_roi_format(boxes)
    if num_levels == 1:
        return roi_align(x_filtered[0], rois, output_size=output_size, spatial_scale=scales[0], sampling_ratio=sampling_ratio)
    levels = mapper(boxes)
    num_rois = len(rois)
    num_channels = x_filtered[0].shape[1]
    dtype, device = x_filtered[0].dtype, x_filtered[0].device
    result = torch.zeros((num_rois, num_channels) + output_size, dtype=dtype, device=device)
    tracing_results = []
    for level, (per_level_feature, scale) in enumerate(zip(x_filtered, scales)):
        idx_in_level = torch.where(levels == level)[0]
        rois_per_level = rois[idx_in_level]
        result_idx_in_level = roi_align(per_level_feature, rois_per_level, output_size=output_size, spatial_scale=scale, sampling_ratio=sampling_ratio)
        if torchvision._is_tracing():
            tracing_results.append(result_idx_in_level)
        else:
            result[idx_in_level] = result_idx_in_level
    if torchvision._is_tracing():
        result = _onnx_merge_levels(levels, tracing_results)
    return result


def _infer_scale(feature: 'Tensor\n', original_size: 'List[int]\n') ->float:
    size = feature.shape[-2:]
    possible_scales: 'List[float]\n' = []
    for s1, s2 in zip(size, original_size):
        approx_scale = float(s1) / float(s2)
        scale = 2 ** float(torch.tensor(approx_scale).log2().round())
        possible_scales.append(scale)
    return possible_scales[0]


def initLevelMapper(k_min: 'int\n', k_max: 'int\n', canonical_scale: 'int\n'=224, canonical_level: 'int\n'=4, eps: 'float\n'=1e-06):
    return LevelMapper(k_min, k_max, canonical_scale, canonical_level, eps)


@torch.fx.wrap
def _setup_scales(features: 'List[Tensor]\n', image_shapes: 'List[Tuple[(int, int)]]\n', canonical_scale: 'int\n', canonical_level: 'int\n') ->Tuple[List[float], LevelMapper]:
    if not image_shapes:
        raise ValueError('images list should not be empty')
    max_x = 0
    max_y = 0
    for shape in image_shapes:
        max_x = max(shape[0], max_x)
        max_y = max(shape[1], max_y)
    original_input_shape = max_x, max_y
    scales = [_infer_scale(feat, original_input_shape) for feat in features]
    lvl_min = -torch.log2(torch.tensor(scales[0], dtype=torch.float32)).item()
    lvl_max = -torch.log2(torch.tensor(scales[-1], dtype=torch.float32)).item()
    map_levels = initLevelMapper(int(lvl_min), int(lvl_max), canonical_scale=canonical_scale, canonical_level=canonical_level)
    return scales, map_levels


class MultiScaleRoIAlign(nn.Module):
    """
    Multi-scale RoIAlign pooling, which is useful for detection with or without FPN.

    It infers the scale of the pooling via the heuristics specified in eq. 1
    of the `Feature Pyramid Network paper <https://arxiv.org/abs/1612.03144>`_.
    They keyword-only parameters ``canonical_scale`` and ``canonical_level``
    correspond respectively to ``224`` and ``k0=4`` in eq. 1, and
    have the following meaning: ``canonical_level`` is the target level of the pyramid from
    which to pool a region of interest with ``w x h = canonical_scale x canonical_scale``.

    Args:
        featmap_names (List[str]): the names of the feature maps that will be used
            for the pooling.
        output_size (List[Tuple[int, int]] or List[int]): output size for the pooled region
        sampling_ratio (int): sampling ratio for ROIAlign
        canonical_scale (int, optional): canonical_scale for LevelMapper
        canonical_level (int, optional): canonical_level for LevelMapper

    Examples::

        >>> m = torchvision.ops.MultiScaleRoIAlign(['feat1', 'feat3'], 3, 2)
        >>> i = OrderedDict()
        >>> i['feat1'] = torch.rand(1, 5, 64, 64)
        >>> i['feat2'] = torch.rand(1, 5, 32, 32)  # this feature won't be used in the pooling
        >>> i['feat3'] = torch.rand(1, 5, 16, 16)
        >>> # create some random bounding boxes
        >>> boxes = torch.rand(6, 4) * 256; boxes[:, 2:] += boxes[:, :2]
        >>> # original image size, before computing the feature maps
        >>> image_sizes = [(512, 512)]
        >>> output = m(i, [boxes], image_sizes)
        >>> print(output.shape)
        >>> torch.Size([6, 5, 3, 3])

    """
    __annotations__ = {'scales': Optional[List[float]], 'map_levels': Optional[LevelMapper]}

    def __init__(self, featmap_names: 'List[str]\n', output_size: 'Union[(int, Tuple[int], List[int])]\n', sampling_ratio: 'int\n', *, canonical_scale: int=224, canonical_level: int=4):
        super().__init__()
        _log_api_usage_once(self)
        if isinstance(output_size, int):
            output_size = output_size, output_size
        self.featmap_names = featmap_names
        self.sampling_ratio = sampling_ratio
        self.output_size = tuple(output_size)
        self.scales = None
        self.map_levels = None
        self.canonical_scale = canonical_scale
        self.canonical_level = canonical_level

    def forward(self, x: 'Dict[(str, Tensor)]\n', boxes: 'List[Tensor]\n', image_shapes: 'List[Tuple[(int, int)]]\n') ->Tensor:
        """
        Args:
            x (OrderedDict[Tensor]): feature maps for each level. They are assumed to have
                all the same number of channels, but they can have different sizes.
            boxes (List[Tensor[N, 4]]): boxes to be used to perform the pooling operation, in
                (x1, y1, x2, y2) format and in the image reference size, not the feature map
                reference. The coordinate must satisfy ``0 <= x1 < x2`` and ``0 <= y1 < y2``.
            image_shapes (List[Tuple[height, width]]): the sizes of each image before they
                have been fed to a CNN to obtain feature maps. This allows us to infer the
                scale factor for each one of the levels to be pooled.
        Returns:
            result (Tensor)
        """
        x_filtered = _filter_input(x, self.featmap_names)
        if self.scales is None or self.map_levels is None:
            self.scales, self.map_levels = _setup_scales(x_filtered, image_shapes, self.canonical_scale, self.canonical_level)
        return _multiscale_roi_align(x_filtered, boxes, self.output_size, self.sampling_ratio, self.scales, self.map_levels)

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}(featmap_names={self.featmap_names}, output_size={self.output_size}, sampling_ratio={self.sampling_ratio})'


def check_roi_boxes_shape(boxes: 'Union[(Tensor, List[Tensor])]\n'):
    if isinstance(boxes, (list, tuple)):
        for _tensor in boxes:
            torch._assert(_tensor.size(1) == 4, 'The shape of the tensor in the boxes list is not correct as List[Tensor[L, 4]]')
    elif isinstance(boxes, torch.Tensor):
        torch._assert(boxes.size(1) == 5, 'The boxes tensor shape is not correct as Tensor[K, 5]')
    else:
        torch._assert(False, 'boxes is expected to be a Tensor[L, 5] or a List[Tensor[K, 4]]')
    return


def _cat(tensors: 'List[Tensor]\n', dim: 'int\n'=0) ->Tensor:
    """
    Efficient version of torch.cat that avoids a copy if there is only a single element in a list
    """
    if len(tensors) == 1:
        return tensors[0]
    return torch.cat(tensors, dim)


def convert_boxes_to_roi_format(boxes: 'List[Tensor]\n') ->Tensor:
    concat_boxes = _cat([b for b in boxes], dim=0)
    temp = []
    for i, b in enumerate(boxes):
        temp.append(torch.full_like(b[:, :1], i))
    ids = _cat(temp, dim=0)
    rois = torch.cat([ids, concat_boxes], dim=1)
    return rois


@torch.fx.wrap
def ps_roi_align(input: 'Tensor\n', boxes: 'Tensor\n', output_size: 'int\n', spatial_scale: 'float\n'=1.0, sampling_ratio: 'int\n'=-1) ->Tensor:
    """
    Performs Position-Sensitive Region of Interest (RoI) Align operator
    mentioned in Light-Head R-CNN.

    Args:
        input (Tensor[N, C, H, W]): The input tensor, i.e. a batch with ``N`` elements. Each element
            contains ``C`` feature maps of dimensions ``H x W``.
        boxes (Tensor[K, 5] or List[Tensor[L, 4]]): the box coordinates in (x1, y1, x2, y2)
            format where the regions will be taken from.
            The coordinate must satisfy ``0 <= x1 < x2`` and ``0 <= y1 < y2``.
            If a single Tensor is passed, then the first column should
            contain the index of the corresponding element in the batch, i.e. a number in ``[0, N - 1]``.
            If a list of Tensors is passed, then each Tensor will correspond to the boxes for an element i
            in the batch.
        output_size (int or Tuple[int, int]): the size of the output (in bins or pixels) after the pooling
            is performed, as (height, width).
        spatial_scale (float): a scaling factor that maps the box coordinates to
            the input coordinates. For example, if your boxes are defined on the scale
            of a 224x224 image and your input is a 112x112 feature map (resulting from a 0.5x scaling of
            the original image), you'll want to set this to 0.5. Default: 1.0
        sampling_ratio (int): number of sampling points in the interpolation grid
            used to compute the output value of each pooled output bin. If > 0,
            then exactly ``sampling_ratio x sampling_ratio`` sampling points per bin are used. If
            <= 0, then an adaptive number of grid points are used (computed as
            ``ceil(roi_width / output_width)``, and likewise for height). Default: -1

    Returns:
        Tensor[K, C / (output_size[0] * output_size[1]), output_size[0], output_size[1]]: The pooled RoIs
    """
    if not torch.jit.is_scripting() and not torch.jit.is_tracing():
        _log_api_usage_once(ps_roi_align)
    _assert_has_ops()
    check_roi_boxes_shape(boxes)
    rois = boxes
    output_size = _pair(output_size)
    if not isinstance(rois, torch.Tensor):
        rois = convert_boxes_to_roi_format(rois)
    output, _ = torch.ops.torchvision.ps_roi_align(input, rois, spatial_scale, output_size[0], output_size[1], sampling_ratio)
    return output


class PSRoIAlign(nn.Module):
    """
    See :func:`ps_roi_align`.
    """

    def __init__(self, output_size: 'int\n', spatial_scale: 'float\n', sampling_ratio: 'int\n'):
        super().__init__()
        _log_api_usage_once(self)
        self.output_size = output_size
        self.spatial_scale = spatial_scale
        self.sampling_ratio = sampling_ratio

    def forward(self, input: 'Tensor\n', rois: 'Tensor\n') ->Tensor:
        return ps_roi_align(input, rois, self.output_size, self.spatial_scale, self.sampling_ratio)

    def __repr__(self) ->str:
        s = f'{self.__class__.__name__}(output_size={self.output_size}, spatial_scale={self.spatial_scale}, sampling_ratio={self.sampling_ratio})'
        return s


@torch.fx.wrap
def ps_roi_pool(input: 'Tensor\n', boxes: 'Tensor\n', output_size: 'int\n', spatial_scale: 'float\n'=1.0) ->Tensor:
    """
    Performs Position-Sensitive Region of Interest (RoI) Pool operator
    described in R-FCN

    Args:
        input (Tensor[N, C, H, W]): The input tensor, i.e. a batch with ``N`` elements. Each element
            contains ``C`` feature maps of dimensions ``H x W``.
        boxes (Tensor[K, 5] or List[Tensor[L, 4]]): the box coordinates in (x1, y1, x2, y2)
            format where the regions will be taken from.
            The coordinate must satisfy ``0 <= x1 < x2`` and ``0 <= y1 < y2``.
            If a single Tensor is passed, then the first column should
            contain the index of the corresponding element in the batch, i.e. a number in ``[0, N - 1]``.
            If a list of Tensors is passed, then each Tensor will correspond to the boxes for an element i
            in the batch.
        output_size (int or Tuple[int, int]): the size of the output (in bins or pixels) after the pooling
            is performed, as (height, width).
        spatial_scale (float): a scaling factor that maps the box coordinates to
            the input coordinates. For example, if your boxes are defined on the scale
            of a 224x224 image and your input is a 112x112 feature map (resulting from a 0.5x scaling of
            the original image), you'll want to set this to 0.5. Default: 1.0

    Returns:
        Tensor[K, C / (output_size[0] * output_size[1]), output_size[0], output_size[1]]: The pooled RoIs.
    """
    if not torch.jit.is_scripting() and not torch.jit.is_tracing():
        _log_api_usage_once(ps_roi_pool)
    _assert_has_ops()
    check_roi_boxes_shape(boxes)
    rois = boxes
    output_size = _pair(output_size)
    if not isinstance(rois, torch.Tensor):
        rois = convert_boxes_to_roi_format(rois)
    output, _ = torch.ops.torchvision.ps_roi_pool(input, rois, spatial_scale, output_size[0], output_size[1])
    return output


class PSRoIPool(nn.Module):
    """
    See :func:`ps_roi_pool`.
    """

    def __init__(self, output_size: 'int\n', spatial_scale: 'float\n'):
        super().__init__()
        _log_api_usage_once(self)
        self.output_size = output_size
        self.spatial_scale = spatial_scale

    def forward(self, input: 'Tensor\n', rois: 'Tensor\n') ->Tensor:
        return ps_roi_pool(input, rois, self.output_size, self.spatial_scale)

    def __repr__(self) ->str:
        s = f'{self.__class__.__name__}(output_size={self.output_size}, spatial_scale={self.spatial_scale})'
        return s


class RoIAlign(nn.Module):
    """
    See :func:`roi_align`.
    """

    def __init__(self, output_size: 'BroadcastingList2[int]\n', spatial_scale: 'float\n', sampling_ratio: 'int\n', aligned: 'bool\n'=False):
        super().__init__()
        _log_api_usage_once(self)
        self.output_size = output_size
        self.spatial_scale = spatial_scale
        self.sampling_ratio = sampling_ratio
        self.aligned = aligned

    def forward(self, input: 'Tensor\n', rois: 'Union[(Tensor, List[Tensor])]\n') ->Tensor:
        return roi_align(input, rois, self.output_size, self.spatial_scale, self.sampling_ratio, self.aligned)

    def __repr__(self) ->str:
        s = f'{self.__class__.__name__}(output_size={self.output_size}, spatial_scale={self.spatial_scale}, sampling_ratio={self.sampling_ratio}, aligned={self.aligned})'
        return s


@torch.fx.wrap
def roi_pool(input: 'Tensor\n', boxes: 'Union[(Tensor, List[Tensor])]\n', output_size: 'BroadcastingList2[int]\n', spatial_scale: 'float\n'=1.0) ->Tensor:
    """
    Performs Region of Interest (RoI) Pool operator described in Fast R-CNN

    Args:
        input (Tensor[N, C, H, W]): The input tensor, i.e. a batch with ``N`` elements. Each element
            contains ``C`` feature maps of dimensions ``H x W``.
        boxes (Tensor[K, 5] or List[Tensor[L, 4]]): the box coordinates in (x1, y1, x2, y2)
            format where the regions will be taken from.
            The coordinate must satisfy ``0 <= x1 < x2`` and ``0 <= y1 < y2``.
            If a single Tensor is passed, then the first column should
            contain the index of the corresponding element in the batch, i.e. a number in ``[0, N - 1]``.
            If a list of Tensors is passed, then each Tensor will correspond to the boxes for an element i
            in the batch.
        output_size (int or Tuple[int, int]): the size of the output after the cropping
            is performed, as (height, width)
        spatial_scale (float): a scaling factor that maps the box coordinates to
            the input coordinates. For example, if your boxes are defined on the scale
            of a 224x224 image and your input is a 112x112 feature map (resulting from a 0.5x scaling of
            the original image), you'll want to set this to 0.5. Default: 1.0

    Returns:
        Tensor[K, C, output_size[0], output_size[1]]: The pooled RoIs.
    """
    if not torch.jit.is_scripting() and not torch.jit.is_tracing():
        _log_api_usage_once(roi_pool)
    _assert_has_ops()
    check_roi_boxes_shape(boxes)
    rois = boxes
    output_size = _pair(output_size)
    if not isinstance(rois, torch.Tensor):
        rois = convert_boxes_to_roi_format(rois)
    output, _ = torch.ops.torchvision.roi_pool(input, rois, spatial_scale, output_size[0], output_size[1])
    return output


class RoIPool(nn.Module):
    """
    See :func:`roi_pool`.
    """

    def __init__(self, output_size: 'BroadcastingList2[int]\n', spatial_scale: 'float\n'):
        super().__init__()
        _log_api_usage_once(self)
        self.output_size = output_size
        self.spatial_scale = spatial_scale

    def forward(self, input: 'Tensor\n', rois: 'Union[(Tensor, List[Tensor])]\n') ->Tensor:
        return roi_pool(input, rois, self.output_size, self.spatial_scale)

    def __repr__(self) ->str:
        s = f'{self.__class__.__name__}(output_size={self.output_size}, spatial_scale={self.spatial_scale})'
        return s


def stochastic_depth(input: 'Tensor\n', p: 'float\n', mode: 'str\n', training: 'bool\n'=True) ->Tensor:
    """
    Implements the Stochastic Depth from `"Deep Networks with Stochastic Depth"
    <https://arxiv.org/abs/1603.09382>`_ used for randomly dropping residual
    branches of residual architectures.

    Args:
        input (Tensor[N, ...]): The input tensor or arbitrary dimensions with the first one
                    being its batch i.e. a batch with ``N`` rows.
        p (float): probability of the input to be zeroed.
        mode (str): ``"batch"`` or ``"row"``.
                    ``"batch"`` randomly zeroes the entire input, ``"row"`` zeroes
                    randomly selected rows from the batch.
        training: apply stochastic depth if is ``True``. Default: ``True``

    Returns:
        Tensor[N, ...]: The randomly zeroed tensor.
    """
    if not torch.jit.is_scripting() and not torch.jit.is_tracing():
        _log_api_usage_once(stochastic_depth)
    if p < 0.0 or p > 1.0:
        raise ValueError(f'drop probability has to be between 0 and 1, but got {p}')
    if mode not in ['batch', 'row']:
        raise ValueError(f"mode has to be either 'batch' or 'row', but got {mode}")
    if not training or p == 0.0:
        return input
    survival_rate = 1.0 - p
    if mode == 'row':
        size = [input.shape[0]] + [1] * (input.ndim - 1)
    else:
        size = [1] * input.ndim
    noise = torch.empty(size, dtype=input.dtype, device=input.device)
    noise = noise.bernoulli_(survival_rate)
    if survival_rate > 0.0:
        noise.div_(survival_rate)
    return input * noise


class StochasticDepth(nn.Module):
    """
    See :func:`stochastic_depth`.
    """

    def __init__(self, p: 'float\n', mode: 'str\n') ->None:
        super().__init__()
        _log_api_usage_once(self)
        self.p = p
        self.mode = mode

    def forward(self, input: 'Tensor\n') ->Tensor:
        return stochastic_depth(input, self.p, self.mode, self.training)

    def __repr__(self) ->str:
        s = f'{self.__class__.__name__}(p={self.p}, mode={self.mode})'
        return s


class ConvexMaskPredictor(nn.Module):

    def __init__(self, *, in_channels: int, hidden_size: int, upsample_factor: int, multiplier: float=0.25) ->None:
        super().__init__()
        self.mask_head = nn.Sequential(Conv2dNormActivation(in_channels, hidden_size, norm_layer=None, kernel_size=3), nn.Conv2d(hidden_size, upsample_factor ** 2 * 9, 1, padding=0))
        self.multiplier = multiplier

    def forward(self, x: 'Tensor\n') ->Tensor:
        x = self.mask_head(x) * self.multiplier
        return x


def _check_window_specs(search_window_1d: 'Tuple[(int, int)]\n'=(1, 9), search_dilate_1d: 'Tuple[(int, int)]\n'=(1, 1), search_window_2d: 'Tuple[(int, int)]\n'=(3, 3), search_dilate_2d: 'Tuple[(int, int)]\n'=(1, 1)) ->None:
    if not np.prod(search_window_1d) == np.prod(search_window_2d):
        raise ValueError(f'The 1D and 2D windows should contain the same number of elements. 1D shape: {search_window_1d} 2D shape: {search_window_2d}')
    if not np.prod(search_window_1d) % 2 == 1:
        raise ValueError(f'Search windows should contain an odd number of elements in them.Window of shape {search_window_1d} has {np.prod(search_window_1d)} elements.')
    if not any(size == 1 for size in search_window_1d):
        raise ValueError(f'The 1D search window should have at least one size equal to 1. 1D shape: {search_window_1d}')
    if any(size == 1 for size in search_window_2d):
        raise ValueError(f'The 2D search window should have all dimensions greater than 1. 2D shape: {search_window_2d}')
    if any(dilate < 1 for dilate in search_dilate_1d):
        raise ValueError(f'The 1D search dilation should have all elements equal or greater than 1. 1D shape: {search_dilate_1d}')
    if any(dilate < 1 for dilate in search_dilate_2d):
        raise ValueError(f'The 2D search dilation should have all elements equal greater than 1. 2D shape: {search_dilate_2d}')


def get_correlation(left_feature: 'Tensor\n', right_feature: 'Tensor\n', window_size: 'Tuple[(int, int)]\n'=(3, 3), dilate: 'Tuple[(int, int)]\n'=(1, 1)) ->Tensor:
    """Function that computes a correlation product between the left and right features.

    The correlation is computed in a sliding window fashion, namely the left features are fixed
    and for each ``(i, j)`` location we compute the correlation with a sliding window anchored in
    ``(i, j)`` from the right feature map. The sliding window selects pixels obtained in the range of the sliding
    window; i.e ``(i - window_size // 2, i + window_size // 2)`` respectively ``(j - window_size // 2, j + window_size // 2)``.
    """
    B, C, H, W = left_feature.shape
    di_y, di_x = dilate[0], dilate[1]
    pad_y, pad_x = window_size[0] // 2 * di_y, window_size[1] // 2 * di_x
    right_padded = F.pad(right_feature, (pad_x, pad_x, pad_y, pad_y), mode='replicate')
    right_padded = F.unfold(right_padded, kernel_size=(H, W), dilation=dilate)
    right_padded = right_padded.permute(0, 2, 1)
    right_padded = right_padded.reshape(B, window_size[0] * window_size[1], C, H, W)
    left_feature = left_feature.unsqueeze(1)
    correlation = torch.mean(left_feature * right_padded, dim=2, keepdim=False)
    return correlation


class IterativeCorrelationLayer(nn.Module):

    def __init__(self, groups: 'int\n'=4, search_window_1d: 'Tuple[(int, int)]\n'=(1, 9), search_dilate_1d: 'Tuple[(int, int)]\n'=(1, 1), search_window_2d: 'Tuple[(int, int)]\n'=(3, 3), search_dilate_2d: 'Tuple[(int, int)]\n'=(1, 1)) ->None:
        super().__init__()
        _check_window_specs(search_window_1d=search_window_1d, search_dilate_1d=search_dilate_1d, search_window_2d=search_window_2d, search_dilate_2d=search_dilate_2d)
        self.search_pixels = np.prod(search_window_1d)
        self.groups = groups
        self.patch_sizes = {'2d': [search_window_2d for _ in range(self.groups)], '1d': [search_window_1d for _ in range(self.groups)]}
        self.dilate_sizes = {'2d': [search_dilate_2d for _ in range(self.groups)], '1d': [search_dilate_1d for _ in range(self.groups)]}

    def forward(self, left_feature: 'Tensor\n', right_feature: 'Tensor\n', flow: 'Tensor\n', window_type: 'str\n'='1d') ->Tensor:
        """Function that computes 1 pass of non-offsetted Group-Wise correlation"""
        coords = make_coords_grid(left_feature.shape[0], left_feature.shape[2], left_feature.shape[3], device=str(left_feature.device))
        coords = coords + flow
        coords = coords.permute(0, 2, 3, 1)
        right_feature = grid_sample(right_feature, coords, mode='bilinear', align_corners=True)
        patch_size_list = self.patch_sizes[window_type]
        dilate_size_list = self.dilate_sizes[window_type]
        left_groups = torch.chunk(left_feature, self.groups, dim=1)
        right_groups = torch.chunk(right_feature, self.groups, dim=1)
        correlations = []
        for i in range(len(patch_size_list)):
            correlation = get_correlation(left_groups[i], right_groups[i], patch_size_list[i], dilate_size_list[i])
            correlations.append(correlation)
        final_correlations = torch.cat(correlations, dim=1)
        return final_correlations


class AttentionOffsetCorrelationLayer(nn.Module):

    def __init__(self, groups: 'int\n'=4, attention_module: 'Optional[nn.Module]\n'=None, search_window_1d: 'Tuple[(int, int)]\n'=(1, 9), search_dilate_1d: 'Tuple[(int, int)]\n'=(1, 1), search_window_2d: 'Tuple[(int, int)]\n'=(3, 3), search_dilate_2d: 'Tuple[(int, int)]\n'=(1, 1)) ->None:
        super().__init__()
        _check_window_specs(search_window_1d=search_window_1d, search_dilate_1d=search_dilate_1d, search_window_2d=search_window_2d, search_dilate_2d=search_dilate_2d)
        self.search_pixels = int(np.prod(search_window_1d))
        self.groups = groups
        self.patch_sizes = {'2d': [search_window_2d for _ in range(self.groups)], '1d': [search_window_1d for _ in range(self.groups)]}
        self.dilate_sizes = {'2d': [search_dilate_2d for _ in range(self.groups)], '1d': [search_dilate_1d for _ in range(self.groups)]}
        self.attention_module = attention_module

    def forward(self, left_feature: 'Tensor\n', right_feature: 'Tensor\n', flow: 'Tensor\n', extra_offset: 'Tensor\n', window_type: 'str\n'='1d') ->Tensor:
        """Function that computes 1 pass of offsetted Group-Wise correlation

        If the class was provided with an attention layer, the left and right feature maps
        will be passed through a transformer first
        """
        B, C, H, W = left_feature.shape
        if self.attention_module is not None:
            left_feature = left_feature.permute(0, 2, 3, 1).reshape(B, H * W, C)
            right_feature = right_feature.permute(0, 2, 3, 1).reshape(B, H * W, C)
            left_feature, right_feature = self.attention_module(left_feature, right_feature)
            left_feature = left_feature.reshape(B, H, W, C).permute(0, 3, 1, 2)
            right_feature = right_feature.reshape(B, H, W, C).permute(0, 3, 1, 2)
        left_groups = torch.chunk(left_feature, self.groups, dim=1)
        right_groups = torch.chunk(right_feature, self.groups, dim=1)
        num_search_candidates = self.search_pixels
        extra_offset = extra_offset.reshape(B, num_search_candidates, 2, H, W).permute(0, 1, 3, 4, 2)
        patch_size_list = self.patch_sizes[window_type]
        dilate_size_list = self.dilate_sizes[window_type]
        group_channels = C // self.groups
        correlations = []
        for i in range(len(patch_size_list)):
            left_group, right_group = left_groups[i], right_groups[i]
            patch_size, dilate = patch_size_list[i], dilate_size_list[i]
            di_y, di_x = dilate
            ps_y, ps_x = patch_size
            ry, rx = ps_y // 2 * di_y, ps_x // 2 * di_x
            x_grid, y_grid = torch.meshgrid(torch.arange(-rx, rx + 1, di_x), torch.arange(-ry, ry + 1, di_y), indexing='xy')
            x_grid, y_grid = x_grid, y_grid
            offsets = torch.stack((x_grid, y_grid))
            offsets = offsets.reshape(2, -1).permute(1, 0)
            for d in (0, 2, 3):
                offsets = offsets.unsqueeze(d)
            offsets = offsets + extra_offset
            coords = make_coords_grid(left_feature.shape[0], left_feature.shape[2], left_feature.shape[3], device=str(left_feature.device)) + flow
            coords = coords.permute(0, 2, 3, 1).unsqueeze(1)
            coords = coords + offsets
            coords = coords.reshape(B, -1, W, 2)
            right_group = grid_sample(right_group, coords, mode='bilinear', align_corners=True)
            right_group = right_group.reshape(B, group_channels, -1, H, W)
            left_group = left_group.reshape(B, group_channels, -1, H, W)
            correlation = torch.mean(left_group * right_group, dim=1)
            correlations.append(correlation)
        final_correlation = torch.cat(correlations, dim=1)
        return final_correlation


class AdaptiveGroupCorrelationLayer(nn.Module):
    """
    Container for computing various correlation types between a left and right feature map.
    This module does not contain any optimisable parameters, it's solely a collection of ops.
    We wrap in a nn.Module for torch.jit.script compatibility

    Adaptive Group Correlation operations from: https://openaccess.thecvf.com/content/CVPR2022/papers/Li_Practical_Stereo_Matching_via_Cascaded_Recurrent_Network_With_Adaptive_Correlation_CVPR_2022_paper.pdf

    Canonical reference implementation: https://github.com/megvii-research/CREStereo/blob/master/nets/corr.py
    """

    def __init__(self, iterative_correlation_layer: 'IterativeCorrelationLayer\n', attention_offset_correlation_layer: 'AttentionOffsetCorrelationLayer\n') ->None:
        super().__init__()
        self.iterative_correlation_layer = iterative_correlation_layer
        self.attention_offset_correlation_layer = attention_offset_correlation_layer

    def forward(self, left_features: 'Tensor\n', right_features: 'Tensor\n', flow: 'torch.Tensor\n', extra_offset: 'Optional[Tensor]\n', window_type: 'str\n'='1d', iter_mode: 'bool\n'=False) ->Tensor:
        if iter_mode or extra_offset is None:
            corr = self.iterative_correlation_layer(left_features, right_features, flow, window_type)
        else:
            corr = self.attention_offset_correlation_layer(left_features, right_features, flow, extra_offset, window_type)
        return corr


def elu_feature_map(x: 'Tensor\n') ->Tensor:
    """Elu feature map operation from: https://arxiv.org/pdf/2006.16236.pdf"""
    return F.elu(x) + 1


class LinearAttention(nn.Module):
    """
    Linear attention operation from: https://arxiv.org/pdf/2006.16236.pdf
    Canonical implementation reference: https://github.com/idiap/fast-transformers/blob/master/fast_transformers/attention/linear_attention.py
    LoFTR implementation reference: https://github.com/zju3dv/LoFTR/blob/2122156015b61fbb650e28b58a958e4d632b1058/src/loftr/loftr_module/linear_attention.py
    """

    def __init__(self, eps: 'float\n'=1e-06, feature_map_fn: 'Callable[([Tensor], Tensor)]\n'=elu_feature_map) ->None:
        super().__init__()
        self.eps = eps
        self.feature_map_fn = feature_map_fn

    def forward(self, queries: 'Tensor\n', keys: 'Tensor\n', values: 'Tensor\n', q_mask: 'Optional[Tensor]\n'=None, kv_mask: 'Optional[Tensor]\n'=None) ->Tensor:
        """
        Args:
            queries (torch.Tensor): [N, S1, H, D]
            keys (torch.Tensor): [N, S2, H, D]
            values (torch.Tensor): [N, S2, H, D]
            q_mask (torch.Tensor): [N, S1] (optional)
            kv_mask (torch.Tensor): [N, S2] (optional)
        Returns:
            queried_values (torch.Tensor): [N, S1, H, D]
        """
        queries = self.feature_map_fn(queries)
        keys = self.feature_map_fn(keys)
        if q_mask is not None:
            queries = queries * q_mask[:, :, (None), (None)]
        if kv_mask is not None:
            keys = keys * kv_mask[:, :, (None), (None)]
            values = values * kv_mask[:, :, (None), (None)]
        values_length = values.shape[1]
        values = values / values_length
        kv = torch.einsum('NSHD, NSHV -> NHDV', keys, values)
        z = 1 / (torch.einsum('NLHD, NHD -> NLH', queries, keys.sum(dim=1)) + self.eps)
        queried_values = torch.einsum('NLHD, NHDV, NLH -> NLHV', queries, kv, z) * values_length
        return queried_values


class SoftmaxAttention(nn.Module):
    """
    A simple softmax attention  operation
    LoFTR implementation reference: https://github.com/zju3dv/LoFTR/blob/2122156015b61fbb650e28b58a958e4d632b1058/src/loftr/loftr_module/linear_attention.py
    """

    def __init__(self, dropout: 'float\n'=0.0) ->None:
        super().__init__()
        self.dropout = nn.Dropout(dropout) if dropout else nn.Identity()

    def forward(self, queries: 'Tensor\n', keys: 'Tensor\n', values: 'Tensor\n', q_mask: 'Optional[Tensor]\n'=None, kv_mask: 'Optional[Tensor]\n'=None) ->Tensor:
        """
        Computes classical softmax full-attention between all queries and keys.

        Args:
            queries (torch.Tensor): [N, S1, H, D]
            keys (torch.Tensor): [N, S2, H, D]
            values (torch.Tensor): [N, S2, H, D]
            q_mask (torch.Tensor): [N, S1] (optional)
            kv_mask (torch.Tensor): [N, S2] (optional)
        Returns:
            queried_values: [N, S1, H, D]
        """
        scale_factor = 1.0 / queries.shape[3] ** 0.5
        queries = queries * scale_factor
        qk = torch.einsum('NLHD, NSHD -> NLSH', queries, keys)
        if kv_mask is not None and q_mask is not None:
            qk.masked_fill_(~(q_mask[:, :, (None), (None)] * kv_mask[:, (None), :, (None)]), float('-inf'))
        attention = torch.softmax(qk, dim=2)
        attention = self.dropout(attention)
        queried_values = torch.einsum('NLSH, NSHD -> NLHD', attention, values)
        return queried_values


class PositionalEncodingSine(nn.Module):
    """
    Sinusoidal positional encodings

    Using the scaling term from https://github.com/megvii-research/CREStereo/blob/master/nets/attention/position_encoding.py
    Reference implementation from https://github.com/facebookresearch/detr/blob/8a144f83a287f4d3fece4acdf073f387c5af387d/models/position_encoding.py#L28-L48
    """

    def __init__(self, dim_model: 'int\n', max_size: 'int\n'=256) ->None:
        super().__init__()
        self.dim_model = dim_model
        self.max_size = max_size
        pe = self._make_pe_of_size(self.max_size)
        self.register_buffer('pe', pe)

    def _make_pe_of_size(self, size: 'int\n') ->Tensor:
        pe = torch.zeros((self.dim_model, *(size, size)), dtype=torch.float32)
        y_positions = torch.ones((size, size)).cumsum(0).float().unsqueeze(0)
        x_positions = torch.ones((size, size)).cumsum(1).float().unsqueeze(0)
        div_term = torch.exp(torch.arange(0.0, self.dim_model // 2, 2) * (-math.log(10000.0) / self.dim_model // 2))
        div_term = div_term[:, (None), (None)]
        pe[0::4, :, :] = torch.sin(x_positions * div_term)
        pe[1::4, :, :] = torch.cos(x_positions * div_term)
        pe[2::4, :, :] = torch.sin(y_positions * div_term)
        pe[3::4, :, :] = torch.cos(y_positions * div_term)
        pe = pe.unsqueeze(0)
        return pe

    def forward(self, x: 'Tensor\n') ->Tensor:
        """
        Args:
            x: [B, C, H, W]

        Returns:
            x: [B, C, H, W]
        """
        torch._assert(len(x.shape) == 4, f'PositionalEncodingSine requires a 4-D dimensional input. Provided tensor is of shape {x.shape}')
        B, C, H, W = x.shape
        return x + self.pe[:, :, :H, :W]


class LocalFeatureEncoderLayer(nn.Module):
    """
    LoFTR transformer module from: https://arxiv.org/pdf/2104.00680.pdf
    Canonical implementations at: https://github.com/zju3dv/LoFTR/blob/master/src/loftr/loftr_module/transformer.py
    """

    def __init__(self, *, dim_model: int, num_heads: int, attention_module: Callable[..., nn.Module]=LinearAttention) ->None:
        super().__init__()
        self.attention_op = attention_module()
        if not isinstance(self.attention_op, (LinearAttention, SoftmaxAttention)):
            raise ValueError(f'attention_module must be an instance of LinearAttention or SoftmaxAttention. Got {type(self.attention_op)}')
        self.dim_head = dim_model // num_heads
        self.num_heads = num_heads
        self.query_proj = nn.Linear(dim_model, dim_model, bias=False)
        self.key_proj = nn.Linear(dim_model, dim_model, bias=False)
        self.value_proj = nn.Linear(dim_model, dim_model, bias=False)
        self.merge = nn.Linear(dim_model, dim_model, bias=False)
        self.ffn = nn.Sequential(nn.Linear(dim_model * 2, dim_model * 2, bias=False), nn.ReLU(), nn.Linear(dim_model * 2, dim_model, bias=False))
        self.attention_norm = nn.LayerNorm(dim_model)
        self.ffn_norm = nn.LayerNorm(dim_model)

    def forward(self, x: 'Tensor\n', source: 'Tensor\n', x_mask: 'Optional[Tensor]\n'=None, source_mask: 'Optional[Tensor]\n'=None) ->Tensor:
        """
        Args:
            x (torch.Tensor): [B, S1, D]
            source (torch.Tensor): [B, S2, D]
            x_mask (torch.Tensor): [B, S1] (optional)
            source_mask (torch.Tensor): [B, S2] (optional)
        """
        B, S, D = x.shape
        queries, keys, values = x, source, source
        queries = self.query_proj(queries).reshape(B, S, self.num_heads, self.dim_head)
        keys = self.key_proj(keys).reshape(B, S, self.num_heads, self.dim_head)
        values = self.value_proj(values).reshape(B, S, self.num_heads, self.dim_head)
        message = self.attention_op(queries, keys, values, x_mask, source_mask)
        message = self.merge(message.reshape(B, S, D))
        message = self.attention_norm(message)
        message = self.ffn(torch.cat([x, message], dim=2))
        message = self.ffn_norm(message)
        return x + message


class LocalFeatureTransformer(nn.Module):
    """
    LoFTR transformer module from: https://arxiv.org/pdf/2104.00680.pdf
    Canonical implementations at: https://github.com/zju3dv/LoFTR/blob/master/src/loftr/loftr_module/transformer.py
    """

    def __init__(self, *, dim_model: int, num_heads: int, attention_directions: List[str], attention_module: Callable[..., nn.Module]=LinearAttention) ->None:
        super(LocalFeatureTransformer, self).__init__()
        self.attention_module = attention_module
        self.attention_directions = attention_directions
        for direction in attention_directions:
            if direction not in ['self', 'cross']:
                raise ValueError(f'Attention direction {direction} unsupported. LocalFeatureTransformer accepts only ``attention_type`` in ``[self, cross]``.')
        self.layers = nn.ModuleList([LocalFeatureEncoderLayer(dim_model=dim_model, num_heads=num_heads, attention_module=attention_module) for _ in attention_directions])

    def forward(self, left_features: 'Tensor\n', right_features: 'Tensor\n', left_mask: 'Optional[Tensor]\n'=None, right_mask: 'Optional[Tensor]\n'=None) ->Tuple[Tensor, Tensor]:
        """
        Args:
            left_features (torch.Tensor): [N, S1, D]
            right_features (torch.Tensor): [N, S2, D]
            left_mask (torch.Tensor): [N, S1] (optional)
            right_mask (torch.Tensor): [N, S2] (optional)
        Returns:
            left_features (torch.Tensor): [N, S1, D]
            right_features (torch.Tensor): [N, S2, D]
        """
        torch._assert(left_features.shape[2] == right_features.shape[2], f'left_features and right_features should have the same embedding dimensions. left_features: {left_features.shape[2]} right_features: {right_features.shape[2]}')
        for idx, layer in enumerate(self.layers):
            attention_direction = self.attention_directions[idx]
            if attention_direction == 'self':
                left_features = layer(left_features, left_features, left_mask, left_mask)
                right_features = layer(right_features, right_features, right_mask, right_mask)
            elif attention_direction == 'cross':
                left_features = layer(left_features, right_features, left_mask, right_mask)
                right_features = layer(right_features, left_features, right_mask, left_mask)
        return left_features, right_features


class PyramidDownsample(nn.Module):
    """
    A simple wrapper that return and Avg Pool feature pyramid based on the provided scales.
    Implicitly returns the input as well.
    """

    def __init__(self, factors: 'Iterable[int]\n') ->None:
        super().__init__()
        self.factors = factors

    def forward(self, x: 'torch.Tensor\n') ->List[Tensor]:
        results = [x]
        for factor in self.factors:
            results.append(F.avg_pool2d(x, kernel_size=factor, stride=factor))
        return results


class CREStereo(nn.Module):
    """
    Implements CREStereo from the `"Practical Stereo Matching via Cascaded Recurrent Network
    With Adaptive Correlation" <https://openaccess.thecvf.com/content/CVPR2022/papers/Li_Practical_Stereo_Matching_via_Cascaded_Recurrent_Network_With_Adaptive_Correlation_CVPR_2022_paper.pdf>`_ paper.
    Args:
        feature_encoder (raft.FeatureEncoder): Raft-like Feature Encoder module extract low-level features from inputs.
        update_block (raft.UpdateBlock): Raft-like Update Block which recursively refines a flow-map.
        flow_head (raft.FlowHead): Raft-like Flow Head which predics a flow-map from some inputs.
        self_attn_block (LocalFeatureTransformer): A Local Feature Transformer that performs self attention on the two feature maps.
        cross_attn_block (LocalFeatureTransformer): A Local Feature Transformer that performs cross attention between the two feature maps
            used in the Adaptive Group Correlation module.
        feature_downsample_rates (List[int]): The downsample rates used to build a feature pyramid from the outputs of the `feature_encoder`. Default: [2, 4]
        correlation_groups (int): In how many groups should the features be split when computer per-pixel correlation. Defaults 4.
        search_window_1d (Tuple[int, int]): The alternate search window size in the x and y directions for the 1D case. Defaults to (1, 9).
        search_dilate_1d (Tuple[int, int]): The dilation used in the `search_window_1d` when selecting pixels. Similar to `nn.Conv2d` dilate. Defaults to (1, 1).
        search_window_2d (Tuple[int, int]): The alternate search window size in the x and y directions for the 2D case. Defaults to (3, 3).
        search_dilate_2d (Tuple[int, int]): The dilation used in the `search_window_2d` when selecting pixels. Similar to `nn.Conv2d` dilate. Defaults to (1, 1).
    """

    def __init__(self, *, feature_encoder: raft.FeatureEncoder, update_block: raft.UpdateBlock, flow_head: raft.FlowHead, self_attn_block: LocalFeatureTransformer, cross_attn_block: LocalFeatureTransformer, feature_downsample_rates: Tuple[int, ...]=(2, 4), correlation_groups: int=4, search_window_1d: Tuple[int, int]=(1, 9), search_dilate_1d: Tuple[int, int]=(1, 1), search_window_2d: Tuple[int, int]=(3, 3), search_dilate_2d: Tuple[int, int]=(1, 1)) ->None:
        super().__init__()
        self.output_channels = 2
        self.feature_encoder = feature_encoder
        self.update_block = update_block
        self.flow_head = flow_head
        self.self_attn_block = self_attn_block
        self.downsampling_pyramid = PyramidDownsample(feature_downsample_rates)
        self.downsampling_factors: 'List[int]\n' = [feature_encoder.downsample_factor]
        base_downsample_factor: 'int\n' = self.downsampling_factors[0]
        for rate in feature_downsample_rates:
            self.downsampling_factors.append(base_downsample_factor * rate)
        self.resolutions: 'List[str]\n' = [f'1 / {factor}' for factor in self.downsampling_factors]
        self.search_pixels = int(np.prod(search_window_1d))
        self.mask_predictor = ConvexMaskPredictor(in_channels=feature_encoder.output_dim // 2, hidden_size=feature_encoder.output_dim, upsample_factor=feature_encoder.downsample_factor, multiplier=0.25)
        self.offset_convs = nn.ModuleDict()
        self.correlation_layers = nn.ModuleDict()
        offset_conv_layer = partial(Conv2dNormActivation, in_channels=feature_encoder.output_dim, out_channels=self.search_pixels * 2, norm_layer=None, activation_layer=None)
        iterative_correlation_layer = partial(IterativeCorrelationLayer, groups=correlation_groups, search_window_1d=search_window_1d, search_dilate_1d=search_dilate_1d, search_window_2d=search_window_2d, search_dilate_2d=search_dilate_2d)
        attention_offset_correlation_layer = partial(AttentionOffsetCorrelationLayer, groups=correlation_groups, search_window_1d=search_window_1d, search_dilate_1d=search_dilate_1d, search_window_2d=search_window_2d, search_dilate_2d=search_dilate_2d)
        for idx, resolution in enumerate(reversed(self.resolutions[1:])):
            offset_conv = None if idx == len(self.resolutions) - 1 else offset_conv_layer()
            if offset_conv:
                self.offset_convs[resolution] = offset_conv
                attention_module = cross_attn_block if idx == 0 else None
                self.correlation_layers[resolution] = AdaptiveGroupCorrelationLayer(iterative_correlation_layer=iterative_correlation_layer(), attention_offset_correlation_layer=attention_offset_correlation_layer(attention_module=attention_module))
        self.max_res_correlation_layer = AdaptiveGroupCorrelationLayer(iterative_correlation_layer=iterative_correlation_layer(), attention_offset_correlation_layer=attention_offset_correlation_layer())
        self.positional_encodings = PositionalEncodingSine(feature_encoder.output_dim)

    def _get_window_type(self, iteration: 'int\n') ->str:
        return '1d' if iteration % 2 == 0 else '2d'

    def forward(self, left_image: 'Tensor\n', right_image: 'Tensor\n', flow_init: 'Optional[Tensor]\n'=None, num_iters: 'int\n'=10) ->List[Tensor]:
        features = torch.cat([left_image, right_image], dim=0)
        features = self.feature_encoder(features)
        left_features, right_features = features.chunk(2, dim=0)
        net, ctx = left_features.chunk(2, dim=1)
        net = torch.tanh(net)
        ctx = torch.relu(ctx)
        l_pyramid = self.downsampling_pyramid(left_features)
        r_pyramid = self.downsampling_pyramid(right_features)
        net_pyramid = self.downsampling_pyramid(net)
        ctx_pyramid = self.downsampling_pyramid(ctx)
        l_pyramid = {res: l_pyramid[idx] for idx, res in enumerate(self.resolutions)}
        r_pyramid = {res: r_pyramid[idx] for idx, res in enumerate(self.resolutions)}
        net_pyramid = {res: net_pyramid[idx] for idx, res in enumerate(self.resolutions)}
        ctx_pyramid = {res: ctx_pyramid[idx] for idx, res in enumerate(self.resolutions)}
        offsets: 'Dict[(str, Tensor)]\n' = {}
        for resolution, offset_conv in self.offset_convs.items():
            feature_map = l_pyramid[resolution]
            offset = offset_conv(feature_map)
            offsets[resolution] = (torch.sigmoid(offset) - 0.5) * 2.0
        min_res = self.resolutions[-1]
        max_res = self.resolutions[0]
        B, C, MIN_H, MIN_W = l_pyramid[min_res].shape
        l_pyramid[min_res] = self.positional_encodings(l_pyramid[min_res])
        r_pyramid[min_res] = self.positional_encodings(r_pyramid[min_res])
        l_pyramid[min_res] = l_pyramid[min_res].permute(0, 2, 3, 1).reshape(B, MIN_H * MIN_W, C)
        r_pyramid[min_res] = r_pyramid[min_res].permute(0, 2, 3, 1).reshape(B, MIN_H * MIN_W, C)
        l_pyramid[min_res], r_pyramid[min_res] = self.self_attn_block(l_pyramid[min_res], r_pyramid[min_res])
        l_pyramid[min_res] = l_pyramid[min_res].reshape(B, MIN_H, MIN_W, C).permute(0, 3, 1, 2)
        r_pyramid[min_res] = r_pyramid[min_res].reshape(B, MIN_H, MIN_W, C).permute(0, 3, 1, 2)
        predictions: 'List[Tensor]\n' = []
        flow_estimates: 'Dict[(str, Tensor)]\n' = {}
        flow_pred_prior: 'Tensor\n' = torch.empty(size=(B, 2, left_features.shape[2], left_features.shape[3]), dtype=l_pyramid[max_res].dtype, device=l_pyramid[max_res].device)
        if flow_init is not None:
            scale = l_pyramid[max_res].shape[2] / flow_init.shape[2]
            flow_estimates[max_res] = -scale * F.interpolate(input=flow_init, size=l_pyramid[max_res].shape[2:], mode='bilinear', align_corners=True)
        else:
            flow = torch.zeros(size=(B, 2, MIN_H, MIN_W), device=left_features.device, dtype=left_features.dtype)
            coarse_resolutions: 'List[str]\n' = self.resolutions[::-1]
            fine_grained_resolution = max_res
            flow_estimates[coarse_resolutions[0]] = flow
            for idx, (resolution, correlation_layer) in enumerate(self.correlation_layers.items()):
                scale_to_base = l_pyramid[fine_grained_resolution].shape[2] // l_pyramid[resolution].shape[2]
                for it in range(num_iters // 2):
                    window_type = self._get_window_type(it)
                    flow_estimates[resolution] = flow_estimates[resolution].detach()
                    correlations = correlation_layer(l_pyramid[resolution], r_pyramid[resolution], flow_estimates[resolution], offsets[resolution], window_type)
                    net_pyramid[resolution], delta_flow = self.update_block(net_pyramid[resolution], ctx_pyramid[resolution], correlations, flow_estimates[resolution])
                    up_mask = self.mask_predictor(net_pyramid[resolution])
                    flow_estimates[resolution] = flow_estimates[resolution] + delta_flow
                    flow_pred_prior = upsample_flow(flow_estimates[resolution], up_mask, factor=self.downsampling_factors[0])
                    flow_pred = -upsample_flow(flow_pred_prior, None, factor=scale_to_base)
                    predictions.append(flow_pred)
                next_resolution = coarse_resolutions[idx + 1]
                scale_to_next = l_pyramid[next_resolution].shape[2] / flow_pred_prior.shape[2]
                flow_estimates[next_resolution] = -scale_to_next * F.interpolate(input=flow_pred_prior, size=l_pyramid[next_resolution].shape[2:], mode='bilinear', align_corners=True)
        for it in range(num_iters):
            search_window_type = self._get_window_type(it)
            flow_estimates[max_res] = flow_estimates[max_res].detach()
            correlations = self.max_res_correlation_layer(l_pyramid[max_res], r_pyramid[max_res], flow_estimates[max_res], extra_offset=None, window_type=search_window_type, iter_mode=True)
            net_pyramid[max_res], delta_flow = self.update_block(net_pyramid[max_res], ctx_pyramid[max_res], correlations, flow_estimates[max_res])
            up_mask = self.mask_predictor(net_pyramid[max_res])
            flow_estimates[max_res] = flow_estimates[max_res] + delta_flow
            flow_pred = -upsample_flow(flow_estimates[max_res], up_mask, factor=self.downsampling_factors[0])
            predictions.append(flow_pred)
        return predictions


class BaseEncoder(raft.FeatureEncoder):
    """Base encoder for FeatureEncoder and ContextEncoder in which weight may be shared.

    See the Raft-Stereo paper section 4.6 on backbone part.
    """

    def __init__(self, *, block: Callable[..., nn.Module]=ResidualBlock, layers: Tuple[int, int, int, int]=(64, 64, 96, 128), strides: Tuple[int, int, int, int]=(2, 1, 2, 2), norm_layer: Callable[..., nn.Module]=nn.BatchNorm2d):
        super().__init__(block=block, layers=layers + (256,), strides=strides, norm_layer=norm_layer)
        self.conv = nn.Identity()
        self.output_dim = layers[3]
        num_downsampling = sum([(x - 1) for x in strides])
        self.downsampling_ratio = 2 ** num_downsampling


class MultiLevelContextEncoder(nn.Module):
    """Context Encoder for Raft-Stereo (see paper section 3.1) that may have shared weight with the Feature Encoder.

    The ContextEncoder takes left image as input, and it outputs concatenated hidden_states and contexts.
    In Raft-Stereo we have multi level GRUs and this context encoder will also multi outputs (list of Tensor)
    that correspond to each GRUs.
    Take note that the length of "out_with_blocks" parameter represent the number of GRU's level.
    args:
        base_encoder (nn.Module): The base encoder part that can have a shared weight with feature_encoder's
            base_encoder because they have same architecture.
        out_with_blocks (List[bool]): The length represent the number of GRU's level (length of output), and
            if the element is True then the output layer on that position will have additional block
        output_dim (int): The dimension of output on each level (default: 256)
        block (Callable[..., nn.Module]): The type of basic block used for downsampling and output layer
            (default: ResidualBlock)
    """

    def __init__(self, base_encoder: 'nn.Module\n', out_with_blocks: 'List[bool]\n', output_dim: 'int\n'=256, block: 'Callable[(..., nn.Module)]\n'=ResidualBlock):
        super().__init__()
        self.num_level = len(out_with_blocks)
        self.base_encoder = base_encoder
        self.base_downsampling_ratio = base_encoder.downsampling_ratio
        base_dim = base_encoder.output_dim
        self.downsample_and_out_layers = nn.ModuleList([nn.ModuleDict({'downsampler': self._make_downsampler(block, base_dim, base_dim) if i > 0 else nn.Identity(), 'out_hidden_state': self._make_out_layer(base_dim, output_dim // 2, with_block=out_with_blocks[i], block=block), 'out_context': self._make_out_layer(base_dim, output_dim // 2, with_block=out_with_blocks[i], block=block)}) for i in range(self.num_level)])

    def _make_out_layer(self, in_channels, out_channels, with_block=True, block=ResidualBlock):
        layers = []
        if with_block:
            layers.append(block(in_channels, in_channels, norm_layer=nn.BatchNorm2d, stride=1))
        layers.append(nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1))
        return nn.Sequential(*layers)

    def _make_downsampler(self, block, in_channels, out_channels):
        block1 = block(in_channels, out_channels, norm_layer=nn.BatchNorm2d, stride=2)
        block2 = block(out_channels, out_channels, norm_layer=nn.BatchNorm2d, stride=1)
        return nn.Sequential(block1, block2)

    def forward(self, x: 'Tensor\n') ->List[Tensor]:
        x = self.base_encoder(x)
        outs = []
        for layer_dict in self.downsample_and_out_layers:
            x = layer_dict['downsampler'](x)
            outs.append(torch.cat([layer_dict['out_hidden_state'](x), layer_dict['out_context'](x)], dim=1))
        return outs


class MultiLevelUpdateBlock(nn.Module):
    """The update block which contains the motion encoder and grus

    It must expose a ``hidden_dims`` attribute which is the hidden dimension size of its gru blocks
    """

    def __init__(self, *, motion_encoder: MotionEncoder, hidden_dims: List[int]):
        super().__init__()
        self.motion_encoder = motion_encoder
        gru_input_dims = []
        for i in range(len(hidden_dims)):
            input_dim = hidden_dims[i - 1] if i > 0 else motion_encoder.out_channels
            if i < len(hidden_dims) - 1:
                input_dim += hidden_dims[i + 1]
            gru_input_dims.append(input_dim)
        self.grus = nn.ModuleList([ConvGRU(input_size=gru_input_dims[i], hidden_size=hidden_dims[i], kernel_size=3, padding=1) for i in reversed(list(range(len(hidden_dims))))])
        self.hidden_dims = hidden_dims

    def forward(self, hidden_states: 'List[Tensor]\n', contexts: 'List[List[Tensor]]\n', corr_features: 'Tensor\n', disparity: 'Tensor\n', level_processed: 'List[bool]\n') ->List[Tensor]:
        for reverse_i, gru in enumerate(self.grus):
            i = len(self.grus) - 1 - reverse_i
            if level_processed[i]:
                if i == 0:
                    features = self.motion_encoder(disparity, corr_features)
                else:
                    features = F.avg_pool2d(hidden_states[i - 1], kernel_size=3, stride=2, padding=1)
                if i < len(self.grus) - 1:
                    _, _, h, w = hidden_states[i + 1].shape
                    features = torch.cat([features, F.interpolate(hidden_states[i + 1], size=(2 * h, 2 * w), mode='bilinear', align_corners=True)], dim=1)
                hidden_states[i] = gru(hidden_states[i], features, contexts[i])
        return hidden_states


class CorrPyramid1d(nn.Module):
    """Row-wise correlation pyramid.

    Create a row-wise correlation pyramid with ``num_levels`` level from the outputs of the feature encoder,
    this correlation pyramid will later be used as index to create correlation features using CorrBlock1d.
    """

    def __init__(self, num_levels: 'int\n'=4):
        super().__init__()
        self.num_levels = num_levels

    def forward(self, fmap1: 'Tensor\n', fmap2: 'Tensor\n') ->List[Tensor]:
        """Build the correlation pyramid from two feature maps.

        The correlation volume is first computed as the dot product of each pair (pixel_in_fmap1, pixel_in_fmap2) on the same row.
        The last 2 dimensions of the correlation volume are then pooled num_levels times at different resolutions
        to build the correlation pyramid.
        """
        torch._assert(fmap1.shape == fmap2.shape, f'Input feature maps should have the same shape, instead got {fmap1.shape} (fmap1.shape) != {fmap2.shape} (fmap2.shape)')
        batch_size, num_channels, h, w = fmap1.shape
        fmap1 = fmap1.view(batch_size, num_channels, h, w)
        fmap2 = fmap2.view(batch_size, num_channels, h, w)
        corr = torch.einsum('aijk,aijh->ajkh', fmap1, fmap2)
        corr = corr.view(batch_size, h, w, 1, w)
        corr_volume = corr / torch.sqrt(torch.tensor(num_channels, device=corr.device))
        corr_volume = corr_volume.reshape(batch_size * h * w, 1, 1, w)
        corr_pyramid = [corr_volume]
        for _ in range(self.num_levels - 1):
            corr_volume = F.avg_pool2d(corr_volume, kernel_size=(1, 2), stride=(1, 2))
            corr_pyramid.append(corr_volume)
        return corr_pyramid


class CorrBlock1d(nn.Module):
    """The row-wise correlation block.

    Use indexes from correlation pyramid to create correlation features.
    The "indexing" of a given centroid pixel x' is done by concatenating its surrounding row neighbours
    within radius
    """

    def __init__(self, *, num_levels: int=4, radius: int=4):
        super().__init__()
        self.radius = radius
        self.out_channels = num_levels * (2 * radius + 1)

    def forward(self, centroids_coords: 'Tensor\n', corr_pyramid: 'List[Tensor]\n') ->Tensor:
        """Return correlation features by indexing from the pyramid."""
        neighborhood_side_len = 2 * self.radius + 1
        di = torch.linspace(-self.radius, self.radius, neighborhood_side_len, device=centroids_coords.device)
        di = di.view(1, 1, neighborhood_side_len, 1)
        batch_size, _, h, w = centroids_coords.shape
        centroids_coords = centroids_coords[:, :1].permute(0, 2, 3, 1).reshape(batch_size * h * w, 1, 1, 1)
        indexed_pyramid = []
        for corr_volume in corr_pyramid:
            x0 = centroids_coords + di
            y0 = torch.zeros_like(x0)
            sampling_coords = torch.cat([x0, y0], dim=-1)
            indexed_corr_volume = grid_sample(corr_volume, sampling_coords, align_corners=True, mode='bilinear').view(batch_size, h, w, -1)
            indexed_pyramid.append(indexed_corr_volume)
            centroids_coords = centroids_coords / 2
        corr_features = torch.cat(indexed_pyramid, dim=-1).permute(0, 3, 1, 2).contiguous()
        expected_output_shape = batch_size, self.out_channels, h, w
        torch._assert(corr_features.shape == expected_output_shape, f'Output shape of index pyramid is incorrect. Should be {expected_output_shape}, got {corr_features.shape}')
        return corr_features


class RaftStereo(nn.Module):

    def __init__(self, *, feature_encoder: FeatureEncoder, context_encoder: MultiLevelContextEncoder, corr_pyramid: CorrPyramid1d, corr_block: CorrBlock1d, update_block: MultiLevelUpdateBlock, disparity_head: nn.Module, mask_predictor: Optional[nn.Module]=None, slow_fast: bool=False):
        """RAFT-Stereo model from
        `RAFT-Stereo: Multilevel Recurrent Field Transforms for Stereo Matching <https://arxiv.org/abs/2109.07547>`_.

        args:
            feature_encoder (FeatureEncoder): The feature encoder. Its input is the concatenation of ``left_image`` and ``right_image``.
            context_encoder (MultiLevelContextEncoder): The context encoder. Its input is ``left_image``.
                It has multi-level output and each level will have 2 parts:

                - one part will be used as the actual "context", passed to the recurrent unit of the ``update_block``
                - one part will be used to initialize the hidden state of the recurrent unit of
                  the ``update_block``

            corr_pyramid (CorrPyramid1d): Module to build the correlation pyramid from feature encoder output
            corr_block (CorrBlock1d): The correlation block, which uses the correlation pyramid indexes
                to create correlation features. It takes the coordinate of the centroid pixel and correlation pyramid
                as input and returns the correlation features.
                It must expose an ``out_channels`` attribute.

            update_block (MultiLevelUpdateBlock): The update block, which contains the motion encoder, and the recurrent unit.
                It takes as input the hidden state of its recurrent unit, the context, the correlation
                features, and the current predicted disparity. It outputs an updated hidden state
            disparity_head (nn.Module): The disparity head block will convert from the hidden state into changes in disparity.
            mask_predictor (nn.Module, optional): Predicts the mask that will be used to upsample the predicted flow.
                If ``None`` (default), the flow is upsampled using interpolation.
            slow_fast (bool): A boolean that specify whether we should use slow-fast GRU or not. See RAFT-Stereo paper
                on section 3.4 for more detail.
        """
        super().__init__()
        _log_api_usage_once(self)
        self.output_channels = 1
        self.feature_encoder = feature_encoder
        self.context_encoder = context_encoder
        self.base_downsampling_ratio = feature_encoder.base_downsampling_ratio
        self.num_level = self.context_encoder.num_level
        self.corr_pyramid = corr_pyramid
        self.corr_block = corr_block
        self.update_block = update_block
        self.disparity_head = disparity_head
        self.mask_predictor = mask_predictor
        hidden_dims = self.update_block.hidden_dims
        self.context_convs = nn.ModuleList([nn.Conv2d(hidden_dims[i], hidden_dims[i] * 3, kernel_size=3, padding=1) for i in range(self.num_level)])
        self.slow_fast = slow_fast

    def forward(self, left_image: 'Tensor\n', right_image: 'Tensor\n', flow_init: 'Optional[Tensor]\n'=None, num_iters: 'int\n'=12) ->List[Tensor]:
        """
        Return disparity predictions on every iteration as a list of Tensor.
        args:
            left_image (Tensor): The input left image with layout B, C, H, W
            right_image (Tensor): The input right image with layout B, C, H, W
            flow_init (Optional[Tensor]): Initial estimate for the disparity. Default: None
            num_iters (int): Number of update block iteration on the largest resolution. Default: 12
        """
        batch_size, _, h, w = left_image.shape
        torch._assert((h, w) == right_image.shape[-2:], f'input images should have the same shape, instead got ({h}, {w}) != {right_image.shape[-2:]}')
        torch._assert(h % self.base_downsampling_ratio == 0 and w % self.base_downsampling_ratio == 0, f'input image H and W should be divisible by {self.base_downsampling_ratio}, instead got H={h} and W={w}')
        fmaps = self.feature_encoder(torch.cat([left_image, right_image], dim=0))
        fmap1, fmap2 = torch.chunk(fmaps, chunks=2, dim=0)
        torch._assert(fmap1.shape[-2:] == (h // self.base_downsampling_ratio, w // self.base_downsampling_ratio), f'The feature encoder should downsample H and W by {self.base_downsampling_ratio}')
        corr_pyramid = self.corr_pyramid(fmap1, fmap2)
        context_outs = self.context_encoder(left_image)
        hidden_dims = self.update_block.hidden_dims
        context_out_channels = [(context_outs[i].shape[1] - hidden_dims[i]) for i in range(len(context_outs))]
        hidden_states: 'List[Tensor]\n' = []
        contexts: 'List[List[Tensor]]\n' = []
        for i, context_conv in enumerate(self.context_convs):
            hidden_state, context = torch.split(context_outs[i], [hidden_dims[i], context_out_channels[i]], dim=1)
            hidden_states.append(torch.tanh(hidden_state))
            contexts.append(torch.split(context_conv(F.relu(context)), [hidden_dims[i], hidden_dims[i], hidden_dims[i]], dim=1))
        _, Cf, Hf, Wf = fmap1.shape
        coords0 = make_coords_grid(batch_size, Hf, Wf)
        coords1 = make_coords_grid(batch_size, Hf, Wf)
        if flow_init is not None:
            coords1 = coords1 + flow_init
        disparity_predictions = []
        for _ in range(num_iters):
            coords1 = coords1.detach()
            corr_features = self.corr_block(centroids_coords=coords1, corr_pyramid=corr_pyramid)
            disparity = coords1 - coords0
            if self.slow_fast:
                for i in range(1, self.num_level):
                    level_processed = [False] * (self.num_level - i) + [True] * i
                    hidden_states = self.update_block(hidden_states, contexts, corr_features, disparity, level_processed=level_processed)
            hidden_states = self.update_block(hidden_states, contexts, corr_features, disparity, level_processed=[True] * self.num_level)
            hidden_state = hidden_states[0]
            delta_disparity = self.disparity_head(hidden_state)
            delta_disparity[:, (1)] = 0.0
            coords1 = coords1 + delta_disparity
            up_mask = None if self.mask_predictor is None else self.mask_predictor(hidden_state)
            upsampled_disparity = upsample_flow(coords1 - coords0, up_mask=up_mask, factor=self.base_downsampling_ratio)
            disparity_predictions.append(upsampled_disparity[:, :1])
        return disparity_predictions


class StereoMatching(torch.nn.Module):

    def __init__(self, *, use_gray_scale: bool=False, resize_size: Optional[Tuple[int, ...]], mean: Tuple[float, ...]=(0.5, 0.5, 0.5), std: Tuple[float, ...]=(0.5, 0.5, 0.5), interpolation: Union[InterpolationMode, int]=InterpolationMode.BILINEAR) ->None:
        super().__init__()
        self.resize_size: 'Union[(None, List)]\n'
        if resize_size is not None:
            self.resize_size = list(resize_size)
        else:
            self.resize_size = None
        self.mean = list(mean)
        self.std = list(std)
        self.interpolation = _check_interpolation(interpolation)
        self.use_gray_scale = use_gray_scale

    def forward(self, left_image: 'Tensor\n', right_image: 'Tensor\n') ->Tuple[Tensor, Tensor]:

        def _process_image(img: 'PIL.Image.Image\n') ->Tensor:
            if not isinstance(img, Tensor):
                img = F.pil_to_tensor(img)
            if self.resize_size is not None:
                img = F.resize(img, self.resize_size, interpolation=self.interpolation, antialias=False)
            if self.use_gray_scale is True:
                img = F.rgb_to_grayscale(img)
            img = F.convert_image_dtype(img, torch.float)
            img = F.normalize(img, mean=self.mean, std=self.std)
            img = img.contiguous()
            return img
        left_image = _process_image(left_image)
        right_image = _process_image(right_image)
        return left_image, right_image

    def __repr__(self) ->str:
        format_string = self.__class__.__name__ + '('
        format_string += f'\n    resize_size={self.resize_size}'
        format_string += f'\n    mean={self.mean}'
        format_string += f'\n    std={self.std}'
        format_string += f'\n    interpolation={self.interpolation}'
        format_string += '\n)'
        return format_string

    def describe(self) ->str:
        return f'Accepts ``PIL.Image``, batched ``(B, C, H, W)`` and single ``(C, H, W)`` image ``torch.Tensor`` objects. The images are resized to ``resize_size={self.resize_size}`` using ``interpolation={self.interpolation}``. Finally the values are first rescaled to ``[0.0, 1.0]`` and then normalized using ``mean={self.mean}`` and ``std={self.std}``.'


class _RandomApplyTransform(Transform):

    def __init__(self, p: 'float\n'=0.5) ->None:
        if not 0.0 <= p <= 1.0:
            raise ValueError('`p` should be a floating point value in the interval [0.0, 1.0].')
        super().__init__()
        self.p = p

    def forward(self, *inputs: Any) ->Any:
        inputs = inputs if len(inputs) > 1 else inputs[0]
        flat_inputs, spec = tree_flatten(inputs)
        self._check_inputs(flat_inputs)
        if torch.rand(1) >= self.p:
            return inputs
        needs_transform_list = self._needs_transform_list(flat_inputs)
        params = self._get_params([inpt for inpt, needs_transform in zip(flat_inputs, needs_transform_list) if needs_transform])
        flat_outputs = [(self._transform(inpt, params) if needs_transform else inpt) for inpt, needs_transform in zip(flat_inputs, needs_transform_list)]
        return tree_unflatten(flat_outputs, spec)


class ObjectDetection(nn.Module):

    def forward(self, img: 'Tensor\n') ->Tensor:
        if not isinstance(img, Tensor):
            img = F.pil_to_tensor(img)
        return F.convert_image_dtype(img, torch.float)

    def __repr__(self) ->str:
        return self.__class__.__name__ + '()'

    def describe(self) ->str:
        return 'Accepts ``PIL.Image``, batched ``(B, C, H, W)`` and single ``(C, H, W)`` image ``torch.Tensor`` objects. The images are rescaled to ``[0.0, 1.0]``.'


class ImageClassification(nn.Module):

    def __init__(self, *, crop_size: int, resize_size: int=256, mean: Tuple[float, ...]=(0.485, 0.456, 0.406), std: Tuple[float, ...]=(0.229, 0.224, 0.225), interpolation: InterpolationMode=InterpolationMode.BILINEAR, antialias: Optional[Union[str, bool]]='warn') ->None:
        super().__init__()
        self.crop_size = [crop_size]
        self.resize_size = [resize_size]
        self.mean = list(mean)
        self.std = list(std)
        self.interpolation = interpolation
        self.antialias = antialias

    def forward(self, img: 'Tensor\n') ->Tensor:
        img = F.resize(img, self.resize_size, interpolation=self.interpolation, antialias=self.antialias)
        img = F.center_crop(img, self.crop_size)
        if not isinstance(img, Tensor):
            img = F.pil_to_tensor(img)
        img = F.convert_image_dtype(img, torch.float)
        img = F.normalize(img, mean=self.mean, std=self.std)
        return img

    def __repr__(self) ->str:
        format_string = self.__class__.__name__ + '('
        format_string += f'\n    crop_size={self.crop_size}'
        format_string += f'\n    resize_size={self.resize_size}'
        format_string += f'\n    mean={self.mean}'
        format_string += f'\n    std={self.std}'
        format_string += f'\n    interpolation={self.interpolation}'
        format_string += '\n)'
        return format_string

    def describe(self) ->str:
        return f'Accepts ``PIL.Image``, batched ``(B, C, H, W)`` and single ``(C, H, W)`` image ``torch.Tensor`` objects. The images are resized to ``resize_size={self.resize_size}`` using ``interpolation={self.interpolation}``, followed by a central crop of ``crop_size={self.crop_size}``. Finally the values are first rescaled to ``[0.0, 1.0]`` and then normalized using ``mean={self.mean}`` and ``std={self.std}``.'


class VideoClassification(nn.Module):

    def __init__(self, *, crop_size: Tuple[int, int], resize_size: Tuple[int, int], mean: Tuple[float, ...]=(0.43216, 0.394666, 0.37645), std: Tuple[float, ...]=(0.22803, 0.22145, 0.216989), interpolation: InterpolationMode=InterpolationMode.BILINEAR) ->None:
        super().__init__()
        self.crop_size = list(crop_size)
        self.resize_size = list(resize_size)
        self.mean = list(mean)
        self.std = list(std)
        self.interpolation = interpolation

    def forward(self, vid: 'Tensor\n') ->Tensor:
        need_squeeze = False
        if vid.ndim < 5:
            vid = vid.unsqueeze(dim=0)
            need_squeeze = True
        N, T, C, H, W = vid.shape
        vid = vid.view(-1, C, H, W)
        vid = F.resize(vid, self.resize_size, interpolation=self.interpolation, antialias=False)
        vid = F.center_crop(vid, self.crop_size)
        vid = F.convert_image_dtype(vid, torch.float)
        vid = F.normalize(vid, mean=self.mean, std=self.std)
        H, W = self.crop_size
        vid = vid.view(N, T, C, H, W)
        vid = vid.permute(0, 2, 1, 3, 4)
        if need_squeeze:
            vid = vid.squeeze(dim=0)
        return vid

    def __repr__(self) ->str:
        format_string = self.__class__.__name__ + '('
        format_string += f'\n    crop_size={self.crop_size}'
        format_string += f'\n    resize_size={self.resize_size}'
        format_string += f'\n    mean={self.mean}'
        format_string += f'\n    std={self.std}'
        format_string += f'\n    interpolation={self.interpolation}'
        format_string += '\n)'
        return format_string

    def describe(self) ->str:
        return f'Accepts batched ``(B, T, C, H, W)`` and single ``(T, C, H, W)`` video frame ``torch.Tensor`` objects. The frames are resized to ``resize_size={self.resize_size}`` using ``interpolation={self.interpolation}``, followed by a central crop of ``crop_size={self.crop_size}``. Finally the values are first rescaled to ``[0.0, 1.0]`` and then normalized using ``mean={self.mean}`` and ``std={self.std}``. Finally the output dimensions are permuted to ``(..., C, T, H, W)`` tensors.'


class SemanticSegmentation(nn.Module):

    def __init__(self, *, resize_size: Optional[int], mean: Tuple[float, ...]=(0.485, 0.456, 0.406), std: Tuple[float, ...]=(0.229, 0.224, 0.225), interpolation: InterpolationMode=InterpolationMode.BILINEAR, antialias: Optional[Union[str, bool]]='warn') ->None:
        super().__init__()
        self.resize_size = [resize_size] if resize_size is not None else None
        self.mean = list(mean)
        self.std = list(std)
        self.interpolation = interpolation
        self.antialias = antialias

    def forward(self, img: 'Tensor\n') ->Tensor:
        if isinstance(self.resize_size, list):
            img = F.resize(img, self.resize_size, interpolation=self.interpolation, antialias=self.antialias)
        if not isinstance(img, Tensor):
            img = F.pil_to_tensor(img)
        img = F.convert_image_dtype(img, torch.float)
        img = F.normalize(img, mean=self.mean, std=self.std)
        return img

    def __repr__(self) ->str:
        format_string = self.__class__.__name__ + '('
        format_string += f'\n    resize_size={self.resize_size}'
        format_string += f'\n    mean={self.mean}'
        format_string += f'\n    std={self.std}'
        format_string += f'\n    interpolation={self.interpolation}'
        format_string += '\n)'
        return format_string

    def describe(self) ->str:
        return f'Accepts ``PIL.Image``, batched ``(B, C, H, W)`` and single ``(C, H, W)`` image ``torch.Tensor`` objects. The images are resized to ``resize_size={self.resize_size}`` using ``interpolation={self.interpolation}``. Finally the values are first rescaled to ``[0.0, 1.0]`` and then normalized using ``mean={self.mean}`` and ``std={self.std}``.'


class OpticalFlow(nn.Module):

    def forward(self, img1: 'Tensor\n', img2: 'Tensor\n') ->Tuple[Tensor, Tensor]:
        if not isinstance(img1, Tensor):
            img1 = F.pil_to_tensor(img1)
        if not isinstance(img2, Tensor):
            img2 = F.pil_to_tensor(img2)
        img1 = F.convert_image_dtype(img1, torch.float)
        img2 = F.convert_image_dtype(img2, torch.float)
        img1 = F.normalize(img1, mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
        img2 = F.normalize(img2, mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
        img1 = img1.contiguous()
        img2 = img2.contiguous()
        return img1, img2

    def __repr__(self) ->str:
        return self.__class__.__name__ + '()'

    def describe(self) ->str:
        return 'Accepts ``PIL.Image``, batched ``(B, C, H, W)`` and single ``(C, H, W)`` image ``torch.Tensor`` objects. The images are rescaled to ``[-1.0, 1.0]``.'


class AutoAugment(torch.nn.Module):
    """AutoAugment data augmentation method based on
    `"AutoAugment: Learning Augmentation Strategies from Data" <https://arxiv.org/pdf/1805.09501.pdf>`_.
    If the image is torch Tensor, it should be of type torch.uint8, and it is expected
    to have [..., 1 or 3, H, W] shape, where ... means an arbitrary number of leading dimensions.
    If img is PIL Image, it is expected to be in mode "L" or "RGB".

    Args:
        policy (AutoAugmentPolicy): Desired policy enum defined by
            :class:`torchvision.transforms.autoaugment.AutoAugmentPolicy`. Default is ``AutoAugmentPolicy.IMAGENET``.
        interpolation (InterpolationMode): Desired interpolation enum defined by
            :class:`torchvision.transforms.InterpolationMode`. Default is ``InterpolationMode.NEAREST``.
            If input is Tensor, only ``InterpolationMode.NEAREST``, ``InterpolationMode.BILINEAR`` are supported.
        fill (sequence or number, optional): Pixel fill value for the area outside the transformed
            image. If given a number, the value is used for all bands respectively.
    """

    def __init__(self, policy: 'AutoAugmentPolicy\n'=AutoAugmentPolicy.IMAGENET, interpolation: 'InterpolationMode\n'=InterpolationMode.NEAREST, fill: 'Optional[List[float]]\n'=None) ->None:
        super().__init__()
        self.policy = policy
        self.interpolation = interpolation
        self.fill = fill
        self.policies = self._get_policies(policy)

    def _get_policies(self, policy: 'AutoAugmentPolicy\n') ->List[Tuple[Tuple[str, float, Optional[int]], Tuple[str, float, Optional[int]]]]:
        if policy == AutoAugmentPolicy.IMAGENET:
            return [(('Posterize', 0.4, 8), ('Rotate', 0.6, 9)), (('Solarize', 0.6, 5), ('AutoContrast', 0.6, None)), (('Equalize', 0.8, None), ('Equalize', 0.6, None)), (('Posterize', 0.6, 7), ('Posterize', 0.6, 6)), (('Equalize', 0.4, None), ('Solarize', 0.2, 4)), (('Equalize', 0.4, None), ('Rotate', 0.8, 8)), (('Solarize', 0.6, 3), ('Equalize', 0.6, None)), (('Posterize', 0.8, 5), ('Equalize', 1.0, None)), (('Rotate', 0.2, 3), ('Solarize', 0.6, 8)), (('Equalize', 0.6, None), ('Posterize', 0.4, 6)), (('Rotate', 0.8, 8), ('Color', 0.4, 0)), (('Rotate', 0.4, 9), ('Equalize', 0.6, None)), (('Equalize', 0.0, None), ('Equalize', 0.8, None)), (('Invert', 0.6, None), ('Equalize', 1.0, None)), (('Color', 0.6, 4), ('Contrast', 1.0, 8)), (('Rotate', 0.8, 8), ('Color', 1.0, 2)), (('Color', 0.8, 8), ('Solarize', 0.8, 7)), (('Sharpness', 0.4, 7), ('Invert', 0.6, None)), (('ShearX', 0.6, 5), ('Equalize', 1.0, None)), (('Color', 0.4, 0), ('Equalize', 0.6, None)), (('Equalize', 0.4, None), ('Solarize', 0.2, 4)), (('Solarize', 0.6, 5), ('AutoContrast', 0.6, None)), (('Invert', 0.6, None), ('Equalize', 1.0, None)), (('Color', 0.6, 4), ('Contrast', 1.0, 8)), (('Equalize', 0.8, None), ('Equalize', 0.6, None))]
        elif policy == AutoAugmentPolicy.CIFAR10:
            return [(('Invert', 0.1, None), ('Contrast', 0.2, 6)), (('Rotate', 0.7, 2), ('TranslateX', 0.3, 9)), (('Sharpness', 0.8, 1), ('Sharpness', 0.9, 3)), (('ShearY', 0.5, 8), ('TranslateY', 0.7, 9)), (('AutoContrast', 0.5, None), ('Equalize', 0.9, None)), (('ShearY', 0.2, 7), ('Posterize', 0.3, 7)), (('Color', 0.4, 3), ('Brightness', 0.6, 7)), (('Sharpness', 0.3, 9), ('Brightness', 0.7, 9)), (('Equalize', 0.6, None), ('Equalize', 0.5, None)), (('Contrast', 0.6, 7), ('Sharpness', 0.6, 5)), (('Color', 0.7, 7), ('TranslateX', 0.5, 8)), (('Equalize', 0.3, None), ('AutoContrast', 0.4, None)), (('TranslateY', 0.4, 3), ('Sharpness', 0.2, 6)), (('Brightness', 0.9, 6), ('Color', 0.2, 8)), (('Solarize', 0.5, 2), ('Invert', 0.0, None)), (('Equalize', 0.2, None), ('AutoContrast', 0.6, None)), (('Equalize', 0.2, None), ('Equalize', 0.6, None)), (('Color', 0.9, 9), ('Equalize', 0.6, None)), (('AutoContrast', 0.8, None), ('Solarize', 0.2, 8)), (('Brightness', 0.1, 3), ('Color', 0.7, 0)), (('Solarize', 0.4, 5), ('AutoContrast', 0.9, None)), (('TranslateY', 0.9, 9), ('TranslateY', 0.7, 9)), (('AutoContrast', 0.9, None), ('Solarize', 0.8, 3)), (('Equalize', 0.8, None), ('Invert', 0.1, None)), (('TranslateY', 0.7, 9), ('AutoContrast', 0.9, None))]
        elif policy == AutoAugmentPolicy.SVHN:
            return [(('ShearX', 0.9, 4), ('Invert', 0.2, None)), (('ShearY', 0.9, 8), ('Invert', 0.7, None)), (('Equalize', 0.6, None), ('Solarize', 0.6, 6)), (('Invert', 0.9, None), ('Equalize', 0.6, None)), (('Equalize', 0.6, None), ('Rotate', 0.9, 3)), (('ShearX', 0.9, 4), ('AutoContrast', 0.8, None)), (('ShearY', 0.9, 8), ('Invert', 0.4, None)), (('ShearY', 0.9, 5), ('Solarize', 0.2, 6)), (('Invert', 0.9, None), ('AutoContrast', 0.8, None)), (('Equalize', 0.6, None), ('Rotate', 0.9, 3)), (('ShearX', 0.9, 4), ('Solarize', 0.3, 3)), (('ShearY', 0.8, 8), ('Invert', 0.7, None)), (('Equalize', 0.9, None), ('TranslateY', 0.6, 6)), (('Invert', 0.9, None), ('Equalize', 0.6, None)), (('Contrast', 0.3, 3), ('Rotate', 0.8, 4)), (('Invert', 0.8, None), ('TranslateY', 0.0, 2)), (('ShearY', 0.7, 6), ('Solarize', 0.4, 8)), (('Invert', 0.6, None), ('Rotate', 0.8, 4)), (('ShearY', 0.3, 7), ('TranslateX', 0.9, 3)), (('ShearX', 0.1, 6), ('Invert', 0.6, None)), (('Solarize', 0.7, 2), ('TranslateY', 0.6, 7)), (('ShearY', 0.8, 4), ('Invert', 0.8, None)), (('ShearX', 0.7, 9), ('TranslateY', 0.8, 3)), (('ShearY', 0.8, 5), ('AutoContrast', 0.7, None)), (('ShearX', 0.7, 2), ('Invert', 0.1, None))]
        else:
            raise ValueError(f'The provided policy {policy} is not recognized.')

    def _augmentation_space(self, num_bins: 'int\n', image_size: 'Tuple[(int, int)]\n') ->Dict[str, Tuple[Tensor, bool]]:
        return {'ShearX': (torch.linspace(0.0, 0.3, num_bins), True), 'ShearY': (torch.linspace(0.0, 0.3, num_bins), True), 'TranslateX': (torch.linspace(0.0, 150.0 / 331.0 * image_size[1], num_bins), True), 'TranslateY': (torch.linspace(0.0, 150.0 / 331.0 * image_size[0], num_bins), True), 'Rotate': (torch.linspace(0.0, 30.0, num_bins), True), 'Brightness': (torch.linspace(0.0, 0.9, num_bins), True), 'Color': (torch.linspace(0.0, 0.9, num_bins), True), 'Contrast': (torch.linspace(0.0, 0.9, num_bins), True), 'Sharpness': (torch.linspace(0.0, 0.9, num_bins), True), 'Posterize': (8 - (torch.arange(num_bins) / ((num_bins - 1) / 4)).round().int(), False), 'Solarize': (torch.linspace(255.0, 0.0, num_bins), False), 'AutoContrast': (torch.tensor(0.0), False), 'Equalize': (torch.tensor(0.0), False), 'Invert': (torch.tensor(0.0), False)}

    @staticmethod
    def get_params(transform_num: 'int\n') ->Tuple[int, Tensor, Tensor]:
        """Get parameters for autoaugment transformation

        Returns:
            params required by the autoaugment transformation
        """
        policy_id = int(torch.randint(transform_num, (1,)).item())
        probs = torch.rand((2,))
        signs = torch.randint(2, (2,))
        return policy_id, probs, signs

    def forward(self, img: 'Tensor\n') ->Tensor:
        """
            img (PIL Image or Tensor): Image to be transformed.

        Returns:
            PIL Image or Tensor: AutoAugmented image.
        """
        fill = self.fill
        channels, height, width = F.get_dimensions(img)
        if isinstance(img, Tensor):
            if isinstance(fill, (int, float)):
                fill = [float(fill)] * channels
            elif fill is not None:
                fill = [float(f) for f in fill]
        transform_id, probs, signs = self.get_params(len(self.policies))
        op_meta = self._augmentation_space(10, (height, width))
        for i, (op_name, p, magnitude_id) in enumerate(self.policies[transform_id]):
            if probs[i] <= p:
                magnitudes, signed = op_meta[op_name]
                magnitude = float(magnitudes[magnitude_id].item()) if magnitude_id is not None else 0.0
                if signed and signs[i] == 0:
                    magnitude *= -1.0
                img = _apply_op(img, op_name, magnitude, interpolation=self.interpolation, fill=fill)
        return img

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}(policy={self.policy}, fill={self.fill})'


class RandAugment(torch.nn.Module):
    """RandAugment data augmentation method based on
    `"RandAugment: Practical automated data augmentation with a reduced search space"
    <https://arxiv.org/abs/1909.13719>`_.
    If the image is torch Tensor, it should be of type torch.uint8, and it is expected
    to have [..., 1 or 3, H, W] shape, where ... means an arbitrary number of leading dimensions.
    If img is PIL Image, it is expected to be in mode "L" or "RGB".

    Args:
        num_ops (int): Number of augmentation transformations to apply sequentially.
        magnitude (int): Magnitude for all the transformations.
        num_magnitude_bins (int): The number of different magnitude values.
        interpolation (InterpolationMode): Desired interpolation enum defined by
            :class:`torchvision.transforms.InterpolationMode`. Default is ``InterpolationMode.NEAREST``.
            If input is Tensor, only ``InterpolationMode.NEAREST``, ``InterpolationMode.BILINEAR`` are supported.
        fill (sequence or number, optional): Pixel fill value for the area outside the transformed
            image. If given a number, the value is used for all bands respectively.
    """

    def __init__(self, num_ops: 'int\n'=2, magnitude: 'int\n'=9, num_magnitude_bins: 'int\n'=31, interpolation: 'InterpolationMode\n'=InterpolationMode.NEAREST, fill: 'Optional[List[float]]\n'=None) ->None:
        super().__init__()
        self.num_ops = num_ops
        self.magnitude = magnitude
        self.num_magnitude_bins = num_magnitude_bins
        self.interpolation = interpolation
        self.fill = fill

    def _augmentation_space(self, num_bins: 'int\n', image_size: 'Tuple[(int, int)]\n') ->Dict[str, Tuple[Tensor, bool]]:
        return {'Identity': (torch.tensor(0.0), False), 'ShearX': (torch.linspace(0.0, 0.3, num_bins), True), 'ShearY': (torch.linspace(0.0, 0.3, num_bins), True), 'TranslateX': (torch.linspace(0.0, 150.0 / 331.0 * image_size[1], num_bins), True), 'TranslateY': (torch.linspace(0.0, 150.0 / 331.0 * image_size[0], num_bins), True), 'Rotate': (torch.linspace(0.0, 30.0, num_bins), True), 'Brightness': (torch.linspace(0.0, 0.9, num_bins), True), 'Color': (torch.linspace(0.0, 0.9, num_bins), True), 'Contrast': (torch.linspace(0.0, 0.9, num_bins), True), 'Sharpness': (torch.linspace(0.0, 0.9, num_bins), True), 'Posterize': (8 - (torch.arange(num_bins) / ((num_bins - 1) / 4)).round().int(), False), 'Solarize': (torch.linspace(255.0, 0.0, num_bins), False), 'AutoContrast': (torch.tensor(0.0), False), 'Equalize': (torch.tensor(0.0), False)}

    def forward(self, img: 'Tensor\n') ->Tensor:
        """
            img (PIL Image or Tensor): Image to be transformed.

        Returns:
            PIL Image or Tensor: Transformed image.
        """
        fill = self.fill
        channels, height, width = F.get_dimensions(img)
        if isinstance(img, Tensor):
            if isinstance(fill, (int, float)):
                fill = [float(fill)] * channels
            elif fill is not None:
                fill = [float(f) for f in fill]
        op_meta = self._augmentation_space(self.num_magnitude_bins, (height, width))
        for _ in range(self.num_ops):
            op_index = int(torch.randint(len(op_meta), (1,)).item())
            op_name = list(op_meta.keys())[op_index]
            magnitudes, signed = op_meta[op_name]
            magnitude = float(magnitudes[self.magnitude].item()) if magnitudes.ndim > 0 else 0.0
            if signed and torch.randint(2, (1,)):
                magnitude *= -1.0
            img = _apply_op(img, op_name, magnitude, interpolation=self.interpolation, fill=fill)
        return img

    def __repr__(self) ->str:
        s = f'{self.__class__.__name__}(num_ops={self.num_ops}, magnitude={self.magnitude}, num_magnitude_bins={self.num_magnitude_bins}, interpolation={self.interpolation}, fill={self.fill})'
        return s


class TrivialAugmentWide(torch.nn.Module):
    """Dataset-independent data-augmentation with TrivialAugment Wide, as described in
    `"TrivialAugment: Tuning-free Yet State-of-the-Art Data Augmentation" <https://arxiv.org/abs/2103.10158>`_.
    If the image is torch Tensor, it should be of type torch.uint8, and it is expected
    to have [..., 1 or 3, H, W] shape, where ... means an arbitrary number of leading dimensions.
    If img is PIL Image, it is expected to be in mode "L" or "RGB".

    Args:
        num_magnitude_bins (int): The number of different magnitude values.
        interpolation (InterpolationMode): Desired interpolation enum defined by
            :class:`torchvision.transforms.InterpolationMode`. Default is ``InterpolationMode.NEAREST``.
            If input is Tensor, only ``InterpolationMode.NEAREST``, ``InterpolationMode.BILINEAR`` are supported.
        fill (sequence or number, optional): Pixel fill value for the area outside the transformed
            image. If given a number, the value is used for all bands respectively.
    """

    def __init__(self, num_magnitude_bins: 'int\n'=31, interpolation: 'InterpolationMode\n'=InterpolationMode.NEAREST, fill: 'Optional[List[float]]\n'=None) ->None:
        super().__init__()
        self.num_magnitude_bins = num_magnitude_bins
        self.interpolation = interpolation
        self.fill = fill

    def _augmentation_space(self, num_bins: 'int\n') ->Dict[str, Tuple[Tensor, bool]]:
        return {'Identity': (torch.tensor(0.0), False), 'ShearX': (torch.linspace(0.0, 0.99, num_bins), True), 'ShearY': (torch.linspace(0.0, 0.99, num_bins), True), 'TranslateX': (torch.linspace(0.0, 32.0, num_bins), True), 'TranslateY': (torch.linspace(0.0, 32.0, num_bins), True), 'Rotate': (torch.linspace(0.0, 135.0, num_bins), True), 'Brightness': (torch.linspace(0.0, 0.99, num_bins), True), 'Color': (torch.linspace(0.0, 0.99, num_bins), True), 'Contrast': (torch.linspace(0.0, 0.99, num_bins), True), 'Sharpness': (torch.linspace(0.0, 0.99, num_bins), True), 'Posterize': (8 - (torch.arange(num_bins) / ((num_bins - 1) / 6)).round().int(), False), 'Solarize': (torch.linspace(255.0, 0.0, num_bins), False), 'AutoContrast': (torch.tensor(0.0), False), 'Equalize': (torch.tensor(0.0), False)}

    def forward(self, img: 'Tensor\n') ->Tensor:
        """
            img (PIL Image or Tensor): Image to be transformed.

        Returns:
            PIL Image or Tensor: Transformed image.
        """
        fill = self.fill
        channels, height, width = F.get_dimensions(img)
        if isinstance(img, Tensor):
            if isinstance(fill, (int, float)):
                fill = [float(fill)] * channels
            elif fill is not None:
                fill = [float(f) for f in fill]
        op_meta = self._augmentation_space(self.num_magnitude_bins)
        op_index = int(torch.randint(len(op_meta), (1,)).item())
        op_name = list(op_meta.keys())[op_index]
        magnitudes, signed = op_meta[op_name]
        magnitude = float(magnitudes[torch.randint(len(magnitudes), (1,), dtype=torch.long)].item()) if magnitudes.ndim > 0 else 0.0
        if signed and torch.randint(2, (1,)):
            magnitude *= -1.0
        return _apply_op(img, op_name, magnitude, interpolation=self.interpolation, fill=fill)

    def __repr__(self) ->str:
        s = f'{self.__class__.__name__}(num_magnitude_bins={self.num_magnitude_bins}, interpolation={self.interpolation}, fill={self.fill})'
        return s


class AugMix(torch.nn.Module):
    """AugMix data augmentation method based on
    `"AugMix: A Simple Data Processing Method to Improve Robustness and Uncertainty" <https://arxiv.org/abs/1912.02781>`_.
    If the image is torch Tensor, it should be of type torch.uint8, and it is expected
    to have [..., 1 or 3, H, W] shape, where ... means an arbitrary number of leading dimensions.
    If img is PIL Image, it is expected to be in mode "L" or "RGB".

    Args:
        severity (int): The severity of base augmentation operators. Default is ``3``.
        mixture_width (int): The number of augmentation chains. Default is ``3``.
        chain_depth (int): The depth of augmentation chains. A negative value denotes stochastic depth sampled from the interval [1, 3].
            Default is ``-1``.
        alpha (float): The hyperparameter for the probability distributions. Default is ``1.0``.
        all_ops (bool): Use all operations (including brightness, contrast, color and sharpness). Default is ``True``.
        interpolation (InterpolationMode): Desired interpolation enum defined by
            :class:`torchvision.transforms.InterpolationMode`. Default is ``InterpolationMode.NEAREST``.
            If input is Tensor, only ``InterpolationMode.NEAREST``, ``InterpolationMode.BILINEAR`` are supported.
        fill (sequence or number, optional): Pixel fill value for the area outside the transformed
            image. If given a number, the value is used for all bands respectively.
    """

    def __init__(self, severity: 'int\n'=3, mixture_width: 'int\n'=3, chain_depth: 'int\n'=-1, alpha: 'float\n'=1.0, all_ops: 'bool\n'=True, interpolation: 'InterpolationMode\n'=InterpolationMode.BILINEAR, fill: 'Optional[List[float]]\n'=None) ->None:
        super().__init__()
        self._PARAMETER_MAX = 10
        if not 1 <= severity <= self._PARAMETER_MAX:
            raise ValueError(f'The severity must be between [1, {self._PARAMETER_MAX}]. Got {severity} instead.')
        self.severity = severity
        self.mixture_width = mixture_width
        self.chain_depth = chain_depth
        self.alpha = alpha
        self.all_ops = all_ops
        self.interpolation = interpolation
        self.fill = fill

    def _augmentation_space(self, num_bins: 'int\n', image_size: 'Tuple[(int, int)]\n') ->Dict[str, Tuple[Tensor, bool]]:
        s = {'ShearX': (torch.linspace(0.0, 0.3, num_bins), True), 'ShearY': (torch.linspace(0.0, 0.3, num_bins), True), 'TranslateX': (torch.linspace(0.0, image_size[1] / 3.0, num_bins), True), 'TranslateY': (torch.linspace(0.0, image_size[0] / 3.0, num_bins), True), 'Rotate': (torch.linspace(0.0, 30.0, num_bins), True), 'Posterize': (4 - (torch.arange(num_bins) / ((num_bins - 1) / 4)).round().int(), False), 'Solarize': (torch.linspace(255.0, 0.0, num_bins), False), 'AutoContrast': (torch.tensor(0.0), False), 'Equalize': (torch.tensor(0.0), False)}
        if self.all_ops:
            s.update({'Brightness': (torch.linspace(0.0, 0.9, num_bins), True), 'Color': (torch.linspace(0.0, 0.9, num_bins), True), 'Contrast': (torch.linspace(0.0, 0.9, num_bins), True), 'Sharpness': (torch.linspace(0.0, 0.9, num_bins), True)})
        return s

    @torch.jit.unused
    def _pil_to_tensor(self, img) ->Tensor:
        return F.pil_to_tensor(img)

    @torch.jit.unused
    def _tensor_to_pil(self, img: 'Tensor\n'):
        return F.to_pil_image(img)

    def _sample_dirichlet(self, params: 'Tensor\n') ->Tensor:
        return torch._sample_dirichlet(params)

    def forward(self, orig_img: 'Tensor\n') ->Tensor:
        """
            img (PIL Image or Tensor): Image to be transformed.

        Returns:
            PIL Image or Tensor: Transformed image.
        """
        fill = self.fill
        channels, height, width = F.get_dimensions(orig_img)
        if isinstance(orig_img, Tensor):
            img = orig_img
            if isinstance(fill, (int, float)):
                fill = [float(fill)] * channels
            elif fill is not None:
                fill = [float(f) for f in fill]
        else:
            img = self._pil_to_tensor(orig_img)
        op_meta = self._augmentation_space(self._PARAMETER_MAX, (height, width))
        orig_dims = list(img.shape)
        batch = img.view([1] * max(4 - img.ndim, 0) + orig_dims)
        batch_dims = [batch.size(0)] + [1] * (batch.ndim - 1)
        m = self._sample_dirichlet(torch.tensor([self.alpha, self.alpha], device=batch.device).expand(batch_dims[0], -1))
        combined_weights = self._sample_dirichlet(torch.tensor([self.alpha] * self.mixture_width, device=batch.device).expand(batch_dims[0], -1)) * m[:, (1)].view([batch_dims[0], -1])
        mix = m[:, (0)].view(batch_dims) * batch
        for i in range(self.mixture_width):
            aug = batch
            depth = self.chain_depth if self.chain_depth > 0 else int(torch.randint(low=1, high=4, size=(1,)).item())
            for _ in range(depth):
                op_index = int(torch.randint(len(op_meta), (1,)).item())
                op_name = list(op_meta.keys())[op_index]
                magnitudes, signed = op_meta[op_name]
                magnitude = float(magnitudes[torch.randint(self.severity, (1,), dtype=torch.long)].item()) if magnitudes.ndim > 0 else 0.0
                if signed and torch.randint(2, (1,)):
                    magnitude *= -1.0
                aug = _apply_op(aug, op_name, magnitude, interpolation=self.interpolation, fill=fill)
            mix.add_(combined_weights[:, (i)].view(batch_dims) * aug)
        mix = mix.view(orig_dims)
        if not isinstance(orig_img, Tensor):
            return self._tensor_to_pil(mix)
        return mix

    def __repr__(self) ->str:
        s = f'{self.__class__.__name__}(severity={self.severity}, mixture_width={self.mixture_width}, chain_depth={self.chain_depth}, alpha={self.alpha}, all_ops={self.all_ops}, interpolation={self.interpolation}, fill={self.fill})'
        return s


class CenterCrop(torch.nn.Module):
    """Crops the given image at the center.
    If the image is torch Tensor, it is expected
    to have [..., H, W] shape, where ... means an arbitrary number of leading dimensions.
    If image size is smaller than output size along any edge, image is padded with 0 and then center cropped.

    Args:
        size (sequence or int): Desired output size of the crop. If size is an
            int instead of sequence like (h, w), a square crop (size, size) is
            made. If provided a sequence of length 1, it will be interpreted as (size[0], size[0]).
    """

    def __init__(self, size):
        super().__init__()
        _log_api_usage_once(self)
        self.size = _setup_size(size, error_msg='Please provide only two dimensions (h, w) for size.')

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Image to be cropped.

        Returns:
            PIL Image or Tensor: Cropped image.
        """
        return F.center_crop(img, self.size)

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}(size={self.size})'


class Pad(torch.nn.Module):
    """Pad the given image on all sides with the given "pad" value.
    If the image is torch Tensor, it is expected
    to have [..., H, W] shape, where ... means at most 2 leading dimensions for mode reflect and symmetric,
    at most 3 leading dimensions for mode edge,
    and an arbitrary number of leading dimensions for mode constant

    Args:
        padding (int or sequence): Padding on each border. If a single int is provided this
            is used to pad all borders. If sequence of length 2 is provided this is the padding
            on left/right and top/bottom respectively. If a sequence of length 4 is provided
            this is the padding for the left, top, right and bottom borders respectively.

            .. note::
                In torchscript mode padding as single int is not supported, use a sequence of
                length 1: ``[padding, ]``.
        fill (number or tuple): Pixel fill value for constant fill. Default is 0. If a tuple of
            length 3, it is used to fill R, G, B channels respectively.
            This value is only used when the padding_mode is constant.
            Only number is supported for torch Tensor.
            Only int or tuple value is supported for PIL Image.
        padding_mode (str): Type of padding. Should be: constant, edge, reflect or symmetric.
            Default is constant.

            - constant: pads with a constant value, this value is specified with fill

            - edge: pads with the last value at the edge of the image.
              If input a 5D torch Tensor, the last 3 dimensions will be padded instead of the last 2

            - reflect: pads with reflection of image without repeating the last value on the edge.
              For example, padding [1, 2, 3, 4] with 2 elements on both sides in reflect mode
              will result in [3, 2, 1, 2, 3, 4, 3, 2]

            - symmetric: pads with reflection of image repeating the last value on the edge.
              For example, padding [1, 2, 3, 4] with 2 elements on both sides in symmetric mode
              will result in [2, 1, 1, 2, 3, 4, 4, 3]
    """

    def __init__(self, padding, fill=0, padding_mode='constant'):
        super().__init__()
        _log_api_usage_once(self)
        if not isinstance(padding, (numbers.Number, tuple, list)):
            raise TypeError('Got inappropriate padding arg')
        if not isinstance(fill, (numbers.Number, tuple, list)):
            raise TypeError('Got inappropriate fill arg')
        if padding_mode not in ['constant', 'edge', 'reflect', 'symmetric']:
            raise ValueError('Padding mode should be either constant, edge, reflect or symmetric')
        if isinstance(padding, Sequence) and len(padding) not in [1, 2, 4]:
            raise ValueError(f'Padding must be an int or a 1, 2, or 4 element tuple, not a {len(padding)} element tuple')
        self.padding = padding
        self.fill = fill
        self.padding_mode = padding_mode

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Image to be padded.

        Returns:
            PIL Image or Tensor: Padded image.
        """
        return F.pad(img, self.padding, self.fill, self.padding_mode)

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}(padding={self.padding}, fill={self.fill}, padding_mode={self.padding_mode})'


class RandomApply(torch.nn.Module):
    """Apply randomly a list of transformations with a given probability.

    .. note::
        In order to script the transformation, please use ``torch.nn.ModuleList`` as input instead of list/tuple of
        transforms as shown below:

        >>> transforms = transforms.RandomApply(torch.nn.ModuleList([
        >>>     transforms.ColorJitter(),
        >>> ]), p=0.3)
        >>> scripted_transforms = torch.jit.script(transforms)

        Make sure to use only scriptable transformations, i.e. that work with ``torch.Tensor``, does not require
        `lambda` functions or ``PIL.Image``.

    Args:
        transforms (sequence or torch.nn.Module): list of transformations
        p (float): probability
    """

    def __init__(self, transforms, p=0.5):
        super().__init__()
        _log_api_usage_once(self)
        self.transforms = transforms
        self.p = p

    def forward(self, img):
        if self.p < torch.rand(1):
            return img
        for t in self.transforms:
            img = t(img)
        return img

    def __repr__(self) ->str:
        format_string = self.__class__.__name__ + '('
        format_string += f'\n    p={self.p}'
        for t in self.transforms:
            format_string += '\n'
            format_string += f'    {t}'
        format_string += '\n)'
        return format_string


class RandomCrop(torch.nn.Module):
    """Crop the given image at a random location.
    If the image is torch Tensor, it is expected
    to have [..., H, W] shape, where ... means an arbitrary number of leading dimensions,
    but if non-constant padding is used, the input is expected to have at most 2 leading dimensions

    Args:
        size (sequence or int): Desired output size of the crop. If size is an
            int instead of sequence like (h, w), a square crop (size, size) is
            made. If provided a sequence of length 1, it will be interpreted as (size[0], size[0]).
        padding (int or sequence, optional): Optional padding on each border
            of the image. Default is None. If a single int is provided this
            is used to pad all borders. If sequence of length 2 is provided this is the padding
            on left/right and top/bottom respectively. If a sequence of length 4 is provided
            this is the padding for the left, top, right and bottom borders respectively.

            .. note::
                In torchscript mode padding as single int is not supported, use a sequence of
                length 1: ``[padding, ]``.
        pad_if_needed (boolean): It will pad the image if smaller than the
            desired size to avoid raising an exception. Since cropping is done
            after padding, the padding seems to be done at a random offset.
        fill (number or tuple): Pixel fill value for constant fill. Default is 0. If a tuple of
            length 3, it is used to fill R, G, B channels respectively.
            This value is only used when the padding_mode is constant.
            Only number is supported for torch Tensor.
            Only int or tuple value is supported for PIL Image.
        padding_mode (str): Type of padding. Should be: constant, edge, reflect or symmetric.
            Default is constant.

            - constant: pads with a constant value, this value is specified with fill

            - edge: pads with the last value at the edge of the image.
              If input a 5D torch Tensor, the last 3 dimensions will be padded instead of the last 2

            - reflect: pads with reflection of image without repeating the last value on the edge.
              For example, padding [1, 2, 3, 4] with 2 elements on both sides in reflect mode
              will result in [3, 2, 1, 2, 3, 4, 3, 2]

            - symmetric: pads with reflection of image repeating the last value on the edge.
              For example, padding [1, 2, 3, 4] with 2 elements on both sides in symmetric mode
              will result in [2, 1, 1, 2, 3, 4, 4, 3]
    """

    @staticmethod
    def get_params(img: 'Tensor\n', output_size: 'Tuple[(int, int)]\n') ->Tuple[int, int, int, int]:
        """Get parameters for ``crop`` for a random crop.

        Args:
            img (PIL Image or Tensor): Image to be cropped.
            output_size (tuple): Expected output size of the crop.

        Returns:
            tuple: params (i, j, h, w) to be passed to ``crop`` for random crop.
        """
        _, h, w = F.get_dimensions(img)
        th, tw = output_size
        if h < th or w < tw:
            raise ValueError(f'Required crop size {th, tw} is larger than input image size {h, w}')
        if w == tw and h == th:
            return 0, 0, h, w
        i = torch.randint(0, h - th + 1, size=(1,)).item()
        j = torch.randint(0, w - tw + 1, size=(1,)).item()
        return i, j, th, tw

    def __init__(self, size, padding=None, pad_if_needed=False, fill=0, padding_mode='constant'):
        super().__init__()
        _log_api_usage_once(self)
        self.size = tuple(_setup_size(size, error_msg='Please provide only two dimensions (h, w) for size.'))
        self.padding = padding
        self.pad_if_needed = pad_if_needed
        self.fill = fill
        self.padding_mode = padding_mode

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Image to be cropped.

        Returns:
            PIL Image or Tensor: Cropped image.
        """
        if self.padding is not None:
            img = F.pad(img, self.padding, self.fill, self.padding_mode)
        _, height, width = F.get_dimensions(img)
        if self.pad_if_needed and width < self.size[1]:
            padding = [self.size[1] - width, 0]
            img = F.pad(img, padding, self.fill, self.padding_mode)
        if self.pad_if_needed and height < self.size[0]:
            padding = [0, self.size[0] - height]
            img = F.pad(img, padding, self.fill, self.padding_mode)
        i, j, h, w = self.get_params(img, self.size)
        return F.crop(img, i, j, h, w)

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}(size={self.size}, padding={self.padding})'


class RandomVerticalFlip(torch.nn.Module):
    """Vertically flip the given image randomly with a given probability.
    If the image is torch Tensor, it is expected
    to have [..., H, W] shape, where ... means an arbitrary number of leading
    dimensions

    Args:
        p (float): probability of the image being flipped. Default value is 0.5
    """

    def __init__(self, p=0.5):
        super().__init__()
        _log_api_usage_once(self)
        self.p = p

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Image to be flipped.

        Returns:
            PIL Image or Tensor: Randomly flipped image.
        """
        if torch.rand(1) < self.p:
            return F.vflip(img)
        return img

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}(p={self.p})'


class RandomPerspective(torch.nn.Module):
    """Performs a random perspective transformation of the given image with a given probability.
    If the image is torch Tensor, it is expected
    to have [..., H, W] shape, where ... means an arbitrary number of leading dimensions.

    Args:
        distortion_scale (float): argument to control the degree of distortion and ranges from 0 to 1.
            Default is 0.5.
        p (float): probability of the image being transformed. Default is 0.5.
        interpolation (InterpolationMode): Desired interpolation enum defined by
            :class:`torchvision.transforms.InterpolationMode`. Default is ``InterpolationMode.BILINEAR``.
            If input is Tensor, only ``InterpolationMode.NEAREST``, ``InterpolationMode.BILINEAR`` are supported.
            The corresponding Pillow integer constants, e.g. ``PIL.Image.BILINEAR`` are accepted as well.
        fill (sequence or number): Pixel fill value for the area outside the transformed
            image. Default is ``0``. If given a number, the value is used for all bands respectively.
    """

    def __init__(self, distortion_scale=0.5, p=0.5, interpolation=InterpolationMode.BILINEAR, fill=0):
        super().__init__()
        _log_api_usage_once(self)
        self.p = p
        if isinstance(interpolation, int):
            interpolation = _interpolation_modes_from_int(interpolation)
        self.interpolation = interpolation
        self.distortion_scale = distortion_scale
        if fill is None:
            fill = 0
        elif not isinstance(fill, (Sequence, numbers.Number)):
            raise TypeError('Fill should be either a sequence or a number.')
        self.fill = fill

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Image to be Perspectively transformed.

        Returns:
            PIL Image or Tensor: Randomly transformed image.
        """
        fill = self.fill
        channels, height, width = F.get_dimensions(img)
        if isinstance(img, Tensor):
            if isinstance(fill, (int, float)):
                fill = [float(fill)] * channels
            else:
                fill = [float(f) for f in fill]
        if torch.rand(1) < self.p:
            startpoints, endpoints = self.get_params(width, height, self.distortion_scale)
            return F.perspective(img, startpoints, endpoints, self.interpolation, fill)
        return img

    @staticmethod
    def get_params(width: 'int\n', height: 'int\n', distortion_scale: 'float\n') ->Tuple[List[List[int]], List[List[int]]]:
        """Get parameters for ``perspective`` for a random perspective transform.

        Args:
            width (int): width of the image.
            height (int): height of the image.
            distortion_scale (float): argument to control the degree of distortion and ranges from 0 to 1.

        Returns:
            List containing [top-left, top-right, bottom-right, bottom-left] of the original image,
            List containing [top-left, top-right, bottom-right, bottom-left] of the transformed image.
        """
        half_height = height // 2
        half_width = width // 2
        topleft = [int(torch.randint(0, int(distortion_scale * half_width) + 1, size=(1,)).item()), int(torch.randint(0, int(distortion_scale * half_height) + 1, size=(1,)).item())]
        topright = [int(torch.randint(width - int(distortion_scale * half_width) - 1, width, size=(1,)).item()), int(torch.randint(0, int(distortion_scale * half_height) + 1, size=(1,)).item())]
        botright = [int(torch.randint(width - int(distortion_scale * half_width) - 1, width, size=(1,)).item()), int(torch.randint(height - int(distortion_scale * half_height) - 1, height, size=(1,)).item())]
        botleft = [int(torch.randint(0, int(distortion_scale * half_width) + 1, size=(1,)).item()), int(torch.randint(height - int(distortion_scale * half_height) - 1, height, size=(1,)).item())]
        startpoints = [[0, 0], [width - 1, 0], [width - 1, height - 1], [0, height - 1]]
        endpoints = [topleft, topright, botright, botleft]
        return startpoints, endpoints

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}(p={self.p})'


class RandomResizedCrop(torch.nn.Module):
    """Crop a random portion of image and resize it to a given size.

    If the image is torch Tensor, it is expected
    to have [..., H, W] shape, where ... means an arbitrary number of leading dimensions

    A crop of the original image is made: the crop has a random area (H * W)
    and a random aspect ratio. This crop is finally resized to the given
    size. This is popularly used to train the Inception networks.

    Args:
        size (int or sequence): expected output size of the crop, for each edge. If size is an
            int instead of sequence like (h, w), a square output size ``(size, size)`` is
            made. If provided a sequence of length 1, it will be interpreted as (size[0], size[0]).

            .. note::
                In torchscript mode size as single int is not supported, use a sequence of length 1: ``[size, ]``.
        scale (tuple of float): Specifies the lower and upper bounds for the random area of the crop,
            before resizing. The scale is defined with respect to the area of the original image.
        ratio (tuple of float): lower and upper bounds for the random aspect ratio of the crop, before
            resizing.
        interpolation (InterpolationMode): Desired interpolation enum defined by
            :class:`torchvision.transforms.InterpolationMode`. Default is ``InterpolationMode.BILINEAR``.
            If input is Tensor, only ``InterpolationMode.NEAREST``, ``InterpolationMode.NEAREST_EXACT``,
            ``InterpolationMode.BILINEAR`` and ``InterpolationMode.BICUBIC`` are supported.
            The corresponding Pillow integer constants, e.g. ``PIL.Image.BILINEAR`` are accepted as well.
        antialias (bool, optional): Whether to apply antialiasing.
            It only affects **tensors** with bilinear or bicubic modes and it is
            ignored otherwise: on PIL images, antialiasing is always applied on
            bilinear or bicubic modes; on other modes (for PIL images and
            tensors), antialiasing makes no sense and this parameter is ignored.
            Possible values are:

            - ``True``: will apply antialiasing for bilinear or bicubic modes.
              Other mode aren't affected. This is probably what you want to use.
            - ``False``: will not apply antialiasing for tensors on any mode. PIL
              images are still antialiased on bilinear or bicubic modes, because
              PIL doesn't support no antialias.
            - ``None``: equivalent to ``False`` for tensors and ``True`` for
              PIL images. This value exists for legacy reasons and you probably
              don't want to use it unless you really know what you are doing.

            The current default is ``None`` **but will change to** ``True`` **in
            v0.17** for the PIL and Tensor backends to be consistent.
    """

    def __init__(self, size, scale=(0.08, 1.0), ratio=(3.0 / 4.0, 4.0 / 3.0), interpolation=InterpolationMode.BILINEAR, antialias: 'Optional[Union[(str, bool)]]\n'='warn'):
        super().__init__()
        _log_api_usage_once(self)
        self.size = _setup_size(size, error_msg='Please provide only two dimensions (h, w) for size.')
        if not isinstance(scale, Sequence):
            raise TypeError('Scale should be a sequence')
        if not isinstance(ratio, Sequence):
            raise TypeError('Ratio should be a sequence')
        if scale[0] > scale[1] or ratio[0] > ratio[1]:
            warnings.warn('Scale and ratio should be of kind (min, max)')
        if isinstance(interpolation, int):
            interpolation = _interpolation_modes_from_int(interpolation)
        self.interpolation = interpolation
        self.antialias = antialias
        self.scale = scale
        self.ratio = ratio

    @staticmethod
    def get_params(img: 'Tensor\n', scale: 'List[float]\n', ratio: 'List[float]\n') ->Tuple[int, int, int, int]:
        """Get parameters for ``crop`` for a random sized crop.

        Args:
            img (PIL Image or Tensor): Input image.
            scale (list): range of scale of the origin size cropped
            ratio (list): range of aspect ratio of the origin aspect ratio cropped

        Returns:
            tuple: params (i, j, h, w) to be passed to ``crop`` for a random
            sized crop.
        """
        _, height, width = F.get_dimensions(img)
        area = height * width
        log_ratio = torch.log(torch.tensor(ratio))
        for _ in range(10):
            target_area = area * torch.empty(1).uniform_(scale[0], scale[1]).item()
            aspect_ratio = torch.exp(torch.empty(1).uniform_(log_ratio[0], log_ratio[1])).item()
            w = int(round(math.sqrt(target_area * aspect_ratio)))
            h = int(round(math.sqrt(target_area / aspect_ratio)))
            if 0 < w <= width and 0 < h <= height:
                i = torch.randint(0, height - h + 1, size=(1,)).item()
                j = torch.randint(0, width - w + 1, size=(1,)).item()
                return i, j, h, w
        in_ratio = float(width) / float(height)
        if in_ratio < min(ratio):
            w = width
            h = int(round(w / min(ratio)))
        elif in_ratio > max(ratio):
            h = height
            w = int(round(h * max(ratio)))
        else:
            w = width
            h = height
        i = (height - h) // 2
        j = (width - w) // 2
        return i, j, h, w

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Image to be cropped and resized.

        Returns:
            PIL Image or Tensor: Randomly cropped and resized image.
        """
        i, j, h, w = self.get_params(img, self.scale, self.ratio)
        return F.resized_crop(img, i, j, h, w, self.size, self.interpolation, antialias=self.antialias)

    def __repr__(self) ->str:
        interpolate_str = self.interpolation.value
        format_string = self.__class__.__name__ + f'(size={self.size}'
        format_string += f', scale={tuple(round(s, 4) for s in self.scale)}'
        format_string += f', ratio={tuple(round(r, 4) for r in self.ratio)}'
        format_string += f', interpolation={interpolate_str}'
        format_string += f', antialias={self.antialias})'
        return format_string


class FiveCrop(torch.nn.Module):
    """Crop the given image into four corners and the central crop.
    If the image is torch Tensor, it is expected
    to have [..., H, W] shape, where ... means an arbitrary number of leading
    dimensions

    .. Note::
         This transform returns a tuple of images and there may be a mismatch in the number of
         inputs and targets your Dataset returns. See below for an example of how to deal with
         this.

    Args:
         size (sequence or int): Desired output size of the crop. If size is an ``int``
            instead of sequence like (h, w), a square crop of size (size, size) is made.
            If provided a sequence of length 1, it will be interpreted as (size[0], size[0]).

    Example:
         >>> transform = Compose([
         >>>    FiveCrop(size), # this is a list of PIL Images
         >>>    Lambda(lambda crops: torch.stack([PILToTensor()(crop) for crop in crops])) # returns a 4D tensor
         >>> ])
         >>> #In your test loop you can do the following:
         >>> input, target = batch # input is a 5d tensor, target is 2d
         >>> bs, ncrops, c, h, w = input.size()
         >>> result = model(input.view(-1, c, h, w)) # fuse batch size and ncrops
         >>> result_avg = result.view(bs, ncrops, -1).mean(1) # avg over crops
    """

    def __init__(self, size):
        super().__init__()
        _log_api_usage_once(self)
        self.size = _setup_size(size, error_msg='Please provide only two dimensions (h, w) for size.')

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Image to be cropped.

        Returns:
            tuple of 5 images. Image can be PIL Image or Tensor
        """
        return F.five_crop(img, self.size)

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}(size={self.size})'


class TenCrop(torch.nn.Module):
    """Crop the given image into four corners and the central crop plus the flipped version of
    these (horizontal flipping is used by default).
    If the image is torch Tensor, it is expected
    to have [..., H, W] shape, where ... means an arbitrary number of leading
    dimensions

    .. Note::
         This transform returns a tuple of images and there may be a mismatch in the number of
         inputs and targets your Dataset returns. See below for an example of how to deal with
         this.

    Args:
        size (sequence or int): Desired output size of the crop. If size is an
            int instead of sequence like (h, w), a square crop (size, size) is
            made. If provided a sequence of length 1, it will be interpreted as (size[0], size[0]).
        vertical_flip (bool): Use vertical flipping instead of horizontal

    Example:
         >>> transform = Compose([
         >>>    TenCrop(size), # this is a tuple of PIL Images
         >>>    Lambda(lambda crops: torch.stack([PILToTensor()(crop) for crop in crops])) # returns a 4D tensor
         >>> ])
         >>> #In your test loop you can do the following:
         >>> input, target = batch # input is a 5d tensor, target is 2d
         >>> bs, ncrops, c, h, w = input.size()
         >>> result = model(input.view(-1, c, h, w)) # fuse batch size and ncrops
         >>> result_avg = result.view(bs, ncrops, -1).mean(1) # avg over crops
    """

    def __init__(self, size, vertical_flip=False):
        super().__init__()
        _log_api_usage_once(self)
        self.size = _setup_size(size, error_msg='Please provide only two dimensions (h, w) for size.')
        self.vertical_flip = vertical_flip

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Image to be cropped.

        Returns:
            tuple of 10 images. Image can be PIL Image or Tensor
        """
        return F.ten_crop(img, self.size, self.vertical_flip)

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}(size={self.size}, vertical_flip={self.vertical_flip})'


class LinearTransformation(torch.nn.Module):
    """Transform a tensor image with a square transformation matrix and a mean_vector computed
    offline.
    This transform does not support PIL Image.
    Given transformation_matrix and mean_vector, will flatten the torch.*Tensor and
    subtract mean_vector from it which is then followed by computing the dot
    product with the transformation matrix and then reshaping the tensor to its
    original shape.

    Applications:
        whitening transformation: Suppose X is a column vector zero-centered data.
        Then compute the data covariance matrix [D x D] with torch.mm(X.t(), X),
        perform SVD on this matrix and pass it as transformation_matrix.

    Args:
        transformation_matrix (Tensor): tensor [D x D], D = C x H x W
        mean_vector (Tensor): tensor [D], D = C x H x W
    """

    def __init__(self, transformation_matrix, mean_vector):
        super().__init__()
        _log_api_usage_once(self)
        if transformation_matrix.size(0) != transformation_matrix.size(1):
            raise ValueError(f'transformation_matrix should be square. Got {tuple(transformation_matrix.size())} rectangular matrix.')
        if mean_vector.size(0) != transformation_matrix.size(0):
            raise ValueError(f'mean_vector should have the same length {mean_vector.size(0)} as any one of the dimensions of the transformation_matrix [{tuple(transformation_matrix.size())}]')
        if transformation_matrix.device != mean_vector.device:
            raise ValueError(f'Input tensors should be on the same device. Got {transformation_matrix.device} and {mean_vector.device}')
        if transformation_matrix.dtype != mean_vector.dtype:
            raise ValueError(f'Input tensors should have the same dtype. Got {transformation_matrix.dtype} and {mean_vector.dtype}')
        self.transformation_matrix = transformation_matrix
        self.mean_vector = mean_vector

    def forward(self, tensor: 'Tensor\n') ->Tensor:
        """
        Args:
            tensor (Tensor): Tensor image to be whitened.

        Returns:
            Tensor: Transformed image.
        """
        shape = tensor.shape
        n = shape[-3] * shape[-2] * shape[-1]
        if n != self.transformation_matrix.shape[0]:
            raise ValueError('Input tensor and transformation matrix have incompatible shape.' + f'[{shape[-3]} x {shape[-2]} x {shape[-1]}] != ' + f'{self.transformation_matrix.shape[0]}')
        if tensor.device.type != self.mean_vector.device.type:
            raise ValueError(f'Input tensor should be on the same device as transformation matrix and mean vector. Got {tensor.device} vs {self.mean_vector.device}')
        flat_tensor = tensor.view(-1, n) - self.mean_vector
        transformation_matrix = self.transformation_matrix
        transformed_tensor = torch.mm(flat_tensor, transformation_matrix)
        tensor = transformed_tensor.view(shape)
        return tensor

    def __repr__(self) ->str:
        s = f'{self.__class__.__name__}(transformation_matrix={self.transformation_matrix.tolist()}, mean_vector={self.mean_vector.tolist()})'
        return s


def _setup_angle(x, name, req_sizes=(2,)):
    if isinstance(x, numbers.Number):
        if x < 0:
            raise ValueError(f'If {name} is a single number, it must be positive.')
        x = [-x, x]
    else:
        _check_sequence_input(x, name, req_sizes)
    return [float(d) for d in x]


class RandomRotation(torch.nn.Module):
    """Rotate the image by angle.
    If the image is torch Tensor, it is expected
    to have [..., H, W] shape, where ... means an arbitrary number of leading dimensions.

    Args:
        degrees (sequence or number): Range of degrees to select from.
            If degrees is a number instead of sequence like (min, max), the range of degrees
            will be (-degrees, +degrees).
        interpolation (InterpolationMode): Desired interpolation enum defined by
            :class:`torchvision.transforms.InterpolationMode`. Default is ``InterpolationMode.NEAREST``.
            If input is Tensor, only ``InterpolationMode.NEAREST``, ``InterpolationMode.BILINEAR`` are supported.
            The corresponding Pillow integer constants, e.g. ``PIL.Image.BILINEAR`` are accepted as well.
        expand (bool, optional): Optional expansion flag.
            If true, expands the output to make it large enough to hold the entire rotated image.
            If false or omitted, make the output image the same size as the input image.
            Note that the expand flag assumes rotation around the center and no translation.
        center (sequence, optional): Optional center of rotation, (x, y). Origin is the upper left corner.
            Default is the center of the image.
        fill (sequence or number): Pixel fill value for the area outside the rotated
            image. Default is ``0``. If given a number, the value is used for all bands respectively.

    .. _filters: https://pillow.readthedocs.io/en/latest/handbook/concepts.html#filters

    """

    def __init__(self, degrees, interpolation=InterpolationMode.NEAREST, expand=False, center=None, fill=0):
        super().__init__()
        _log_api_usage_once(self)
        if isinstance(interpolation, int):
            interpolation = _interpolation_modes_from_int(interpolation)
        self.degrees = _setup_angle(degrees, name='degrees', req_sizes=(2,))
        if center is not None:
            _check_sequence_input(center, 'center', req_sizes=(2,))
        self.center = center
        self.interpolation = interpolation
        self.expand = expand
        if fill is None:
            fill = 0
        elif not isinstance(fill, (Sequence, numbers.Number)):
            raise TypeError('Fill should be either a sequence or a number.')
        self.fill = fill

    @staticmethod
    def get_params(degrees: 'List[float]\n') ->float:
        """Get parameters for ``rotate`` for a random rotation.

        Returns:
            float: angle parameter to be passed to ``rotate`` for random rotation.
        """
        angle = float(torch.empty(1).uniform_(float(degrees[0]), float(degrees[1])).item())
        return angle

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Image to be rotated.

        Returns:
            PIL Image or Tensor: Rotated image.
        """
        fill = self.fill
        channels, _, _ = F.get_dimensions(img)
        if isinstance(img, Tensor):
            if isinstance(fill, (int, float)):
                fill = [float(fill)] * channels
            else:
                fill = [float(f) for f in fill]
        angle = self.get_params(self.degrees)
        return F.rotate(img, angle, self.interpolation, self.expand, self.center, fill)

    def __repr__(self) ->str:
        interpolate_str = self.interpolation.value
        format_string = self.__class__.__name__ + f'(degrees={self.degrees}'
        format_string += f', interpolation={interpolate_str}'
        format_string += f', expand={self.expand}'
        if self.center is not None:
            format_string += f', center={self.center}'
        if self.fill is not None:
            format_string += f', fill={self.fill}'
        format_string += ')'
        return format_string


class RandomAffine(torch.nn.Module):
    """Random affine transformation of the image keeping center invariant.
    If the image is torch Tensor, it is expected
    to have [..., H, W] shape, where ... means an arbitrary number of leading dimensions.

    Args:
        degrees (sequence or number): Range of degrees to select from.
            If degrees is a number instead of sequence like (min, max), the range of degrees
            will be (-degrees, +degrees). Set to 0 to deactivate rotations.
        translate (tuple, optional): tuple of maximum absolute fraction for horizontal
            and vertical translations. For example translate=(a, b), then horizontal shift
            is randomly sampled in the range -img_width * a < dx < img_width * a and vertical shift is
            randomly sampled in the range -img_height * b < dy < img_height * b. Will not translate by default.
        scale (tuple, optional): scaling factor interval, e.g (a, b), then scale is
            randomly sampled from the range a <= scale <= b. Will keep original scale by default.
        shear (sequence or number, optional): Range of degrees to select from.
            If shear is a number, a shear parallel to the x-axis in the range (-shear, +shear)
            will be applied. Else if shear is a sequence of 2 values a shear parallel to the x-axis in the
            range (shear[0], shear[1]) will be applied. Else if shear is a sequence of 4 values,
            an x-axis shear in (shear[0], shear[1]) and y-axis shear in (shear[2], shear[3]) will be applied.
            Will not apply shear by default.
        interpolation (InterpolationMode): Desired interpolation enum defined by
            :class:`torchvision.transforms.InterpolationMode`. Default is ``InterpolationMode.NEAREST``.
            If input is Tensor, only ``InterpolationMode.NEAREST``, ``InterpolationMode.BILINEAR`` are supported.
            The corresponding Pillow integer constants, e.g. ``PIL.Image.BILINEAR`` are accepted as well.
        fill (sequence or number): Pixel fill value for the area outside the transformed
            image. Default is ``0``. If given a number, the value is used for all bands respectively.
        center (sequence, optional): Optional center of rotation, (x, y). Origin is the upper left corner.
            Default is the center of the image.

    .. _filters: https://pillow.readthedocs.io/en/latest/handbook/concepts.html#filters

    """

    def __init__(self, degrees, translate=None, scale=None, shear=None, interpolation=InterpolationMode.NEAREST, fill=0, center=None):
        super().__init__()
        _log_api_usage_once(self)
        if isinstance(interpolation, int):
            interpolation = _interpolation_modes_from_int(interpolation)
        self.degrees = _setup_angle(degrees, name='degrees', req_sizes=(2,))
        if translate is not None:
            _check_sequence_input(translate, 'translate', req_sizes=(2,))
            for t in translate:
                if not 0.0 <= t <= 1.0:
                    raise ValueError('translation values should be between 0 and 1')
        self.translate = translate
        if scale is not None:
            _check_sequence_input(scale, 'scale', req_sizes=(2,))
            for s in scale:
                if s <= 0:
                    raise ValueError('scale values should be positive')
        self.scale = scale
        if shear is not None:
            self.shear = _setup_angle(shear, name='shear', req_sizes=(2, 4))
        else:
            self.shear = shear
        self.interpolation = interpolation
        if fill is None:
            fill = 0
        elif not isinstance(fill, (Sequence, numbers.Number)):
            raise TypeError('Fill should be either a sequence or a number.')
        self.fill = fill
        if center is not None:
            _check_sequence_input(center, 'center', req_sizes=(2,))
        self.center = center

    @staticmethod
    def get_params(degrees: 'List[float]\n', translate: 'Optional[List[float]]\n', scale_ranges: 'Optional[List[float]]\n', shears: 'Optional[List[float]]\n', img_size: 'List[int]\n') ->Tuple[float, Tuple[int, int], float, Tuple[float, float]]:
        """Get parameters for affine transformation

        Returns:
            params to be passed to the affine transformation
        """
        angle = float(torch.empty(1).uniform_(float(degrees[0]), float(degrees[1])).item())
        if translate is not None:
            max_dx = float(translate[0] * img_size[0])
            max_dy = float(translate[1] * img_size[1])
            tx = int(round(torch.empty(1).uniform_(-max_dx, max_dx).item()))
            ty = int(round(torch.empty(1).uniform_(-max_dy, max_dy).item()))
            translations = tx, ty
        else:
            translations = 0, 0
        if scale_ranges is not None:
            scale = float(torch.empty(1).uniform_(scale_ranges[0], scale_ranges[1]).item())
        else:
            scale = 1.0
        shear_x = shear_y = 0.0
        if shears is not None:
            shear_x = float(torch.empty(1).uniform_(shears[0], shears[1]).item())
            if len(shears) == 4:
                shear_y = float(torch.empty(1).uniform_(shears[2], shears[3]).item())
        shear = shear_x, shear_y
        return angle, translations, scale, shear

    def forward(self, img):
        """
            img (PIL Image or Tensor): Image to be transformed.

        Returns:
            PIL Image or Tensor: Affine transformed image.
        """
        fill = self.fill
        channels, height, width = F.get_dimensions(img)
        if isinstance(img, Tensor):
            if isinstance(fill, (int, float)):
                fill = [float(fill)] * channels
            else:
                fill = [float(f) for f in fill]
        img_size = [width, height]
        ret = self.get_params(self.degrees, self.translate, self.scale, self.shear, img_size)
        return F.affine(img, *ret, interpolation=self.interpolation, fill=fill, center=self.center)

    def __repr__(self) ->str:
        s = f'{self.__class__.__name__}(degrees={self.degrees}'
        s += f', translate={self.translate}' if self.translate is not None else ''
        s += f', scale={self.scale}' if self.scale is not None else ''
        s += f', shear={self.shear}' if self.shear is not None else ''
        s += f', interpolation={self.interpolation.value}' if self.interpolation != InterpolationMode.NEAREST else ''
        s += f', fill={self.fill}' if self.fill != 0 else ''
        s += f', center={self.center}' if self.center is not None else ''
        s += ')'
        return s


class Grayscale(torch.nn.Module):
    """Convert image to grayscale.
    If the image is torch Tensor, it is expected
    to have [..., 3, H, W] shape, where ... means an arbitrary number of leading dimensions

    Args:
        num_output_channels (int): (1 or 3) number of channels desired for output image

    Returns:
        PIL Image: Grayscale version of the input.

        - If ``num_output_channels == 1`` : returned image is single channel
        - If ``num_output_channels == 3`` : returned image is 3 channel with r == g == b

    """

    def __init__(self, num_output_channels=1):
        super().__init__()
        _log_api_usage_once(self)
        self.num_output_channels = num_output_channels

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Image to be converted to grayscale.

        Returns:
            PIL Image or Tensor: Grayscaled image.
        """
        return F.rgb_to_grayscale(img, num_output_channels=self.num_output_channels)

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}(num_output_channels={self.num_output_channels})'


class RandomGrayscale(torch.nn.Module):
    """Randomly convert image to grayscale with a probability of p (default 0.1).
    If the image is torch Tensor, it is expected
    to have [..., 3, H, W] shape, where ... means an arbitrary number of leading dimensions

    Args:
        p (float): probability that image should be converted to grayscale.

    Returns:
        PIL Image or Tensor: Grayscale version of the input image with probability p and unchanged
        with probability (1-p).
        - If input image is 1 channel: grayscale version is 1 channel
        - If input image is 3 channel: grayscale version is 3 channel with r == g == b

    """

    def __init__(self, p=0.1):
        super().__init__()
        _log_api_usage_once(self)
        self.p = p

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Image to be converted to grayscale.

        Returns:
            PIL Image or Tensor: Randomly grayscaled image.
        """
        num_output_channels, _, _ = F.get_dimensions(img)
        if torch.rand(1) < self.p:
            return F.rgb_to_grayscale(img, num_output_channels=num_output_channels)
        return img

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}(p={self.p})'


class RandomErasing(torch.nn.Module):
    """Randomly selects a rectangle region in a torch.Tensor image and erases its pixels.
    This transform does not support PIL Image.
    'Random Erasing Data Augmentation' by Zhong et al. See https://arxiv.org/abs/1708.04896

    Args:
         p: probability that the random erasing operation will be performed.
         scale: range of proportion of erased area against input image.
         ratio: range of aspect ratio of erased area.
         value: erasing value. Default is 0. If a single int, it is used to
            erase all pixels. If a tuple of length 3, it is used to erase
            R, G, B channels respectively.
            If a str of 'random', erasing each pixel with random values.
         inplace: boolean to make this transform inplace. Default set to False.

    Returns:
        Erased Image.

    Example:
        >>> transform = transforms.Compose([
        >>>   transforms.RandomHorizontalFlip(),
        >>>   transforms.PILToTensor(),
        >>>   transforms.ConvertImageDtype(torch.float),
        >>>   transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225)),
        >>>   transforms.RandomErasing(),
        >>> ])
    """

    def __init__(self, p=0.5, scale=(0.02, 0.33), ratio=(0.3, 3.3), value=0, inplace=False):
        super().__init__()
        _log_api_usage_once(self)
        if not isinstance(value, (numbers.Number, str, tuple, list)):
            raise TypeError('Argument value should be either a number or str or a sequence')
        if isinstance(value, str) and value != 'random':
            raise ValueError("If value is str, it should be 'random'")
        if not isinstance(scale, (tuple, list)):
            raise TypeError('Scale should be a sequence')
        if not isinstance(ratio, (tuple, list)):
            raise TypeError('Ratio should be a sequence')
        if scale[0] > scale[1] or ratio[0] > ratio[1]:
            warnings.warn('Scale and ratio should be of kind (min, max)')
        if scale[0] < 0 or scale[1] > 1:
            raise ValueError('Scale should be between 0 and 1')
        if p < 0 or p > 1:
            raise ValueError('Random erasing probability should be between 0 and 1')
        self.p = p
        self.scale = scale
        self.ratio = ratio
        self.value = value
        self.inplace = inplace

    @staticmethod
    def get_params(img: 'Tensor\n', scale: 'Tuple[(float, float)]\n', ratio: 'Tuple[(float, float)]\n', value: 'Optional[List[float]]\n'=None) ->Tuple[int, int, int, int, Tensor]:
        """Get parameters for ``erase`` for a random erasing.

        Args:
            img (Tensor): Tensor image to be erased.
            scale (sequence): range of proportion of erased area against input image.
            ratio (sequence): range of aspect ratio of erased area.
            value (list, optional): erasing value. If None, it is interpreted as "random"
                (erasing each pixel with random values). If ``len(value)`` is 1, it is interpreted as a number,
                i.e. ``value[0]``.

        Returns:
            tuple: params (i, j, h, w, v) to be passed to ``erase`` for random erasing.
        """
        img_c, img_h, img_w = img.shape[-3], img.shape[-2], img.shape[-1]
        area = img_h * img_w
        log_ratio = torch.log(torch.tensor(ratio))
        for _ in range(10):
            erase_area = area * torch.empty(1).uniform_(scale[0], scale[1]).item()
            aspect_ratio = torch.exp(torch.empty(1).uniform_(log_ratio[0], log_ratio[1])).item()
            h = int(round(math.sqrt(erase_area * aspect_ratio)))
            w = int(round(math.sqrt(erase_area / aspect_ratio)))
            if not (h < img_h and w < img_w):
                continue
            if value is None:
                v = torch.empty([img_c, h, w], dtype=torch.float32).normal_()
            else:
                v = torch.tensor(value)[:, (None), (None)]
            i = torch.randint(0, img_h - h + 1, size=(1,)).item()
            j = torch.randint(0, img_w - w + 1, size=(1,)).item()
            return i, j, h, w, v
        return 0, 0, img_h, img_w, img

    def forward(self, img):
        """
        Args:
            img (Tensor): Tensor image to be erased.

        Returns:
            img (Tensor): Erased Tensor image.
        """
        if torch.rand(1) < self.p:
            if isinstance(self.value, (int, float)):
                value = [float(self.value)]
            elif isinstance(self.value, str):
                value = None
            elif isinstance(self.value, (list, tuple)):
                value = [float(v) for v in self.value]
            else:
                value = self.value
            if value is not None and not len(value) in (1, img.shape[-3]):
                raise ValueError(f'If value is a sequence, it should have either a single value or {img.shape[-3]} (number of input channels)')
            x, y, h, w, v = self.get_params(img, scale=self.scale, ratio=self.ratio, value=value)
            return F.erase(img, x, y, h, w, v, self.inplace)
        return img

    def __repr__(self) ->str:
        s = f'{self.__class__.__name__}(p={self.p}, scale={self.scale}, ratio={self.ratio}, value={self.value}, inplace={self.inplace})'
        return s


class GaussianBlur(torch.nn.Module):
    """Blurs image with randomly chosen Gaussian blur.
    If the image is torch Tensor, it is expected
    to have [..., C, H, W] shape, where ... means an arbitrary number of leading dimensions.

    Args:
        kernel_size (int or sequence): Size of the Gaussian kernel.
        sigma (float or tuple of float (min, max)): Standard deviation to be used for
            creating kernel to perform blurring. If float, sigma is fixed. If it is tuple
            of float (min, max), sigma is chosen uniformly at random to lie in the
            given range.

    Returns:
        PIL Image or Tensor: Gaussian blurred version of the input image.

    """

    def __init__(self, kernel_size, sigma=(0.1, 2.0)):
        super().__init__()
        _log_api_usage_once(self)
        self.kernel_size = _setup_size(kernel_size, 'Kernel size should be a tuple/list of two integers')
        for ks in self.kernel_size:
            if ks <= 0 or ks % 2 == 0:
                raise ValueError('Kernel size value should be an odd and positive number.')
        if isinstance(sigma, numbers.Number):
            if sigma <= 0:
                raise ValueError('If sigma is a single number, it must be positive.')
            sigma = sigma, sigma
        elif isinstance(sigma, Sequence) and len(sigma) == 2:
            if not 0.0 < sigma[0] <= sigma[1]:
                raise ValueError('sigma values should be positive and of the form (min, max).')
        else:
            raise ValueError('sigma should be a single number or a list/tuple with length 2.')
        self.sigma = sigma

    @staticmethod
    def get_params(sigma_min: 'float\n', sigma_max: 'float\n') ->float:
        """Choose sigma for random gaussian blurring.

        Args:
            sigma_min (float): Minimum standard deviation that can be chosen for blurring kernel.
            sigma_max (float): Maximum standard deviation that can be chosen for blurring kernel.

        Returns:
            float: Standard deviation to be passed to calculate kernel for gaussian blurring.
        """
        return torch.empty(1).uniform_(sigma_min, sigma_max).item()

    def forward(self, img: 'Tensor\n') ->Tensor:
        """
        Args:
            img (PIL Image or Tensor): image to be blurred.

        Returns:
            PIL Image or Tensor: Gaussian blurred image
        """
        sigma = self.get_params(self.sigma[0], self.sigma[1])
        return F.gaussian_blur(img, self.kernel_size, [sigma, sigma])

    def __repr__(self) ->str:
        s = f'{self.__class__.__name__}(kernel_size={self.kernel_size}, sigma={self.sigma})'
        return s


class RandomInvert(torch.nn.Module):
    """Inverts the colors of the given image randomly with a given probability.
    If img is a Tensor, it is expected to be in [..., 1 or 3, H, W] format,
    where ... means it can have an arbitrary number of leading dimensions.
    If img is PIL Image, it is expected to be in mode "L" or "RGB".

    Args:
        p (float): probability of the image being color inverted. Default value is 0.5
    """

    def __init__(self, p=0.5):
        super().__init__()
        _log_api_usage_once(self)
        self.p = p

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Image to be inverted.

        Returns:
            PIL Image or Tensor: Randomly color inverted image.
        """
        if torch.rand(1).item() < self.p:
            return F.invert(img)
        return img

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}(p={self.p})'


class RandomPosterize(torch.nn.Module):
    """Posterize the image randomly with a given probability by reducing the
    number of bits for each color channel. If the image is torch Tensor, it should be of type torch.uint8,
    and it is expected to have [..., 1 or 3, H, W] shape, where ... means an arbitrary number of leading dimensions.
    If img is PIL Image, it is expected to be in mode "L" or "RGB".

    Args:
        bits (int): number of bits to keep for each channel (0-8)
        p (float): probability of the image being posterized. Default value is 0.5
    """

    def __init__(self, bits, p=0.5):
        super().__init__()
        _log_api_usage_once(self)
        self.bits = bits
        self.p = p

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Image to be posterized.

        Returns:
            PIL Image or Tensor: Randomly posterized image.
        """
        if torch.rand(1).item() < self.p:
            return F.posterize(img, self.bits)
        return img

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}(bits={self.bits},p={self.p})'


class RandomSolarize(torch.nn.Module):
    """Solarize the image randomly with a given probability by inverting all pixel
    values above a threshold. If img is a Tensor, it is expected to be in [..., 1 or 3, H, W] format,
    where ... means it can have an arbitrary number of leading dimensions.
    If img is PIL Image, it is expected to be in mode "L" or "RGB".

    Args:
        threshold (float): all pixels equal or above this value are inverted.
        p (float): probability of the image being solarized. Default value is 0.5
    """

    def __init__(self, threshold, p=0.5):
        super().__init__()
        _log_api_usage_once(self)
        self.threshold = threshold
        self.p = p

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Image to be solarized.

        Returns:
            PIL Image or Tensor: Randomly solarized image.
        """
        if torch.rand(1).item() < self.p:
            return F.solarize(img, self.threshold)
        return img

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}(threshold={self.threshold},p={self.p})'


class RandomAdjustSharpness(torch.nn.Module):
    """Adjust the sharpness of the image randomly with a given probability. If the image is torch Tensor,
    it is expected to have [..., 1 or 3, H, W] shape, where ... means an arbitrary number of leading dimensions.

    Args:
        sharpness_factor (float):  How much to adjust the sharpness. Can be
            any non-negative number. 0 gives a blurred image, 1 gives the
            original image while 2 increases the sharpness by a factor of 2.
        p (float): probability of the image being sharpened. Default value is 0.5
    """

    def __init__(self, sharpness_factor, p=0.5):
        super().__init__()
        _log_api_usage_once(self)
        self.sharpness_factor = sharpness_factor
        self.p = p

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Image to be sharpened.

        Returns:
            PIL Image or Tensor: Randomly sharpened image.
        """
        if torch.rand(1).item() < self.p:
            return F.adjust_sharpness(img, self.sharpness_factor)
        return img

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}(sharpness_factor={self.sharpness_factor},p={self.p})'


class RandomAutocontrast(torch.nn.Module):
    """Autocontrast the pixels of the given image randomly with a given probability.
    If the image is torch Tensor, it is expected
    to have [..., 1 or 3, H, W] shape, where ... means an arbitrary number of leading dimensions.
    If img is PIL Image, it is expected to be in mode "L" or "RGB".

    Args:
        p (float): probability of the image being autocontrasted. Default value is 0.5
    """

    def __init__(self, p=0.5):
        super().__init__()
        _log_api_usage_once(self)
        self.p = p

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Image to be autocontrasted.

        Returns:
            PIL Image or Tensor: Randomly autocontrasted image.
        """
        if torch.rand(1).item() < self.p:
            return F.autocontrast(img)
        return img

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}(p={self.p})'


class RandomEqualize(torch.nn.Module):
    """Equalize the histogram of the given image randomly with a given probability.
    If the image is torch Tensor, it is expected
    to have [..., 1 or 3, H, W] shape, where ... means an arbitrary number of leading dimensions.
    If img is PIL Image, it is expected to be in mode "P", "L" or "RGB".

    Args:
        p (float): probability of the image being equalized. Default value is 0.5
    """

    def __init__(self, p=0.5):
        super().__init__()
        _log_api_usage_once(self)
        self.p = p

    def forward(self, img):
        """
        Args:
            img (PIL Image or Tensor): Image to be equalized.

        Returns:
            PIL Image or Tensor: Randomly equalized image.
        """
        if torch.rand(1).item() < self.p:
            return F.equalize(img)
        return img

    def __repr__(self) ->str:
        return f'{self.__class__.__name__}(p={self.p})'


class ElasticTransform(torch.nn.Module):
    """Transform a tensor image with elastic transformations.
    Given alpha and sigma, it will generate displacement
    vectors for all pixels based on random offsets. Alpha controls the strength
    and sigma controls the smoothness of the displacements.
    The displacements are added to an identity grid and the resulting grid is
    used to grid_sample from the image.

    Applications:
        Randomly transforms the morphology of objects in images and produces a
        see-through-water-like effect.

    Args:
        alpha (float or sequence of floats): Magnitude of displacements. Default is 50.0.
        sigma (float or sequence of floats): Smoothness of displacements. Default is 5.0.
        interpolation (InterpolationMode): Desired interpolation enum defined by
            :class:`torchvision.transforms.InterpolationMode`. Default is ``InterpolationMode.BILINEAR``.
            If input is Tensor, only ``InterpolationMode.NEAREST``, ``InterpolationMode.BILINEAR`` are supported.
            The corresponding Pillow integer constants, e.g. ``PIL.Image.BILINEAR`` are accepted as well.
        fill (sequence or number): Pixel fill value for the area outside the transformed
            image. Default is ``0``. If given a number, the value is used for all bands respectively.

    """

    def __init__(self, alpha=50.0, sigma=5.0, interpolation=InterpolationMode.BILINEAR, fill=0):
        super().__init__()
        _log_api_usage_once(self)
        if not isinstance(alpha, (float, Sequence)):
            raise TypeError(f'alpha should be float or a sequence of floats. Got {type(alpha)}')
        if isinstance(alpha, Sequence) and len(alpha) != 2:
            raise ValueError(f'If alpha is a sequence its length should be 2. Got {len(alpha)}')
        if isinstance(alpha, Sequence):
            for element in alpha:
                if not isinstance(element, float):
                    raise TypeError(f'alpha should be a sequence of floats. Got {type(element)}')
        if isinstance(alpha, float):
            alpha = [float(alpha), float(alpha)]
        if isinstance(alpha, (list, tuple)) and len(alpha) == 1:
            alpha = [alpha[0], alpha[0]]
        self.alpha = alpha
        if not isinstance(sigma, (float, Sequence)):
            raise TypeError(f'sigma should be float or a sequence of floats. Got {type(sigma)}')
        if isinstance(sigma, Sequence) and len(sigma) != 2:
            raise ValueError(f'If sigma is a sequence its length should be 2. Got {len(sigma)}')
        if isinstance(sigma, Sequence):
            for element in sigma:
                if not isinstance(element, float):
                    raise TypeError(f'sigma should be a sequence of floats. Got {type(element)}')
        if isinstance(sigma, float):
            sigma = [float(sigma), float(sigma)]
        if isinstance(sigma, (list, tuple)) and len(sigma) == 1:
            sigma = [sigma[0], sigma[0]]
        self.sigma = sigma
        if isinstance(interpolation, int):
            interpolation = _interpolation_modes_from_int(interpolation)
        self.interpolation = interpolation
        if isinstance(fill, (int, float)):
            fill = [float(fill)]
        elif isinstance(fill, (list, tuple)):
            fill = [float(f) for f in fill]
        else:
            raise TypeError(f'fill should be int or float or a list or tuple of them. Got {type(fill)}')
        self.fill = fill

    @staticmethod
    def get_params(alpha: 'List[float]\n', sigma: 'List[float]\n', size: 'List[int]\n') ->Tensor:
        dx = torch.rand([1, 1] + size) * 2 - 1
        if sigma[0] > 0.0:
            kx = int(8 * sigma[0] + 1)
            if kx % 2 == 0:
                kx += 1
            dx = F.gaussian_blur(dx, [kx, kx], sigma)
        dx = dx * alpha[0] / size[0]
        dy = torch.rand([1, 1] + size) * 2 - 1
        if sigma[1] > 0.0:
            ky = int(8 * sigma[1] + 1)
            if ky % 2 == 0:
                ky += 1
            dy = F.gaussian_blur(dy, [ky, ky], sigma)
        dy = dy * alpha[1] / size[1]
        return torch.concat([dx, dy], 1).permute([0, 2, 3, 1])

    def forward(self, tensor: 'Tensor\n') ->Tensor:
        """
        Args:
            tensor (PIL Image or Tensor): Image to be transformed.

        Returns:
            PIL Image or Tensor: Transformed image.
        """
        _, height, width = F.get_dimensions(tensor)
        displacement = self.get_params(self.alpha, self.sigma, [height, width])
        return F.elastic_transform(tensor, displacement, self.interpolation, self.fill)

    def __repr__(self):
        format_string = self.__class__.__name__
        format_string += f'(alpha={self.alpha}'
        format_string += f', sigma={self.sigma}'
        format_string += f', interpolation={self.interpolation}'
        format_string += f', fill={self.fill})'
        return format_string


import torch
from torch.nn import MSELoss, ReLU
from _paritybench_helpers import _mock_config, _mock_layer, _paritybench_base, _fails_compile


TESTCASES = [
    # (nn.Module, init_args, forward_args, jit_compiles)
    (ASPPConv,
     lambda: ([], {'in_channels': 4, 'out_channels': 4, 'dilation': 1}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (AlexNet,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 3, 64, 64])], {}),
     True),
    (AnyStage,
     lambda: ([], {'width_in': 4, 'width_out': 4, 'stride': 1, 'depth': 1, 'block_constructor': _mock_layer, 'norm_layer': 1, 'activation_layer': 1, 'group_width': 4, 'bottleneck_multiplier': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (AugMix,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4])], {}),
     False),
    (AutoAugment,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4])], {}),
     False),
    (BaseEncoder,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 3, 64, 64])], {}),
     True),
    (BasicBlock,
     lambda: ([], {'inplanes': 4, 'planes': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     False),
    (BasicStem,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 3, 64, 64, 64])], {}),
     True),
    (BottleneckBlock,
     lambda: ([], {'in_channels': 4, 'out_channels': 4, 'norm_layer': _mock_layer}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (BottleneckTransform,
     lambda: ([], {'width_in': 4, 'width_out': 4, 'stride': 1, 'norm_layer': _mock_layer, 'activation_layer': _mock_layer, 'group_width': 4, 'bottleneck_multiplier': 4, 'se_ratio': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (CNBlock,
     lambda: ([], {'dim': 4, 'layer_scale': 1, 'stochastic_depth_prob': 1}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     False),
    (CenterCrop,
     lambda: ([], {'size': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (ColorJitter,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     False),
    (Conv2Plus1D,
     lambda: ([], {'in_planes': 4, 'out_planes': 4, 'midplanes': 4}),
     lambda: ([torch.rand([4, 4, 4, 4, 4])], {}),
     True),
    (Conv2dNormActivation,
     lambda: ([], {'in_channels': 4, 'out_channels': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (Conv3DNoTemporal,
     lambda: ([], {'in_planes': 4, 'out_planes': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (Conv3DSimple,
     lambda: ([], {'in_planes': 4, 'out_planes': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (Conv3dNormActivation,
     lambda: ([], {'in_channels': 4, 'out_channels': 4}),
     lambda: ([torch.rand([4, 4, 4, 4, 4])], {}),
     True),
    (ConvNormActivation,
     lambda: ([], {'in_channels': 4, 'out_channels': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (ConvertBCHWtoCBHW,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (ConvertImageDtype,
     lambda: ([], {'dtype': torch.float32}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (ConvexMaskPredictor,
     lambda: ([], {'in_channels': 4, 'hidden_size': 4, 'upsample_factor': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (DropBlockWrapper,
     lambda: ([], {'obj': _mock_layer()}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (ElasticTransform,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 64, 64])], {}),
     False),
    (Encoder,
     lambda: ([], {'seq_length': 4, 'num_layers': 1, 'num_heads': 4, 'hidden_dim': 4, 'mlp_dim': 4, 'dropout': 0.5, 'attention_dropout': 0.5}),
     lambda: ([torch.rand([4, 4, 4])], {}),
     True),
    (EncoderBlock,
     lambda: ([], {'num_heads': 4, 'hidden_dim': 4, 'mlp_dim': 4, 'dropout': 0.5, 'attention_dropout': 0.5}),
     lambda: ([torch.rand([4, 4, 4])], {}),
     True),
    (ExtraFPNBlock,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4])], {}),
     False),
    (FCNHead,
     lambda: ([], {'in_channels': 4, 'channels': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (FastRCNNConvFCHead,
     lambda: ([], {'input_size': [4, 4, 4], 'conv_layers': [4, 4], 'fc_layers': [4, 4]}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (FastRCNNPredictor,
     lambda: ([], {'in_channels': 4, 'num_classes': 4}),
     lambda: ([torch.rand([4, 4])], {}),
     True),
    (Fire,
     lambda: ([], {'inplanes': 4, 'squeeze_planes': 4, 'expand1x1_planes': 4, 'expand3x3_planes': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (FiveCrop,
     lambda: ([], {'size': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (FlowHead,
     lambda: ([], {'in_channels': 4, 'hidden_size': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (FrozenBatchNorm2d,
     lambda: ([], {'num_features': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (ImageClassification,
     lambda: ([], {'crop_size': 4}),
     lambda: ([torch.rand([4, 3, 4, 4])], {}),
     True),
    (InvertedResidual,
     lambda: ([], {'inp': 4, 'oup': 4, 'stride': 1}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (KeypointRCNNHeads,
     lambda: ([], {'in_channels': 4, 'layers': [4, 4]}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (KeypointRCNNPredictor,
     lambda: ([], {'in_channels': 4, 'num_keypoints': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (MBConv,
     lambda: ([], {'in_channels': 4, 'out_channels': 4, 'expansion_ratio': 4, 'squeeze_ratio': 4, 'stride': 1, 'activation_layer': _mock_layer, 'norm_layer': _mock_layer}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (MLP,
     lambda: ([], {'in_channels': 4, 'hidden_channels': [4, 4]}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (MLPBlock,
     lambda: ([], {'in_dim': 4, 'mlp_dim': 4, 'dropout': 0.5}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (MNASNet,
     lambda: ([], {'alpha': 4}),
     lambda: ([torch.rand([4, 3, 64, 64])], {}),
     True),
    (MakeValidDisparityMask,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4])], {}),
     False),
    (MakeValidFlowMask,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4])], {}),
     True),
    (MaskPredictor,
     lambda: ([], {'in_channels': 4, 'hidden_size': 4, 'out_channels': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (MaskRCNNHeads,
     lambda: ([], {'in_channels': 4, 'layers': [4, 4], 'dilation': 1}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (MaskRCNNPredictor,
     lambda: ([], {'in_channels': 4, 'dim_reduced': 4, 'num_classes': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (MotionEncoder,
     lambda: ([], {'in_channels_corr': 4}),
     lambda: ([torch.rand([4, 2, 64, 64]), torch.rand([4, 4, 64, 64])], {}),
     True),
    (Normalize,
     lambda: ([], {'mean': 4, 'std': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     False),
    (ObjectDetection,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (OpticalFlow,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 3, 4, 4]), torch.rand([4, 3, 4, 4])], {}),
     True),
    (PSNRLoss,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4])], {}),
     False),
    (Pad,
     lambda: ([], {'padding': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     False),
    (PositionalEncoding,
     lambda: ([], {'embed_size': 4, 'spatial_size': 4, 'temporal_size': 4, 'rel_pos_embed': 4}),
     lambda: ([torch.rand([4, 4, 4])], {}),
     True),
    (PositionalEncodingSine,
     lambda: ([], {'dim_model': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (R2Plus1dStem,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 3, 64, 64, 64])], {}),
     True),
    (RPNHead,
     lambda: ([], {'in_channels': 4, 'num_anchors': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     False),
    (RandAugment,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     False),
    (RandomAdjustSharpness,
     lambda: ([], {'sharpness_factor': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     False),
    (RandomAffine,
     lambda: ([], {'degrees': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     False),
    (RandomApply,
     lambda: ([], {'transforms': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     False),
    (RandomAutocontrast,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (RandomCrop,
     lambda: ([], {'size': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     False),
    (RandomEqualize,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (RandomErase,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4])], {}),
     False),
    (RandomErasing,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     False),
    (RandomGrayscale,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (RandomHorizontalFlip,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (RandomInvert,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (RandomOcclusion,
     lambda: ([], {}),
     lambda: ([(torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4])), torch.rand([4, 4]), torch.rand([4, 4])], {}),
     False),
    (RandomPerspective,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (RandomPosterize,
     lambda: ([], {'bits': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (RandomResizedCrop,
     lambda: ([], {'size': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     False),
    (RandomRotation,
     lambda: ([], {'degrees': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     False),
    (RandomSolarize,
     lambda: ([], {'threshold': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     False),
    (RandomSpatialShift,
     lambda: ([], {}),
     lambda: ([(torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4])), torch.rand([4, 4]), torch.rand([4, 4])], {}),
     False),
    (RandomVerticalFlip,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (ResBottleneckBlock,
     lambda: ([], {'width_in': 4, 'width_out': 4, 'stride': 1, 'norm_layer': _mock_layer, 'activation_layer': _mock_layer}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (ResidualBlock,
     lambda: ([], {'in_channels': 4, 'out_channels': 4, 'norm_layer': _mock_layer}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (Resize,
     lambda: ([], {'size': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     False),
    (SSDClassificationHead,
     lambda: ([], {'in_channels': [4, 4], 'num_anchors': [4, 4], 'num_classes': 4}),
     lambda: ([torch.rand([4, 4, 4, 4, 4])], {}),
     False),
    (SSDHead,
     lambda: ([], {'in_channels': [4, 4], 'num_anchors': [4, 4], 'num_classes': 4}),
     lambda: ([torch.rand([4, 4, 4, 4, 4])], {}),
     False),
    (SSDLiteClassificationHead,
     lambda: ([], {'in_channels': [4, 4], 'num_anchors': [4, 4], 'num_classes': 4, 'norm_layer': _mock_layer}),
     lambda: ([torch.rand([4, 4, 4, 4, 4])], {}),
     False),
    (SSDLiteHead,
     lambda: ([], {'in_channels': [4, 4], 'num_anchors': [4, 4], 'num_classes': 4, 'norm_layer': _mock_layer}),
     lambda: ([torch.rand([4, 4, 4, 4, 4])], {}),
     False),
    (SSDLiteRegressionHead,
     lambda: ([], {'in_channels': [4, 4], 'num_anchors': [4, 4], 'norm_layer': _mock_layer}),
     lambda: ([torch.rand([4, 4, 4, 4, 4])], {}),
     False),
    (SSDRegressionHead,
     lambda: ([], {'in_channels': [4, 4], 'num_anchors': [4, 4]}),
     lambda: ([torch.rand([4, 4, 4, 4, 4])], {}),
     False),
    (SemanticSegmentation,
     lambda: ([], {'resize_size': 4}),
     lambda: ([torch.rand([4, 3, 4, 4])], {}),
     True),
    (SepInceptionBlock3D,
     lambda: ([], {'in_planes': 4, 'b0_out': 4, 'b1_mid': 4, 'b1_out': 4, 'b2_mid': 4, 'b2_out': 4, 'b3_out': 4, 'norm_layer': _mock_layer}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (ShuffleNetV2,
     lambda: ([], {'stages_repeats': [4, 4, 4], 'stages_out_channels': [4, 4, 4, 4, 4]}),
     lambda: ([torch.rand([4, 3, 64, 64])], {}),
     True),
    (SimpleStemIN,
     lambda: ([], {'width_in': 4, 'width_out': 4, 'norm_layer': _mock_layer, 'activation_layer': _mock_layer}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (SoftmaxAttention,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4])], {}),
     False),
    (SqueezeExcitation,
     lambda: ([], {'input_channels': 4, 'squeeze_channels': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (SqueezeNet,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 3, 64, 64])], {}),
     True),
    (StereoMatching,
     lambda: ([], {'resize_size': [4, 4]}),
     lambda: ([torch.rand([4, 3, 4, 4]), torch.rand([4, 3, 4, 4])], {}),
     False),
    (StochasticDepthWrapper,
     lambda: ([], {'obj': _mock_layer()}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (SwapAxes,
     lambda: ([], {'a': 4, 'b': 4}),
     lambda: ([torch.rand([4, 4, 4, 4, 4])], {}),
     True),
    (TemporalSeparableConv,
     lambda: ([], {'in_planes': 4, 'out_planes': 4, 'kernel_size': 4, 'stride': 1, 'padding': 4, 'norm_layer': _mock_layer}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (TenCrop,
     lambda: ([], {'size': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (TestModule,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (TestSubModule,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (ToGPU,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4])], {}),
     False),
    (TripletMarginLoss,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4]), torch.rand([4, 4, 4, 4])], {}),
     False),
    (TrivialAugmentWide,
     lambda: ([], {}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
    (VideoClassification,
     lambda: ([], {'crop_size': [4, 4], 'resize_size': [4, 4]}),
     lambda: ([torch.rand([4, 3, 4, 4])], {}),
     True),
    (_Transition,
     lambda: ([], {'num_input_features': 4, 'num_output_features': 4}),
     lambda: ([torch.rand([4, 4, 4, 4])], {}),
     True),
]

class Test_vision(_paritybench_base):
    def test_000(self):
        self._check(*TESTCASES[0])

    def test_001(self):
        self._check(*TESTCASES[1])

    def test_002(self):
        self._check(*TESTCASES[2])

    def test_003(self):
        self._check(*TESTCASES[3])

    def test_004(self):
        self._check(*TESTCASES[4])

    def test_005(self):
        self._check(*TESTCASES[5])

    def test_006(self):
        self._check(*TESTCASES[6])

    def test_007(self):
        self._check(*TESTCASES[7])

    def test_008(self):
        self._check(*TESTCASES[8])

    def test_009(self):
        self._check(*TESTCASES[9])

    def test_010(self):
        self._check(*TESTCASES[10])

    def test_011(self):
        self._check(*TESTCASES[11])

    def test_012(self):
        self._check(*TESTCASES[12])

    def test_013(self):
        self._check(*TESTCASES[13])

    def test_014(self):
        self._check(*TESTCASES[14])

    def test_015(self):
        self._check(*TESTCASES[15])

    def test_016(self):
        self._check(*TESTCASES[16])

    def test_017(self):
        self._check(*TESTCASES[17])

    def test_018(self):
        self._check(*TESTCASES[18])

    def test_019(self):
        self._check(*TESTCASES[19])

    def test_020(self):
        self._check(*TESTCASES[20])

    def test_021(self):
        self._check(*TESTCASES[21])

    def test_022(self):
        self._check(*TESTCASES[22])

    def test_023(self):
        self._check(*TESTCASES[23])

    def test_024(self):
        self._check(*TESTCASES[24])

    def test_025(self):
        self._check(*TESTCASES[25])

    def test_026(self):
        self._check(*TESTCASES[26])

    def test_027(self):
        self._check(*TESTCASES[27])

    def test_028(self):
        self._check(*TESTCASES[28])

    def test_029(self):
        self._check(*TESTCASES[29])

    def test_030(self):
        self._check(*TESTCASES[30])

    def test_031(self):
        self._check(*TESTCASES[31])

    def test_032(self):
        self._check(*TESTCASES[32])

    def test_033(self):
        self._check(*TESTCASES[33])

    def test_034(self):
        self._check(*TESTCASES[34])

    def test_035(self):
        self._check(*TESTCASES[35])

    def test_036(self):
        self._check(*TESTCASES[36])

    def test_037(self):
        self._check(*TESTCASES[37])

    def test_038(self):
        self._check(*TESTCASES[38])

    def test_039(self):
        self._check(*TESTCASES[39])

    def test_040(self):
        self._check(*TESTCASES[40])

    def test_041(self):
        self._check(*TESTCASES[41])

    def test_042(self):
        self._check(*TESTCASES[42])

    def test_043(self):
        self._check(*TESTCASES[43])

    def test_044(self):
        self._check(*TESTCASES[44])

    def test_045(self):
        self._check(*TESTCASES[45])

    def test_046(self):
        self._check(*TESTCASES[46])

    def test_047(self):
        self._check(*TESTCASES[47])

    def test_048(self):
        self._check(*TESTCASES[48])

    def test_049(self):
        self._check(*TESTCASES[49])

    def test_050(self):
        self._check(*TESTCASES[50])

    def test_051(self):
        self._check(*TESTCASES[51])

    def test_052(self):
        self._check(*TESTCASES[52])

    def test_053(self):
        self._check(*TESTCASES[53])

    def test_054(self):
        self._check(*TESTCASES[54])

    def test_055(self):
        self._check(*TESTCASES[55])

    def test_056(self):
        self._check(*TESTCASES[56])

    def test_057(self):
        self._check(*TESTCASES[57])

    def test_058(self):
        self._check(*TESTCASES[58])

    def test_059(self):
        self._check(*TESTCASES[59])

    def test_060(self):
        self._check(*TESTCASES[60])

    def test_061(self):
        self._check(*TESTCASES[61])

    def test_062(self):
        self._check(*TESTCASES[62])

    def test_063(self):
        self._check(*TESTCASES[63])

    def test_064(self):
        self._check(*TESTCASES[64])

    def test_065(self):
        self._check(*TESTCASES[65])

    def test_066(self):
        self._check(*TESTCASES[66])

    def test_067(self):
        self._check(*TESTCASES[67])

    def test_068(self):
        self._check(*TESTCASES[68])

    def test_069(self):
        self._check(*TESTCASES[69])

    def test_070(self):
        self._check(*TESTCASES[70])

    def test_071(self):
        self._check(*TESTCASES[71])

    def test_072(self):
        self._check(*TESTCASES[72])

    def test_073(self):
        self._check(*TESTCASES[73])

    def test_074(self):
        self._check(*TESTCASES[74])

    def test_075(self):
        self._check(*TESTCASES[75])

    def test_076(self):
        self._check(*TESTCASES[76])

    def test_077(self):
        self._check(*TESTCASES[77])

    def test_078(self):
        self._check(*TESTCASES[78])

    def test_079(self):
        self._check(*TESTCASES[79])

    def test_080(self):
        self._check(*TESTCASES[80])

    def test_081(self):
        self._check(*TESTCASES[81])

    def test_082(self):
        self._check(*TESTCASES[82])

    def test_083(self):
        self._check(*TESTCASES[83])

    def test_084(self):
        self._check(*TESTCASES[84])

    def test_085(self):
        self._check(*TESTCASES[85])

    def test_086(self):
        self._check(*TESTCASES[86])

    def test_087(self):
        self._check(*TESTCASES[87])

    def test_088(self):
        self._check(*TESTCASES[88])

    def test_089(self):
        self._check(*TESTCASES[89])

    def test_090(self):
        self._check(*TESTCASES[90])

    def test_091(self):
        self._check(*TESTCASES[91])

    def test_092(self):
        self._check(*TESTCASES[92])

    def test_093(self):
        self._check(*TESTCASES[93])

    def test_094(self):
        self._check(*TESTCASES[94])

    def test_095(self):
        self._check(*TESTCASES[95])

    def test_096(self):
        self._check(*TESTCASES[96])

    def test_097(self):
        self._check(*TESTCASES[97])

    def test_098(self):
        self._check(*TESTCASES[98])

    def test_099(self):
        self._check(*TESTCASES[99])

    def test_100(self):
        self._check(*TESTCASES[100])

    def test_101(self):
        self._check(*TESTCASES[101])

    def test_102(self):
        self._check(*TESTCASES[102])

    def test_103(self):
        self._check(*TESTCASES[103])

    def test_104(self):
        self._check(*TESTCASES[104])

